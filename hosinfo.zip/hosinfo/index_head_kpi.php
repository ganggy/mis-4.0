<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

	$sm_depart_usertt = " kpi_year = $s_year AND k.kpi_dpid ='".$mis_u_m_depart."' ";
	$sm_depart_user = " AND kpi_year = $s_year AND k.kpi_dpid ='".$mis_u_m_depart."' ";
	$sm_depart = " ";

if ($mis_user_level >= 3) {
	$s_kpi_view = "  AND k.kpi_view IN (1,2,3,4) ";
	$s_kpi_view_c = " k.kpi_view IN (1,2,3,4) ";
} else if ($mis_user_level >= 1) {
	$s_kpi_view = " AND k.kpi_view IN (2,3,4) ";
	$s_kpi_view_c = " k.kpi_view IN (2,3,4) ";
} else {
	if ($login_ok == 1) {
		$s_kpi_view = " AND k.kpi_view IN (3,4) ";
		$s_kpi_view_c = " k.kpi_view IN (3,4) ";
	} else {
		$s_kpi_view = " AND k.kpi_view = 4 ";
		$s_kpi_view_c = " k.kpi_view = 4 ";
	}
}

	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");

		$sql = "SELECT yearprocess FROM sys_config ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			//$s_year = $data['yearprocess'];
			$s_yearb1 = $data['yearprocess']-1;
			$s_yearb2 = $data['yearprocess']-2;
			$s_yearb3 = $data['yearprocess']-3;
		}

		$sql4 = "SELECT d.dp_name AS kpidepartname,COUNT(*) AS kpidepart FROM kpi k LEFT JOIN depart d ON d.id = k.kpi_dpid WHERE k.kpi_year = '$s_year' ";
		$query4 = $myPDO->query($sql4);
		foreach($query4 as $data4) {
			$kpi_year_count = $data4['kpidepart'];
		}

		$sql3 = "SELECT d.dp_name AS kpidepartname,COUNT(*) AS kpidepart FROM kpi k LEFT JOIN depart d ON d.id = k.kpi_dpid WHERE k.kpi_dpid = $mis_u_m_depart AND kpi_year = $s_year";
		$query3 = $myPDO->query($sql3);
		foreach($query3 as $data3) {
			$kpi_depart_count = $data3['kpidepart'];
			$kpi_depart_name = $data3['kpidepartname'];
		}

		$sql6 = "SELECT COUNT(*) AS c_kpi_tt
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_tt

FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE kpi_year = $s_year
";

		$query6 = $myPDO->query($sql6);
		foreach($query6 as $data6) {
			$c_kpi_tt2 = $data6['c_kpi_tt'];
			$wpercent_tt2 = $data6['wpercent_tt'];
		}

			if ($wpercent_tt2 < 50) {
				$data_color_tt2 = "#ff0000";
			} else if ($wpercent_tt2 >= 90) {
				$data_color_tt2 = "#009900";
			} else if ($wpercent_tt2 >= 80) {
				$data_color_tt2 = "#0099ff";
			} else if ($wpercent_tt2 >= 70) {
				$data_color_tt2 = "#ffff00";
			} else if ($wpercent_tt2 >= 60) {
				$data_color_tt2 = "#ff6600";
			} else if ($wpercent_tt2 >= 50) {
				$data_color_tt2 = "#ff0000";
			} else {
				$data_color_tt2 = "#ffffff";
			}

		$sql2 = "SELECT SUM(t.c_kpi_f) AS sum_f,SUM(t.c_kpi_c) AS sum_c,SUM(t.c_kpi_p) AS sum_p,SUM(t.c_kpi_o) AS sum_o 
,SUM(t.wpercent_f) AS sum_pf,SUM(t.wpercent_c) AS sum_pc,SUM(t.wpercent_p) AS sum_pp,SUM(t.wpercent_o) AS sum_po
FROM (

SELECT 'BSC' AS bscname,COUNT(*) AS c_kpi_f,0 AS c_kpi_c,0 AS c_kpi_p,0 AS c_kpi_o
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_f
,0 AS wpercent_c,0 AS wpercent_p,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'F' AND kpi_year = $s_year

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,COUNT(*) AS c_kpi_c,0 AS c_kpi_p,0 AS c_kpi_o
,0 AS wpercent_f
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_c
,0 AS wpercent_p,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'C' AND kpi_year = $s_year

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,0 AS c_kpi_c,COUNT(*) AS c_kpi_p,0 AS c_kpi_o
,0 AS wpercent_f,0 AS wpercent_c
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_p
,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'P' AND kpi_year = $s_year

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,0 AS c_kpi_c,0 AS c_kpi_p,COUNT(*) AS c_kpi_o
,0 AS wpercent_f,0 AS wpercent_c,0 AS wpercent_p
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'O' AND kpi_year = $s_year
) t";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$sum_f = $data2['sum_f'];
			$sum_c = $data2['sum_c'];
			$sum_p = $data2['sum_p'];
			$sum_o = $data2['sum_o'];
			$sum_pf = $data2['sum_pf'];
			$sum_pc = $data2['sum_pc'];
			$sum_pp = $data2['sum_pp'];
			$sum_po = $data2['sum_po'];
		}

			if ($sum_pf < 50) {
				$data_color_f = "#ff0000";
			} else if ($sum_pf >= 90) {
				$data_color_f = "#009900";
			} else if ($sum_pf >= 80) {
				$data_color_f = "#0099ff";
			} else if ($sum_pf >= 70) {
				$data_color_f = "#ffff00";
			} else if ($sum_pf >= 60) {
				$data_color_f = "#ff6600";
			} else if ($sum_pf >= 50) {
				$data_color_f = "#ff0000";
			} else {
				$data_color_f = "#ffffff";
			}

			if ($sum_pc < 50) {
				$data_color_c = "#ff0000";
			} else if ($sum_pc >= 90) {
				$data_color_c = "#009900";
			} else if ($sum_pc >= 80) {
				$data_color_c = "#0099ff";
			} else if ($sum_pc >= 70) {
				$data_color_c = "#ffff00";
			} else if ($sum_pc >= 60) {
				$data_color_c = "#ff6600";
			} else if ($sum_pc >= 50) {
				$data_color_c = "#ff0000";
			} else {
				$data_color_c = "#ffffff";
			}

			if ($sum_pp < 50) {
				$data_color_p = "#ff0000";
			} else if ($sum_pp >= 90) {
				$data_color_p = "#009900";
			} else if ($sum_pp >= 80) {
				$data_color_p = "#0099ff";
			} else if ($sum_pp >= 70) {
				$data_color_p = "#ffff00";
			} else if ($sum_pp >= 60) {
				$data_color_p = "#ff6600";
			} else if ($sum_pp >= 50) {
				$data_color_p = "#ff0000";
			} else {
				$data_color_p = "#ffffff";
			}

			if ($sum_po < 50) {
				$data_color_o = "#ff0000";
			} else if ($sum_po >= 90) {
				$data_color_o = "#009900";
			} else if ($sum_po >= 80) {
				$data_color_o = "#0099ff";
			} else if ($sum_po >= 70) {
				$data_color_o = "#ffff00";
			} else if ($sum_po >= 60) {
				$data_color_o = "#ff6600";
			} else if ($sum_po >= 50) {
				$data_color_o = "#ff0000";
			} else {
				$data_color_o = "#ffffff";
			}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo $kpi_year_count;?></h3>
              <p>ตัวชี้วัดทั้งหมดของ รพ.</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            <a href="#" class="small-box-footer">รายละเอียด <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo "?";?></h3>
              <p>ตัวชี้วัดที่ผ่านแล้ว</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            <a href="#" class="small-box-footer">รายละเอียด <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo "?";?></h3>
              <p>ตัวชี้วัดที่กำลังดำเนินการ</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            <a href="?kpi=103" class="small-box-footer">รายละเอียด  <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo "?";?></h3>
              <p>ตัวชี้วัดที่ยังไม่ผ่าน</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            <a href="#" class="small-box-footer">รายละเอียด  <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
			<i class="fa  fa-bar-chart"></i>
              <h3 class="box-title">ผลการดำเนินงานตามตัวชี้วัดองค์กร</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">

            <div class="box-body table-responsive no-padding">
			<table id="DataTableT1" class="table table-hover">
				<thead>
                <tr>
                  <th class="text-center">BSC</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">วันที่ปรับปรุง</th>
                </tr>
                </thead>
				<tbody>

<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code <> '' $s_kpi_view $sm_depart
					ORDER BY k.bsc_code ASC";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['data_last_update']);

			if ($data['kpi_duration_type'] == "1") {
				if ($data['ndaday'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndaday']."</span>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<span class='badge bg-green'>".$data['ndaday']."</span>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<span class='badge bg-aqua'>".$data['ndaday']."</span>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<span class='badge bg-yellow'>".$data['ndaday']."</span>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<span class='badge bg-orange'>".$data['ndaday']."</span>";
				} else if ($data['ndaday'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndaday']."</span>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "2") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<span class='badge bg-green'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<span class='badge bg-aqua'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<span class='badge bg-yellow'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<span class='badge bg-orange'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadat']."</span>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "3") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<span class='badge bg-green'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<span class='badge bg-aqua'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<span class='badge bg-yellow'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<span class='badge bg-orange'>".$data['ndadat']."</span>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadat']."</span>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "4") {
				if ($data['ndadam'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadam']."</span>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<span class='badge bg-green'>".$data['ndadam']."</span>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<span class='badge bg-aqua'>".$data['ndadam']."</span>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<span class='badge bg-yellow'>".$data['ndadam']."</span>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<span class='badge bg-orange'>".$data['ndadam']."</span>";
				} else if ($data['ndadam'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<span class='badge bg-red'>".$data['ndadam']."</span>";
				} else {
					$k_kpi_result_c = "";
				}
			}

			echo "<tr>";
			echo "<td class='text-center'>".$data['bsc_code']."</td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </tbody>
			  </table>
            </div>
            <!-- /.box-body -->

<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");

		$sql5 = "SELECT COUNT(*) AS c_kpi_tt
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_tt

FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE $sm_depart_usertt ";

		$query5 = $myPDO->query($sql5);
		foreach($query5 as $data5) {
			$c_kpi_tt = $data5['c_kpi_tt'];
			$wpercent_tt = $data5['wpercent_tt'];
		}

			if ($wpercent_tt < 50) {
				$data_color_tt = "#ff0000";
			} else if ($wpercent_tt >= 90) {
				$data_color_tt = "#009900";
			} else if ($wpercent_tt >= 80) {
				$data_color_tt = "#0099ff";
			} else if ($wpercent_tt >= 70) {
				$data_color_tt = "#ffff00";
			} else if ($wpercent_tt >= 60) {
				$data_color_tt = "#ff6600";
			} else if ($wpercent_tt >= 50) {
				$data_color_tt = "#ff0000";
			} else {
				$data_color_tt = "#ffffff";
			}

		$sql4 = "SELECT SUM(t.c_kpi_f) AS sum_f,SUM(t.c_kpi_c) AS sum_c,SUM(t.c_kpi_p) AS sum_p,SUM(t.c_kpi_o) AS sum_o 
,SUM(t.wpercent_f) AS sum_pf,SUM(t.wpercent_c) AS sum_pc,SUM(t.wpercent_p) AS sum_pp,SUM(t.wpercent_o) AS sum_po
FROM (

SELECT 'BSC' AS bscname,COUNT(*) AS c_kpi_f,0 AS c_kpi_c,0 AS c_kpi_p,0 AS c_kpi_o
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_f
,0 AS wpercent_c,0 AS wpercent_p,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'F' $sm_depart_user

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,COUNT(*) AS c_kpi_c,0 AS c_kpi_p,0 AS c_kpi_o
,0 AS wpercent_f
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_c
,0 AS wpercent_p,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'C' $sm_depart_user

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,0 AS c_kpi_c,COUNT(*) AS c_kpi_p,0 AS c_kpi_o
,0 AS wpercent_f,0 AS wpercent_c
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_p
,0 AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'P' $sm_depart_user

UNION

SELECT 'BSC' AS bscname,0 AS c_kpi_f,0 AS c_kpi_c,0 AS c_kpi_p,COUNT(*) AS c_kpi_o
,0 AS wpercent_f,0 AS wpercent_c,0 AS wpercent_p
,SUM(IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0))))))*k.kpi_weight)*100/SUM(5*k.kpi_weight) AS wpercent_o
FROM kpi k 
LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
WHERE k.bsc_code = 'O' $sm_depart_user
) t";
		$query4 = $myPDO->query($sql4);
		foreach($query4 as $data4) {
			$dsum_f = $data4['sum_f'];
			$dsum_c = $data4['sum_c'];
			$dsum_p = $data4['sum_p'];
			$dsum_o = $data4['sum_o'];
			$dsum_pf = $data4['sum_pf'];
			$dsum_pc = $data4['sum_pc'];
			$dsum_pp = $data4['sum_pp'];
			$dsum_po = $data4['sum_po'];
		}

			if ($dsum_pf < 50) {
				$ddata_color_f = "progress-bar progress-bar-red progress-bar-striped active";
			} else if ($dsum_pf >= 90) {
				$ddata_color_f = "progress-bar progress-bar-green progress-bar-striped active";
			} else if ($dsum_pf >= 80) {
				$ddata_color_f = "progress-bar progress-bar-aqua progress-bar-striped active";
			} else if ($dsum_pf >= 70) {
				$ddata_color_f = "progress-bar progress-bar-yellow progress-bar-striped active";
			} else if ($dsum_pf >= 60) {
				$ddata_color_f = "progress-bar bg-orange bg-darken-2 progress-bar-striped active";
			} else if ($dsum_pf >= 50) {
				$ddata_color_f = "progress-bar progress-bar-red progress-bar-striped active";
			} else {
				$ddata_color_f = "progress-bar progress-bar-default progress-bar-striped active";
			}

			if ($dsum_pc < 50) {
				$ddata_color_c = "progress-bar progress-bar-red progress-bar-striped active";
			} else if ($dsum_pc >= 90) {
				$ddata_color_c = "progress-bar progress-bar-green progress-bar-striped active";
			} else if ($dsum_pc >= 80) {
				$ddata_color_c = "progress-bar progress-bar-aqua progress-bar-striped active";
			} else if ($dsum_pc >= 70) {
				$ddata_color_c = "progress-bar progress-bar-yellow progress-bar-striped active";
			} else if ($dsum_pc >= 60) {
				$ddata_color_c = "progress-bar bg-orange bg-darken-2 progress-bar-striped active";
			} else if ($dsum_pc >= 50) {
				$ddata_color_c = "progress-bar progress-bar-red progress-bar-striped active";
			} else {
				$ddata_color_c = "progress-bar progress-bar-default progress-bar-striped active";
			}

			if ($dsum_pp < 50) {
				$ddata_color_p = "progress-bar progress-bar-red progress-bar-striped active";
			} else if ($dsum_pp >= 90) {
				$ddata_color_p = "progress-bar progress-bar-green progress-bar-striped active";
			} else if ($dsum_pp >= 80) {
				$ddata_color_p = "progress-bar progress-bar-aqua progress-bar-striped active";
			} else if ($dsum_pp >= 70) {
				$ddata_color_p = "progress-bar progress-bar-yellow progress-bar-striped active";
			} else if ($dsum_pp >= 60) {
				$ddata_color_p = "progress-bar bg-orange bg-darken-2 progress-bar-striped active";
			} else if ($dsum_pp >= 50) {
				$ddata_color_p = "progress-bar progress-bar-red progress-bar-striped active";
			} else {
				$ddata_color_p = "progress-bar progress-bar-default progress-bar-striped active";
			}

			if ($dsum_po < 50) {
				$ddata_color_o = "progress-bar progress-bar-red progress-bar-striped active";
			} else if ($dsum_po >= 90) {
				$ddata_color_o = "progress-bar progress-bar-green progress-bar-striped active";
			} else if ($dsum_po >= 80) {
				$ddata_color_o = "progress-bar progress-bar-aqua progress-bar-striped active";
			} else if ($dsum_po >= 70) {
				$ddata_color_o = "progress-bar progress-bar-yellow progress-bar-striped active";
			} else if ($dsum_po >= 60) {
				$ddata_color_o = "progress-bar bg-orange bg-darken-2 progress-bar-striped active";
			} else if ($dsum_po >= 50) {
				$ddata_color_o = "progress-bar progress-bar-red progress-bar-striped active";
			} else {
				$ddata_color_o = "progress-bar progress-bar-default progress-bar-striped active";
			}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

				</div>
                <!-- /.col -->

                <div class="col-md-4">
                  <div class="text-center">
                    <strong><h4>BSC องค์กร</h4></strong>
                  </div>

                <div class="text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($wpercent_tt2,2,'.','');?>" data-width="250" data-height="190" data-fgColor="<?php echo $data_color_tt2;?>" data-bgColor="#c0c0c0">
                </div>
<hr>
              <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-6 text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($sum_pf,2,'.','');?>" data-width="160" data-height="120" data-fgColor="<?php echo $data_color_f;?>" data-bgColor="#c0c0c0">
                  <div class="knob-label">F ด้านการเงิน <?php echo $sum_f;?> ตัววัด</div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-6 text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($sum_pc,2,'.','');?>" data-width="160" data-height="120" data-fgColor="<?php echo $data_color_c;?>" data-bgColor="#c0c0c0">
                  <div class="knob-label">C ด้านลูกค้า <?php echo $sum_c;?> ตัววัด</div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-6 text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($sum_pp,2,'.','');?>" data-width="160" data-height="120" data-fgColor="<?php echo $data_color_p;?>" data-bgColor="#c0c0c0">
                  <div class="knob-label">P ด้านกระบวนการภายใน <?php echo $sum_p;?> ตัววัด</div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-6 text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($sum_po,2,'.','');?>" data-width="160" data-height="120" data-fgColor="<?php echo $data_color_o;?>" data-bgColor="#c0c0c0">
                  <div class="knob-label">O ด้านการเรียนรู้และการเติบโต <?php echo $sum_o;?> ตัววัด</div>
                </div>
              </div>


				</div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-yellow"><i class="fa fa-caret-left"></i> 0%</span>
                    <h5 class="description-header">$10,390.90</h5>
                    <span class="description-text">TOTAL COST</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-yellow"><i class="fa fa-caret-left"></i> 0%</span>
                    <h5 class="description-header">$10,390.90</h5>
                    <span class="description-text">TOTAL COST</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                    <span class="description-percentage text-green"><i class="fa fa-caret-up"></i> 20%</span>
                    <h5 class="description-header">$24,813.53</h5>
                    <span class="description-text">TOTAL PROFIT</span>
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                    <span class="description-percentage text-red"><i class="fa fa-caret-down"></i> 18%</span>
                    <h5 class="description-header">1200</h5>
                    <span class="description-text">GOAL COMPLETIONS</span>
                  </div>
                  <!-- /.description-block -->
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

      <div class="row">
        <div class="col-md-12">
          <div class="box box-success">
            <div class="box-header with-border">
			<i class="fa  fa-bar-chart"></i>
              <h3 class="box-title">BSC <?php echo $kpi_depart_name;?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">
                <div class="col-md-6">
                <div class="text-center">
                  <input type="text" class="knob" data-readonly="true" data-thickness="0.4" data-angleArc="210" data-angleOffset="-105" value="<?php echo number_format($wpercent_tt,2,'.','');?>" data-width="250" data-height="190" data-fgColor="<?php echo $data_color_tt;?>" data-bgColor="#c0c0c0">
                </div>
                </div>

				<div class="col-md-6">

                  <!-- /.progress-group -->
                  <div class="progress-group">
                    <span class="progress-text">F ด้านการเงิน <?php echo number_format($dsum_f,0,'.','');?> ตัววัด</span>
                    <span class="progress-number"><b><?php echo number_format($dsum_pf,2,'.','')."%";?></b></span>
                    <div class="progress sm">
                      <div class="<?php echo $ddata_color_f;?>" style="width: <?php echo number_format($dsum_pf,2,'.','');?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                  <div class="progress-group">
                    <span class="progress-text">C ด้านลูกค้า <?php echo number_format($dsum_c,0,'.','');?> ตัววัด</span>
                    <span class="progress-number"><b><?php echo number_format($dsum_pc,2,'.','')."%";?></b></span>
                    <div class="progress sm">
                      <div class="<?php echo $ddata_color_c;?>" style="width: <?php echo number_format($dsum_pc,2,'.','');?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                  <div class="progress-group">
                    <span class="progress-text">P ด้านกระบวนการภายใน <?php echo number_format($dsum_p,0,'.','');?> ตัววัด</span>
                    <span class="progress-number"><b><?php echo number_format($dsum_pp,2,'.','')."%";?></b></span>
                    <div class="progress sm">
                      <div class="<?php echo $ddata_color_p;?>" style="width: <?php echo number_format($dsum_pp,2,'.','');?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                  <div class="progress-group">
                    <span class="progress-text">O ด้านการเรียนรู้และการเติบโต <?php echo number_format($dsum_o,0,'.','');?> ตัววัด</span>
                    <span class="progress-number"><b><?php echo number_format($dsum_po,2,'.','')."%";?></b></span>
                    <div class="progress sm">
                      <div class="<?php echo $ddata_color_o;?>" style="width: <?php echo number_format($dsum_po,2,'.','');?>%"></div>
                    </div>
                  </div>
                  <!-- /.progress-group -->
                </div>
				</div>
                <div class="col-md-4">
                    <span class="description-percentage text-red"><i class="fa fa-caret-down"></i> 18%</span>
                    <h5 class="description-header">1200</h5>
                    <span class="description-text">GOAL COMPLETIONS</span>
				</div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->