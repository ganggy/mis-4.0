          <!-- Chat box -->
		  <section id="chat">
          <div class="box box-success">
                <div class="box-header with-border">
				<i class="fa fa-comments-o"></i>
                  <h3 class="box-title">แจ้งปัญหา/สอบถามการใช้งาน</h3>

                  <div class="box-tools pull-right">
                    <span data-toggle="tooltip" title="<?php echo $cchat; ?> ข้อความ" class="badge bg-red"><?php echo $cchat; ?></span>
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                  </div>
                </div>

				<div class="box-body">
					<div class="box-body chat" id="chat-box">

<?php

	try {
		require_once("_cfg_mis40db.php");
		// คำสั่ง SQL
		$sql = "SELECT c.*,u.* FROM chat c LEFT JOIN mis_user u ON u.m_login = c.chatuser ORDER BY id DESC ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['user_picture'] == "") {
				$user_picture = "dist/img/guestuser.png";
			} else {
				$user_picture = "images/users/".$data['user_picture']."";
			}
?>

              <!-- chat item -->
              <div class="item">
                <img src="<?php echo $wwwurl;?>/<?php echo $user_picture;?>" alt="user image" class="online">

                <p class="message">
                  <a class="name">
                    <small class="text-muted pull-right">
					<i class="fa fa-clock-o"></i> <?php echo DateTimeThai($data['chatdate']);?>
					</small>
					<?php echo $data['chatuser'];?>
                  </a>
                    <?php echo $data['questiontext'];?>
                </p>
<?php if ($data['answertext'] == "") {
	if ($mis_user_level >= 4) {
?>

                  <form action="main_chat_up.php" method="POST">
                    <div class="input-group">
                      <input type="text" name="answertext" placeholder="ตอบคำถาม" class="form-control">
					  <input type="hidden" name="c_id" value="<?php echo $data['id']; ?>">
                      <span class="input-group-btn">
                            <button type="submit" class="btn btn-info" name="submit_chat" value="answer"><i class="fa fa-plus"></i> ตอบคำถาม</button>
                          </span>
                    </div>
                  </form>

<?php
	} else {}
} else {?>
				<div class="attachment">
                  <h4>ตอบ:</h4><small class="text-muted pull-right"><i class="fa fa-clock-o"></i> <?php echo DateTimeThai($data['ansdate']);?></small>
                  <p class="filename">
                    <?php echo $data['answertext'];?>
                  </p>
                </div>
<?php } ?>
              </div>
              <!-- /.item -->

<?php
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
					</div>
				</div>
                <div class="box-footer">
                  <form action="main_chat_up.php" method="POST">
                    <div class="input-group">
                      <input type="text" name="questiontext" placeholder="ข้อความคำถาม" class="form-control">
					  <input type="hidden" name="login_user" value="<?php echo $ok_login_user; ?>">
                      <span class="input-group-btn">
                            <button type="submit" class="btn btn-success" name="submit_chat" value="question"><i class="fa fa-plus"></i> ตั้งคำถาม</button>
                          </span>
                    </div>
                  </form>
                </div>
          <!-- /.box (chat box) -->
			</div>
            <!-- /.chat -->
</section>