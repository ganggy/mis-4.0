<?php

if ($_GET['main'] == NULL) {

	// เมนู KPI

	switch ($_GET['kpi']) {
		case "101":
			$act10 = 'active';
			$act101 = ' class=active ';
			$incmaindata = 'data_kpi100.php';
			break;
		case "102":
			$act10 = 'active';
			$act102 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "103":
			$act10 = 'active';
			$act103 = 'class=active';
			$incmaindata = 'kpi/show_kpi_list.php';
			break;
		case "104":
			$act10 = 'active';
			$act104 = 'class=active';
			$incmaindata = 'kpi/data_kpi_depart.php';
			break;
		case "201":
			$act20 = 'active';
			$act201 = 'class=active';
			$incmaindata = 'kpi/data_kpi_create.php';
			break;
		case "202":
			$act20 = 'active';
			$act202 = ' class=active ';
			$incmaindata = 'rep_ucvisit30.php';
			break;
		case "301":
			$act30 = 'active';
			$act301 = ' class=active ';
			$incmaindata = 'temp.php';
			break;
		case "302":
			$act30 = 'active';
			$act302 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "303":
			$act30 = 'active';
			$act303 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "304":
			$act30 = 'active';
			$act304 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "401":
			$act40 = 'active';
			$act401 = ' class=active ';
			$incmaindata = 'kpi/ppho_mis_61.php';
			break;
		case "402":
			$act40 = 'active';
			$act402 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "991":
			$act99 = 'active';
			$act991 = 'class=active';
			$incmaindata = 'index_main111.php';
			break;
		case "992":
			$act99 = 'active';
			$act992 = 'class=active';
			$incmaindata = 'index_main_test.php';
			break;
		case "993":
			$act99 = 'active';
			$act993 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "994":
			$act99 = 'active';
			$act994 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "995":
			$act99 = 'active';
			$act995 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "996":
			$act99 = 'active';
			$act996 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "997":
			$act99 = 'active';
			$act997 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "998":
			$act99 = 'active';
			$act998 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "999":
			$act99 = 'active';
			$act999 = 'class=active';
			$incmaindata = 'temp.php';
			break;
		case "888":
			$act99 = 'active';
			$act888 = 'class=active';
			$incmaindata = 'index_admin.php';
			break;
		default:
			$act_index = 'class=active';
			if ($mis_user_level >= 3) {
				$incmaindata = 'index_head.php';
			} else if ($mis_user_level >= 1) {
				$incmaindata = 'index_user.php';
			} else {
				$incmaindata = 'index_main.php';
			}
	}

	// เมนูผู้ป่วยใน
	
	switch ($_GET['stat']) {
		case "opd":
			$act50 = 'active';
			$act501 = 'class=active';
			$incmaindata = 'stat/stat_opd.php';
			break;
		case "ipd":
			$act50 = 'active';
			$act60 = 'active';
			$act502 = 'class=active';
			$incmaindata = 'stat/stat_ipd.php';
			break;
		case "dent":
			$act50 = 'active';
			$act503 = 'class=active';
			$incmaindata = 'stat/stat_dent.php';
			break;
		case "ppt":
			$act50 = 'active';
			$act504 = 'class=active';
			$incmaindata = 'stat/stat_ppt.php';
			break;
		case "er":
			$act50 = 'active';
			$act505 = 'class=active';
			$incmaindata = 'stat/stat_er.php';
			break;
		case "or":
			$act50 = 'active';
			$act506 = 'class=active';
			$incmaindata = 'stat/stat_or.php';
			break;
		case "cd":
			$act50 = 'active';
			$act508 = 'class=active';
			$incmaindata = 'stat/stat_cd.php';
			break;
		case "ncd":
			$act50 = 'active';
			$act509 = 'class=active';
			$incmaindata = 'stat/stat_ncd.php';
			break;
		case "pts":
			$act50 = 'active';
			$act510 = 'class=active';
			$incmaindata = 'stat/stat_pts.php';
			break;
		case "xray":
			$act50 = 'active';
			$act511 = 'class=active';
			$incmaindata = 'stat/stat_xray.php';
			break;
	}
	
	// เมนูผู้ป่วยใน
	$ward_info_id = $_GET['ward'];

	try {
		include '_cfg_hos.php';
		$sql = "SELECT w.ward,w.name AS wardname,s.nhso_code FROM ward w LEFT OUTER JOIN  spclty s ON s.spclty = w.spclty WHERE ward_active = 'Y' AND ward = '$ward_info_id' ";
		$result = $myPDO->query($sql);
		foreach ($result AS $data) {
			$ward_nhso_code = $data['nhso_code'];
		}
	}
	catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();
	}

	if ($_GET['ward'] || NULL) {
		if ($ward_nhso_code == "03") {
			$act50 = 'active';
			$act60 = 'active';
			$incmaindata = 'stat/stat_obs.php';
		} else {
			$act50 = 'active';
			$act60 = 'active';
			$incmaindata = 'stat/stat_ward.php';
		}
	}
	
	// ระบบ data export
	switch ($_GET['exp']) {
		case "person":
			$act80 = 'active';
			$act801 = 'class=active';
			$export_name = "รายชื่อประชากร";
			$incmaindata = 'ex_person.php';
			break;
		case "persons":
			$act80 = 'active';
			$act804 = 'class=active';
			$export_name = "รายชื่อประชากร";
			$incmaindata = 'ex_person_ssp.php';
			break;
		case "patient":
			$act80 = 'active';
			$act802 = 'class=active';
			$export_name = "รายชื่อผู้รับบริการ/ผู้ป่วย";
			$incmaindata = 'ex_patient_ssp.php';
			break;
		case "service":
			$act80 = 'active';
			$act803 = 'class=active';
			$export_name = "ค้นหาบริการ";
			$incmaindata = 'ex_service_ssp.php';
			break;
		case "cxr":
			$act80 = 'active';
			$act805 = 'class=active';
			$export_name = "ผู้รับบริการได้รับการตรวจ CXR";
			$incmaindata = 'ex_service_cxr.php';
			break;
		case "tb":
			$act80 = 'active';
			$act807 = 'class=active';
			$export_name = "เป้าหมายตรวจ TB";
			$incmaindata = 'ex_service_tbtarget.php';
			break;
		case "drugsearch":
			$act80 = 'active';
			$act808 = 'class=active';
			$export_name = "ผู้รับบริการที่รับยา";
			$incmaindata = 'ex_service_losartan.php';
			break;
		case "rabies":
			$act80 = 'active';
			$act806 = 'class=active';
			$export_name = "รายงานการใช้วัคซีน RABIES";
			$incmaindata = 'ex_service_rabies.php';
			break;
		case "moneyopd":
			$act80 = 'active';
			$act809 = 'class=active';
			$export_name = "สรุปค่าใช้จ่ายผู้ป่วยนอก";
			$incmaindata = 'reports/money_opd.php';
			break;
		case "moneyipd":
			$act80 = 'active';
			$act810 = 'class=active';
			$export_name = "สรุปค่าใช้จ่ายผู้ป่วยใน";
			$incmaindata = 'reports/money_ipd.php';
			break;
		case "dentalcare":
			$act80 = 'active';
			$act811 = 'class=active';
			$export_name = "ผู้รับบริการในเขต ได้รับการตรวจสุขภาพฟัน";
			$incmaindata = 'reports/dental_care.php';
			break;
		case "visitpttype":
			$act80 = 'active';
			$act812 = 'class=active';
			$export_name = "จำนวนผู้รับบริการผู้ป่วยนอก";
			$incmaindata = 'reports/visit_pttype.php';
			break;
	}

} else {

	// ระบบหลัก
	switch ($_GET['main']) {
		case "profile":
			$incmaindata = 'main_profile.php';
			break;
		case "profileup":
			$incmaindata = 'main_profileup.php';
			break;
		case "kpimanage":
			$act_kpimanage = 'class=active';
			$incmaindata = 'kpi/data_kpi_manage.php';
			break;
		case "reports":
			$act_reports = 'class=active';
			$incmaindata = 'reports/report_list.php';
			break;
		case "reportsdetail":
			$act_reports = 'class=active';
			$incmaindata = 'reports/report_detail.php';
			break;
		case "login":
			$incmaindata = 'main_login.php';
			break;
		case "logout":
			$incmaindata = 'main_logout.php';
			break;
		case "setting":
			$act_setting = 'class=active';
			$incmaindata = 'main_setting.php';
			break;
		case "user":
			$act_user = 'class=active';
			$incmaindata = 'main_user.php';
			break;
		case "labsearch":
			$act_labsearch = 'class=active';
			$export_name = "ค้นหาข้อมูลการตรวจ LAB";
			$incmaindata = 'ex_labsearch.php';
			break;
		case "vacsearch":
			$act_vacsearch = 'class=active';
			$export_name = "ค้นหาข้อมูลวัคซีน";
			$incmaindata = 'ex_vaccine_search.php';
			break;
		case "form":
			$act20 = 'active';
			$act_form = ' class=active ';
			$export_name = "แบบลงทะเบียน";
			$incmaindata = 'form/form.php';
			break;
		case "update":
			$act30 = 'active';
			$act_last_update = 'class=active';
			$export_name = "การพัฒนาปรับปรุง MIS 4.0";
			$incmaindata = 'last_update.php';
			break;
	}

}
?>
