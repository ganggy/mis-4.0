<?php
if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php

if ($_POST['submit_user_edit'] == "modalsaveuser") {

if ($_POST['1user_status'] == '1') {$md_user_status = '1';} else {$md_user_status = '0';}
if ($_POST['1user_head'] == '1') {$md_user_head = '1';} else {$md_user_head = '0';}
if ($_POST['1user_approve'] == '1') {$md_user_approve = '1';} else {$md_user_approve = '0';}

try {
	include "_cfg_mis40db.php";
	$sql = "UPDATE mis_user SET
				dpid = :dpid,
				user_status = :user_status,
				user_head = :user_head,
				user_approve = :user_approve,
				m_namefull = :up_fullname,
				m_email = :up_email,
				m_phoneno = :up_phoneno,
				last_update = :up_last_update 
				WHERE login_secure = :chk_login_secure ";
	
	$stmt = $myPDO->prepare($sql);
	$stmt->bindParam(':dpid',$_POST['dpid'],PDO::PARAM_STR);
	$stmt->bindParam(':user_status',$md_user_status,PDO::PARAM_STR);
	$stmt->bindParam(':user_head',$md_user_head,PDO::PARAM_STR);
	$stmt->bindParam(':user_approve',$md_user_approve,PDO::PARAM_STR);
	$stmt->bindParam(':up_fullname',$_POST['m_namefull'],PDO::PARAM_STR);
	$stmt->bindParam(':up_email',$_POST['m_email'],PDO::PARAM_STR);
	$stmt->bindParam(':up_phoneno',$_POST['m_phoneno'],PDO::PARAM_STR);
	$stmt->bindParam(':up_last_update',date("Y-m-d H:i:s"),PDO::PARAM_STR);
	$stmt->bindParam(':chk_login_secure',$_POST['login_secure'],PDO::PARAM_STR);
	$stmt->execute();

}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>


<?php

if ($_POST['submit_user_delete'] == "modaldeleteuser") {

$chk_login_secure = $_POST['dlogin_secure'];

try {
	include "_cfg_mis40db.php";
	$sql = "DELETE FROM mis_user WHERE login_secure='$chk_login_secure' ";
	$myPDO->exec($sql);
		echo "<script type= 'text/javascript'>alert('Delete User Successfully.');</script>";

}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
$myPDO = null;

//**************//
} else {}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL="<?php echo $wwwurl;?>/?main=user&act=userall">
</head>
<body>
</body>
</html>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } ?>
