<?php
if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        แบบฟอร์ม
      </h1>
      <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">แบบฟอร์ม</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <div class="box box-solid box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">แบบฟอร์มลงทะเบียน</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
              <?php
                if ($_GET['new'] == "provider") {
                  $new_sel_provider = ' class="active" ';
                } else if ($_GET['new'] == "provider2") {
                  $new_sel_active2 = ' class="active" ';
                } else if ($_GET['new'] == "internet") {
                  $new_sel_internet = ' class="active" ';
                } else if ($_GET['new'] == "provider4") {
                  $new_sel_active4 = ' class="active" ';
                } else {
                }
              ?>
                <li <?php echo $new_sel_provider;?>><a href="?main=form&new=provider"><i class="fa  fa-user-plus"></i> ลงทะเบียน User HOSxP ใหม่
                  <span class="label label-primary pull-right">12</span></a></li>
                <li <?php echo $new_sel_active2;?>><a href="?main=form&new=provider2"><i class="fa fa-money"></i> ลงทะเบียนค่าใช้จ่ายเพิ่มเติม</a></li>
                <li <?php echo $new_sel_internet;?>><a href="?main=form&new=internet"><i class="fa fa-globe"></i> ขอใช้อินเตอร์เน็ต</a></li>
                <li <?php echo $new_sel_active4;?>><a href="?main=form&new=provider4"><i class="fa fa-folder-open"></i> ขอใช้ระบบ Datacenter <span class="label label-warning pull-right">65</span></a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>

          <div class="box box-solid box-default">
            <div class="box-header with-border">
              <h3 class="box-title">แบบฟอร์มอื่นๆ</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li <?php echo $new_sel_active5;?>><a href="#"><i class="fa fa-circle-o text-red"></i> แบบฟอร์ม 1</a></li>
                <li <?php echo $new_sel_active6;?>><a href="#"><i class="fa fa-circle-o text-yellow"></i> แบบฟอร์ม 2</a></li>
                <li <?php echo $new_sel_active7;?>><a href="#"><i class="fa fa-circle-o text-light-blue"></i> แบบฟอร์ม 3</a></li>
                <li <?php echo $new_sel_active5;?>><a href="#"><i class="fa fa-circle-o text-red"></i> แบบฟอร์ม 1</a></li>
                <li <?php echo $new_sel_active6;?>><a href="#"><i class="fa fa-circle-o text-yellow"></i> แบบฟอร์ม 2</a></li>
                <li <?php echo $new_sel_active7;?>><a href="#"><i class="fa fa-circle-o text-light-blue"></i> แบบฟอร์ม 3</a></li>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>

        </div>
        <!-- /.col -->

<?php 
if ($_GET['new'] == "provider") {
    include "provider.php";
} else if ($_GET['new'] == "internet") {
    include "internet.php";
} else {
    include "form_blank.php";
}

?>

      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } ?>