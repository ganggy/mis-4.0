<div class="col-md-9">
        <div class="box box-danger">
            <div class="box-header">
              <i class="fa fa-user"></i>

              <h3 class="box-title">เลือกแบบฟอร์มที่ต้องการใช้งาน</h3>
              <!-- tools box -->

              <div class="pull-right box-tools">
				<!-- <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title=" ย่อ "><i class="fa fa-minus"></i></button> -->
                <button type="button" class="btn btn-danger btn-sm" data-widget="remove" data-toggle="tooltip" title=" ปิด "><i class="fa fa-times"></i></button>
              </div>
              <!-- /. tools -->
            </div>
                <div class="box-body">


                </div>
            </div>
        </div>
        <!-- /.col -->
