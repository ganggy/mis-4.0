<div class="col-md-9">
        <div class="box box-warning">
            <div class="box-header">
              <i class="fa fa-user"></i>

              <h3 class="box-title">แบบลงทะเบียน User HOSxP</h3>
              <!-- tools box -->

              <div class="pull-right box-tools">
				<button type="button" class="btn btn-warning btn-sm" data-widget="collapse" data-toggle="tooltip" title=" ย่อ "><i class="fa fa-minus"></i></button>
                <!-- <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title=" ปิด "><i class="fa fa-times"></i></button> -->
              </div>
              <!-- /. tools -->
            </div>
                <div class="box-body">

			<?php
			if($login_secure_ok == "") {
				$m_namefull_ok = $_pname.$_fname."  ".$_lname;
			} else {
				$m_namefull_ok = $mis_u_m_namefull;
			}
			?>

    <form action="<?php echo $PHP_SELF ?>" method="post" enctype="multipart/form-data">

    <div class="form-group">
    <label><i class="fa fa-user margin-r-5"></i>ชื่อ-สกุล:</label>
                  <div class="row">
                  <div class="col-lg-3">
                <div class="input-group">
				          <div class="input-group-addon">
                    คำนำหน้า:
                  </div>
<?php
	try {
    include "_cfg_hos.php";
		$sql = "SELECT * FROM provis_pname";
		$query = $myPDO->query($sql);
    echo "<select class='form-control select2' style='width: 100%;' id='provis_pname_code' name='hos_pname'>";
    
		foreach($query as $data) {
      if ($data['provis_pname_code'] == $_provider_type_code) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['provis_pname_code']."'".$eselected.">".$data['provis_pname_short_name']."</option>";
		}
    echo "</select>";
    
	} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
  ?>
              </div>
                </div>
                <!-- /.col-lg-6 -->
                <div class="col-lg-4">
                  <div class="input-group">
                        <span class="input-group-addon">
                          ชื่อ:
                        </span>
                    <input type="text" name="hos_fname" class="form-control" placeholder="ชื่อ">
                  </div>
                  <!-- /input-group -->
                </div>
                <!-- /.col-lg-6 -->
                <div class="col-lg-5">
                  <div class="input-group">
                        <span class="input-group-addon">
                          นามสกุล:
                        </span>
                    <input type="text" name="hos_lname" class="form-control" placeholder="นามสกุล">
                  </div>
                  <!-- /input-group -->
                </div>
                <!-- /.col-lg-6 -->
              </div>
              <!-- /.row -->
            </div>

            <section>
            <div class="form-group">
				<label><i class="fa fa-file-image-o margin-r-5"></i>เลือกภาพสมาชิก</label>
				<div class="input-group">
					<div class="input-group-addon">
						<i class="fa fa-file-image-o"></i>
					</div>
					<!-- <input id="fileToUpload" type="file" name="fileToUpload" multiple /> -->
					<input id="fileToUpload" type="file" name="fileToUpload" />
					<script>
						$('#fileToUpload').fileselect({
							//allowedNumberOfFiles: 3, // default: false, no limitation
							allowedFileExtensions: ['jpg','jpeg','png','gif'], // default: false, all extensions allowed
							allowedFileSize: 2048000 // 2MB, default: false, no limitation
						});
					</script>
				</div>
            </div>
            </section>
            <div class="form-group">
                <label><i class="fa fa-home margin-r-5"></i>หน่วยงานที่ปฏิบัติงาน:</label>
                <div class="input-group">
				  <div class="input-group-addon">
                    <i class="fa fa-home"></i>
                  </div>

<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE dp_status <> 0";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='user_department' name='user_department'>";

		foreach($query as $data) {
			if ($data['id'] == $mis_u_m_depart) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['id']."'".$eselected.">".$data['dp_name']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
              </div>
            </div>
                <div class="form-group">
                <label><i class="fa fa-crosshairs margin-r-5"></i>ตำแหน่ง/หน้าที่: <font  color="#ff0000">(ส่วนนี้ผู้ดูแลระบบจะกำหนดให้)</font></label>
                <br><label>
                  <input type="checkbox" name="user_status" class="minimal" checked disabled> สมาชิก
                </label>
                <br><label>
                  <input type="checkbox" name="user_head" class="minimal-red"  disabled <?php if ($mis_u_user_head == 1) {echo "checked";};?>> หัวหน้างาน
                </label>
                <br><label>
                  <input type="checkbox" name="user_approve" class="flat-red"  disabled <?php if ($mis_u_user_approve == 1) {echo "checked";};?>> ผู้รับรองรายงาน
                </label>

                </div>

				      <div class="form-group">
                <label><i class="fa fa-envelope margin-r-5"></i>อีเมล์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>
                  <input type="email" class="form-control" name="user_email" placeholder="Email" value="<?php echo $mis_u_m_email;?>">
                </div>
              </div>

              <div class="form-group">
                <label><i class="fa fa-mobile margin-r-5"></i>เบอร์โทรศัพท์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-phone"></i>
                  </div>
                  <input name="user_phoneno" type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask value="<?php echo $mis_u_m_phoneno;?>">
                </div>
              </div>

			        <div class="form-group">
                <label><i class="fa fa-commenting-o margin-r-5"></i>ที่อยู่:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-commenting-o"></i>
                  </div>
                  <input type="text" class="form-control" name="user_subject" placeholder="บ้านเลขที่ หมู่ ตำบล อำเภอ จังหวัด" value="<?php echo $mis_u_user_subject;?>">
                </div>
              </div>

			        <div class="form-group">
                <label><i class="fa fa-comments-o margin-r-5"></i>คติประจำใจ ข้อคิดในการทำงาน:</label>
                  <textarea name="user_descript" class="textarea" placeholder="พิมพ์ข้อความข้อคิดในการทำงาน" 
				  style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $mis_u_user_descript;?></textarea>
              </div>
 
			<input type="hidden" name="user_login_secure" value="<?php echo $ok_login_secure;?>">
			<input type="hidden" name="user_login_user" value="<?php echo $ok_login_user;?>">
			<input type="hidden" name="mis_u_user_picture" value="<?php echo $mis_u_user_picture;?>">
			<input type="hidden" name="submit_user_picture" value="submit_user_picture">

            <div class="form-group">
                <label><i class="fa fa-home margin-r-5"></i>ตำแหน่ง:</label>
                <div class="input-group">
				          <div class="input-group-addon">
                    <i class="fa fa-user-secret"></i>
                  </div>
<?php
	try {
    include "_cfg_hos.php";
		$sql = "SELECT * FROM provider_type";
		$query = $myPDO->query($sql);
    echo "<select class='form-control select2' style='width: 100%;' id='provider_type' name='provider_type'>";
    
		foreach($query as $data) {
      if ($data['provider_type_code'] == $_provider_type_code) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['provider_type_code']."'".$eselected.">".$data['provider_type_name']."</option>";
		}
    echo "</select>";
    
	} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
  ?>
              </div>
            </div>



            <div class="box-footer clearfix">
			<?php
			if($mis_user_level >= 4) {
        echo "<button type='submit' class='pull-right btn btn-danger' id='submit_user_regist' name='submit_user_regist' value='regist'> ลงทะเบียน <i class='fa fa-arrow-circle-right'></i></button>";
			} else {
        // echo "<button type='submit' class='pull-right btn btn-info' id='submit_user_update' name='submit_user_update' value='update'> ปรับปรุงข้อมูล <i class='fa fa-arrow-circle-right'></i></button>";
			}
			?>
        </form>

        </div>
            </div>
        </div>
        <!-- /.col -->
