<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">รายงานการใช้วัคซีน RABIES</h3> <small> (ที่มีใช้ใน รพ. icode : 1590025,1520379,1520165,1520061,1520694)</small>
            </div>

            <!-- /.box-header -->
            <div class="box-body">

  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
	<div class="form-group">
      <label for="daterange-btn">เลือกช่วงวันที่:</label>
      <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
    </div>
    <button type="submit" class="btn btn-default"> ประมวลผล </button>
<?php
$date1d = substr($_POST['cxrdaterange'],3,2);
$date1m = substr($_POST['cxrdaterange'],0,2);
$date1y = substr($_POST['cxrdaterange'],6,4);
$date2d = substr($_POST['cxrdaterange'],16,2);
$date2m = substr($_POST['cxrdaterange'],13,2);
$date2y = substr($_POST['cxrdaterange'],19,4);

$cxrdate1 = $date1y."-".$date1m."-".$date1d;
$cxrdate2 = $date2y."-".$date2m."-".$date2d;
?>
	&nbsp;(ประมวลผลช่วงวันที่ <?php echo $cxrdate1." - ".$cxrdate2; ?>)<br>
  </form>

              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>vdate</th>
                  <th>hn</th>
                  <th>cid</th>
                  <th>สิทธิ์รักษา</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>วันเกิด</th>
                  <th>อายุ</th>
                  <th>บ้านเลขที่</th>
                  <th>ถนน</th>
                  <th>หมู่</th>
                  <th>ที่อยู่</th>
                  <th>ชื่อยา</th>
                  <th>หน่วย</th>
                  <th>จำนวนจ่าย</th>
                  <th>มูลค่า</th>
                  <th>diag</th>
                  <th>แพทย์</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT o.vstdate,o.hn,p.cid,o.pttype,pt.`name` AS pttypename,p.pname,p.fname,p.lname,p.birthday,v.age_y,p.addrpart,p.road,p.moopart,t.full_name
,o.icode,d.`name` AS drugname,d.units,o.qty,o.sum_price,v.pdx,i.`name` AS diagname,dr.`name` AS doctorname

FROM opitemrece o
LEFT JOIN drugitems d ON d.icode = o.icode
LEFT JOIN patient p ON p.hn = o.hn
LEFT JOIN vn_stat v ON v.vn = o.vn
LEFT JOIN pttype pt ON pt.pttype = o.pttype
LEFT JOIN icd101 i ON i.`code` = v.pdx
LEFT JOIN doctor dr ON dr.`code` = o.doctor
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)

WHERE o.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' AND o.icode IN (
SELECT icode FROM drugitems WHERE icode IN ('1590025','1520379','1520165','1520061','1520694')
) ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['vstdate']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['pttype']." : ".$data['pttypename']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['birthday']."</td>";
			echo "<td>".$data['age_y']."</td>";
			echo "<td>".$data['addrpart']."</td>";
			echo "<td>".$data['road']."</td>";
			echo "<td>".$data['moopart']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "<td>".$data['drugname']."</td>";
			echo "<td>".$data['units']."</td>";
			echo "<td>".$data['qty']."</td>";
			echo "<td>".$data['sum_price']."</td>";
			echo "<td>".$data['pdx']." : ".$data['diagname']."</td>";
			echo "<td>".$data['doctorname']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
