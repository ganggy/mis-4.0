
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chat
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `questiontext` text,
  `chatdate` datetime DEFAULT NULL,
  `chatuser` varchar(255) DEFAULT NULL,
  `answertext` text,
  `ansdate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chat
-- ----------------------------

-- ----------------------------
-- Table structure for depart
-- ----------------------------
DROP TABLE IF EXISTS `depart`;
CREATE TABLE `depart` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dp_name` varchar(150) NOT NULL,
  `dp_status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=738 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of depart
-- ----------------------------
INSERT INTO `depart` VALUES ('708', 'งานธุรการ(สารบรรณกลาง)', '1');
INSERT INTO `depart` VALUES ('709', 'งานการเงินและบัญชี', '1');
INSERT INTO `depart` VALUES ('710', 'งานโภชนาการ', '1');
INSERT INTO `depart` VALUES ('711', 'หน่วยอาคารสถานที่และซ่อมบำรุง', '1');
INSERT INTO `depart` VALUES ('712', 'งานผู้ป่วยนอก+CRM', '1');
INSERT INTO `depart` VALUES ('713', 'งานอุบัติเหตุและฉุกเฉิน+คคก.EMS', '1');
INSERT INTO `depart` VALUES ('714', 'งานตึกผู้ป่วย1', '1');
INSERT INTO `depart` VALUES ('715', 'งานตึกผู้ป่วย2', '1');
INSERT INTO `depart` VALUES ('716', 'งานตึกผู้ป่วย3', '1');
INSERT INTO `depart` VALUES ('717', 'งานผู้ป่วยหนัก+PCT-MED', '1');
INSERT INTO `depart` VALUES ('718', 'งานผ่าตัด+PCT-SURG', '1');
INSERT INTO `depart` VALUES ('719', 'งานสูติกรรม+PCT-OBS', '1');
INSERT INTO `depart` VALUES ('720', 'งาน IC + คกก.Risk', '1');
INSERT INTO `depart` VALUES ('721', 'งานสนับสนุนบริการ', '1');
INSERT INTO `depart` VALUES ('722', 'งานให้คำปรึกษา', '1');
INSERT INTO `depart` VALUES ('723', 'งานรังสีวินิจฉัย X-Ray', '1');
INSERT INTO `depart` VALUES ('724', 'งานประกันสุขภาพ', '1');
INSERT INTO `depart` VALUES ('725', 'งานตึกผู้ป่วย4+PCT-PED', '1');
INSERT INTO `depart` VALUES ('726', 'งานบริการทำความสะอาด', '1');
INSERT INTO `depart` VALUES ('727', 'งานวิสัญญี', '1');
INSERT INTO `depart` VALUES ('707', 'งานบริหารพัสดุ', '1');
INSERT INTO `depart` VALUES ('706', 'งานแพทย์แผนไทย', '1');
INSERT INTO `depart` VALUES ('704', 'งานคอมพิวเตอร์', '1');
INSERT INTO `depart` VALUES ('705', 'งานโสตฯ-ศิลป์', '1');
INSERT INTO `depart` VALUES ('700', 'ฝ่ายชันสูตรสาธารณสุข', '1');
INSERT INTO `depart` VALUES ('701', 'กลุ่มงานเวชกรรมสังคม', '1');
INSERT INTO `depart` VALUES ('702', 'งานเวชปฏิบัติทั่วไป', '1');
INSERT INTO `depart` VALUES ('703', 'งานกายภาพบำบัด', '1');
INSERT INTO `depart` VALUES ('694', 'ผู้อำนวยการโรงพยาบาล', '1');
INSERT INTO `depart` VALUES ('695', 'ฝ่ายบริหารทั่วไป', '1');
INSERT INTO `depart` VALUES ('696', 'กลุ่มการพยาบาล+CSR', '1');
INSERT INTO `depart` VALUES ('697', 'ศูนย์คุณภาพและงานแผนงาน(สารบรรณกลาง)', '1');
INSERT INTO `depart` VALUES ('698', 'ฝ่ายเภสัชฯ(คลังยา)+CUP', '1');
INSERT INTO `depart` VALUES ('699', 'ฝ่ายทันตสาธารณสุข', '1');
INSERT INTO `depart` VALUES ('728', 'งานห้องสมุด', '1');
INSERT INTO `depart` VALUES ('729', 'งานตรวจสอบเวชระเบียน', '1');
INSERT INTO `depart` VALUES ('730', 'งานสุขศึกษาประชาสัมพันธ์', '1');
INSERT INTO `depart` VALUES ('731', 'งานควบคุมโรคและโรคติดต่อ', '1');
INSERT INTO `depart` VALUES ('732', 'ฝ่ายเภสัชฯ(ห้องจ่ายยา)+PTC', '1');
INSERT INTO `depart` VALUES ('733', 'คณะกรรมการ ENV', '0');
INSERT INTO `depart` VALUES ('735', 'คณะกรรมการโรงพยาบาลส่งเสริมสุขภาพ', '0');
INSERT INTO `depart` VALUES ('734', 'คณะกรรมการ PCT-ใหญ่', '0');

-- ----------------------------
-- Table structure for kpi
-- ----------------------------
DROP TABLE IF EXISTS `kpi`;
CREATE TABLE `kpi` (
  `kpi_id` int(11) NOT NULL AUTO_INCREMENT,
  `kpi_dpid` varchar(3) DEFAULT NULL,
  `kpi_year` varchar(4) DEFAULT NULL,
  `bsc_code` varchar(10) DEFAULT NULL,
  `kpi_code` varchar(255) DEFAULT NULL,
  `qp_code` varchar(25) DEFAULT NULL,
  `kpi_number` varchar(25) DEFAULT NULL,
  `kpi_name_t` varchar(255) DEFAULT NULL,
  `kpi_name_e` varchar(255) DEFAULT NULL,
  `kpi_meaning` text,
  `kpi_object` varchar(255) DEFAULT NULL,
  `kpi_cal_a` text,
  `kpi_cal_b` text,
  `kpi_cal_c` varchar(10) DEFAULT NULL,
  `kpi_source` varchar(255) DEFAULT NULL,
  `kpi_unit` varchar(255) DEFAULT NULL,
  `kpi_translate` varchar(255) DEFAULT NULL,
  `kpi_duration_type` varchar(2) DEFAULT NULL,
  `kpi_baseline1` double(12,2) DEFAULT NULL,
  `kpi_baseline2` double(12,2) DEFAULT NULL,
  `kpi_baseline3` double(12,2) DEFAULT NULL,
  `kpi_weight` double(12,2) DEFAULT NULL,
  `kpi_target_type` varchar(1) DEFAULT NULL,
  `kpi_targeta` double(12,2) DEFAULT NULL,
  `kpi_targetb` double(12,2) DEFAULT NULL,
  `kpi_target` double(12,2) DEFAULT NULL,
  `kpi_result` double(12,2) DEFAULT NULL,
  `kpi_resultg` double(1,0) DEFAULT NULL,
  `kpi_owner` varchar(255) DEFAULT NULL,
  `kpi_input_type` varchar(1) DEFAULT NULL,
  `kpi_type` varchar(1) DEFAULT NULL,
  `kpi_sql1` text,
  `kpi_sql2` text,
  `kpi_sql3` text,
  `kpi_sql4` text,
  `kpi_view` varchar(1) DEFAULT NULL,
  `kpi_status` varchar(1) DEFAULT NULL,
  `kpi_template_file` varchar(255) DEFAULT NULL,
  `kpi_last_update` datetime DEFAULT NULL,
  `kpi_user_update` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kpi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kpi
-- ----------------------------

-- ----------------------------
-- Table structure for kpi_data
-- ----------------------------
DROP TABLE IF EXISTS `kpi_data`;
CREATE TABLE `kpi_data` (
  `data_id` int(11) NOT NULL AUTO_INCREMENT,
  `data_year` varchar(4) DEFAULT NULL,
  `kpi_code` varchar(255) DEFAULT NULL,
  `data_m1` decimal(12,2) DEFAULT NULL,
  `data_m2` double(12,2) DEFAULT NULL,
  `data_m3` double(12,2) DEFAULT NULL,
  `data_m4` double(12,2) DEFAULT NULL,
  `data_m5` double(12,2) DEFAULT NULL,
  `data_m6` double(12,2) DEFAULT NULL,
  `data_m7` double(12,2) DEFAULT NULL,
  `data_m8` double(12,2) DEFAULT NULL,
  `data_m9` double(12,2) DEFAULT NULL,
  `data_m10` double(12,2) DEFAULT NULL,
  `data_m11` double(12,2) DEFAULT NULL,
  `data_m12` double(12,2) DEFAULT NULL,
  `data_t1` double(12,2) DEFAULT NULL,
  `data_t2` double(12,2) DEFAULT NULL,
  `data_t3` double(12,2) DEFAULT NULL,
  `data_t4` double(12,2) DEFAULT NULL,
  `data_y` double(12,2) DEFAULT NULL,
  `data_last_update` datetime DEFAULT NULL,
  `data_user_update` varchar(255) DEFAULT NULL,
  `data_approve_user` varchar(255) DEFAULT NULL,
  `data_approve_update` datetime DEFAULT NULL,
  `data_approved` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kpi_data
-- ----------------------------

-- ----------------------------
-- Table structure for mis_user
-- ----------------------------
DROP TABLE IF EXISTS `mis_user`;
CREATE TABLE `mis_user` (
  `m_login` varchar(50) NOT NULL,
  `dpid` varchar(50) NOT NULL,
  `m_namefull` varchar(255) NOT NULL,
  `m_realname` varchar(255) DEFAULT NULL,
  `user_status` varchar(1) DEFAULT NULL,
  `user_head` varchar(1) DEFAULT NULL,
  `user_approve` varchar(1) DEFAULT NULL,
  `user_admin` varchar(1) DEFAULT NULL,
  `m_email` varchar(255) DEFAULT NULL,
  `m_phoneno` varchar(255) DEFAULT NULL,
  `login_secure` varchar(255) DEFAULT NULL,
  `user_subject` varchar(255) DEFAULT NULL,
  `user_descript` tinytext,
  `regist_date` datetime DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `user_picture` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `last_logout` datetime DEFAULT NULL,
  `online_status` varchar(1) DEFAULT NULL,
  `ip_login` varchar(255) DEFAULT NULL,
  `os_login` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`m_login`),
  KEY `index_2` (`dpid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mis_user
-- ----------------------------

-- ----------------------------
-- Table structure for rep_506_dhf
-- ----------------------------
DROP TABLE IF EXISTS `rep_506_dhf`;
CREATE TABLE `rep_506_dhf` (
  `year` varchar(255) NOT NULL,
  `code506` varchar(255) NOT NULL,
  `m01` int(255) DEFAULT NULL,
  `m02` int(255) DEFAULT NULL,
  `m03` int(255) DEFAULT NULL,
  `m04` int(255) DEFAULT NULL,
  `m05` int(255) DEFAULT NULL,
  `m06` int(255) DEFAULT NULL,
  `m07` int(255) DEFAULT NULL,
  `m08` int(255) DEFAULT NULL,
  `m09` int(255) DEFAULT NULL,
  `m10` int(255) DEFAULT NULL,
  `m11` int(255) DEFAULT NULL,
  `m12` int(255) DEFAULT NULL,
  `lastupdate` datetime DEFAULT NULL,
  `useredit` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`year`,`code506`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rep_506_dhf
-- ----------------------------
INSERT INTO `rep_506_dhf` VALUES ('2556', '66', '10', '4', '2', '5', '7', '7', '13', '17', '2', '3', '4', '0', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2557', '66', '1', '7', '1', '0', '1', '3', '3', '2', '2', '0', '1', '0', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2558', '66', '0', '0', '1', '1', '1', '3', '4', '8', '32', '23', '35', '5', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2559', '66', '7', '3', '7', '0', '0', '0', '1', '0', '1', '0', '1', '6', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2560', '66', '0', '0', '0', '2', '0', '9', '6', '5', '2', '2', '7', '7', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2561', '66', '6', '18', '13', '9', '23', '31', '17', '18', '7', '3', '0', '0', null, null);
INSERT INTO `rep_506_dhf` VALUES ('2562', '66', '1', '3', '3', '0', '1', '1', '1', '0', '0', '0', '0', '0', '2019-07-26 08:18:19', 'jintrakan');
INSERT INTO `rep_506_dhf` VALUES ('median', '66', '1', '3', '1', '1', '1', '3', '4', '5', '2', '2', '1', '5', '2019-07-26 08:18:19', 'jintrakan');

-- ----------------------------
-- Table structure for rep_reports
-- ----------------------------
DROP TABLE IF EXISTS `rep_reports`;
CREATE TABLE `rep_reports` (
  `repid` int(11) NOT NULL AUTO_INCREMENT,
  `rep_code` varchar(255) DEFAULT NULL,
  `rep_name` varchar(255) DEFAULT NULL,
  `rep_column` varchar(255) DEFAULT NULL,
  `rep_sql1` text,
  `rep_sql2` text,
  `rep_sql3` text,
  `rep_sql4` text,
  `rep_where` varchar(255) DEFAULT NULL,
  `rep_where_fdatename` varchar(255) DEFAULT NULL,
  `rep_where_selecter` varchar(255) DEFAULT NULL,
  `rep_groupby` varchar(255) DEFAULT NULL,
  `rep_user_reporter` varchar(15) DEFAULT NULL,
  `rep_user_request` varchar(255) DEFAULT NULL,
  `rep_update` datetime DEFAULT NULL,
  `rep_cat` varchar(2) DEFAULT NULL,
  `rep_template` text,
  `rep_status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`repid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rep_reports
-- ----------------------------
INSERT INTO `rep_reports` VALUES ('1', 'HOS-1-2-2018-001', 'รายชื่อประชากร person (เลือกวันเกิด)', 'เลขบัตรประชาชน,คำนำหน้า,ชื่อ,นามสกุล', 'SELECT cid,pname,fname,lname FROM person', '', '', '', 'house_regist_type_id', 'birthdate', '13', '', 'ghost', 'ณัฐพงศ์  เครือเทศ', '2018-12-09 01:15:34', '8', 'ข้อมูลประชากรในเขตรับผิดชอบ Type Area = 1,3', '1');
INSERT INTO `rep_reports` VALUES ('2', 'HOS-1-2-2018-002', 'รายชื่อผู้รับบริการที่เกิดระหว่างวันที่ที่เลือก', 'HN,ชื่อ-นามสกุล,วันเกิด,อายุ,เพศ,ที่อยู่', 'SELECT hn,CONCAT(pname,fname,lname) AS ptname,birthday,TIMESTAMPDIFF(YEAR,birthday,CURDATE()) AS agey,sex,addrpart FROM patient', '', '', '', '', 'birthday', '13', '', 'ghost', 'ณัฐพงศ์  เครือเทศ', '2018-04-22 16:06:08', '8', '', '1');
INSERT INTO `rep_reports` VALUES ('6', '2561-20180421190609', 'รายงานจำนวนผู้รับบริการแยกตามสิทธิ์รักษาพยาบาล', 'รหัสสิทธิ์,สิทธิ์รักษาพยาบาล,จำนวน(คน),จำนวน(ครั้ง)', 'SELECT o.pttype,t.name AS pttypename,COUNT(DISTINCT o.hn) AS visitkon,COUNT(*) AS visitkrung FROM ovst o LEFT JOIN pttype t ON t.pttype = o.pttype', '', '', '', '', 'o.vstdate', '15', 'o.pttype', 'ghost', '', '2018-04-21 19:42:19', '8', '', '1');
INSERT INTO `rep_reports` VALUES ('7', '2561-20180421193930', 'ข้อมูลประชากรหลังคาเรือนในเขตรับผิดชอบ', 'หมู่ที่,ชื่อหมู่บ้าน(ชุมชน),จำนวนหลังคาเรือน,จำนวนประชากร', 'SELECT v.village_moo,v.village_name,COUNT(DISTINCT h.house_id) AS chouse,COUNT(*) AS khon\r\nFROM person p \r\nLEFT JOIN house h ON h.house_id = p.house_id\r\nLEFT JOIN village v ON v.village_id = h.village_id', '', '', '', 'p.house_regist_type_id AND v.village_id <> 1', '', '3', 'v.village_moo', 'ghost', '', '2018-12-09 01:26:28', '8', '', '1');
INSERT INTO `rep_reports` VALUES ('8', '2561-20180421195519', 'จำนวนผู้รับบริการรายวัน', 'วันที่,ในเวลา(คน),ในเวลา(ครั้ง),นอกเวลา(คน),นอกเวลา(ครั้ง),รวม(คน),รวม(ครั้ง)', 'SELECT o.vstdate\r\n,COUNT(DISTINCT(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN \'08:30:00\' AND \'16:30:00\',o.hn,0)))-1 AS intimekon\r\n,SUM(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN \'08:30:00\' AND \'16:30:00\',1,0)) AS intime\r\n,COUNT(DISTINCT o.hn) - SUM(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN \'08:30:00\' AND \'16:30:00\',1,0)) AS outtimekon\r\n,COUNT(*) - SUM(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN \'08:30:00\' AND \'16:30:00\',1,0)) AS outtime\r\n,COUNT(DISTINCT o.hn) AS visitkon\r\n,COUNT(*) AS visitkrung\r\nFROM ovst o \r\nLEFT JOIN pttype t ON t.pttype = o.pttype', '', '', '', '', 'o.vstdate', '1', 'o.vstdate', 'ghost', '', '2018-04-22 14:43:24', '8', 'นอกเวลาหมายถึงนอกเวลาราชการตั้งแต่หลังเวลา 16.30 น. ก่อนถึง 08.30 น. และวันหยุดจะหมายถึงนอกเวลาราชการทั้งวัน', '1');
INSERT INTO `rep_reports` VALUES ('9', '2561-20180423091010', 'รายชื่อเด็กเกิด (เลือกวันเกิด)', 'ชื่อ,สกุล,วันเกิด,ที่อยู่', 'SELECT fname,lname,birthday,chwpart FROM patient', '', '', '', '', 'birthday', '', '', 'ghost', 'เภสัชกรรม', '2019-07-16 20:11:50', '1', 'รายชื่อเด็กเกิด (เลือกวันเกิด)', '1');

-- ----------------------------
-- Table structure for sys_bsc
-- ----------------------------
DROP TABLE IF EXISTS `sys_bsc`;
CREATE TABLE `sys_bsc` (
  `bsc_id` int(11) NOT NULL AUTO_INCREMENT,
  `bsc_code` varchar(10) DEFAULT NULL,
  `bsc_name_t` varchar(255) DEFAULT NULL,
  `bsc_name_e` varchar(255) DEFAULT NULL,
  `bsc_description` text,
  PRIMARY KEY (`bsc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_bsc
-- ----------------------------
INSERT INTO `sys_bsc` VALUES ('1', 'F', 'ด้านการเงิน', 'Finance', null);
INSERT INTO `sys_bsc` VALUES ('2', 'C', 'ด้านลูกค้า', 'Customer', null);
INSERT INTO `sys_bsc` VALUES ('3', 'P', 'ด้านกระบวนการภายใน', 'Process', null);
INSERT INTO `sys_bsc` VALUES ('4', 'O', 'ด้านการเรียนรู้และการเติบโต', 'Opportunity', null);

-- ----------------------------
-- Table structure for sys_config
-- ----------------------------
DROP TABLE IF EXISTS `sys_config`;
CREATE TABLE `sys_config` (
  `id` int(11) NOT NULL,
  `hospitalcode` varchar(5) DEFAULT NULL,
  `yearprocess` varchar(4) DEFAULT NULL,
  `shot_name` varchar(255) DEFAULT NULL,
  `hosp_name` varchar(255) DEFAULT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `tmb_part` varchar(2) DEFAULT NULL,
  `tmb_name` varchar(255) DEFAULT NULL,
  `amp_part` varchar(2) DEFAULT NULL,
  `amp_name` varchar(255) DEFAULT NULL,
  `chw_part` varchar(2) DEFAULT NULL,
  `chw_name` varchar(255) DEFAULT NULL,
  `logo_icon1` varchar(255) DEFAULT NULL,
  `logo_icon2` varchar(255) DEFAULT NULL,
  `last_update` datetime DEFAULT NULL,
  `version` varchar(50) DEFAULT NULL,
  `active` varchar(30) DEFAULT NULL,
  `s_runtime` date DEFAULT NULL,
  `e_runtime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_config
-- ----------------------------
INSERT INTO `sys_config` VALUES ('1', '11456', '2562', 'รพร.ตะพานหิน', 'โรงพยาบาลสมเด็จพระยุพราชตะพานหิน', '1 ซ.9 ถ.ชมฐีระเวช', '01', 'ต.ตะพานหิน', '04', 'อ.ตะพานหิน', '66', 'จ.พิจิตร', 'mis-hos-info-logo-1.png', 'mis-hos-info-logo-2.png', '2019-07-28 21:12:31', '1', '1', '2019-01-01', '2019-12-31');

-- ----------------------------
-- Table structure for sys_kpi_duration_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_kpi_duration_type`;
CREATE TABLE `sys_kpi_duration_type` (
  `kpi_duration_type` varchar(1) NOT NULL,
  `kpi_duration_type_name` varchar(255) DEFAULT NULL,
  `kpi_duration_type_m2m` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kpi_duration_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_kpi_duration_type
-- ----------------------------
INSERT INTO `sys_kpi_duration_type` VALUES ('1', 'รายปี', '1-12');
INSERT INTO `sys_kpi_duration_type` VALUES ('2', 'รายงวด 6 เดือน', '1-6,7-12');
INSERT INTO `sys_kpi_duration_type` VALUES ('3', 'รายงวด 3 เดือน', '1-3,4-6,7-9,10-12');
INSERT INTO `sys_kpi_duration_type` VALUES ('4', 'รายเดือน', '1,2,3,4,5,6,7,8,9,10,11,12');

-- ----------------------------
-- Table structure for sys_kpi_input_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_kpi_input_type`;
CREATE TABLE `sys_kpi_input_type` (
  `kpi_input_type` varchar(1) NOT NULL,
  `kpi_input_type_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kpi_input_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_kpi_input_type
-- ----------------------------
INSERT INTO `sys_kpi_input_type` VALUES ('1', 'ประมวลผล');
INSERT INTO `sys_kpi_input_type` VALUES ('2', 'KeyIn');

-- ----------------------------
-- Table structure for sys_kpi_type
-- ----------------------------
DROP TABLE IF EXISTS `sys_kpi_type`;
CREATE TABLE `sys_kpi_type` (
  `kpi_type` varchar(1) NOT NULL,
  `kpi_type_name` varchar(255) DEFAULT NULL,
  `kpi_type_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kpi_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_kpi_type
-- ----------------------------
INSERT INTO `sys_kpi_type` VALUES ('1', 'AP', 'แผนปฏิบัติ');
INSERT INTO `sys_kpi_type` VALUES ('2', 'QMP', 'แผนพัฒนาคุณภาพ');
INSERT INTO `sys_kpi_type` VALUES ('3', 'QP', 'แผนคุณภาพ');
INSERT INTO `sys_kpi_type` VALUES ('4', 'BCS', 'องค์กร');

-- ----------------------------
-- Table structure for sys_kpi_view
-- ----------------------------
DROP TABLE IF EXISTS `sys_kpi_view`;
CREATE TABLE `sys_kpi_view` (
  `kpi_view` varchar(1) NOT NULL,
  `kpi_view_name_e` varchar(255) DEFAULT NULL,
  `kpi_view_name_t` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`kpi_view`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_kpi_view
-- ----------------------------
INSERT INTO `sys_kpi_view` VALUES ('1', 'Admin', 'ผู้ดูแลระบบ');
INSERT INTO `sys_kpi_view` VALUES ('2', 'User', 'สมาชิก');
INSERT INTO `sys_kpi_view` VALUES ('3', 'HospUser', 'เจ้าหน้าที่ รพ.');
INSERT INTO `sys_kpi_view` VALUES ('4', 'Guest', 'ผู้เยี่ยมชม');

-- ----------------------------
-- Table structure for sys_rep_cat
-- ----------------------------
DROP TABLE IF EXISTS `sys_rep_cat`;
CREATE TABLE `sys_rep_cat` (
  `id` int(11) NOT NULL,
  `rep_cat` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_rep_cat
-- ----------------------------
INSERT INTO `sys_rep_cat` VALUES ('1', 'อุบัติเหตุและฉุกเฉิน');
INSERT INTO `sys_rep_cat` VALUES ('2', 'ผู้ป่วยนอก');
INSERT INTO `sys_rep_cat` VALUES ('3', 'ผู้ป่วยใน');
INSERT INTO `sys_rep_cat` VALUES ('5', 'สูติกรรม');
INSERT INTO `sys_rep_cat` VALUES ('6', 'ผ่าตัดและวิสัญญี');
INSERT INTO `sys_rep_cat` VALUES ('8', 'เวชกรรมสังคม');
INSERT INTO `sys_rep_cat` VALUES ('10', 'เภสัชกรรม');
INSERT INTO `sys_rep_cat` VALUES ('14', 'กายภาพ');
INSERT INTO `sys_rep_cat` VALUES ('15', 'เวชระเบียน');
INSERT INTO `sys_rep_cat` VALUES ('17', 'ประกันสุขภาพ');

-- ----------------------------
-- Table structure for sys_setting
-- ----------------------------
DROP TABLE IF EXISTS `sys_setting`;
CREATE TABLE `sys_setting` (
  `sys_name` varchar(255) NOT NULL,
  `sys_show_name` varchar(255) DEFAULT NULL,
  `sys_value` varchar(255) DEFAULT NULL,
  `sys_status` varchar(1) DEFAULT NULL,
  `sys_include` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sys_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_setting
-- ----------------------------
INSERT INTO `sys_setting` VALUES ('cd_disease_tab1', 'ไข้เลือดออก', '66', 'Y', null);
INSERT INTO `sys_setting` VALUES ('cd_disease_tab2', 'อุจาระร่วง', '02', 'Y', null);
INSERT INTO `sys_setting` VALUES ('cd_disease_tab3', 'โรคอื่นๆ', '\'15\',\'71\',\'14\',\'91\'', 'Y', null);
INSERT INTO `sys_setting` VALUES ('icu', 'ตึกผู้ป่วยหนัก ICU', '04', 'Y', null);
INSERT INTO `sys_setting` VALUES ('obs', 'ตึกสูติกรรม', '05', 'Y', null);
INSERT INTO `sys_setting` VALUES ('ward1', 'ตึกผู้ป่วย 1 (หญิง)', '01', 'Y', null);
INSERT INTO `sys_setting` VALUES ('ward2', 'ตึกผู้ป่วย 2 (ชาย)', '02', 'Y', null);
INSERT INTO `sys_setting` VALUES ('ward3', 'ตึกผู้ป่วย 3 (พิเศษ)', '03', 'Y', null);
INSERT INTO `sys_setting` VALUES ('ward4', 'ตึกผู้ป่วย 4 (พิเศษ)', '07', 'Y', null);
INSERT INTO `sys_setting` VALUES ('ward5', null, null, 'N', null);
INSERT INTO `sys_setting` VALUES ('ward6', null, null, 'N', null);

-- ----------------------------
-- Table structure for sys_update
-- ----------------------------
DROP TABLE IF EXISTS `sys_update`;
CREATE TABLE `sys_update` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sysupdate` datetime DEFAULT NULL,
  `updatetext` text,
  `position` varchar(1) DEFAULT NULL,
  `sysuser` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sys_update
-- ----------------------------
INSERT INTO `sys_update` VALUES ('1', '2018-01-01 09:43:04', 'เริ่มจัดทำตามแผนคณะกรรมการ MIS', 'r', 'ghost');
INSERT INTO `sys_update` VALUES ('2', '2018-03-12 09:43:37', 'เชื่อมต่อระบบแจ้งเตือนเข้ากลุ่มไลน์โดย Line Notify', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('3', '2018-03-16 09:44:02', 'การจัดเก็บประวัติเข้าใช้งาน', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('4', '2018-03-23 09:44:23', 'ปรับปรุงระบบแสดงผลงานทั่วไปหน้าหลัก', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('5', '2018-02-26 09:44:47', 'เริ่มทดสอบการใช้งาน', 'r', 'ghost');
INSERT INTO `sys_update` VALUES ('14', '2018-04-05 11:57:13', 'ปรับปรุงระบบแจ้งเตือนหน้าเว็บ', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('15', '2018-04-06 00:43:54', 'ปรับปรุง เพิ่มเติมระบบการแจ้งปัญหาและสอบถามการใช้งาน', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('16', '2018-04-19 17:32:13', 'เพิ่มระบบรายงาน End User ประมวลจากฐานข้อมูล HOSxP ให้ทำได้ผ่านอินเตอร์เน็ต', 'l', 'ghost');
INSERT INTO `sys_update` VALUES ('17', '2018-06-13 10:47:16', 'รอกรรมการ MIS ทดสอบระบบครับ', 'r', 'ghost');
INSERT INTO `sys_update` VALUES ('18', '2019-03-18 11:45:29', 'จัดทำ Dashboard ข้อมูลและสถิติต่างๆในงานให้บริการ', 'r', 'ghost');
INSERT INTO `sys_update` VALUES ('19', '2019-06-29 15:36:29', 'ปรับปรุงการจัดการตัวชี้วัด KPI', 'l', 'ghost');
