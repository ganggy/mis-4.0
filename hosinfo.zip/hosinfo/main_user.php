  <script language="JavaScript">
	   var HttPRequest = true;

	   function doCallAjax(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	   function doCallAjax2(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage2").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage2').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	</script>

 <body>

<?php
if ($mis_user_level >= 3) {

	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT COUNT(*) AS mstatus
					,SUM(IF (u.user_head='1',1,0)) AS head
					,SUM(IF (u.user_approve='1',1,0)) AS approve
					,SUM(IF (u.user_status='1' AND u.user_admin<>'1' AND u.user_head<>'1' AND u.user_approve<>'1',1,0)) AS mwork
					,SUM(IF (u.user_status='0',1,0)) AS statusoff
					FROM mis_user u LEFT JOIN depart d ON d.id = u.dpid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$c_mstatus = $data['mstatus'];
			$c_head = $data['head'];
			$c_approve = $data['approve'];
			$c_mwork = $data['mwork'];
			$c_statusoff = $data['statusoff'];

/* นับจำนวน record
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT u.*,d.* FROM mis_user u LEFT JOIN depart d ON d.id = u.dpid ";
		$query = $myPDO->prepare($sql);
		$query->execute();
		$scount = $query->rowCount();
*/
		}
	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}


if ($_GET['s'] == "head") {
	$user_search = "WHERE u.user_head='1' ";
	$user_search_n = "(หัวหน้า)";
	$act_user_head = " class='active'";
} else if ($_GET['s'] == "approve") {
	$user_search = "WHERE u.user_approve='1' ";
	$user_search_n = "(ผู้รับรองรายงาน)";
	$act_user_approve = " class='active'";
} else if ($_GET['s'] == "work") {
	$user_search = "WHERE u.user_status='1' AND u.user_admin<>'1' AND u.user_head<>'1' AND u.user_approve<>'1' ";
	$user_search_n = "(สมาชิก)";
	$act_user_work = " class='active'";
} else if ($_GET['s'] == "statusoff") {
	$user_search = "WHERE u.user_status='0' ";
	$user_search_n = "(ผู้ใช้ถูกปิดใช้งาน)";
	$act_user_statusoff = " class='active'";
} else {
	$user_search = "";
	$user_search_n = "(ทั้งหมด)";
	$act_user_userall = " class='active'";
}

?>

<!-- <body Onload="JavaScript:doCallAjax('data_kpi100_dash.php');"> -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Admin Users
        <small>บริหารจัดการผู้ใช้</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Admin Users</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <div class="box box-solid">

			<div class="box-header with-border btn-info">
              <h3 class="box-title">User Menu</h3>
              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li <?php echo $act_user_userall;?>><a href="?main=user&act=userall"><i class="fa fa-group"></i> รายชื่อผู้ใช้ทั้งหมด 
					<span class="label label-default pull-right"><?php echo $c_mstatus; ?></span></a></li>
                <li <?php echo $act_user_head;?>><a href="?main=user&act=userall&s=head"><i class="fa fa-user-plus"></i> หัวหน้า
					<span class="label label-primary pull-right"><?php echo $c_head; ?></span></a></li>
                <li <?php echo $act_user_approve;?>><a href="?main=user&act=userall&s=approve"><i class="fa fa-check-square-o"></i> ผู้รับรองรายงาน
					<span class="label label-warning pull-right"><?php echo $c_approve; ?></span></a></li>
                <li <?php echo $act_user_work;?>><a href="?main=user&act=userall&s=work"><i class="fa fa-user"></i> สมาชิก
					<span class="label label-success pull-right"><?php echo $c_mwork; ?></span></a></li>
                <li <?php echo $act_user_statusoff;?>><a href="?main=user&act=userall&s=statusoff"><i class="fa fa-user-times"></i> <font color="#ff0000">ถูกปิดใช้งาน</font>
					<span class="label label-danger pull-right"><?php echo $c_statusoff; ?></span></a></li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
		  <!-- เมนูที่ 2 ด้านล่าง -->
<!-- <span id="myAjaxLoadPage"></span> -->

		</div>
        <!-- /.col -->

<!-- <span id="myAjaxLoadPage2"></span> -->

<?php

if ($_GET['act'] == "userall") {
	include 'user_all.php';
} else if ($_GET['act'] == "usersave") {
	include 'user_save_edit.php';
} else {
	include 'user_all.php';
}

?>

        <!-- /.col -->
      </div>


	</section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>

 </body>
</html>
