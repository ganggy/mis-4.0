<?php
if ($_POST['submit_address'] == "ok_update") {

// Upload file
$target_dir1 = "images/logo/";
$fndate1 = date("YmdHis");
$target_file1 = $target_dir1.$fndate1."_logo-".basename($_FILES["n_logo1"]["name"]);
$target_file_name1 = basename($_FILES["n_logo1"]["name"]);
$uploadOk1 = 1;
$imageFileType1 = strtolower(pathinfo($target_file1,PATHINFO_EXTENSION));
if (file_exists($target_file1)) {
    echo "ไฟล์นี้มีอยู่แล้ว";
    $uploadOk1 = 0;
}
if ($_FILES["n_logo1"]["size"] > 5120000) {
    echo "ไฟล์มีขนาดใหญ่เกินไปกว่าที่กำหนด";
    $uploadOk1 = 0;
}
if ($uploadOk1 == 0) {
    echo "ไม่สามารถอับโหลดไฟล์ได้";
} else {
    if (move_uploaded_file($_FILES["n_logo1"]["tmp_name"], $target_file1)) {
        echo "The file ". basename( $_FILES["n_logo1"]["name"]). " has been uploaded.";
		$firename_pic1 = $fndate1."_logo-".basename($_FILES["n_logo1"]["name"]);
    } else {
        echo "เกิดข้อผิดพลาดไม่สามารถอับโหลดได้";
    }
}
// Upload file //
// Upload file2
$target_dir2 = "images/logo/";
$fndate2 = date("YmdHis");
$target_file2 = $target_dir2.$fndate2."_logo-".basename($_FILES["n_logo2"]["name"]);
$target_file_name2 = basename($_FILES["n_logo2"]["name"]);
$uploadOk2 = 1;
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
if (file_exists($target_file2)) {
    echo "ไฟล์นี้มีอยู่แล้ว";
    $uploadOk2 = 0;
}
if ($_FILES["n_logo2"]["size"] > 5120000) {
    echo "ไฟล์มีขนาดใหญ่เกินไปกว่าที่กำหนด";
    $uploadOk2 = 0;
}
if ($uploadOk2 == 0) {
    echo "ไม่สามารถอับโหลดไฟล์ได้";
} else {
    if (move_uploaded_file($_FILES["n_logo2"]["tmp_name"], $target_file2)) {
        echo "The file ". basename( $_FILES["n_logo2"]["name"]). " has been uploaded.";
		$firename_pic2 = $fndate2."_logo-".basename($_FILES["n_logo2"]["name"]);
    } else {
        echo "เกิดข้อผิดพลาดไม่สามารถอับโหลดได้";
    }
}
// Upload file //


$last_update = date("Y-m-d H:i:s");

if ($firename_pic1 == "") {
	$s_firename_pic1 = $_POST['s_logo_icon1'];
} else {
	$s_firename_pic1 = $firename_pic1;
}

if ($firename_pic2 == "") {
	$s_firename_pic2 = $_POST['s_logo_icon2'];
} else {
	$s_firename_pic2 = $firename_pic2;
}

try {
	include '_cfg_mis40db.php';
	$sql = "UPDATE sys_config SET hospitalcode='".$_POST['hos_code']."',hosp_name='".$_POST['hospitalname']."',shot_name='".$_POST['hosp_shot_name']."',addr='".$_POST['addr']."',tmb_part='".$_POST['tmb_part']."',
  tmb_name='".$_POST['tmb_name']."',amp_part='".$_POST['amp_part']."',amp_name='".$_POST['amp_name']."',chw_part='".$_POST['chw_part']."',chw_name='".$_POST['chw_name']."',
  logo_icon1='".$s_firename_pic1."',logo_icon2='".$s_firename_pic2."',
  last_update = '".$last_update."' WHERE id=1 ";
	$myPDO->query($sql);

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลสำเร็จ');</script>";
  ?>

<!-- // Update OK -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=<?php echo $_POST['link_main_setting'];?>>
</head>
<body></body>
</html>
<!-- Update OK // -->

  <?php
  } else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! ไม่สำเร็จ');</script>";
	}

} catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();}

} else {}
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ตั้งค่าระบบ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">System Setting</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

    <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <p align="center" class="bg-primary text-white">
                <br>
                <img class="img-responsive" src="images/logo/<?php echo $s_logo_icon1;?>" alt="">
                (ภาพ Logo เล็ก...ขนาด 30x35 pixel)<br><br>
                <img class="img-responsive" src="images/logo/<?php echo $s_logo_icon2;?>" alt="">
                (ภาพ Logo ใหญ่...ขนาด 180x40 pixel)<br><br>
            </p>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title"><?php echo $hospitalname;?></h3>
            </div>
          </div>
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">ข้อมูลทั่วไป</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> รหัสสถานพยาบาล</strong>
              <p class="text-muted"><?php echo $hos_code;?></p>
              <hr>
              <strong><i class="fa fa-map-marker margin-r-5"></i> ที่อยู่</strong>
              <p class="text-muted"><?php echo $addr." ".$tmb_name." ".$amp_name." ".$chw_name;?></p>
              <hr>
              <strong><i class="fa fa-file-text-o margin-r-5"></i> ประเภท</strong>
              <p></p>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#settings" data-toggle="tab">Setting</a></li>
              <!-- <li><a href="#setdepart" data-toggle="tab">หน่วยงาน</a></li> -->
              <!-- <li><a href="#setward" data-toggle="tab">ระบบผู้ป่วยใน</a></li> -->
              <!-- <li><a href="#setcd" data-toggle="tab">งานโรคติดต่อ CD</a></li> -->
              <!-- <li><a href="#setncd" data-toggle="tab">งานโรคไม่ติดต่อ NCD</a></li> -->
            </ul>
            <div class="tab-content">

              <div class="active tab-pane" id="settings">
                <form class="form-horizontal" action="<?php echo $PHP_SELF ?>" method="POST" enctype="multipart/form-data">

                  <div class="form-group">
                    <label for="fileToUploadLogo1" class="col-sm-3 control-label">ภาพ Logo (เล็ก)</label>
                    <div class="col-sm-4">
                      <input type="file" id="n_logo1" name="n_logo1">
                        <script>
                          $('#n_logo1').fileselect({
                            allowedFileExtensions: ['jpg','jpeg','png'], // default: false, all extensions allowed
                            allowedFileSize: 5120000 // 5MB, default: false, no limitation
                          });
                        </script>
                    </div>
                    (ขนาดภาพ 30x35 pixel)
                  </div>

                  <div class="form-group">
                    <label for="fileToUploadLogo1" class="col-sm-3 control-label">ภาพ Logo (ใหญ่)</label>
                    <div class="col-sm-4">
                      <input type="file" id="n_logo2" name="n_logo2">
                        <script>
                          $('#n_logo2').fileselect({
                            allowedFileExtensions: ['jpg','jpeg','png'], // default: false, all extensions allowed
                            allowedFileSize: 5120000 // 5MB, default: false, no limitation
                          });
                        </script>
                    </div>
                    (ขนาดภาพ 180x40 pixel)
                  </div>

                  <div class="form-group">
                    <label for="hospitalname1" class="col-sm-3 control-label">รหัสโรงพยาบาล(5 หลัก)</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="hospitalcode" placeholder="รหัสสถานพยาบาล 5 หลัก" value="<?php echo $hos_code;?>" disabled>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="hospitalname1" class="col-sm-3 control-label">ชื่อโรงพยาบาล(เต็ม)</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="hospitalname" placeholder="ชื่อเต็ม" value="<?php echo $hospitalname;?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="hospitalname2" class="col-sm-3 control-label">ชื่อโรงพยาบาล(ย่อ)</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="hosp_shot_name" placeholder="ชื่อย่อ" value="<?php echo $hosp_shot_name;?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">ที่อยู่</label>
                    <label class="col-sm-2 control-label">เลขที่</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="addr" placeholder="ที่อยู่เลขที่" value="<?php echo $addr;?>">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-sm-3 control-label"></label>
                    <label class="col-sm-2 control-label">ตำบล</label>
                    <div class="col-sm-3">
                      <input type="text" class="form-control" name="tmb_name" placeholder="ตำบล" value="<?php echo $tmb_name;?>">
                    </div>
                    <label class="col-sm-2 control-label">รหัสตำบล</label>
                    <div class="col-sm-2">
                      <input type="text" class="form-control" name="tmb_part" placeholder="ที่อยู่เลขที่" value="<?php echo $tmb_part;?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"></label>
                    <label class="col-sm-2 control-label">อำเภอ</label>
                    <div class="col-sm-3">
                      <input type="text" class="form-control" name="amp_name" placeholder="ตำบล" value="<?php echo $amp_name;?>">
                    </div>
                    <label class="col-sm-2 control-label">รหัสอำเภอ</label>
                    <div class="col-sm-2">
                      <input type="text" class="form-control" name="amp_part" placeholder="ที่อยู่เลขที่" value="<?php echo $amp_part;?>">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label"></label>
                    <label class="col-sm-2 control-label">จังหวัด</label>
                    <div class="col-sm-3">
                      <input type="text" class="form-control" name="chw_name" placeholder="ตำบล" value="<?php echo $chw_name;?>">
                    </div>
                    <label class="col-sm-2 control-label">รหัสจังหวัด</label>
                    <div class="col-sm-2">
                      <input type="text" class="form-control" name="chw_part" placeholder="ที่อยู่เลขที่" value="<?php echo $chw_part;?>">
                    </div>
                  </div>

                <div class="box-footer clearfix">
                <button type='submit' class='pull-right btn btn-danger' name='submit_address' value='ok_update'> บันทึก <i class='fa fa-arrow-circle-right'></i></button>
                      <input type="hidden" name="s_logo_icon1" value="<?php echo $s_logo_icon1;?>">
                      <input type="hidden" name="s_logo_icon2" value="<?php echo $s_logo_icon2;?>">
                      <input type="hidden" name="hos_code" value="<?php echo $hos_code;?>">
                      <input type="hidden" name="link_main_setting" value="<?php echo $link;?>">
                </div>
                </form>
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="setdepart">
                <form>
                <table class="table table-hover">
    <thead>
      <tr>
        <th>รหัสหน่วยงาน</th>
        <th>ชื่อหน่วยงาน</th>
        <th>สถานะ</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>งานคอมพิวเตอร์</td>
        <td></td>
      </tr>
      <tr>
        <td>2</td>
        <td>งานผู้ป่วยนอก</td>
        <td></td>
      </tr>
      <tr>
        <td>3</td>
        <td>ตึก 1</td>
        <td></td>
      </tr>
      <tr>
        <td>4</td>
        <td>ตึกสูติกรรม</td>
        <td></td>
      </tr>
    </tbody>
  </table>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger"> บันทึก </button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="setward">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="wardidobs" class="col-sm-2 control-label">ตึกสูติกรรม</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardidobs" name="wardidobs" placeholder="รหัสตึกสูติกรรม">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="wardidicu" class="col-sm-2 control-label">ตึกผู้ป่วยหนัก ICU</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardidicu" name="wardidicu" placeholder="รหัสตึกผู้ป่วยหนัก ICU">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="wardid1" class="col-sm-2 control-label">ตึกผู้ป่วย 1</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardid1" name="wardid1" placeholder="รหัสตึกผู้ป่วย 1">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="wardid2" class="col-sm-2 control-label">ตึกผู้ป่วย 2</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardid2" name="wardid2" placeholder="รหัสตึกผู้ป่วย 2">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="wardid3" class="col-sm-2 control-label">ตึกผู้ป่วย 3</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardid3" name="wardid3" placeholder="รหัสตึกผู้ป่วย 3">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="wardid4" class="col-sm-2 control-label">ตึกผู้ป่วย 4</label>
                    <div class="col-sm-10">
                      <input type="test" class="form-control" id="wardid4" name="wardid4" placeholder="รหัสตึกผู้ป่วย 4">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger"> บันทึก </button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="setcd">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Experience</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Skills</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="setncd">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                    <div class="col-sm-10">
                      <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputName" class="col-sm-2 control-label">Name</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputName" placeholder="Name">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputExperience" class="col-sm-2 control-label">Experience</label>

                    <div class="col-sm-10">
                      <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="inputSkills" class="col-sm-2 control-label">Skills</label>

                    <div class="col-sm-10">
                      <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                      <button type="submit" class="btn btn-danger">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
              <!-- /.tab-pane -->

            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->


    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
