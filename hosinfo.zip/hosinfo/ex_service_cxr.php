<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">ผู้รับบริการได้รับการตรวจ CXR</h3>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
			<div>
  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
	<div class="form-group">
      <label>เลือกช่วงวันที่:</label>
      <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
    </div>
    <button type="submit" class="btn btn-default"> ประมวลผล </button>
<?php
$date1d = substr($_POST['cxrdaterange'],3,2);
$date1m = substr($_POST['cxrdaterange'],0,2);
$date1y = substr($_POST['cxrdaterange'],6,4);
$date2d = substr($_POST['cxrdaterange'],16,2);
$date2m = substr($_POST['cxrdaterange'],13,2);
$date2y = substr($_POST['cxrdaterange'],19,4);

$cxrdate1 = $date1y."-".$date1m."-".$date1d;
$cxrdate2 = $date2y."-".$date2m."-".$date2d;
?>
	&nbsp;(ประมวลผลช่วงวันที่ <?php echo $cxrdate1." - ".$cxrdate2; ?>)<br>
  </form>
			</div>

              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>vdate</th>
                  <th>cid</th>
                  <th>hn</th>
                  <th>vnan</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>เพศ</th>
                  <th>วันเกิด</th>
                  <th>บ้านเลขที่</th>
                  <th>ซอย</th>
                  <th>ถนน</th>
                  <th>หมู่</th>
                  <th>ที่อยู่</th>
                  <th>อายุ</th>
                  <th>pdx</th>
                  <th>dx0</th>
                  <th>dx1</th>
                  <th>dx2</th>
                  <th>dx3</th>
                  <th>dx4</th>
                  <th>dx5</th>
                  <th>xray</th>
                  <th>แผนก</th>
                  <th>คลินิก</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT t.*,IF (t.clinic_member_status_id = '3',GROUP_CONCAT(name),'') AS clinicname

FROM (

SELECT v.vstdate AS vdate,p.cid,v.hn,v.vn AS vnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department,c.clinic,c.clinic_member_status_id,cn.name

FROM vn_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.vn
LEFT JOIN clinicmember c ON c.hn = v.hn
LEFT JOIN clinic cn ON cn.clinic = c.clinic
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2'
AND x.xray_list LIKE 'CXR%'

UNION

SELECT v.regdate AS vdate,p.cid,v.hn,v.an AS hnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department,c.clinic,c.clinic_member_status_id,cn.name

FROM an_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.an
LEFT JOIN clinicmember c ON c.hn = v.hn
LEFT JOIN clinic cn ON cn.clinic = c.clinic
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.regdate BETWEEN '$cxrdate1' AND '$cxrdate2'
AND x.xray_list LIKE 'CXR%'
) AS t

GROUP BY t.hn
ORDER BY t.hn ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['vdate']."</td>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['vnan']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['sex']."</td>";
			echo "<td>".$data['bdate']."</td>";
			echo "<td>".$data['addrpart']."</td>";
			echo "<td>".$data['addr_soi']."</td>";
			echo "<td>".$data['road']."</td>";
			echo "<td>".$data['moopart']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "<td>".$data['age_at_visit']."</td>";
			echo "<td>".$data['pdx']."</td>";
			echo "<td>".$data['dx0']."</td>";
			echo "<td>".$data['dx1']."</td>";
			echo "<td>".$data['dx2']."</td>";
			echo "<td>".$data['dx3']."</td>";
			echo "<td>".$data['dx4']."</td>";
			echo "<td>".$data['dx5']."</td>";
			echo "<td>".$data['xray_list']."</td>";
			echo "<td>".$data['department']."</td>";
			echo "<td>".$data['clinicname']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
