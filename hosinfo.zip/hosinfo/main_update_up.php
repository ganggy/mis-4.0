<?php

try {
	include "_cfg_mis40db.php";
	$update = date("Y-m-d H:i:s");

	if ($_POST['position'] == "r") {
		$position = $_POST['position'];
	} else {
		$position = "l";
	}

	$sql = "	INSERT INTO sys_update (updatetext,sysupdate,sysuser,position) VALUES ('".$_POST['updatetext']."','".$update."','".$_POST['login_user']."','".$position."') ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('เรียบร้อยแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}
?>

<!-- // Login not OK -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=<?php echo $wwwurl;?>/>
</head>
</body>
</html>
<!-- Login not OK // -->

<?php
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();
}

?>
