<?php
	function DateThai($strDate)
	{
		$strYear = substr(date("Y",strtotime($strDate))+543, 2, 2);
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$strMonthThai=$strMonthCut[$strMonth];
		//return "$strDay/$strMonth/$strYear";
		return "$strDay $strMonthThai $strYear";
		//return "$strDay $strMonthThai $strYear, $strHour:$strMinute";
	}

	function LongDateThai($strDate)
	{
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");
		$strMonthThai=$strMonthCut[$strMonth];
		//return "$strDay/$strMonth/$strYear";
		return "$strDay $strMonthThai $strYear";
		//return "$strDay $strMonthThai $strYear, $strHour:$strMinute";
	}

	function DateTimeThai($strDate)
	{
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$strMonthThai=$strMonthCut[$strMonth];
		//return "$strDay/$strMonth/$strYear";
		return "$strDay $strMonthThai $strYear $strHour.$strMinute น.";
		//return "$strDay $strMonthThai $strYear, $strHour:$strMinute";
	}
?>

  <style>
    .example-modal .modal {
      position: relative;
      top: auto;
      bottom: auto;
      right: auto;
      left: auto;
      display: block;
      z-index: 1;
    }

    .example-modal .modal {
      background: transparent !important;
    }
  </style>

	<!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button"></a>

	  <div class="navbar-custom-menu">

<?php

	try {
		include "_cfg_mis40db.php";
		// คำสั่ง SQL
		$sql1 = "SELECT COUNT(*) AS cchat FROM chat ";
		$query1 = $myPDO->query($sql1);
		foreach($query1 as $data1) {
			$cchat = $data1['cchat'];
		}

		$sql1 = "SELECT COUNT(*) AS userregis,COUNT(IF(DATE_FORMAT(regist_date,'%Y-%m-%d') = DATE_FORMAT(NOW(),'%Y-%m-%d'),1,NULL)) AS registoday FROM mis_user ";
		$query1 = $myPDO->query($sql1);
		foreach($query1 as $data1) {
			$user_regis_mis = $data1['userregis'];
			$user_registoday_mis = $data1['registoday'];
		}

		$sql1 = "SELECT COUNT(*) AS user_onlune FROM mis_user WHERE online_status = '1' ";
		$query1 = $myPDO->query($sql1);
		foreach($query1 as $data1) {
			$user_onlune = $data1['user_onlune'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
        <ul class="nav navbar-nav">

<?php //if ($mis_user_level >= 3) { ?>

				<li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-user"></i>
              <span class="label label-success"><?php echo $user_onlune;?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"><i class="fa fa-user-plus"></i> กำลังใช้งาน <span class="label label-success"><?php echo $user_onlune;?></span> คน</li>
              <li class="header"><i class="fa fa-user-plus"></i> ลงทะเบียนใหม่วันนี้ <span class="label label-warning"><?php echo $user_registoday_mis;?></span> คน</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">

<?php
try {
	include "_cfg_mis40db.php";
	$sql1 = "SELECT * FROM mis_user WHERE DATE_FORMAT(regist_date,'%Y-%m-%d') = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
	$query1 = $myPDO->query($sql1);
	foreach($query1 as $data1) {
?>
                  <!-- start message -->
									<li>
                    <a>
                      <div class="pull-left">
                        <img src="<?php if ($data1['user_picture'] == "") {echo "dist/img/guestuser.png";} else {echo "images/users/".$data1['user_picture']."";} ?>" class="img-circle" alt="User Image">
                      </div>
                      <h4><?php echo $data1['m_namefull'];?></h4>
                    </a>
                  </li>
                  <!-- end message -->
<?php
	}
} catch (PDOException $e) {
	echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>

                </ul>
              </li>
              <li class="footer"><a href="?main=user">จัดการสมาชิก</a></li>
            </ul>
          </li>
<?php //} else { }?>

          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-danger"><?php echo $cchat; ?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="header"><i class="fa fa-comments-o"></i> แจ้งปัญหา/สอบถาม <span class="label label-danger"> <?php echo $cchat; ?> </span></li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <!-- <li>
                    <a href="#chat">
                      <i class="fa fa-comments-o"></i> แจ้งปัญหา/สอบถามการใช้งาน
                    </a>
                  </li> -->

<?php
	try {
		include "_cfg_mis40db.php";
		// คำสั่ง SQL
		$sql4 = "SELECT c.*,u.* FROM chat c LEFT JOIN mis_user u ON u.m_login = c.chatuser ORDER BY id DESC ";
		$query4 = $myPDO->query($sql4);

		foreach($query4 as $data4) {
?>
              <!-- chat item -->
              <li>
				<a href="#chat">
				&nbsp; - <?php echo iconv_substr($data4['questiontext'], 0,25, "UTF-8");?>...(<?php echo $data4['chatuser'];?>)
				</a>
			  </li>
<?php
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </ul>
              </li>
              <!-- <li class="footer"><a href="#">ดูทั้งหมด</a></li> -->
            </ul>
          </li>

<?php
if ($login_ok == 1) {
?>

          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">

	<?php
if ($login_ok == 1) {
			if ($mis_u_user_picture == "") {
					
						if ($_sex == 1) {
							echo "<img src='dist/img/user-icon-image-man.jpg' class='user-image' alt=''>";
						} else {
							echo "<img src='dist/img/user-icon-image-women.jpg' class='user-image' alt=''>";
						}
					} else {
						echo "<img src='images/users/".$mis_u_user_picture."' class='user-image' alt=''>";
					}
	
} else {
	echo "<img src='dist/img/guestuser.png' class='user-image' alt=''>";
}
?>

              <span class="hidden-xs"><?php echo $ok_login_name;?></span>
            </a>
            <ul class="dropdown-menu">
              <li class="user-header">
<?php
if ($login_ok == 1) {
			if ($mis_u_user_picture == "") {
					
						if ($_sex == 1) {
							echo "<img src='dist/img/user-icon-image-man.jpg' class='img-circle' alt=''>";
						} else {
							echo "<img src='dist/img/user-icon-image-women.jpg' class='img-circle' alt=''>";
						}
					} else {
						echo "<img src='images/users/".$mis_u_user_picture."' class='img-circle' alt=''>";
					}
	
} else {
	echo "<img src='dist/img/guestuser.png' class='img-circle' alt=''>";
}
?>
                <p>
                  <?php echo $ok_login_name;?>
                  <small>ระดับผู้ใช้งาน : <?php echo $mis_user_level_name;?></small>
                </p>
              </li>

              <li class="user-footer">
                <div class="pull-left">
                  <a href="?main=profile" class="btn btn-info">ข้อมูลสมาชิก</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-danger">ออกจากระบบ</a>
                </div>
              </li>
            </ul>
          </li>


<?php
} else {
?>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="modal" data-target="#modal-login2">
			<?php if ($login_ok == 1) {
				if ($_sex == 1) {
					echo "<img src='dist/img/user-icon-image-man.jpg' class='user-image' alt=''>";
				} else {
					echo "<img src='dist/img/user-icon-image-women.jpg' class='user-image' alt=''>";
				}
			} else {
				echo "<img src='dist/img/guestuser.png' class='user-image' alt=''>";
			}?>
              <span class="hidden-xs"><?php echo $ok_login_user;?></span>
            </a>
          </li>
<?php
}
?>

          <!-- Control Sidebar Toggle Button --><!-- ปิดใช้งาน control-sidebar -->
          <li>
					<?php if ($mis_user_level >= 5) { ?>
            <a href="?main=setting"><i class="fa fa-gears"></i></a>
            <!-- <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a> -->
					<?php } else {?>
            <a><i class="fa fa-gears"></i></a>
					<?php }?>

          </li>
        </ul>
      </div>
    </nav>

		<?php 
// Program to display current page URL. 
  
$link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 
                "https" : "http") . "://" . $_SERVER['HTTP_HOST'] .  
                $_SERVER['REQUEST_URI']; 
?>
