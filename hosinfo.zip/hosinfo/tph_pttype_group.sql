
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tph_pttype_group
-- ----------------------------
DROP TABLE IF EXISTS `tph_pttype_group`;
CREATE TABLE `tph_pttype_group` (
  `type` varchar(2) DEFAULT NULL,
  `typename` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=tis620;

-- ----------------------------
-- Records of tph_pttype_group
-- ----------------------------
INSERT INTO `tph_pttype_group` VALUES ('OT', '6. อื่นๆ');
INSERT INTO `tph_pttype_group` VALUES ('UC', '4. บัตรทองมี ท');
INSERT INTO `tph_pttype_group` VALUES ('RE', '1. ข้าราชการ/รัฐวิสาหกิจ');
INSERT INTO `tph_pttype_group` VALUES ('IN', '2. ประกันสังคม');
INSERT INTO `tph_pttype_group` VALUES ('FK', '5. ต่างด้าวขึ้นทะเบียน');
INSERT INTO `tph_pttype_group` VALUES ('NU', '3. บัตรทอง ไม่มี ท');
