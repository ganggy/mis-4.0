<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">เป้าหมายผู้รับบริการตรวจ TB</h3>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>cid</th>
                  <th>hn</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>อายุ</th>
                  <th>บ้านเลขที่</th>
                  <th>หมู่</th>
                  <th>ชื่อหมู่บ้าน</th>
                  <th>ที่อยู่</th>
                  <th>Last HbA1C</th>
                  <th>HbA1C date</th>
                  <th>Last FBS</th>
                  <th>FBS date</th>
                  <th>Type</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT * FROM tph_tb_targetall WHERE cid NOT IN (
SELECT t.cid

FROM (

SELECT v.vstdate AS vdate,p.cid,v.hn,v.vn AS vnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department,c.clinic,c.clinic_member_status_id,cn.name

FROM vn_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.vn
LEFT JOIN clinicmember c ON c.hn = v.hn
LEFT JOIN clinic cn ON cn.clinic = c.clinic
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.vstdate BETWEEN '2018-10-01' AND '2019-09-30'
AND x.xray_list LIKE 'CXR%'

UNION

SELECT v.regdate AS vdate,p.cid,v.hn,v.an AS hnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department,c.clinic,c.clinic_member_status_id,cn.name

FROM an_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.an
LEFT JOIN clinicmember c ON c.hn = v.hn
LEFT JOIN clinic cn ON cn.clinic = c.clinic
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.regdate BETWEEN '2018-10-01' AND '2019-09-30'
AND x.xray_list LIKE 'CXR%'
) AS t

GROUP BY t.cid
)
GROUP BY cid ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['patnane']."</td>";
			echo "<td>".$data['AGE_YEAR']."</td>";
			echo "<td>".$data['addrpart']."</td>";
			echo "<td>".$data['moopart']."</td>";
			echo "<td>".$data['name']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "<td>".$data['last_hba1c_value']."</td>";
			echo "<td>".$data['last_hba1c_date']."</td>";
			echo "<td>".$data['last_fbs_value']."</td>";
			echo "<td>".$data['last_fbs_date']."</td>";
			echo "<td>".$data['type']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
