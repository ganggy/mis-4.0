  <!-- =============================================== -->

  <!-- Left side column. contains the sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
<?php
if ($login_ok == 1) {
			if ($mis_u_user_picture == "") {
					
						if ($_sex == 1) {
							echo "<img src='dist/img/user-icon-image-man.jpg' class='img-circle' alt=''>";
						} else {
							echo "<img src='dist/img/user-icon-image-women.jpg' class='img-circle' alt=''>";
						}
					} else {
						echo "<img src='images/users/".$mis_u_user_picture."' class='img-circle' alt=''>";
					}
	
} else {
	echo "<img src='dist/img/guestuser.png' class='img-circle' alt=''>";
}
?>
		</div>
        <div class="pull-left info">
          <p><?php if ($login_ok == 1) {echo "<a href='?main=profile'>$ok_login_name</a>";} else {echo "<a>$ok_login_name</a>";}?></p>
          <?php if ($login_ok == 1) {echo "<a href='?main=profile'><i class='fa fa-circle text-success'></i> Online</a>";} else {echo "<i class='fa fa-circle text-danger'></i> User Offline";}?>
        </div>
      </div>

      <!-- search form -->
      <!-- <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form> -->
      <!-- /.search form -->

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">เมนูหลัก</li>

        <li <?php echo $act_index;?>>
          <a href="<?php echo $wwwurl;?>/">
            <i class="fa fa-home"></i> <span>Home</span>
          </a>
        </li>

	<!-- สำหรับ Admin -->
	<?php if ($mis_user_level >= 5) { ?>
        <li <?php echo $act_setting;?>>
          <a href="?main=setting">
            <i class="fa fa-gear"></i> <span>ตั้งค่าระบบ</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-red">a</small>
            </span>
          </a>
        </li>

        <li <?php echo $act_user;?>>
          <a href="?main=user">
            <i class="fa fa-user"></i> <span>จัดการผู้ใช้</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-red">a</small>
            </span>
          </a>
        </li>
	<?php } else { }?>

		<li class="treeview <?php echo $act50;?>">
          <a href="#">
            <i class="fa fa-folder"></i>
            <span>ข้อมูลและสถิติ</span>
            <span class="pull-right-container">
			  <i class="fa fa-angle-left pull-right"></i>
              <small class="label pull-right bg-blue">10</small>
            </span>
		  </a>
          <ul class="treeview-menu">
            <li <?php echo $act501;?>><a href="?stat=opd"><i class="fa fa-arrow-right"></i> ผู้ป่วยนอก</a></li>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT COUNT(*) AS cward FROM ward WHERE ward_active = 'Y' ORDER BY ward ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
      $count_ward = $data['cward'];
    }
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
            <li class="treeview <?php echo $act60;?>">
              <a href="#"><i class="fa fa-level-down"></i> ผู้ป่วยใน
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
	              <small class="label pull-right bg-red"><?php echo $count_ward;?></small>
                </span>
              </a>
              <ul class="treeview-menu">
				<li <?php echo $act502;?>><a href="?stat=ipd"><i class="fa fa-angle-double-right"></i> ภาพรวมผู้ป่วยใน</a></li>

<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT ward,name FROM ward WHERE ward_active = 'Y' ORDER BY ward ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
?>
                <li <?php if ($_GET['ward'] == $data['ward']) {echo "class=active";};?>><a href="?ward=<?php echo $data['ward'];?>"><i class="fa fa-angle-double-right"></i> <?php echo $data['name'];?></a></li>
<?php
    }
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

              </ul>
            </li>
            <li <?php echo $act503;?>><a href="?stat=dent"><i class="fa fa-arrow-right"></i> ทันตกรรม</a></li>
            <li <?php echo $act504;?>><a href="?stat=ppt"><i class="fa fa-arrow-right"></i> แพทย์แผนไทย</a></li>
            <li <?php echo $act505;?>><a href="?stat=er"><i class="fa fa-arrow-right"></i> อุบัติเหตุและฉุกเฉิน</a></li>
            <li <?php echo $act506;?>><a href="?stat=or"><i class="fa fa-arrow-right"></i> ผ่าตัดและวิสัญญี</a></li>
            <li <?php echo $act508;?>><a href="?stat=cd"><i class="fa fa-arrow-right"></i> โรคติดต่อ CD</a></li>
            <li <?php echo $act509;?>><a href="?stat=ncd"><i class="fa fa-arrow-right"></i> โรคไม่ติดต่อ NCD</a></li>
            <li <?php echo $act510;?>><a href="?stat=pts"><i class="fa fa-arrow-right"></i> กายภาพบำบัด</a></li>
            <li <?php echo $act511;?>><a href="?stat=xray"><i class="fa fa-arrow-right"></i> ชัณสูตรและ X-Ray</a></li>
          </ul>
        </li>

	<!-- // สำหรับสมาชิก HOSxP login -->
	<?php if ($mis_user_level >= 1) { ?>

        <li <?php echo $act_reports;?>>
          <a href="?main=reports">
            <i class="fa fa-files-o"></i> <span>รายงาน End User</span>
            <span class="pull-right-container">
              <small class="label pull-right bg-green">u</small>
            </span>
          </a>
        </li>

	<?php } else { }?>
	<!-- สำหรับสมาชิก HOSxP login // -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($mis_user_level >= 1) { ?>

		<li class="treeview <?php echo $act80;?>">
          <a href="#">
            <i class="fa fa-pie-chart"></i>
            <span>คืนข้อมูล Data Export</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?php echo $act801;?>><a href="?exp=person"><i class="fa fa-arrow-right"></i> รายชื่อประชากร person (ในเขต)</a></li>
            <li <?php echo $act804;?>><a href="?exp=persons"><i class="fa fa-arrow-right"></i> รายชื่อประชากร person</a></li>
            <li <?php echo $act802;?>><a href="?exp=patient"><i class="fa fa-arrow-right"></i> รายชื่อผู้ป่วย patient</a></li>
            <!-- <li <?php echo $act803;?>><a href="?exp=service"><i class="fa fa-arrow-right"></i> รายการบริการ service</a></li> -->
            <li <?php echo $act805;?>><a href="?exp=cxr"><i class="fa fa-arrow-right"></i> รายการบริการ CXR</a></li>
            <li <?php echo $act806;?>><a href="?exp=rabies"><i class="fa fa-arrow-right"></i> รง.การใช้วัคซีน RABIES</a></li>
            <li <?php echo $act807;?>><a href="?exp=tb"><i class="fa fa-arrow-right"></i> เป้าหมายตรวจ TB</a></li>
            <li <?php echo $act808;?>><a href="?exp=drugsearch"><i class="fa fa-arrow-right"></i> ผู้รับบริการรับยา</a></li>
            <li <?php echo $act809;?>><a href="?exp=moneyopd"><i class="fa fa-arrow-right"></i> สรุปค่าใช้จ่ายผู้ป่วยนอก</a></li>
            <li <?php echo $act810;?>><a href="?exp=moneyipd"><i class="fa fa-arrow-right"></i> สรุปค่าใช้จ่ายผู้ป่วยใน</a></li>
            <li <?php echo $act811;?>><a href="?exp=dentalcare"><i class="fa fa-arrow-right"></i> คนในเขตตรวจสุขภาพฟัน</a></li>
            <li <?php echo $act812;?>><a href="?exp=visitpttype"><i class="fa fa-arrow-right"></i> จำนวนผู้รับบริการผู้ป่วยนอก</a></li>
          </ul>
    </li>


	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->


        <li <?php echo $act_labsearch;?>>
          <a href="?main=labsearch">
            <i class="fa fa-search"></i> <span>ค้นผล LAB</span>
          </a>
        </li>
        <li <?php echo $act_vacsearch;?>>
          <a href="?main=vacsearch">
            <i class="fa fa-search"></i> <span>ข้อมูล Vaccine</span>
          </a>
        </li>

	<!-- // สำหรับ Guest -->
        <li class="header"></li>

        <li class="treeview <?php echo $act30;?>">
          <a href="#">
            <i class="fa fa-book"></i>
            <span>คู่มือใช้งาน</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i><span class="label label-primary pull-right">4</span>
            </span>
          </a>
          <ul class="treeview-menu">
            <li <?php echo $act301;?>><a target="_blank" href="https://drive.google.com/file/d/1Yo8K53NkXAUmquN7brfFecMRnNHzfAZB/view?usp=sharing"><i class="fa fa-arrow-right"></i> <span>คู่มือ MIS Web4.0</span></a></li>
            <li <?php echo $act303;?>><a href="#"><i class="fa fa-arrow-right"></i> <span>คู่มือรายงาน End User</span></a></li>
            <li <?php echo $act_last_update;?>><a href="?main=update"><i class="fa fa-arrow-right"></i> <span>Last Update</span></a></li>
          </ul>
        </li>

	<!-- สำหรับ Guest // -->

		<li class="header">&raquo; Create by GHOST &laquo;</li>

	  </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- =============================================== -->
