              <!-- DIRECT CHAT -->
			  <div class="box box-primary direct-chat">
				<div class="box-header with-border">
				<i class="fa fa-file-pdf-o"></i>
				  <h3 class="box-title">คู่มือและข้อตกลงการใช้งาน</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="ข้อตกลงการใช้งาน"
                    data-widget="chat-pane-toggle">
                    <i class="fa fa-comments"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
              </div>

				<!-- /.box-header -->
                <div class="box-body">
                  <!-- Conversations are loaded here -->
                  <div class="direct-chat-messages">

              <ul class="products-list product-list-in-box">
                <li class="item">
                  <div class="product-img">
                    <img src="<?php echo $wwwurl;?>/images/manual-book.png" alt="Product Image">
                  </div>
                  <div class="product-info">
                    <a href="https://drive.google.com/file/d/1Yo8K53NkXAUmquN7brfFecMRnNHzfAZB/view?usp=sharing" target="_blank" class="product-title">คู่มือ MIS (Web 4.0)
                      <span class="label label-info pull-right">คลิกอ่าน</span></a>
                    <span class="product-description">
                          คู่มือการใช้งานโปรแกรมระบบเว็บ MIS
                        </span>
                  </div>
                </li>
                <!-- /.item -->
                <li class="item">
                  <div class="product-img">
                    <img src="<?php echo $wwwurl;?>/images/manual-book.png" alt="Product Image">
                  </div>
                  <div class="product-info">
                    <a href="javascript:void(0)" class="product-title">คู่มือการจัดทำรายงาน End User
                      <span class="label label-info pull-right">คลิกอ่าน</span></a>
                    <span class="product-description">
                          คู่มือสำหรับผู้ดูแล จัดทำรายงาน End User เพื่อประมวลผลข้อมูลจากฐานข้อมูล HOSxP
                        </span>
                  </div>
                </li>
                <!-- item //-->
                <!-- /.item -->
                <li class="item">
                  <div class="product-img">
                    <img src="<?php echo $wwwurl;?>/images/pdf-icon.png" alt="Product Image">
                  </div>
                  <div class="product-info">
                    <a href="javascript:void(0)" class="product-title">รวม Template
                      <span class="label label-warning pull-right">คลิกอ่าน</span></a>
                    <span class="product-description">
                          รวม Template และคำอธิบายทุกตัวชี้วัด
                        </span>
                  </div>
                </li>
                <!-- item //-->
              </ul>

                  </div>
                  <!--/.direct-chat-messages-->

                  <!-- Contacts are loaded here -->
                  <div class="direct-chat-contacts">
                    <ul class="contacts-list">
                      <li>
                        <a>
                          <img class="contacts-list-img" src="<?php echo $wwwurl;?>/images/agreement2.png" alt="Agreement">

                          <div class="contacts-list-info">
                                <span class="contacts-list-name">
                                  ข้อตกลงการใช้งาน
                                  <small class="contacts-list-date pull-right"></small>
                                </span>
                            <span class="contacts-list-msg">ใช้เพื่อประมวลผล และแสดงข้อมูลสถิติรายงานต่างๆ ของโรงพยาบาลสมเด็จพระยุพราชตะพานหิน แห่งนี้เท่านั้น<br>ห้ามนำไปอ้างอิง เพื่อผลประโยชน์ หรือโต้แย้งใดๆ ที่ก่อให้เกิดความเสียหายให้แก่โรงพยาบาล หรือผู้เกี่ยวข้อง รวมทั้งผู้รับบริการที่มาใช้บริการในโรงพยาบาลแห่งนี้ <br>ทางโรงพยาบาลหรือผู้จัดทำ จะไม่รับผิดชอบใดๆ ในการนำข้อมูลบนเว็บไซต์แห่งนี้ไปใช้ในทางที่สร้างความเสียหายต่างๆทั้งสิ้น ...</span>
                          </div>
                          <!-- /.contacts-list-info -->
                        </a>
                      </li>
                      <!-- End Contact Item -->
                    </ul>
                    <!-- /.contatcts-list -->
				  </div>

				</div>
                <!-- /.box-body -->
              </div>
              <!--/.direct-chat -->
