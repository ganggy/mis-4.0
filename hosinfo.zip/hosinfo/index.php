<?php
date_default_timezone_set("Asia/Bangkok");
$wwwurl = "/hosinfo";
$gettime = date("h");
$getipaddress = $_SERVER['REMOTE_ADDR'];
$getlogin = sha1($getipaddress.$gettime);

if ($_GET['login'] == $getlogin) {
	include 'uloginf.php';
} else {
	
?>

<?php
session_start();

if ($_SESSION["login_user"] || "") {
	$login_ok = 1;
	$ok_login_secure = substr($_SESSION["login_user_s"],20,20).substr($_SESSION["login_pass_s"],20,20);
	$ok_login_user = $_SESSION["login_user"];
	$ok_login_name = $_SESSION["login_name"];
	$ok_login_encode = $_SESSION["login_encode"];
} else {
	$login_ok = 0;
	$ok_login_user = "เข้าระบบสมาชิก";
	$ok_login_name = "Guest";
	$ok_login_encode = "";
}

$name_month_10 = "ตุลาคม";
$name_month_11 = "พฤศจิกายน";
$name_month_12 = "ธันวาคม";
$name_month_01 = "มกราคม";
$name_month_02 = "กุมภาพันธ์";
$name_month_03 = "มีนาคม";
$name_month_04 = "เมษายน";
$name_month_05 = "พฤษภาคม";
$name_month_06 = "มิถุนายน";
$name_month_07 = "กรกฎาคม";
$name_month_08 = "สิงหาคม";
$name_month_09 = "กันยายน";

function DateThaiShort($strDate)
	{
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$strMonthThai=$strMonthCut[$strMonth];
		return "$strDay $strMonthThai $strYear";
	}
function DateThaiFull($strDate)
	{
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");
		$strMonthThai=$strMonthCut[$strMonth];
		return "$strDay $strMonthThai $strYear";
	}

?>

<?php
try {
	require_once("_cfg_hos.php");
	$sql = "SELECT o.*,d.* FROM opduser o LEFT JOIN doctor d ON d.code = o.doctorcode WHERE o.loginname = '$ok_login_user' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$_entryposition = $data['entryposition'];
		$_cid = $data['cid'];
		$_birth_date = $data['birth_date'];
		$_name = $data['name'];
		$_pname = $data['pname'];
		$_lname = $data['lname'];
		$_fname = $data['fname'];
		$_licenseno = $data['licenseno'];
		$_sex = $data['sex'];
		$_doctorcode = $data['doctorcode'];
	}

	$sql = "SELECT * FROM doctor WHERE code = '$_doctorcode' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$_provider_type_code = $data['provider_type_code'];
	}

	$sql = "SELECT o.hospitalcode,o.hospitalname,h.chwpart,h.amppart FROM opdconfig o
	INNER JOIN hospcode h ON o.hospitalcode = h.hospcode
	";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$hos_name = $data['hospitalname'];
		$hos_code = $data['hospitalcode'];
		$hos_chwpart = $data['chwpart'];
		$hos_amppart = $data['amppart'];
		// $hos_chwname = $data['PROVINCE_NAME'];
		// $hos_ampname = $data['AMPHUR_NAME'];
	}

	$sql = "SELECT sys_value FROM sys_var WHERE sys_name = 'dm_clinic_code' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$dm_clinic_code = $data['sys_value'];
	}
	$sql = "SELECT sys_value FROM sys_var WHERE sys_name = 'ht_clinic_code' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$ht_clinic_code = $data['sys_value'];
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>

<?php
try {
	include "_cfg_mis40db.php";
	$sql = "SELECT * FROM mis_user WHERE login_secure = '$ok_login_secure' AND user_status = '1' ";
	$result = $myPDO->query($sql);
			$mis_user_level = 0;
			$mis_user_level_name = "<font color='#ff0000'>ยังไม่ได้ลงทะเบียนผู้ใช้ระบบ MIS</font>";
	foreach ($result AS $data) {
		$login_secure_ok = "2WayAcceptOK";
		$mis_u_m_namefull = $data['m_namefull'];
		$mis_u_user_status = $data['user_status'];
		$mis_u_m_depart = $data['dpid'];
		$mis_u_user_head = $data['user_head'];
		$mis_u_user_approve = $data['user_approve'];
		$mis_u_m_email = $data['m_email'];
		$mis_u_m_phoneno = $data['m_phoneno'];
		$mis_u_user_subject = $data['user_subject'];
		$mis_u_user_descript = $data['user_descript'];
		$mis_u_user_admin = $data['user_admin'];
		$mis_u_user_picture = $data['user_picture'];

		if ($data['user_admin'] == "2") {
			$mis_user_level = 5;
			$mis_user_level_name = "SuperAdmin";
		} else if ($data['user_admin'] == "1") {
			$mis_user_level = 4;
			$mis_user_level_name = "ผู้ดูแลระบบ";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "111") {
			$mis_user_level = 3;
			$mis_user_level_name = "หัวหน้า";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "110") {
			$mis_user_level = 3;
			$mis_user_level_name = "หัวหน้า";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "101") {
			$mis_user_level = 2;
			$mis_user_level_name = "ผู้รับรองรายงาน";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "100") {
			$mis_user_level = 1;
			$mis_user_level_name = "สมาชิก";
		} else {
			$mis_user_level = 0;
			$mis_user_level_name = "ผู้ใช้HOSxP";
		}
	}


	$sql = "SELECT * FROM sys_config ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$hospitalname = $data['hosp_name'];
		$hosp_shot_name = $data['shot_name'];
		$s_logo_icon1 = $data['logo_icon1'];
		$s_logo_icon2 = $data['logo_icon2'];
		$s_year = $data['yearprocess'];
		$addr = $data['addr'];
		$tmb_part = $data['tmb_part'];
		$tmb_name = $data['tmb_name'];
		$amp_part = $data['amp_part'];
		$amp_name = $data['amp_name'];
		$chw_part = $data['chw_part'];
		$chw_name = $data['chw_name'];

	}
//$myPDO = null;
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>

<?php
	switch ($_GET['kpi']) {
		case "103":
			$sidebar = 'sidebar-collapse';
			break;
		case "104":
			$sidebar = 'sidebar-collapse';
			break;
		default:
			$sidebar = '';
	}

	switch ($_GET['main']) {
		case "kpimanage":
			$sidebar = 'sidebar-collapse';
			break;
		case "reportsdetail":
			$sidebar = 'sidebar-collapse';
			break;
	}

	if (isset($_GET['exp'])) {
		$sidebar = 'sidebar-collapse';
	}

	if ($mis_user_level >= 3) {
		$sidebar = '';
	} else if ($mis_user_level >= 1) {
		$sidebar = 'sidebar-collapse';
	} else {
		$sidebar = 'sidebar-collapse';
	}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" type="image/png" href="images/logo/mistphcp-favicon.png">
  <title>MIS 4.0 <?php echo $hospitalname;?></title>

  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="bower_components/select2/dist/css/select2.min.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href="plugins/iCheck/all.css">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-colorpicker/dist/css/bootstrap-colorpicker.min.css">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="plugins/timepicker/bootstrap-timepicker.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.4.2/css/buttons.dataTables.min.css">

  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <!-- jQuery File Select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="plugins/jQuery-file-select/bootstrap-fileselect.js"></script>

</head>
<!-- ADD THE CLASS fixed TO GET A FIXED HEADER AND SIDEBAR LAYOUT -->
<!-- the fixed layout is not compatible with sidebar-mini -->
<body class="hold-transition skin-blue <?php echo $sidebar; ?> fixed sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="<?php echo $wwwurl;?>/" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img src="<?php echo $wwwurl;?>/images/logo/<?php echo $s_logo_icon1;?>" border="0" alt=""></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><img src="<?php echo $wwwurl;?>/images/logo/<?php echo $s_logo_icon2;?>" border="0" alt=""></span>
    </a>

<?php include 'main_navbar.php';?>

  </header>

<?php
	include 'main_menu.php';
	include 'main_sidebar.php';
?>

<!-- =============================================== -->
  <!-- Content Wrapper. Contains page content -->
<?php include $incmaindata;?> <!-- main_menu.php -->

<!-- =============================================== -->
        <div class="modal modal-info fade" id="modal-login2">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Login ระบบสมาชิก</h4>
              </div>
              <div class="modal-body">
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">*** HOSxP User ***</p>

    <form action="?login=<?php echo $getlogin;?>" method="post">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="ชื่อผู้ใช้" name="username" id="username" required autofocus>
		<span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="รหัสผ่าน" name="passwd" id="passwd" required>
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div>
            <!-- <label>
              <input type="checkbox"> จำรหัสผ่าน
            </label>
 -->          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">เข้าสู่ระบบ</button>
		  <input type="hidden" name="getlogin2" id="getlogin2" value="<?php echo $getlogin;?>">
		  <input type="hidden" name="link2" id="link2" value="<?php echo $link;?>">
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-box-body -->

			  </div>
              <!-- <div class="modal-footer">
                <button type="button" class="btn btn-outline" data-dismiss="modal"> ปิด </button>
              </div> -->
            </div>
            <!-- /.modal-content -->
          </div>
          <!-- /.modal-dialog -->
        </div>
        <!-- /.modal -->

<?php
	include 'main_footer.php';
	include 'main_footer_script.php';
?>

</body>
</html>

<?php
}
?>
