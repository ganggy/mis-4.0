<?php
date_default_timezone_set("Asia/Bangkok");

session_start();
$ok_login_user = $_SESSION["login_user"];

try {
	include "_cfg_mis40db.php";
	$logouttime = date("Y-m-d H:i:s");
	$sql = "UPDATE mis_user SET last_logout = '$logouttime', online_status = '0' WHERE m_login = '$ok_login_user' ";
	if ($myPDO->query($sql)) {
		echo "";
	}
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}

// session_start();
session_destroy();
?>

<!-- // OK Logout -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=/hosinfo>
</head>
<body>
<!-- OK Logout // -->
