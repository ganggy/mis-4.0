	  <div class="row">

            <div class="col-md-6">

<?php
	include 'update.php';
	include 'manual.php';
?>

			</div>


			<div class="col-md-6">

<?php
	include 'chat.php';
?>

            </div>
            <!-- /.col -->

	  </div>
