	  <div class="row">

        <section class="col-lg-7 connectedSortable">
          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <i class="fa fa-cc-visa"></i><h3 class="box-title">ค่าใช้จ่ายผู้ป่วยนอก 10 อันดับแรก (เดือนนี้)</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
				        <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#">ข้อมูลการเงิน</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
                <table class="table table-condensed table-hover">
                    <tr>
                      <th style="text-align:center"><b>รหัส</b></th>
                      <th style="text-align:center"><b>กลุ่มสิทธิรักษาพยาบาล</b></th>
                      <td style="text-align:center"><b>ผู้รับบริการ(คน/ครั้ง)</b></td>
                      <td style="text-align:right"><b>ชำระเงิน</b></td>
                      <td style="text-align:right"><b>ลูกหนี้สิทธิ</b></td>
                      <td style="text-align:right"><b>ค่าใช้จ่าย</b></td>
                    </tr>
<?php
try {
include '_cfg_hos.php';                    
    $sql5 = "SELECT v.pcode,c.name AS income_name,COUNT(DISTINCT hn) AS khon,COUNT(*) AS krung
    ,SUM(v.income) AS sum_income,SUM(v.paid_money) AS sum_paid,SUM(v.uc_money) AS sum_uc
    FROM vn_stat v
    LEFT OUTER JOIN pcode c ON c.code = v.pcode
    WHERE DATE_FORMAT(v.vstdate,'%y-%m') = DATE_FORMAT(NOW(),'%y-%m')
    GROUP BY pcode ORDER BY SUM(v.income) DESC LIMIT 10 ";
		$query5 = $myPDO->query($sql5);
		foreach($query5 as $data5) {
?>
                    <tr>
                      <td style="text-align:center"><?php echo $data5['pcode'];?></td>
                      <td><?php echo $data5['income_name'];?></td>
                      <td style="text-align:center"><?php echo $data5['khon']."/".$data5['krung'];?></td>
                      <td style="text-align:right"><?php echo number_format($data5['sum_paid'],0);?></td>
                      <td style="text-align:right"><?php echo number_format($data5['sum_uc'],0);?></td>
                      <td style="text-align:right"><?php echo number_format($data5['sum_income'],0);?></td>
                    </tr>
<?php
    }
} catch (PDOException $e) {
  echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
                </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </section>
            <!-- /.col -->

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

        <section class="col-lg-5 connectedSortable">
          <!-- Custom tabs (Charts with tabs)-->
          <div class="nav-tabs-custom">
            <!-- Tabs within a box -->
            <ul class="nav nav-tabs pull-right">
              <li class="active"><a href="#container-col2" data-toggle="tab">รายหมวด</a></li>
              <li><a href="#container-col" data-toggle="tab">เบิกได้</a></li>
              <li><a href="#container-pie" data-toggle="tab">UC</a></li>
              <li class="pull-left header"><i class="fa fa-bar-chart"></i> กราฟค่าใช้จ่าย</li>
            </ul>
            <div class="tab-content no-padding">
              <!-- Morris chart - Sales -->
              <div class="chart tab-pane active" id="container-col2" style="position: relative; height: 340px;"></div>
              <div class="chart tab-pane" id="container-col" style="position: relative; height: 340px;"></div>
              <div class="chart tab-pane" id="container-pie" style="position: relative; height: 340px;"></div>
            </div>
          </div>
          <!-- /.nav-tabs-custom -->

        </section>
	  
	  </div>
	  <!-- /.row -->

<script type="text/javascript">
Highcharts.chart('container-pie', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: ''
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.1f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Chrome',
            y: 61.41,
            sliced: true,
            selected: true
        }, {
            name: 'Internet Explorer',
            y: 11.84
        }, {
            name: 'Firefox',
            y: 10.85
        }, {
            name: 'Edge',
            y: 4.67
        }, {
            name: 'Safari',
            y: 4.18
        }, {
            name: 'Sogou Explorer',
            y: 1.64
        }, {
            name: 'Opera',
            y: 1.6
        }, {
            name: 'QQ',
            y: 1.2
        }, {
            name: 'Other',
            y: 2.61
        }]
    }]
});
</script>

<script type="text/javascript">
Highcharts.chart('container-col', {
    chart: {
        type: 'bar'
    },
    title: {
        text: ''
    },
    xAxis: {
        categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total fruit consumption'
        }
    },
    legend: {
        reversed: true
    },
    plotOptions: {
        series: {
            stacking: 'normal'
        }
    },
    series: [{
        name: 'John',
        data: [5, 3, 4, 7, 2]
    }, {
        name: 'Jane',
        data: [2, 2, 3, 2, 1]
    }, {
        name: 'Joe',
        data: [3, 4, 4, 2, 5]
    }]
});
</script>

<script type="text/javascript">
Highcharts.chart('container-col2', {

    chart: {
        type: 'column'
    },

    title: {
        text: ''
    },

    xAxis: {
        categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: 'Number of fruits'
        }
    },

    tooltip: {
        formatter: function () {
            return '<b>' + this.x + '</b><br/>' +
                this.series.name + ': ' + this.y + '<br/>' +
                'Total: ' + this.point.stackTotal;
        }
    },

    plotOptions: {
        column: {
            stacking: 'normal'
        }
    },

    series: [{
        name: 'John',
        data: [5, 3, 4, 7, 2],
        stack: 'male'
    }, {
        name: 'Joe',
        data: [3, 4, 4, 2, 5],
        stack: 'male'
    }, {
        name: 'Jane',
        data: [2, 5, 6, 2, 1],
        stack: 'female'
    }, {
        name: 'Janet',
        data: [3, 0, 4, 4, 3],
        stack: 'female'
    }]
});
</script>
