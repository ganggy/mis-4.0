<!-- // Connect DB get data record for display -->
<?php

session_start();
$ok_login_user = $_SESSION["login_user"];

try {
	include "_cfg_mis40db.php";
	$sql = "SELECT o.*,d.* FROM opduser o LEFT JOIN doctor d ON d.code = o.doctorcode WHERE o.loginname = '$ok_login_user' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$user_picture = $data['picture'];
	}
	header("content-type : image/jpeg");
	echo $user_picture;

}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>
<!--  Connect DB get data record for display // -->
