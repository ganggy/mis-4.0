<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        MIS 4.0 Dashboard <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>


    <!-- Main content -->
    <section class="content">

<?php
	include 'index_dashboard_info.php';
	include 'index_module_addon.php';
?>

	  <div class="row">
      <div class="col-md-6">

<?php
	include 'update.php';
?>

			</div>
			<div class="col-md-6">

<?php
	include 'manual.php';
?>

      </div>
            <!-- /.col -->
	  </div>
	  <!-- /.row -->


    </section>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

