<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">รายชื่อประชากร</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="DataTableExport" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>cid</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>วันเกิด</th>
                  <th>อายุ</th>
                  <th>เพศ</th>
                  <th>บ้านเลขที่</th>
                  <th>ถนน</th>
                  <th>หมู่</th>
                  <th>ชื่อหมู่บ้าน</th>
                  <th>ที่อยู่</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT p.cid,p.pname,p.fname,p.lname,p.birthdate,TIMESTAMPDIFF(YEAR,p.birthdate,NOW()) AS age,s.name AS sexname,h.address,h.road,v.village_moo,v.village_name,t.full_name
					FROM person p
					LEFT JOIN house h ON h.house_id = p.house_id
					LEFT JOIN village v ON v.village_id = h.village_id
					LEFT JOIN thaiaddress t ON t.addressid = v.address_id
					LEFT JOIN sex s ON s.code = p.sex
					WHERE p.death <> 'Y' AND p.house_regist_type_id IN (1,3) ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['birthdate']."</td>";
			echo "<td>".$data['age']."</td>";
			echo "<td>".$data['sexname']."</td>";
			echo "<td>".$data['address']."</td>";
			echo "<td>".$data['road']."</td>";
			echo "<td>".$data['village_moo']."</td>";
			echo "<td>".$data['village_name']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
