<?php

$uname = $_POST['username'];
$pword = md5($_POST['passwd']);

try {
	include "_cfg_mis40db.php";
	$sql = "SELECT * FROM opduser WHERE loginname = '$uname' AND passweb = '$pword' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		session_start();
		$_SESSION["login_user"] = $data['loginname'];
		$_SESSION["login_name"] = $data['name'];
		session_write_close();
?>

<!-- // OK Login -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=/mis/>
</head>
<body>
<!-- OK Login // -->

<?php
 }
?>


	<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        MIS-TPHCP
        <small>ระบบสารสนเทศเพื่อการจัด (Management Information System)</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/mis/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ภาพรวม</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
<div class="login-box">
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">เข้าสู้ระบบสมาชิกเพื่อเริ่มใช้งาน</p>

    <form action="?main=login" method="post">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="ชื่อผู้ใช้" name="username" id="username">
        <span class="glyphicon glyphicon-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="รหัสผ่าน" name="passwd" id="passwd">
        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div>
            <label>
              <input type="checkbox"> จำรหัสผ่าน
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-4">
          <button type="submit" class="btn btn-primary btn-block btn-flat">เข้าสู่ระบบ</button>
        </div>
        <!-- /.col -->
      </div>
    </form>

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' /* optional */
    });
  });
</script>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>
