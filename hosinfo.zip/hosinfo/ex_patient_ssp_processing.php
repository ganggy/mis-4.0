<?php
	
include "_mysqli_hos.php";

$params = $columns = $totalRecords = $data = array();
$params = $_REQUEST;
$columns = array(	//for ORDER BY
	0 => 'cid',
	1 => 'hn',
	2 => 'ptname',
	3 => 'birthday',
	4 => 'age',
	5 => 'sexname',
	6 => 'addrpart',
	7 => 'road',
	8 => 'moopart',
	9 => 'full_name'
);

$where_condition = $sqlTot = $sqlRec = "";

// for WHERE from SEARCH
if( !empty($params['search']['value']) ) {
	$where_condition .= " AND ( p.cid LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR p.hn LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR p.fname LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR p.road LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR t.full_name LIKE '%".$params['search']['value']."%' )";
}

// NO Thai text in Query
$sql_query = "SELECT p.cid,p.hn,concat(p.pname,p.fname,' ',p.lname) as ptname,p.birthday,TIMESTAMPDIFF(YEAR,p.birthday,NOW()) AS age,s.name AS sexname,p.addrpart,p.road,p.moopart,t.full_name
					FROM patient p
					LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
					LEFT JOIN sex s ON s.code = p.sex
					WHERE p.death <> 'Y' ";
$sqlTot .= $sql_query;
$sqlRec .= $sql_query;

if(isset($where_condition) && $where_condition != '') {
	$sqlTot .= $where_condition;
	$sqlRec .= $where_condition;
}

$sqlRec .=  " ORDER BY ". $columns[$params['order'][0]['column']]."   ".$params['order'][0]['dir']."  LIMIT ".$params['start']." ,".$params['length']." ";

$queryTot = mysqli_query($con, $sqlTot) or die("Database Error:". mysqli_error($con));
$totalRecords = mysqli_num_rows($queryTot);
$queryRecords = mysqli_query($con, $sqlRec) or die("Error to Get the Post details.");

while( $row = mysqli_fetch_row($queryRecords) ) {
	$data[] = $row;
}

$json_data = array(
	"draw" => intval( $params['draw'] ),
	"recordsTotal" => intval( $totalRecords ),
	"recordsFiltered" => intval($totalRecords),
	"data" => $data
);

echo json_encode($json_data);

?>