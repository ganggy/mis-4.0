<?php

// QUESTION

if ($_POST['submit_chat'] == "question") {
$postusername = $_POST['login_user'];
$questiontext = $_POST['questiontext'];
try {
	include "_cfg_mis40db.php";
	$update = date("Y-m-d H:i:s");

	$sql = "	INSERT INTO chat (questiontext,chatdate,chatuser) VALUES ('".$_POST['questiontext']."','".$update."','".$_POST['login_user']."') ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('เรียบร้อยแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}
?>

<!-- // Login not OK -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=/>
</head>
</body>
</html>
<!-- Login not OK // -->

<?php
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();
}

// กรณีต้องการตรวจสอบการแจ้ง error ให้เปิด 3 บรรทัดล่างนี้ให้ทำงาน กรณีไม่ ให้ comment ปิดไป
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
// กรณีมีการเชื่อมต่อกับฐานข้อมูล
//require_once("dbconnect.php");
 
$accToken = "Q7ekj0hKxXyJSjGpKoinle3HcopFuAkja2fe3AO406E";
$notifyURL = "https://notify-api.line.me/api/notify";
 
$headers = array(
    'Content-Type: application/x-www-form-urlencoded',
    'Authorization: Bearer '.$accToken
);
$data = array(
    'message' => "คุณ ".$postusername." แจ้งปัญหา MIS -> ".$questiontext." ".$update.""
);
 
// ส่วนของการส่งการแจ้งเตือนผ่านฟังก์ชั่น cURL
$ch = curl_init();
curl_setopt( $ch, CURLOPT_URL, $notifyURL);
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0); // ถ้าเว็บเรามี ssl สามารถเปลี่ยนเป้น 2
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0); // ถ้าเว็บเรามี ssl สามารถเปลี่ยนเป้น 1
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec( $ch );
curl_close( $ch );
 
// ตรวจสอบค่าข้อมูล ว่าเป็นตัวแปร ปรเภทไหน ข้อมูลอะไร
var_dump($result);
 
// การเช็คสถานะการทำงาน 
$result = json_decode($result,TRUE);
// ดูโครงสร้าง กรณีแปลงเป็น array แล้ว
//echo "<pre>";
//print_r($result);
 
// ตรวจสอบข้อมูล ใช้เป็นเงื่อนไขในการทำงาน
if(!is_null($result) && array_key_exists('status',$result)){
    if($result['status']==200){
        echo "Pass";
    }
}

} else {}


// ANSWER

if ($_POST['submit_chat'] == "answer") {

try {
	include "_cfg_mis40db.php";
	$update = date("Y-m-d H:i:s");

	$sql = "UPDATE chat SET answertext='".$_POST['answertext']."',ansdate='".$update."' WHERE id='".$_POST['c_id']."' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลสำเร็จ');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}
?>

<!-- // Login not OK -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=/>
</head>
</body>
</html>
<!-- Login not OK // -->

<?php
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();
}

} else {}

?>
