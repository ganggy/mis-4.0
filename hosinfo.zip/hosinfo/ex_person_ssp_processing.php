<?php
	
include "_mysqli_hos.php";

$params = $columns = $totalRecords = $data = array();
$params = $_REQUEST;
$columns = array(	//for ORDER BY
	0 => 'cid',
	1 => 'ptname',
	2 => 'birthdate',
	3 => 'age',
	4 => 'sexname',
	5 => 'address',
	6 => 'road',
	7 => 'village_moo',
	8 => 'village_name',
	9 => 'full_name'
);

$where_condition = $sqlTot = $sqlRec = "";

// for WHERE from SEARCH
if( !empty($params['search']['value']) ) {
	$where_condition .= " AND ( p.cid LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR p.fname LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR p.lname LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR v.village_name LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR h.road LIKE '%".$params['search']['value']."%' ";
	$where_condition .= " OR t.full_name LIKE '%".$params['search']['value']."%' )";
}

// NO Thai text in Query
$sql_query = "SELECT p.cid,CONCAT(p.pname,p.fname,'  ',p.lname) AS ptname,p.birthdate,TIMESTAMPDIFF(YEAR,p.birthdate,NOW()) AS age
					,s.name AS sexname,h.address,h.road,v.village_moo,v.village_name,t.full_name
					FROM person p
					LEFT JOIN house h ON h.house_id = p.house_id
					LEFT JOIN village v ON v.village_id = h.village_id
					LEFT JOIN thaiaddress t ON t.addressid = v.address_id
					LEFT JOIN sex s ON s.code = p.sex
					WHERE p.death <> 'Y'";
$sqlTot .= $sql_query;
$sqlRec .= $sql_query;

if(isset($where_condition) && $where_condition != '') {
	$sqlTot .= $where_condition;
	$sqlRec .= $where_condition;
}

$sqlRec .=  " ORDER BY ". $columns[$params['order'][0]['column']]."   ".$params['order'][0]['dir']."  LIMIT ".$params['start']." ,".$params['length']." ";

$queryTot = mysqli_query($con, $sqlTot) or die("Database Error:". mysqli_error($con));
$totalRecords = mysqli_num_rows($queryTot);
$queryRecords = mysqli_query($con, $sqlRec) or die("Error to Get the Post details.");

while( $row = mysqli_fetch_row($queryRecords) ) {
	$data[] = $row;
}

$json_data = array(
	"draw" => intval( $params['draw'] ),
	"recordsTotal" => intval( $totalRecords ),
	"recordsFiltered" => intval($totalRecords),
	"data" => $data
);

echo json_encode($json_data);

?>