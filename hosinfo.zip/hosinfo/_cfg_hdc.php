<?php
$host = "203.157.x.x";
$user = "user";
$pwd = "password";
$db = "hdc";

$myPDO = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
$myPDO -> exec("set names utf8");
$myPDO -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>