<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">รายชื่อประชากร</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>cid</th>
                  <th>hn</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>วันเกิด</th>
                  <th>อายุ</th>
                  <th>เพศ</th>
                  <th>บ้านเลขที่</th>
                  <th>ถนน</th>
                  <th>หมู่</th>
                  <th>ที่อยู่</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		require_once("_cfg_hos.php");
		// คำสั่ง SQL
		$sql = "SELECT p.cid,p.pname,p.fname,p.lname,p.birthday,TIMESTAMPDIFF(YEAR,p.birthday,NOW()) AS age,s.name AS sexname,p.addrpart,p.road,p.moopart,t.full_name
					FROM patient p
					LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
					LEFT JOIN sex s ON s.code = p.sex
					WHERE p.death <> 'Y' ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['birthdate']."</td>";
			echo "<td>".$data['age']."</td>";
			echo "<td>".$data['sexname']."</td>";
			echo "<td>".$data['addrpart']."</td>";
			echo "<td>".$data['road']."</td>";
			echo "<td>".$data['moopart']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
