<?php
if ($login_ok == 1) {

if ($_POST['submitsearch'] == "submitcid") {
	$ptcid = " p.cid = '".str_replace("-","",$_POST['cid'])."'";
} else {
	$ptcid = " p.hn = '".$_POST['hn']."'";
}

if ($_POST['searchfor'] == "hdc") {
	$ptcid = " p.cid = '".$_POST['info_cid_hdc']."'";
}

if ($_POST['searchfor'] == "hos") {
	$ptcid = " p.cid = '".$_POST['info_cid_hdc']."'";
}

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        SEARCH :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Search Lab</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">ค้นหารายการตรวจทางห้องปฏิบัติการ </h3><!-- LOSARTAN (icode 1520549) -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">

			<div class="row">
				<div class="col-sm-3">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-search"></i><h3 class="box-title">ค้นหา</h3>
						</div>
						<div class="box-footer text-black">
						<div>ค้นหาด้วยเลขประจำตัวประชาชน หรือเลขที่โรงพยาบาล
						</div>
<form method="post" name="search_form" action="<?php echo $PHP_SELF ?>">

						  <div class="form-group">
							  <div class="input-group">
								<div class="input-group-addon">
										<i class="fa fa-credit-card"></i>
								</div>
								<input type="text" name="cid" class="form-control" data-inputmask='"mask": "9-9999-99999-99-9"' data-mask>
									<span class="input-group-btn">
									  <button type="submit" name="submitsearch" value="submitcid" class="btn btn-info btn-flat"> ค้นหาด้วย CID </button>
									</span>
							  </div>
						  </div>

						  <div class="form-group">
							  <div class="input-group">
								<div class="input-group-addon">
										<i class="fa fa-list-alt"></i>
								</div>
								<input type="text" name="hn" class="form-control" data-inputmask='"mask": "999999999"' data-mask>
									<span class="input-group-btn">
									  <button type="submit" name="submitsearch" value="submithn" class="btn btn-success btn-flat"> ค้นหาด้วย HN </button>
									</span>
							  </div>
						  </div>

</form>
						</div>
					</div>



<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT p.hn,p.cid,p.pname,p.fname,p.lname,p.birthday,p.fathername,p.mathername,p.addrpart,p.road,p.moopart,t.full_name,p.last_visit
			FROM patient p LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart) WHERE $ptcid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$info_hn = $data[hn];
			$info_cid = $data[cid];
			$info_last_visit = $data[last_visit];
			$info_name = $data[pname]."".$data[fname]."  ".$data[lname];
			$info_birthday = $data[birthday];
			$info_fathername = $data[fathername];
			$info_mathername = $data[mathername];
			$info_address = $data[addrpart]." ".$data[road]." ม.".$data[moopart]." ".$data[full_name];
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle text-black" style="background-color: #ffcc00;">
							<i class="fa fa-user"></i><h3 class="box-title">ข้อมูลคนไข้</h3>
						</div>
						<div class="box-footer text-black">

              <table class="table table-hover">
                <tr>
                  <th class='text-right'>ชื่อ - สกุล :</th>
                  <th><?php echo $info_name; ?></th>
                </tr>
                <tr>
                  <td class='text-right'>HN :</td>
                  <td><?php echo $info_hn; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>CID :</td>
                  <td><?php echo $info_cid; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>วันเกิด :</td>
                  <td><?php echo DateThaiFull($info_birthday); ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ชื่อบิดา :</td>
                  <td><?php echo $info_fathername; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ชื่อมารดา :</td>
                  <td><?php echo $info_mathername; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ที่อยู่ :</td>
                  <td><?php echo $info_address; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>รับบริการครั้งล่าสุด :</td>
                  <td><?php echo DateThaiFull($info_last_visit); ?></td>
                </tr>
              </table>
						
						</div>
					</div>

<?php 
if ($info_cid == "") {
} else {
if ($_POST['searchfor'] == "hdc") {
?>

	<form method="post" name="search_form" action="<?php echo $PHP_SELF ?>">
	<div class="form-group">
		<div class="input-group">
		<input type="hidden" name="info_cid_hdc" value="<?php echo $info_cid; ?>">
			<span class="input-group-btn">
				<button type="submit" name="searchfor" value="hos" class="btn btn-block btn-success btn-lg">ดูผล LAB จาก <?php echo $hosp_shot_name;?></button>
			</span>
		</div>
	</div>
	</form>

<?php
} else {
?>

	<form method="post" name="search_form" action="<?php echo $PHP_SELF ?>">
	<div class="form-group">
		<div class="input-group">
		<input type="hidden" name="info_cid_hdc" value="<?php echo $info_cid; ?>">
			  <span class="input-group-btn">
				<button type="submit" name="searchfor" value="hdc" class="btn btn-block btn-primary btn-lg">*** ดูผล LAB จาก HDC ***</button>
			  </span>
		</div>
	</div>
	</form>

<?php
}
}
?>

				</div>



<?php 
if ($_POST['searchfor'] == "hdc") {
	$info_cid_hdc = $_POST['info_cid_hdc'];
?>
				<div class="col-sm-9">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #0080c0;">
							<i class="fa fa-eyedropper"></i><h3 class="box-title">รายการตรวจจาก >>> HDC</h3>
						</div>
						<div class="box-footer text-black">
              <table id="DataTableT1" class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                  <th class='text-center'>วันที่ตรวจ</th>
                  <th class='text-center'>LABTEST</th>
                  <th class='text-center'>รายการ LAB</th>
                  <th class='text-center'>ผลตรวจ</th>
                  <th class='text-center'>LastUpdate</th>
                  <th class='text-center'>สถานพยาบาลที่ส่งข้อมูล</th>
                  <th class='text-center'>สถานพยาบาลที่ตรวจ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hdc.php";
		$sql = "SELECT l.HOSPCODE,h.hosname AS hosname1,l.LABPLACE,h2.hosname AS hosname2,l.DATE_SERV,l.D_UPDATE,l.LABTEST,lc.EN,lc.TH,l.LABRESULT
		FROM labfu l
		LEFT OUTER JOIN clabtest_new lc ON lc.`code` = l.LABTEST
		LEFT OUTER JOIN chospital h ON h.hoscode = l.HOSPCODE
		LEFT OUTER JOIN chospital h2 ON h2.hoscode = l.LABPLACE
		WHERE l.CID = '$info_cid_hdc' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {

			echo "<tr>";
			echo "<td>".$data['DATE_SERV']."</td>";
			echo "<td>".$data['LABTEST']."</td>";
			echo "<td>".$data['TH']."</td>";
			echo "<td class='text-center'>".$data['LABRESULT']."</td>";
			echo "<td>".$data['D_UPDATE']."</td>";
			echo "<td>".$data['hosname1']."</td>";
			echo "<td>".$data['hosname2']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
              </table>
						</div>
					</div>
				</div>
<?php
} else {
?>

				<div class="col-sm-9">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #009900;">
							<i class="fa fa-eyedropper"></i><h3 class="box-title">รายการตรวจจาก >>> <?php echo $hosp_shot_name;?></h3>
						</div>
						<div class="box-footer text-black">
              <table id="DataTable" class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                  <th class='text-center'>วันที่สั่ง</th>
                  <th class='text-center'>รายการ LAB</th>
                  <th class='text-center'>ค่าปกติ</th>
                  <th class='text-center'>min-max</th>
                  <th class='text-center'>ผลตรวจ</th>
                  <th class='text-center'>วันที่รายงานผล</th>
                  <th class='text-center'>ยืนยันผล</th>
                  <th class='text-center'>ผู้รายงาน</th>
                  <th class='text-center'>ผู้ตรวจสอบ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hosmain.php";
		$sql = "SELECT h.order_date,o.lab_items_code,h.report_date,h.lab_order_number,h.hn,h.vn,o.lab_items_name_ref
,o.lab_items_normal_value_ref,o.lab_order_result,h.reporter_name,h.approve_staff,o.confirm,h.department
,IF(REPLACE(o.lab_order_result,',','') < i.range_check_min OR REPLACE(o.lab_order_result,',','') > i.range_check_max OR REPLACE(o.lab_order_result,',','') = 'Positive',1,0 ) AS range_check2
,i.range_check_min,i.range_check_max
,concat(i.range_check_min,'-',i.range_check_max) AS normal_num
FROM lab_head h
LEFT OUTER JOIN lab_order o ON o.lab_order_number = h.lab_order_number
LEFT OUTER JOIN lab_items i ON i.lab_items_code = o.lab_items_code
WHERE hn = '$info_hn' AND o.lab_items_code NOT IN (SELECT lab_items_code FROM lab_items WHERE lab_items_name LIKE '%hiv%') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			if ($data['confirm'] == "Y") {
				$confirm = "<span class='label label-success'>".$data['confirm']."</span>";
			} else {
				$confirm = "<font color='#ff0000'>".$data['confirm']."</font>";
			}

			if ($data['department'] == "IPD") {
				$c_order_date = "<font color='#ff0000'>".$data['order_date']."</font>";
			} else {
				$c_order_date = "".$data['order_date']."";
			}

			IF ($data['range_check2'] == 1) {
				$result_color_a = "<span class='label label-danger' style='font-size:1em;'><b><font size='4' color='#ffffff'>";
				$result_color2_a = "<b><font size='4' color='#ff0000'>";
				$result_color_b = "</font></b></span>";
			} else {
				$result_color_a = "<b><font size='4' color='#009900'>";
				$result_color2_a = "";
				$result_color_b = "</font></b>";
			}

			echo "<tr>";
			echo "<td>".$c_order_date."</td>";
			echo "<td>".$result_color2_a.$data['lab_items_name_ref'].$result_color_b."</span></td>";
			echo "<td>".$data['lab_items_normal_value_ref']."</td>";
			echo "<td>".$data['range_check_min']."-".$data['range_check_max']."</td>";
			echo "<td class='text-center'>".$result_color_a.$data['lab_order_result'].$result_color_b."</td>";
			echo "<td class='text-center'>".$data['report_date']."</td>";
			echo "<td class='text-center'>".$confirm."</td>";
			echo "<td>".$data['reporter_name']."</td>";
			echo "<td>".$data['approve_staff']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
              </table>
						</div>
					</div>
				</div>

<?php
}
?>

			</div>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
