<?php
if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

<?php

	try {
		include "_cfg_hos.php";
		// คำสั่ง SQL
		$sql1 = "SELECT COUNT(*) AS uc_count,SUM(IF(v.inc17 = 0,1,0)) AS uc_count30 FROM ovst o
					LEFT JOIN vn_stat v ON v.vn = o.vn
					LEFT JOIN patient p ON p.hn = o.hn
					WHERE o.vstdate BETWEEN DATE_ADD(NOW(),INTERVAL - 7 DAY) AND NOW()
					AND v.pcode = 'UC'
					AND o.an IS NULL ";
		$query1 = $myPDO->query($sql1);
		foreach($query1 as $data1) {
			$uc_count = $data1['uc_count'];
			$uc_count30 = $data1['uc_count30'];
		}
	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ผู้รับบริการ UC ไม่เก็บค่าธรรมเนียม 30 บาท
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li><a href="#">Pt UC ไม่เก็บค่าธรรมเนียม</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">ไม่ได้เก็บค่าธรรมเนียม <b><?php echo $uc_count30;?></b> คน จากผู้รับบริการ UC ทั้งหมด <b><?php echo $uc_count;?></b> คน (ย้อนหลัง 7 วัน)</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="DataTable" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>วันที่รับบริการ</th>
                  <th>เวลา</th>
                  <th>HN</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>เลขที่บัตรสิทธิ</th>
                  <th>แผนกที่รับบริการ</th>
                  <th>ผู้ให้บริการ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		// คำสั่ง SQL
		$sql = "SELECT p.*,o.*,v.* FROM ovst o
					LEFT JOIN vn_stat v ON v.vn = o.vn
					LEFT JOIN patient p ON p.hn = o.hn
					WHERE o.vstdate BETWEEN DATE_ADD(NOW(),INTERVAL - 7 DAY) AND NOW()
					AND v.pcode = 'UC' AND v.inc17 = 0
					AND o.an IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['vstdate']."</td>";
			echo "<td>".$data['vsttime']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['pname']."".$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['pttypeno']."</td>";
			echo "<td>".$data['main_dep']."</td>";
			echo "<td>".$data['staff']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } ?>