<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">ผู้รับบริการที่รับยา </h3><!-- LOSARTAN (icode 1520549) -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">

  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
            <div class="box-body">
              <div class="row">
					<div class="form-group">
					  <label for="cxrdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
					</div>
					<?php
						$date1d = substr($_POST['cxrdaterange'],3,2);
						$date1m = substr($_POST['cxrdaterange'],0,2);
						$date1y = substr($_POST['cxrdaterange'],6,4);
						$date2d = substr($_POST['cxrdaterange'],16,2);
						$date2m = substr($_POST['cxrdaterange'],13,2);
						$date2y = substr($_POST['cxrdaterange'],19,4);

						$cxrdate1 = $date1y."-".$date1m."-".$date1d;
						$cxrdate2 = $date2y."-".$date2m."-".$date2d;
						$icode = $_POST['icode'];
					?>

					<div class="form-group">

                <select name="icode" class="form-control select2" style="width: 100%;">
                  <option selected="selected">= = = = = = = = = = = = = เลือกรายการยาที่ต้องการ = = = = = = = = = = = = =</option>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT icode,CONCAT(name,' ',strength,' ',units,' ',dosageform) AS drugname FROM drugitems";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<option value = '".$row[icode]."'>".$row[drugname]."</option>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                </select>


					  <!-- <input type="text" class="form-control" id="icode" placeholder="ใส่ icode ของยา" name="icode"> -->
					</div>
					<button type="submit" class="btn btn-default"> ประมวลผล </button>
	&nbsp;(ประมวลผลช่วงวันที่ <b><?php echo $cxrdate1." - ".$cxrdate2; ?></b> icode : <b><?php echo $icode; ?></b>)
              </div>
            </div>
  </form>


              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>hn</th>
                  <th>วันที่รับบริการ</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ที่อยู่</th>
                  <!-- <th>ที่อยู่2</th> -->
                  <th>เบอร์โทรศัพท์</th>
                  <th>ยา</th>
                  <th>จำนวนจ่าย</th>
                  <th>แพทย์ผู้ตรวจ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT DISTINCT(o.hn),GROUP_CONCAT(o.vstdate) AS vstdate,p.pname,p.fname,p.lname
		,p.addrpart,p.road,p.moopart,t.full_name AS address_full,p.informaddr AS inform_address
		,p.hometel,p.informtel,p.worktel,p.email
		,p.clinic,o.icode,d.name AS drugname,GROUP_CONCAT(o.qty) AS qty,GROUP_CONCAT(c.name) AS doctor_name

		FROM opitemrece o
		LEFT OUTER JOIN patient p ON p.hn = o.hn
		LEFT OUTER JOIN drugitems d ON d.icode = o.icode
		LEFT OUTER JOIN doctor c ON c.`code` = o.doctor
		LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)

		WHERE o.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' AND p.death <> 'Y'
		AND o.icode = '$icode'

		GROUP BY o.hn  ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['vstdate']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['addrpart']." ".$data['road']." ม.".$data['moopart']." ".$data['address_full']."</td>";
			//echo "<td>".$data['inform_address']."</td>";
			echo "<td>".$data['hometel'].", ".$data['informtel'].", ".$data['worktel']."</td>";
			echo "<td>".$data['drugname']."</td>";
			echo "<td>".$data['qty']."</td>";
			echo "<td>".$data['doctor_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
