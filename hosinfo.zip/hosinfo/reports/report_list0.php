<?php
if ($login_ok == 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        สถิติและรายงาน
        <small>รพร.ตะพานหิน</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ประมวลผลจากฐานข้อมูล HOSxP</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-info">
              <li class="active"><a href="#tab_1-1" data-toggle="tab">[ ทั้งหมด รายงาน ]</a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  เลือกกลุ่มรายงาน <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
<?php
	try {
		//require_once("_cfg_mis40db.php");
		$sql = "SELECT * FROM sys_rep_cat ";
		$query = $myPDO->query($sql);
			echo "<li role='presentation'>";

		foreach($query as $data) {
			echo "<a role='menuitem' tabindex='-1' href=?main=reports&repgid=".$data['id'].">".$data['rep_cat']."</a>";
		}
			echo "</li>";
//$myPDO = null;
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="?main=reports">ทั้งหมด</a></li>
                </ul>
              </li>
              <li class="pull-left header"><i class="fa fa-files-o"></i> 
			  แสดงรายงานทั้งหมด  ตัว
			  </li>
            </ul>
            <div class="tab-content">
			<div>
              <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<form class="form-inline" method="post" action="<? echo $PHP_SELF ?>">
              <!-- Date and time range -->
              <div class="form-group">
                <label>ประมวลผลช่วงวันที่ : </label>
                <div class="input-group">
                  <input type="text" class="btn btn-default pull-right" id="daterange-btn" name="dateselect">
                </div>
              </div>
              <!-- /.form group -->
<?php
$date1d = substr($_POST['dateselect'],3,2);
$date1m = substr($_POST['dateselect'],0,2);
$date1y = substr($_POST['dateselect'],6,4);
$date2d = substr($_POST['dateselect'],16,2);
$date2m = substr($_POST['dateselect'],13,2);
$date2y = substr($_POST['dateselect'],19,4);

$fulldate1 = $date1y."-".$date1m."-".$date1d;
$fulldate2 = $date2y."-".$date2m."-".$date2d;
/*
	try {
		require_once("_cfg_content.php");
		$sql = "SELECT * FROM depart WHERE dp_status NOT IN (1,-1)";
		$query = $myPDO->query($sql);
			echo "<select class='btn btn-default select2' id='user_department' name='user_department'>";

		foreach($query as $data) {
			if ($data['id'] == $mis_u_m_depart) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['id']."'".$eselected.">".$data['dp_name']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
*/
?>

                <div class="input-group">
                <select class="form-control select2" multiple="multiple" data-placeholder="เลือก Type Area" style="width: 100%;">
                  <option value="1">[1] มีชื่ออยู่ตามทะเบียนบ้านในเขตและอยู่จริง</option>
                  <option value="2">[2] มีชื่ออยู่ตามทะเบียนบ้านในเขตแต่ตัวไม่อยู่จริง</option>
                  <option value="3">[3] มาอาศัยอยู่ในเขตแต่ทะเบียนบ้านอยู่นอกเขต</option>
                  <option value="4">[4] บุคคลนอกเขตรับผิดชอบ</option>
                  <option value="5">[5] คนเร่ร่อนไม่มีที่พักอาศัย</option>
                </select>
              </div>
              <!-- /.form-group -->
              <div class="input-group">
                <label><input type="radio" name="typearea" value="1" class="minimal" checked> ในเขต </label>
                <label><input type="radio" name="typearea" value="0" class="minimal-red"> นอกเขต</label>
              </div>

			  <button type="submit" class="btn btn-default"> ประมวลผล </button> <?php echo "('".$fulldate1."' - '".$fulldate2."')";?>
</form>
			</div>

              <table id="DataTable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>vdate</th>
                  <th>cid</th>
                  <th>hn</th>
                  <th>vnan</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>เพศ</th>
                  <th>วันเกิด</th>
                  <th>อายุ</th>
                  <th>บ้านเลขที่</th>
                  <th>ซอย</th>
                  <th>ถนน</th>
                  <th>หมู่</th>
                  <th>ที่อยู่</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		require_once("_cfg_hosmain.php");
		// คำสั่ง SQL
		$sql = "SELECT t.* FROM (

SELECT v.vstdate AS vdate,p.cid,v.hn,v.vn AS vnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department

FROM vn_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.vn
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.vstdate BETWEEN '$fulldate1' AND '$fulldate2'
AND x.xray_list LIKE 'CXR%'

UNION

SELECT v.regdate AS vdate,p.cid,v.hn,v.an AS hnan,p.pname,p.fname,p.lname,p.sex,CONCAT(DATE_FORMAT(p.birthday,'%d/%m/'),DATE_FORMAT(p.birthday,'%Y')+543) AS bdate
,p.addrpart,p.addr_soi,p.road,p.moopart,p.chwpart,p.amppart,p.tmbpart,t.full_name,v.age_y AS age_at_visit
,v.pdx,v.dx0,v.dx1,v.dx2,v.dx3,v.dx4,v.dx5,x.xray_list,x.department

FROM an_stat v
LEFT JOIN patient p ON p.hn = v.hn
LEFT JOIN xray_head x ON x.vn = v.an
LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
WHERE v.regdate BETWEEN '$cxrdate1' AND '$cxrdate2'
AND x.xray_list LIKE 'CXR%'
) AS t

ORDER BY t.hn ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['vdate']."</td>";
			echo "<td>".$data['cid']."</td>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['vnan']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['sex']."</td>";
			echo "<td>".$data['bdate']."</td>";
			echo "<td>".$data['age_at_visit']."</td>";
			echo "<td>".$data['addrpart']."</td>";
			echo "<td>".$data['addr_soi']."</td>";
			echo "<td>".$data['road']."</td>";
			echo "<td>".$data['moopart']."</td>";
			echo "<td>".$data['full_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php } else {include 'error505.php';} ?>