<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php

if ($_POST['submit_rep'] == "create") {

echo $_POST['rep_name'];
$last_update = date("Y-m-d H:i:s");

if(isset($_POST['rep_where_selecter'])){
	$getInput = $_POST['rep_where_selecter'];
	$selectedOption = "";
	foreach ($getInput as $option => $value) {
		$selectedOption .= $value;
	}
	$rep_where_selecter = $selectedOption; 
}

try {
	include "_cfg_mis40db.php";
	$sql = "INSERT INTO rep_reports (rep_code,rep_name,rep_column,rep_sql1,rep_sql2,rep_sql3,rep_sql4,rep_where,rep_where_fdatename,rep_where_selecter,rep_groupby,rep_user_reporter,rep_user_request,rep_update,rep_cat,rep_template,rep_status)
	VALUES ('".$_POST['rep_code']."','".$_POST['rep_name']."','".$_POST['rep_column']."','".$_POST['rep_sql1']."','".$_POST['rep_sql2']."','".$_POST['rep_sql3']."','".$_POST['rep_sql4']."','".$_POST['rep_where']."','".$_POST['rep_where_fdatename']."','".$rep_where_selecter."','".$_POST['rep_groupby']."','".$ok_login_user."','".$_POST['rep_user_request']."','".$last_update."','".$_POST['rep_cat']."','".$_POST['rep_template']."','1') ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('เพิ่มรายงานแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>


<?php

if ($_POST['submit_rep'] == "update") {

$last_update = date("Y-m-d H:i:s");
$sql1string = htmlspecialchars($_POST['rep_sql1']);

if(isset($_POST['rep_where_selecter'])){
	$getInput = $_POST['rep_where_selecter'];
	$selectedOption = "";
	foreach ($getInput as $option => $value) {
		$selectedOption .= $value;
	}
	$rep_where_selecter = $selectedOption; 
}

try {
	include "_cfg_mis40db.php";
	$sql = "UPDATE rep_reports SET rep_name='".$_POST['rep_name']."',rep_column='".$_POST['rep_column']."',rep_sql1='".$sql1string."'
	,rep_sql2='".$_POST['rep_sql2']."',rep_sql3='".$_POST['rep_sql3']."',rep_sql4='".$_POST['rep_sql4']."',rep_where='".$_POST['rep_where']."'
	,rep_where_fdatename='".$_POST['rep_where_fdatename']."',rep_where_selecter='".$rep_where_selecter."',rep_groupby='".$_POST['rep_groupby']."'
	,rep_user_request='".$_POST['rep_user_request']."',rep_cat='".$_POST['rep_cat']."',rep_template='".$_POST['rep_template']."'
	,rep_update='".$last_update."' WHERE repid='".$_POST['repid']."' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลสำเร็จ');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<?php

if ($_GET['submit'] == "delete") {

$repid = $_GET['repid'];

try {
	include "_cfg_mis40db.php";
	$sql = "DELETE FROM rep_reports WHERE repid='$repid'; ";
	$myPDO->exec($sql);
		echo "<script type= 'text/javascript'>alert('ลบข้อมูลเรียบร้อยแล้ว');</script>";
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL="<?php echo $wwwurl;?>/?main=reports">
</head>
<body>
</body>
</html>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
