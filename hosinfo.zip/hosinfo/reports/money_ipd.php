<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">สรุปค่าใช้จ่ายผู้ป่วยใน </h3><!-- LOSARTAN (icode 1520549) -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">

  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
            <div class="box-body">
              <div class="row">
					<div class="form-group">
					  <label for="cxrdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
					</div>
					<?php
						$date1d = substr($_POST['cxrdaterange'],3,2);
						$date1m = substr($_POST['cxrdaterange'],0,2);
						$date1y = substr($_POST['cxrdaterange'],6,4);
						$date2d = substr($_POST['cxrdaterange'],16,2);
						$date2m = substr($_POST['cxrdaterange'],13,2);
						$date2y = substr($_POST['cxrdaterange'],19,4);

						$cxrdate1 = $date1y."-".$date1m."-".$date1d;
						$cxrdate2 = $date2y."-".$date2m."-".$date2d;
						$icode = $_POST['icode'];
					?>

					<button type="submit" class="btn btn-default"> ประมวลผล </button>
	&nbsp;(ประมวลผลช่วงวันที่ <b><?php echo $cxrdate1." - ".$cxrdate2; ?></b>)
              </div>
            </div>
  </form>

  <table id="DataTableExport2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
                        <th colspan='2' scope='col'></th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
        FROM income_group g
        LEFT OUTER JOIN income i ON i.income_group = g.income_group
        GROUP BY g.income_group
        ORDER BY g.income_group ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th colspan='2' scope='col' class='text-center'>".$row['group_name']."</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th colspan='2' scope='col' class='text-center'>รวม</th>
					  </tr>
					  <tr class="info">
                        <th scope='col' class='text-center'>pcode</th>
                        <th scope='col' class='text-center'>กลุ่มสิทธิ์</th>
                        <th scope='col' class='text-center'>pttype</th>
                        <th scope='col' class='text-center'>สิทธิ์ย่อย</th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
        FROM income_group g
        LEFT OUTER JOIN income i ON i.income_group = g.income_group
        GROUP BY g.income_group
        ORDER BY g.income_group ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th scope='col' class='text-center'>".$row['group_name']." (ครั้ง)</th>";
            echo "<th scope='col' class='text-center'>ค่าใช้จ่าย</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th scope='col' class='text-center'>รวมครั้ง</th>
                        <th scope='col' class='text-center'>รวมค่าใช้จ่าย</th>
					  </tr>
					</thead>
                    <tbody>

<?php
	try {
		include '_cfg_hos.php';
    $sql = "SELECT a.pcode,p.name AS pname,a.pttype,ptt.name AS pttname
        ,COUNT(IF(a.inc01 > 0,a.an,NULL)) AS 'vis01',SUM(a.inc01) AS 'inc01'
        ,COUNT(IF(a.inc02 > 0,a.an,NULL)) AS 'vis02',SUM(a.inc02) AS 'inc02'
        ,COUNT(IF(a.inc03 > 0,a.an,NULL)) AS 'vis03',SUM(a.inc03) AS 'inc03'
        ,COUNT(IF(a.inc04 > 0,a.an,NULL)) AS 'vis04',SUM(a.inc04) AS 'inc04'
        ,COUNT(IF(a.inc05 > 0,a.an,NULL)) AS 'vis05',SUM(a.inc05) AS 'inc05'
        ,COUNT(IF(a.inc06 > 0,a.an,NULL)) AS 'vis06',SUM(a.inc06) AS 'inc06'
        ,COUNT(IF(a.inc07 > 0,a.an,NULL)) AS 'vis07',SUM(a.inc07) AS 'inc07'
        ,COUNT(IF(a.inc08 > 0,a.an,NULL)) AS 'vis08',SUM(a.inc08) AS 'inc08'
        ,COUNT(IF(a.inc09 > 0,a.an,NULL)) AS 'vis09',SUM(a.inc09) AS 'inc09'
        ,COUNT(IF(a.inc10 > 0,a.an,NULL)) AS 'vis10',SUM(a.inc10) AS 'inc10'
        ,COUNT(IF(a.inc11 > 0,a.an,NULL)) AS 'vis11',SUM(a.inc11) AS 'inc11'
        ,COUNT(IF(a.inc12 > 0,a.an,NULL)) AS 'vis12',SUM(a.inc12) AS 'inc12'
        ,COUNT(IF(a.inc13 > 0,a.an,NULL)) AS 'vis13',SUM(a.inc13) AS 'inc13'
        ,COUNT(IF(a.inc14 > 0,a.an,NULL)) AS 'vis14',SUM(a.inc14) AS 'inc14'
        ,COUNT(IF(a.inc15 > 0,a.an,NULL)) AS 'vis15',SUM(a.inc15) AS 'inc15'
        ,COUNT(IF(a.inc16 > 0,a.an,NULL)) AS 'vis16',SUM(a.inc16) AS 'inc16'
        ,COUNT(IF(a.inc17 > 0,a.an,NULL)) AS 'vis17',SUM(a.inc17) AS 'inc17'
        ,COUNT(*) AS 'vis_total2',SUM(income) AS inc_total2
        FROM an_stat a
        LEFT OUTER JOIN pcode p ON p.code = a.pcode
        LEFT OUTER JOIN pttype ptt ON ptt.pttype = a.pttype
        WHERE a.dchdate BETWEEN '$cxrdate1' AND '$cxrdate2' AND a.ward IS NOT NULL
        GROUP BY a.pttype
        ORDER BY a.pcode,a.pttype ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $inc01 = $row['inc01'];
            $inc02 = $row['inc02'];
            $inc03 = $row['inc03'];
            $inc04 = $row['inc04'];
            $inc05 = $row['inc05'];
            $inc06 = $row['inc06'];
            $inc07 = $row['inc07'];
            $inc08 = $row['inc08'];
            $inc09 = $row['inc09'];
            $inc10 = $row['inc10'];
            $inc11 = $row['inc11'];
            $inc12 = $row['inc12'];
            $inc13 = $row['inc13'];
            $inc14 = $row['inc14'];
            $inc15 = $row['inc15'];
            $inc16 = $row['inc16'];
            $inc17 = $row['inc17'];
            $inc_total2 = $row['inc_total2'];

            $vis01 = $row['vis01'];
            $vis02 = $row['vis02'];
            $vis03 = $row['vis03'];
            $vis04 = $row['vis04'];
            $vis05 = $row['vis05'];
            $vis06 = $row['vis06'];
            $vis07 = $row['vis07'];
            $vis08 = $row['vis08'];
            $vis09 = $row['vis09'];
            $vis10 = $row['vis10'];
            $vis11 = $row['vis11'];
            $vis12 = $row['vis12'];
            $vis13 = $row['vis13'];
            $vis14 = $row['vis14'];
            $vis15 = $row['vis15'];
            $vis16 = $row['vis16'];
            $vis17 = $row['vis17'];
            $vis_total2 = $row['vis_total2'];

            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['pcode']."</a></td>";
            echo "        <td>".$row['pname']."</td>";
            echo "        <td class='text-center'><a>".$row['pttype']."</a></td>";
            echo "        <td>".$row['pttname']."</td>";

            $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
            FROM income_group g
            LEFT OUTER JOIN income i ON i.income_group = g.income_group
            GROUP BY g.income_group
            ORDER BY g.income_group ASC";
            $query = $myPDO->query($sql);
            $pcodexx = $row['pcode'];
            foreach($query as $row) {
                $incomecol = "inc".$row['income_group']."";
                $visitcol = "vis".$row['income_group']."";
                echo "    <td class='text-right'>".number_format($$visitcol,0)."</td>";
                echo "    <td class='text-right'>".number_format($$incomecol,2)."</td>";
            }
    
            echo "        <td class='text-right'>".number_format($vis_total2,0)."</td>";
            echo "        <td class='text-right'>".number_format($inc_total2,2)."</td>";
            echo "      </tr>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                </table>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
