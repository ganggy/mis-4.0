<?php
$repid = $_GET['repid'];
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * 
			,IF(rep_where_selecter LIKE '%1%',1,NULL) AS s1
			,IF(rep_where_selecter LIKE '%2%',2,NULL) AS s2
			,IF(rep_where_selecter LIKE '%3%',3,NULL) AS s3
			,IF(rep_where_selecter LIKE '%4%',4,NULL) AS s4
			,IF(rep_where_selecter LIKE '%5%',5,NULL) AS s5
			FROM rep_reports WHERE repid = $repid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$rep_code = $data['rep_code'];
			$rep_name = $data['rep_name'];
			$rep_column = $data['rep_column'];
			$rep_sql1 = $data['rep_sql1'];
			$rep_sql2 = $data['rep_sql2'];
			$rep_sql3 = $data['rep_sql3'];
			$rep_sql4 = $data['rep_sql4'];
			$rep_where = $data['rep_where'];
			$rep_where_fdatename = $data['rep_where_fdatename'];
			$rep_where_selecter = $data['rep_where_selecter'];
			$rep_groupby = $data['rep_groupby'];
			$rep_user_reporter = $data['rep_user_reporter'];
			$rep_user_request = $data['rep_user_request'];
			$rep_update = $data['rep_update'];
			$rep_cat = $data['rep_cat'];
			$rep_template = $data['rep_template'];
			$rep_status = $data['rep_status'];
			$s1 = $data['s1'];
			$s2 = $data['s2'];
			$s3 = $data['s3'];
			$s4 = $data['s4'];
			$s5 = $data['s5'];
		}
		$sql2 = "SELECT yearprocess FROM sys_config";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$sys_year = $data2['yearprocess'];
			$repidgen = date("YmdHis");
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

		  <!-- general form elements disabled -->
          <div class="box box-info">
            <div class="box-header with-border bg-info">
              <h3 class="box-title"><i class="fa fa-edit"></i> ปรับปรุง/แก้ไขรายงาน --> <?php echo $rep_name;?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="?main=reports&action=save&repid=<?php echo $repid;?>" method="POST" enctype="multipart/form-data">
                <!-- text input -->
					<div class="row">
					<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> กลุ่มรายงาน</label>
<?php
	try {
		require_once("_cfg_mis40db.php");
		$sql = "SELECT * FROM sys_rep_cat ";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='rep_cat' name='rep_cat'>";

		foreach($query as $data) {
			echo "<option value='".$data['id']."'>".$data['rep_cat']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                </div>
					</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> รหัสรายงาน</label>
					  <input type="text" class="form-control" value="<?php echo $rep_code;?>" disabled>
					  <input type="hidden" name="rep_code" class="form-control" value="<?php echo $rep_code;?>">
                </div>
					</div>
					</div>

                <div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> ชื่อรายงาน</label>
                  <input type="text" name="rep_name" class="form-control" value="<?php echo $rep_name;?>">
                </div>

                <div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> นิยาม/เงื่อนไขการประมวลผลรายงาน (Template)</label>
                  <textarea class="form-control" name="rep_template" rows="3" placeholder="นิยาม/เงื่อนไขการประมวลผลรายงาน"><?php echo $rep_template;?></textarea>
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> <span data-toggle="tooltip" title="หัวคอลัมน์ที่จะแสดงของตารางข้อมูล">หัวตาราง (Field) <i class="fa fa-commenting-o"></i></span></label>
                  <input type="text" name="rep_column" class="form-control" value="<?php echo $rep_column;?>">
                </div>
                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> <span data-toggle="tooltip" title="คำสั่งหลัก SQL1 (SELECT ... FROM ... ให้เรียงลำดับฟิลด์ให้ตรงตามหัวตาราง)">คำสั่งประมวลผล (Query) <i class="fa fa-commenting-o"></i></span></label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12">SQL1
					  <textarea class="form-control" name="rep_sql1" rows="5"><?php echo $rep_sql1;?></textarea></div>
					  <div class="col-lg-6 col-md-6 col-sm-12">SQL2
					  <textarea class="form-control" name="rep_sql2" rows="5"><?php echo $rep_sql2;?></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> WHERE</label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12"><span data-toggle="tooltip" title="ชื่อฟิลด์วันที่ใน WHERE"> Date Field Name <i class="fa fa-commenting-o"></i></span>
					  <input type="text" name="rep_where_fdatename" class="form-control" value="<?php echo $rep_where_fdatename;?>"></div>
					  <div class="col-lg-6 col-md-6 col-sm-12"><span data-toggle="tooltip" title="เงื่อนไขต่อจากวันที่"> AND <i class="fa fa-commenting-o"></i></span>
					  <textarea class="form-control" name="rep_where" rows="3"><?php echo $rep_where;?></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> GROUP BY</label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12">
					  <textarea class="form-control" name="rep_groupby" rows="3"><?php echo $rep_groupby;?></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> ตัวเลือกการกรองข้อมูล</label>
				  <?php
				if ($s1 == 1) {$rep_where_selected1 = "selected";}
				if ($s2 == 2) {$rep_where_selected2 = "selected";}
				if ($s3 == 3) {$rep_where_selected3 = "selected";}
				if ($s4 == 4) {$rep_where_selected4 = "selected";}
				if ($s5 == 5) {$rep_where_selected5 = "selected";}
				  ?>
					<select name="rep_where_selecter" class="form-control select2" multiple="multiple" style="width: 100%;">
					  <option <?php echo $rep_where_selected1;?> value="1">ช่วงวันที่</option>
					  <option <?php echo $rep_where_selected2;?> value="2">Type Area</option>
					  <option <?php echo $rep_where_selected3;?> value="3">ในเขต/นอกเขต</option>
					  <option <?php echo $rep_where_selected4;?> value="4">ในเวลา/นอกเวลา</option>
					  <option <?php echo $rep_where_selected5;?> value="5">สิทธิ์รักษาฯ</option>
					</select>
              </div>

				<div class="form-group">
					<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-12">
                  <label class="control-label"><i class="fa fa-check"></i> ผู้ขอรายงาน</label>
                  <input type="text" name="rep_user_request" class="form-control" value="<?php echo $rep_user_request;?>">
                </div>
					</div>
					</div>

            </div>
            <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default"> ยกเลิก </button> -->
                <input type="hidden" name="repid" class="form-control" value="<?php echo $repid;?>">
                <button type="submit" class="btn btn-info pull-right" name="submit_rep" value="update"><i class='fa fa-plus'></i> ปรับปรุง </button>
              </div>
              <!-- /.box-footer -->
          </div>
              </form>
