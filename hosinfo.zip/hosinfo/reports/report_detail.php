<?php
if ($login_ok == 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        สถิติและรายงาน
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ประมวลผลจากฐานข้อมูล HOSxP</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-info">
              <li class="active"><a href="#tab_1-1" data-toggle="tab">[ <?php echo $_POST['rep_code'];?> ]</a></li>
              <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  เลือกกลุ่มรายงาน <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM sys_rep_cat ";
		$query = $myPDO->query($sql);
			echo "<li role='presentation'>";

		foreach($query as $data) {
			echo "<a role='menuitem' tabindex='-1' href=?main=reports&repgid=".$data['id'].">".$data['rep_cat']."</a>";
		}
			echo "</li>";
//$myPDO = null;
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="?main=reports">ทั้งหมด</a></li>
                </ul>
              </li>
              <li class="pull-left header"><i class="fa fa-files-o"></i> 
			  <?php echo $_POST['rep_name'];?>
			  </li>
            </ul>
            <div class="tab-content">
			<div>
              <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<form class="form-inline" method="post" action="<?php echo $PHP_SELF; ?>">

<?php if (strpos($_POST['rep_where_selecter'], '1') !== false) {?>
			<!-- Selecter Date -->
			  <div class="form-group">
                <label>ประมวลผลช่วงวันที่ : </label>
                <div class="input-group">
                  <input type="text" class="btn btn-default pull-right" id="daterange-btn" name="dateselect">
                </div>
              </div>
			<!-- Selecter Date //-->
<?php } else {}?>

<?php if (strpos($_POST['rep_where_selecter'], '2') !== false) {?>
			<!-- Selecter TypeArea -->
              <div class="input-group">
                <select name="typearea[]" class="form-control select2" multiple="multiple" data-placeholder="เลือก Type Area" style="width: 100%;">
                  <option value="1">[1] มีชื่อมีตัวอยู่จริง</option>
                  <option value="2">[2] มีชื่อแต่ตัวไม่อยู่</option>
                  <option value="3">[3] มาอาศัยอยู่ในเขต</option>
                  <option value="4">[4] บุคคลนอกเขต</option>
                  <option value="5">[5] คนเร่ร่อน</option>
                </select>
              </div>
			<!-- Selecter TypeArea //-->
<?php } else {}?>

<?php if (strpos($_POST['rep_where_selecter'], '3') !== false) {
	if ($_POST['inoutarea'] == "1") {
		$inoutarea = " ".$_POST['rep_where']." IN (1,3)";
	} else {
		$inoutarea = " ".$_POST['rep_where']." NOT IN (1,3)";
	}
?>
			<!-- Selecter In/Out Area -->
              <div class="input-group">
                <label><input type="radio" name="inoutarea" value="1" class="minimal"> ในเขต </label>
                <label><input type="radio" name="inoutarea" value="0" class="minimal-red"> นอกเขต</label>
              </div>
			<!-- Selecter In/Out Area //-->
<?php } else {}?>

<?php if (strpos($_POST['rep_where_selecter'], '4') !== false) {?>
			<!-- Selecter In/Out Time -->
              <div class="input-group">
                <label><input type="radio" name="inouttime" value="1" class="minimal"> ในเวลา </label>
                <label><input type="radio" name="inouttime" value="0" class="minimal-red"> นอกเวลา</label>
              </div>
			<!-- Selecter In/Out Time //-->
<?php } else {}?>

<?php if (strpos($_POST['rep_where_selecter'], '5') !== false) {?>
			<!-- Selecter PtType -->
              <div class="input-group">
                <select name="pttype[]" class="form-control select2" multiple="multiple" data-placeholder="เลือกสิทธิ์รักษาฯ" style="width: 100%;">
                  <option value="1">ข้าราชการ</option>
                  <option value="2">UC</option>
                  <option value="3">ประกันสังคม</option>
                  <option value="4">อน.</option>
                  <option value="5">ชำระเงินเอง</option>
                </select>
              </div>
			<!-- Selecter PtType //-->
<?php } else {}?>

<?php
$date1d = substr($_POST['dateselect'],3,2);
$date1m = substr($_POST['dateselect'],0,2);
$date1y = substr($_POST['dateselect'],6,4);
$date2d = substr($_POST['dateselect'],16,2);
$date2m = substr($_POST['dateselect'],13,2);
$date2y = substr($_POST['dateselect'],19,4);
$fulldate1 = $date1y."-".$date1m."-".$date1d;
$fulldate2 = $date2y."-".$date2m."-".$date2d;
?>

	<input type="hidden" name="repid" value="<?php echo $_POST['repid'];?>">
	<input type="hidden" name="rep_code" value="<?php echo $_POST['rep_code'];?>">
	<input type="hidden" name="rep_name" value="<?php echo $_POST['rep_name'];?>">
	<input type="hidden" name="rep_column" value="<?php echo $_POST['rep_column'];?>">
	<input type="hidden" name="rep_sql1" value="<?php echo $_POST['rep_sql1'];?>">
	<input type="hidden" name="rep_sql2" value="<?php echo $_POST['rep_sql2'];?>">
	<input type="hidden" name="rep_sql3" value="<?php echo $_POST['rep_sql3'];?>">
	<input type="hidden" name="rep_sql4" value="<?php echo $_POST['rep_sql4'];?>">
	<input type="hidden" name="rep_where" value="<?php echo $_POST['rep_where'];?>">
	<input type="hidden" name="rep_where_fdatename" value="<?php echo $_POST['rep_where_fdatename'];?>">
	<input type="hidden" name="rep_where_selecter" value="<?php echo $_POST['rep_where_selecter'];?>">
	<input type="hidden" name="rep_groupby" value="<?php echo $_POST['rep_groupby'];?>">
	<input type="hidden" name="rep_template" value="<?php echo $_POST['rep_template'];?>">

<?php if ($_POST['rep_where_selecter'] || "") { ?>
			  <button type="submit" class="btn btn-success"> ประมวลผล </button>
<?php } else {} ?>

<?php if ($_POST['rep_template'] || "") { ?>
<a href="#<?php echo $_POST['repid'];?>" data-toggle="modal" data-target="#modal-showdetail-<?php echo $_POST['repid'];?>"><i class="fa fa-comment"></i></a>
<?php } else {} ?>

</form>
			</div>

              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
					<?php
					echo "<tr>";
					$headarray = explode("," , $_POST['rep_column']);
					$iCount = count($headarray);
					foreach ($headarray as $ha) {
						echo "<th>".$ha."</th>";
					}
					echo "</tr>";
					?>
                </thead>
                <tbody>

<?php
if ($_POST['rep_where_fdatename'] == "") {
	$wheresql = " ";
	$wheresqland1 = " WHERE ";
} else {
	$wheresql = " WHERE ".$_POST['rep_where_fdatename']." BETWEEN '".$fulldate1."' AND '".$fulldate2."' ";
	$wheresqland1 = " AND ";
}

if ($_POST['rep_where'] == "") {
	$wheresqland = " ";
} else {
	$wheresqland = $wheresqland1." ".$inoutarea." ";
}

if ($_POST['rep_groupby'] == "") {
	$groupsql = " ";
} else {
	$groupsql = " GROUP BY ".$_POST['rep_groupby']." ";
}

$sql1string = htmlspecialchars_decode($_POST['rep_sql1']);

	try {
		include "_cfg_hos.php";
		$sql = " ".$sql1string." ".$wheresql." ".$wheresqland." ".$groupsql." ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			echo "<tr>";
			for ($i = 0; $i<$iCount; $i++) {
				echo "<td>".$data[$i]."</td>";
			}
			echo "</tr>";
		}
	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
				</tbody>
<!-- 
				<tfoot>
                <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th>รวม</th>
                  <th>ผลรวม</th>
                </tr>
                </tfoot>
 -->
			  </table>
			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-showdetail-<?php echo $_POST['repid'];?>">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff">เงื่อนไขการประมวลผล</font></h4>
				<!-- <font color="#ff0000"><?php echo $data['rep_template'];?></font> -->
              </div>
              <div class="modal-body">
			  <?php echo $_POST['rep_template'];?>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"> ปิด </button>
              </div>
            </div>
          </div>
        </div>
        <!-- modal1-content./ -->

<?php } else {include 'error505.php';} ?>