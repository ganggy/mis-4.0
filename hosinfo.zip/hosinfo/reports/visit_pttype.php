<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Data Export</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">

<form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
            <div class="box-body">
              <div class="row">
					<div class="form-group">
					  <label for="cxrdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
					</div>
					<?php
						$date1d = substr($_POST['cxrdaterange'],3,2);
						$date1m = substr($_POST['cxrdaterange'],0,2);
						$date1y = substr($_POST['cxrdaterange'],6,4);
						$date2d = substr($_POST['cxrdaterange'],16,2);
						$date2m = substr($_POST['cxrdaterange'],13,2);
						$date2y = substr($_POST['cxrdaterange'],19,4);

						$cxrdate1 = $date1y."-".$date1m."-".$date1d;
						$cxrdate2 = $date2y."-".$date2m."-".$date2d;
						$icode = $_POST['icode'];
					?>

<?php if ($_POST['inoutarea'] == "1") {
		$inoutarea = "AND p.cid IN (SELECT p.cid FROM person p WHERE p.death <> 'Y' AND p.house_regist_type_id IN (1,3))";
	} else {
		$inoutarea = "";
	}
?>
			<!-- Selecter In/Out Area -->
              <div class="input-group">
                <label><input type="radio" name="inoutarea" value="1" class="minimal" checked> ในเขต </label>
                <label><input type="radio" name="inoutarea" value="0" class="minimal-red"> ทั้งหมด</label>
              </div>
			<!-- Selecter In/Out Area //-->


					<button type="submit" class="btn btn-default"> ประมวลผล </button>
	&nbsp;(ประมวลผลช่วงวันที่ <b><?php echo $cxrdate1." - ".$cxrdate2; ?></b>)
              </div>
            </div>
  </form>
<div><br></div>

              <h3 class="box-title">จำนวนผู้รับบริการผู้ป่วยนอก (จำแนกตามสิทธิ์รักษาพยาบาล) </h3>
            </div>



            <!-- /.box-header -->
            <div class="box-body">

  <table id="DataTableExport2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
                        <th scope='col' class='text-center'>pcode</th>
                        <th scope='col' class='text-center'>กลุ่มสิทธิ์</th>
                        <th scope='col' class='text-center'>pttype</th>
                        <th scope='col' class='text-center'>สิทธิ์ย่อย</th>
                        <th scope='col' class='text-right'>จำนวน(คน)</th>
                        <th scope='col' class='text-right'>จำนวน(ครั้ง)</th>
					  </tr>
					</thead>
                    <tbody>
<?php
	try {
		include '_cfg_hos.php';
    $sql = "SELECT a.pcode,pc.name AS pname,a.pttype,ptt.name AS pttname
        ,COUNT(DISTINCT a.hn) AS 'pt_total',COUNT(*) AS 'vis_total'
        FROM vn_stat a
        LEFT OUTER JOIN pcode pc ON pc.code = a.pcode
        LEFT OUTER JOIN pttype ptt ON ptt.pttype = a.pttype
        LEFT OUTER JOIN patient pt ON pt.hn = a.hn
	    	LEFT OUTER JOIN person p ON p.cid = pt.cid
        WHERE a.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' $inoutarea
        GROUP BY a.pttype
        ORDER BY a.pcode,a.pttype ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $pt_total = $row['pt_total'];
            $vis_total = $row['vis_total'];

            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['pcode']."</a></td>";
            echo "        <td>".$row['pname']."</td>";
            echo "        <td class='text-center'><a>".$row['pttype']."</a></td>";
            echo "        <td>".$row['pttname']."</td>";
            echo "        <td class='text-right'>".number_format($pt_total,0)."</td>";
            echo "        <td class='text-right'>".number_format($vis_total,0)."</td>";
            echo "      </tr>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                  <thead>
<?php
	try {
		include '_cfg_hos.php';
    $sql = "SELECT a.pcode,pc.name AS pname,a.pttype,ptt.name AS pttname
        ,COUNT(DISTINCT a.hn) AS 'pt_total',COUNT(*) AS 'vis_total'
        FROM vn_stat a
        LEFT OUTER JOIN pcode pc ON pc.code = a.pcode
        LEFT OUTER JOIN pttype ptt ON ptt.pttype = a.pttype
        LEFT OUTER JOIN patient pt ON pt.hn = a.hn
	    	LEFT OUTER JOIN person p ON p.cid = pt.cid
        WHERE a.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' $inoutarea ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $pt_total = $row['pt_total'];
            $vis_total = $row['vis_total'];

            echo "      <tr>";
            echo "        <td></td>";
            echo "        <td></td>";
            echo "        <td></td>";
            echo "        <td class='text-right'>รวม</td>";
            echo "        <td class='text-right'>".number_format($pt_total,0)."</td>";
            echo "        <td class='text-right'>".number_format($vis_total,0)."</td>";
            echo "      </tr>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </thead>
                </table>


<?php if ($_POST['inoutarea'] == "1") { ?>
            <div class="box-header with-border">
              <h3 class="box-title">รายชื่อผู้รับบริการผู้ป่วยนอก (ในเขตรับผิดชอบ)</h3>
            </div>
                <table id="DataTableT2" class="table table-bordered table-hover">
                  <thead>
                  <tr class="info">
                    <td class='text-center'>เลขบัตร ปชช.</th>
                    <td class='text-center'>ชื่อ-นามสกุล</th>
                    <td class='text-center'>วันเกิด</th>
                    <td class='text-center'>อายุ</th>
                    <td class='text-center'>เพศ</th>
                    <td class='text-center'>สิทธิรักษาฯ</th>
                    <td class='text-center'>ที่อยู่</th>
                  </tr>
                  </thead>
                  <tbody>
<?php
	try {
		require_once("_cfg_hos.php");
		// คำสั่ง SQL
		$sql = "SELECT p.cid,p.pname,p.fname,p.lname,p.birthdate,TIMESTAMPDIFF(YEAR,p.birthdate,NOW()) AS age,s.name AS sexname,h.address,h.road,v.village_moo,v.village_name,t.full_name,ptt.name AS pttype_name
    FROM vn_stat a
    LEFT OUTER JOIN pcode pc ON pc.code = a.pcode
    LEFT OUTER JOIN pttype ptt ON ptt.pttype = a.pttype
    LEFT OUTER JOIN patient pt ON pt.hn = a.hn
    LEFT OUTER JOIN person p ON p.cid = pt.cid
    LEFT OUTER JOIN house h ON h.house_id = p.house_id
    LEFT OUTER JOIN village v ON v.village_id = h.village_id
    LEFT OUTER JOIN thaiaddress t ON t.addressid = v.address_id
    LEFT OUTER JOIN sex s ON s.code = p.sex
    WHERE a.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' $inoutarea 
    GROUP BY pt.cid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
      if ($mis_user_level >= '1') {
        $cidmem = $data['cid'];
      } else {
        $cidmem = substr($data['cid'],0,10)."xxx";
      }
      
			echo "<tr>";
			echo "<td>".$cidmem."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".DateThaiShort($data['birthdate'])."</td>";
			echo "<td class='text-center'>".$data['age']."</td>";
			echo "<td class='text-center'>".$data['sexname']."</td>";
			echo "<td>".$data['pttype_name']."</td>";
			echo "<td>".$data['address']." ".$data['road']." หมู่ที่ ".$data['village_moo']." ".$data['full_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
				</tbody>
                </table>
<?php	} else {} ?>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
