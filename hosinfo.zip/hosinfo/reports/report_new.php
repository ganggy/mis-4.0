		  <!-- general form elements disabled -->
          <div class="box box-warning">
            <div class="box-header with-border bg-warning">
              <h3 class="box-title"><i class="fa fa-plus-square-o"></i> สร้างรายงานใหม่ --> <?php echo $bsc_menu_name;?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="?main=reports&action=save" method="POST">
                <!-- text input -->
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE id = $mis_u_m_depart ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$kpi_depart_name = $data['dp_name'];
		}
		$sql2 = "SELECT yearprocess FROM sys_config";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$sys_year = $data2['yearprocess'];
			$repidgen = date("YmdHis");
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
					<div class="row">
					<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> กลุ่มรายงาน</label>
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM sys_rep_cat ";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='rep_cat' name='rep_cat'>";

		foreach($query as $data) {
			echo "<option value='".$data['id']."'>".$data['rep_cat']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                </div>
					</div>
				<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> รหัสรายงาน</label>
					  <input type="text" class="form-control" value="<?php echo $sys_year."-".$repidgen;?>" disabled>
					  <input type="hidden" name="rep_code" class="form-control" value="<?php echo $sys_year."-".$repidgen;?>">
                </div>
					</div>
					</div>

                <div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> ชื่อรายงาน</label>
                  <input type="text" name="rep_name" class="form-control" placeholder="ชื่อรายงาน" required autofocus>
                </div>

                <div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> นิยาม/เงื่อนไขการประมวลผลรายงาน (Template)</label>
                  <textarea class="form-control" name="rep_template" rows="3" placeholder="นิยาม/เงื่อนไขการประมวลผลรายงาน"></textarea>
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> <span data-toggle="tooltip" title="หัวคอลัมน์ที่จะแสดงของตารางข้อมูล">หัวตาราง (Field) <i class="fa fa-commenting-o"></i></span></label>
                  <input type="text" name="rep_column" class="form-control" placeholder="หัวตาราง คั่นด้วยเครื่องหมาย comma เช่น ... ชื่อ,อายุ,ที่อยู่" required>
                </div>
                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> <span data-toggle="tooltip" title="คำสั่งหลัก SQL1 (SELECT ... FROM ...)">คำสั่งประมวลผล (Query) <i class="fa fa-commenting-o"></i></span></label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12">SQL1
					  <textarea class="form-control" name="rep_sql1" rows="5" placeholder="SELECT ... FROM ... (ให้เรียงลำดับฟิลด์ให้ตรงตามหัวตาราง)" required></textarea></div>
					  <div class="col-lg-6 col-md-6 col-sm-12">SQL2
					  <textarea class="form-control" name="rep_sql2" rows="5" placeholder="SQL2" disabled></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> WHERE</label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12"><span data-toggle="tooltip" title="ชื่อฟิลด์วันที่ใน WHERE"> Date Field Name <i class="fa fa-commenting-o"></i></span>
					  <input type="text" name="rep_where_fdatename" class="form-control" placeholder="ชื่อฟิลด์วันที่ใน WHERE ที่ต้องการระบุช่วงวันที่ในการค้นหา (หากไม่มีให้ว่างไว้)"></div>
					  <div class="col-lg-6 col-md-6 col-sm-12"><span data-toggle="tooltip" title="เงื่อนไขต่อจากวันที่"> AND <i class="fa fa-commenting-o"></i></span>
					  <textarea class="form-control" name="rep_where" rows="3" placeholder="เงื่อนไขต่อจากวันที่ไม่ต้องมี AND นำหน้า (หากไม่มีให้ว่างไว้)"></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> GROUP BY</label>
					<div class="row">
					  <div class="col-lg-6 col-md-6 col-sm-12">
					  <textarea class="form-control" name="rep_groupby" rows="3" placeholder="(หากไม่มีให้ว่างไว้)"></textarea></div>
					</div>
                </div>

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> ตัวเลือกการกรองข้อมูล</label>
					<select name="rep_where_selecter[]" class="form-control select2" multiple="multiple" data-placeholder="ตัวเลือกการกรองที่จะแสดงในหน้าทำรายงาน" style="width: 100%;">
					  <option value="1">ช่วงวันที่</option>
					  <option value="2">Type Area</option>
					  <option value="3">ในเขต/นอกเขต</option>
					  <option value="4">ในเวลา/นอกเวลา</option>
					  <option value="5">สิทธิ์รักษาฯ</option>
					</select>
              </div>

				<div class="form-group">
					<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-12">
                  <label class="control-label"><i class="fa fa-check"></i> ผู้ขอรายงาน</label>
                  <input type="text" name="rep_user_request" class="form-control" placeholder="ผู้ขอรายงาน">
                </div>
					</div>
					</div>

            </div>
            <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default"> ยกเลิก </button> -->
                <button type="submit" class="btn btn-warning pull-right" name="submit_rep" value="create"><i class='fa fa-plus'></i> สร้างรายงานใหม่ </button>
              </div>
              <!-- /.box-footer -->
          </div>
              </form>
