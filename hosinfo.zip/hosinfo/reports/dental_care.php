<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Export :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li>Data Export</li> <li class="active">Dental care</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">ผู้รับบริการในเขต ได้รับการตรวจสุขภาพฟัน </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
            <div class="box-body">
              <div class="row">
					<div class="form-group">
					  <label for="cxrdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
					</div>
					<?php
						$date1d = substr($_POST['cxrdaterange'],3,2);
						$date1m = substr($_POST['cxrdaterange'],0,2);
						$date1y = substr($_POST['cxrdaterange'],6,4);
						$date2d = substr($_POST['cxrdaterange'],16,2);
						$date2m = substr($_POST['cxrdaterange'],13,2);
						$date2y = substr($_POST['cxrdaterange'],19,4);

						$cxrdate1 = $date1y."-".$date1m."-".$date1d;
                        $cxrdate2 = $date2y."-".$date2m."-".$date2d;
                        
                        $dtype = $_POST['dtype'];
                        if ($_POST['dtype'] == "NO") {
                            $dtype = "";
                        } else {
                            $dtype = "AND dt.dental_care_type_id = '$dtype' ";
                        }
                        $dplace = $_POST['dplace'];
                        if ($_POST['dplace'] == "NO") {
                            $dplace = "";
                        } else {
                            $dplace = "AND dp.dental_care_service_place_type_id = '$dplace' ";
                        }
					?>

					<div class="form-group">
                <select name="dtype" class="form-control select2" style="width: 100%;">
                  <option value = 'NO' selected="selected">= = = ประเภทผู้รับบริการทั้งหมด = = =</option>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT dental_care_type_id,dental_care_type_name FROM dental_care_type";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<option value = '".$row['dental_care_type_id']."'>".$row['dental_care_type_name']."</option>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                </select>
					</div>
					<div class="form-group">
                <select name="dplace" class="form-control select2" style="width: 100%;">
                  <option value = 'NO' selected="selected">= = = สถานที่ทั้งหมด = = =</option>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT dental_care_service_place_type_id,dental_care_service_place_type_name FROM dental_care_service_place_type";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<option value = '".$row['dental_care_service_place_type_id']."'>".$row['dental_care_service_place_type_name']."</option>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                </select>
					</div>
					<button type="submit" class="btn btn-default"> ประมวลผล </button>
	&nbsp;(ประมวลผลช่วงวันที่ <b><?php echo $cxrdate1." - ".$cxrdate2; ?></b>)
              </div>
            </div>
  </form>


              <table id="DataTableExport" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class='text-center'>hn</th>
                  <th class='text-center'>วันที่รับบริการ</th>
                  <th class='text-center'>ชื่อ-นามสกุล</th>
                  <th class='text-center'>อายุ(ปี)</th>
                  <th class='text-center'>ที่อยู่</th>
                  <th class='text-center'>ประเภทผู้รับบริการ</th>
                  <th class='text-center'>สถานที่</th>
                  <th class='text-center'>อุดฟัน</th>
                  <th class='text-center'>ขูดหินน้ำลาย</th>
                  <th class='text-center'>ต้องทำฟันปลอม</th>
                  <th class='text-center'>ผู้ตรวจ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hos.php";
		$sql = "SELECT vn.vstdate,vn.hn,pt.cid,p.pname,p.fname,p.lname,vn.age_y AS age_service
        ,p.birthdate,TIMESTAMPDIFF(YEAR,p.birthdate,NOW()) AS age
        ,s.name AS sexname,h.address,h.road,v.village_moo,v.village_name,t.full_name
        ,dt.dental_care_type_name,dp.dental_care_service_place_type_name,d.name AS doctor_name,dn.dental_care_nprosthesis_name,dc.*
        FROM dental_care dc
        LEFT OUTER JOIN dental_care_type dt ON dt.dental_care_type_id = dc.dental_care_type_id
        LEFT OUTER JOIN dental_care_service_place_type dp ON dp.dental_care_service_place_type_id = dc.dental_care_service_place_type_id
        LEFT OUTER JOIN dental_care_nprosthesis dn ON dn.dental_care_nprosthesis_id = dc.dental_care_nprosthesis_id
        LEFT OUTER JOIN vn_stat vn ON vn.vn = dc.vn
        LEFT OUTER JOIN patient pt ON pt.hn = vn.hn
        LEFT OUTER JOIN person p ON p.cid = pt.cid
        LEFT OUTER JOIN house h ON h.house_id = p.house_id
        LEFT OUTER JOIN village v ON v.village_id = h.village_id
        LEFT OUTER JOIN thaiaddress t ON t.addressid = v.address_id
        LEFT OUTER JOIN sex s ON s.code = p.sex
        LEFT OUTER JOIN doctor d ON d.code = dc.doctor
        
        WHERE vn.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2'
        AND pt.cid IN (
        SELECT p.cid FROM person p WHERE p.death <> 'Y' AND p.house_regist_type_id IN (1,3)
        ) $dtype $dplace ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['hn']."</td>";
			echo "<td>".$data['vstdate']."</td>";
			echo "<td>".$data['pname'].$data['fname']."  ".$data['lname']."</td>";
			echo "<td>".$data['age']."</td>";
			echo "<td>".$data['address']." ".$data['road']." ม.".$data['village_moo']." ".$data['full_name']."</td>";
			echo "<td>".$data['dental_care_type_name']."</td>";
			echo "<td>".$data['dental_care_service_place_type_name']."</td>";
			echo "<td class='text-center'>".$data['pfilling']."</td>";
			echo "<td class='text-center'>".$data['need_scaling']."</td>";
			echo "<td>".$data['dental_care_nprosthesis_name']."</td>";
			echo "<td>".$data['doctor_name']."</td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
