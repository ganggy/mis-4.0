<?php

$rep_sql1 = "SELECT o.vstdate,SUM(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN '08:30:00' AND '16:30:00',1,0)) AS intime
,COUNT(*) - SUM(IF (o.vstdate NOT IN (SELECT holiday_date FROM holiday) AND o.vsttime BETWEEN '08:30:00' AND '16:30:00',1,0)) AS outtime
,COUNT(*) AS visitkrung
FROM ovst o 
LEFT JOIN pttype t ON t.pttype = o.pttype";
$rep_sql2 = htmlspecialchars($rep_sql1);
echo $rep_sql2;

//echo htmlspecialchars(" BETWEEN '08:30:00' AND '16:30:00',1,0 ");

$new = htmlspecialchars("<a href='test'>Test</a>");
echo $new;

?>