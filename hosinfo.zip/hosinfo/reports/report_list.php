<?php
if ($login_ok == 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        สถิติและรายงาน
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ประมวลผลจากฐานข้อมูล HOSxP</li>
      </ol>
    </section>

<?php
	try {
		include "_cfg_mis40db.php";
		$sql2 = "SELECT COUNT(*) AS c_rep_t,SUM(IF(rep_status = 1,1,0)) AS c_rep_w FROM rep_reports";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$count_rep_t = $data2['c_rep_t'];
			$count_rep_w = $data2['c_rep_w'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-danger">
              <li class="active"><a href="#tab_1-1" data-toggle="tab">[ แสดงรายงาน <?php echo $count_rep_w;?> ตัว ]</a></li>
<?php if ($mis_user_level >= 4) { ?>
			  <li class="bg-success"><a href="#tab_2-2" data-toggle="tab">[ เพิ่มรายงานใหม่ ]</a></li>
<?php } else {} ?>

			  <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  เลือกกลุ่มรายงาน <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM sys_rep_cat ";
		$query = $myPDO->query($sql);
			echo "<li role='presentation'>";

		foreach($query as $data) {
			echo "<a role='menuitem' tabindex='-1' href=?main=reports&repcat=".$data['id'].">".$data['rep_cat']."</a>";
		}
			echo "</li>";
//$myPDO = null;
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="?main=reports">ทั้งหมด</a></li>
                </ul>
              </li>
              <li class="pull-left header"><i class="fa fa-files-o"></i> 
			  แสดงรายงาน <?php echo $count_rep_w;?> ตัว จากทั้งหมด <?php echo $count_rep_t;?> ตัว
			  </li>
            </ul>

			<div class="tab-content">
			  <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
if ($_GET['action'] == "edit") {
	include 'reports/report_edit.php';
} else if ($_GET['action'] == "save") {
	include 'reports/report_up.php';
} else {
?>

              <table id="DataTable" class="table table-bordered table-striped table-hover">
                <thead>
                <tr>
                  <th>กลุ่มรายงาน</th>
                  <th>ชื่อรายงาน</th>
                  <th>ผู้ขอรายงาน</th>
                  <th>ผู้จัดทำรายงาน</th>
                  <th>ปรับปรุงล่าสุด</th>
                  <th>ประมวลผล</th>
                </tr>
                </thead>
                <tbody>

<?php
if ($_GET['repcat'] == "") {
	$cat_select = " ";
} else {
	$cat_select = "AND r.rep_cat = ".$_GET['repcat']." ";
}

	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT r.*,c.rep_cat AS catname,u.m_namefull AS reporter FROM rep_reports r LEFT JOIN sys_rep_cat c ON c.id = r.rep_cat LEFT JOIN mis_user u ON u.m_login = r.rep_user_reporter WHERE r.rep_status = 1 $cat_select ";

		$query = $myPDO->query($sql);

		foreach($query as $data) {

			$rep_update = DateTimeThai($data['rep_update']);

			echo "<tr>";
			echo "<td>".$data['catname']."</td>";
			echo "<td><a>".$data['rep_name']."</a></td>";
			echo "<td>".$data['rep_user_request']."</td>";
			echo "<td>".$data['reporter']."</td>";
			echo "<td>".$rep_update."</td>";
			echo "<td>";
?>

<form class="form-inline" method="post" action="?main=reportsdetail">
	<input type="hidden" name="repid" value="<?php echo $data['repid'];?>">
	<input type="hidden" name="rep_code" value="<?php echo $data['rep_code'];?>">
	<input type="hidden" name="rep_name" value="<?php echo $data['rep_name'];?>">
	<input type="hidden" name="rep_column" value="<?php echo $data['rep_column'];?>">
	<input type="hidden" name="rep_sql1" value="<?php echo $data['rep_sql1'];?>">
	<input type="hidden" name="rep_sql2" value="<?php echo $data['rep_sql2'];?>">
	<input type="hidden" name="rep_sql3" value="<?php echo $data['rep_sql3'];?>">
	<input type="hidden" name="rep_sql4" value="<?php echo $data['rep_sql4'];?>">
	<input type="hidden" name="rep_where" value="<?php echo $data['rep_where'];?>">
	<input type="hidden" name="rep_where_selecter" value="<?php echo $data['rep_where_selecter'];?>">
	<input type="hidden" name="rep_where_fdatename" value="<?php echo $data['rep_where_fdatename'];?>">
	<input type="hidden" name="rep_groupby" value="<?php echo $data['rep_groupby'];?>">
	<input type="hidden" name="rep_template" value="<?php echo $data['rep_template'];?>">

<?php if ($data['rep_sql1'] == "") { ?>
                <div class="btn-group">
                  <button type="button" class="btn btn-warning btn-sm">กำลังจัดทำ </button>
<?php } else { ?>
                <div class="btn-group">
                  <button type="submit" class="btn btn-info btn-sm">ทำรายงาน <i class='fa fa-arrow-circle-right'></i></button>
<?php } ?>

<?php if ($mis_user_level >= 4) { ?>
				  <button type="submit" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <ul class="dropdown-menu" role="menu">
					<li><a href="?main=reports&action=edit&repid=<?php echo $data['repid'];?>">ปรับปรุงแก้ไข</a></li>
					<li><a href="?main=reports&action=save&submit=delete&repid=<?php echo $data['repid'];?>" onClick="return confirm('ยืนยันที่จะลบรายงานนี้');">*** Delete ***</a></li>
<?php if ($data['rep_template'] == "") {} else { ?>
                    <li><a href="#<?php echo $data['repid'];?>" data-toggle="modal" data-target="#modal-showdata-<?php echo $data['repid'];?>">เงื่อนไขประมวลผล</a></li>
<?php } ?>
                  </ul>
<?php } else { ?>
<?php if ($data['rep_template'] == "") {} else { ?>
				  <button type="submit" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown">
                    <span class="caret"></span>
                    <span class="sr-only">Toggle Dropdown</span>
                  </button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="#<?php echo $data['repid'];?>" data-toggle="modal" data-target="#modal-showdata-<?php echo $data['repid'];?>">เงื่อนไขประมวลผล</a></li>
<?php } ?>
                  </ul>
<?php } ?>
				</div>
</form>

<?php echo "</td></tr>"; ?>

        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-showdata-<?php echo $data['repid'];?>">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff">เงื่อนไขการประมวลผล</font></h4>
				<!-- <font color="#ff0000"><?php echo $data['rep_template'];?></font> -->
              </div>
              <div class="modal-body">
			  <?php echo $data['rep_template'];?>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"> ปิด </button>
              </div>
            </div>
          </div>
        </div>
        <!-- modal1-content./ -->
<?php
		}
	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
<?php
}
?>
			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->


              <div class="tab-pane" id="tab_2-2">
            <!-- /.box-header -->
            <div class="box-body">

<?php include 'reports/report_new.php'; ?>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php } else {include 'error505.php';} ?>