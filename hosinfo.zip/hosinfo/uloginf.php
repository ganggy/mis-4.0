<?php

$uname = $_POST['username'];
$pword = md5($_POST['passwd']);
$get_login = $_POST['getlogin2'];

try {
	require_once("_cfg_hos.php");
	$sql = "SELECT * FROM opduser WHERE loginname = '$uname' AND passweb = '$pword' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		session_start();
		$_SESSION["login_user"] = $data['loginname'];
		$_SESSION["login_user_s"] = sha1($data['loginname']);
		$_SESSION["login_pass_s"] = sha1($data['passweb']);
		$_SESSION["login_name"] = $data['name'];
		$_SESSION["login_encode"] = $get_login;
		session_write_close();
		$loginok2main = "1";
		$loginname = $data['loginname'];
	}
	$sql = "SELECT hospitalname,hospitalcode FROM opdconfig LIMIT 1 ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$hosinfo = $loginname." : ".$data['hospitalname']."(".$data['hospitalcode'].")";
	}
?>

<!-- // Login not OK -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=<?php echo $_POST['link2'];?>>
</head>
<?php if ($loginok2main == NULL) {echo "<body onLoad=myFunction()>";} else {echo "<body>";} ?>

<script>
function myFunction() {
    alert('ชื่อผู้ใช้หรือรหัสผ่าน ไม่ถูกต้อง !!!');
}
</script>

</body>
</html>
<!-- Login not OK // -->
<?php
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>

<?php

if ($loginname || "") {

try {
	require_once("_cfg_mis40db.php");
	$last_login = date("Y-m-d H:i:s");
	$ip_login = $_SERVER ['REMOTE_ADDR'];
	$os_login = $_SERVER ['HTTP_USER_AGENT'];
	$sql = "UPDATE mis_user SET last_login='$last_login',last_logout=NULL,ip_login='$ip_login',os_login='$os_login',online_status='1' WHERE m_login='$loginname' ";
	if ($myPDO->query($sql)) {
		echo "";
	}
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}


// กรณีต้องการตรวจสอบการแจ้ง error ให้เปิด 3 บรรทัดล่างนี้ให้ทำงาน กรณีไม่ ให้ comment ปิดไป
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
// กรณีมีการเชื่อมต่อกับฐานข้อมูล
//require_once("dbconnect.php");
 
$accToken = "Q7ekj0hKxXyJSjGpKoinle3HcopFuAkja2fe3AO406E";
$notifyURL = "https://notify-api.line.me/api/notify";
 
$headers = array(
    'Content-Type: application/x-www-form-urlencoded',
    'Authorization: Bearer '.$accToken
);
$data = array(
    'message' => "คุณ ".$hosinfo." เข้าใช้ MIS HOS-Info...".$last_login.""
);
 
// ส่วนของการส่งการแจ้งเตือนผ่านฟังก์ชั่น cURL
$ch = curl_init();
curl_setopt( $ch, CURLOPT_URL, $notifyURL);
curl_setopt( $ch, CURLOPT_POST, 1);
curl_setopt( $ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt( $ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 0); // ถ้าเว็บเรามี ssl สามารถเปลี่ยนเป้น 2
curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, 0); // ถ้าเว็บเรามี ssl สามารถเปลี่ยนเป้น 1
curl_setopt( $ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, 1);
$result = curl_exec( $ch );
curl_close( $ch );
 
// ตรวจสอบค่าข้อมูล ว่าเป็นตัวแปร ปรเภทไหน ข้อมูลอะไร
var_dump($result);
 
// การเช็คสถานะการทำงาน 
$result = json_decode($result,TRUE);
// ดูโครงสร้าง กรณีแปลงเป็น array แล้ว
//echo "<pre>";
//print_r($result);
 
// ตรวจสอบข้อมูล ใช้เป็นเงื่อนไขในการทำงาน
if(!is_null($result) && array_key_exists('status',$result)){
    if($result['status']==200){
        echo "Pass";
    }
}

} else {}

?>
