<?php
$host = "192.168.2.254";
$user = "opd";
$pwd = "opd";
$db = "mishosinfo";

$myPDO = new PDO("mysql:host=$host;dbname=$db", $user, $pwd);
$myPDO -> exec("set names utf8");
$myPDO -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

?>
