<?php
session_start();
session_destroy();
?>

<!-- // OK Logout -->
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL=/mis/>
</head>
<body>
<!-- OK Logout // -->
