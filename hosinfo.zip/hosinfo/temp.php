  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">


    </section>

    <!-- Main content -->
    <section class="content">
      <div class="error-page">
        <img class="img-fluid" src="images/C1.jpg" border="0" alt="">
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
