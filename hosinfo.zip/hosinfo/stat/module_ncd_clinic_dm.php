<div class="row">
	<div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<h3 class="info"><a data-toggle="collapse" data-parent="#accordionWrap111" href="#accordion111" aria-expanded="false" aria-controls="accordion111" class="h6 indigo">Guideline / Service delivery DM กลุ่มผู้ป่วยคลินิกเบาหวาน</a></h4>
				<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
				<div class="heading-elements">
					<ul class="list-inline mb-0">
						<li><a data-action="reload"><i class="icon-reload"></i></a></li>
						<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
						<li><a data-action="close"><i class="icon-cross2"></i></a></li>
					</ul>
				</div>
			</div>
			<div class="card-body collapse in collapse in">
			<div id="accordion111" role="tabpanel" aria-labelledby="heading111" class="card-collapse collapse" aria-expanded="false">
				<div class="card-block">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th class="text-xs-center">
									สภาวะของผู้ป่วย
								</th>
								<th class="text-xs-center">
									กลุ่มที่ 1<br>
									<small>PCU : ตรวจโดยพยาบาล</small>
								</th>
								<th class="text-xs-center">
									กลุ่มที่ 2<br>
									<small>PCC/PCU : ตรวจโดยแพทย์</small>
								</th>
								<th class="text-xs-center">
									กลุ่มที่ 3<br>
									<small>รพร. : ตรวจโดยอายุรแพทย์</small>
								</th>
								<th class="text-xs-center">
									กลุ่มที่ 4<br>
									<small>ส่งต่อ รพ.ศักยภาพสูงขึ้น</small>
								</th>
							</tr>
						</thead>
						<tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT 'cormo_sugar' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value IS NOT NULL AND c.last_fbs_value IS NOT NULL,1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value IS NOT NULL AND c.last_fbs_value IS NOT NULL AND p.tmbpart = '01',1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value < 7 AND c.last_fbs_value < 180,1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value BETWEEN 7 AND 7.9 AND c.last_fbs_value >= 180,1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250,1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250,1,0))
AS gr4
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value < 7 AND c.last_fbs_value < 180 AND p.tmbpart = '01',1,0))
AS gr1_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value BETWEEN 7 AND 7.9 AND c.last_fbs_value >= 180 AND p.tmbpart = '01',1,0))
AS gr2_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250 AND p.tmbpart = '01',1,0))
AS gr3_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250 AND p.tmbpart = '01',1,0))
AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $gr1 = $row[gr1];
            $gr2 = $row[gr2];
            $gr3 = $row[gr3];
            $gr4 = $row[gr4];
            $gr1p = $row[gr1]*100/$row[pt_cormo];
            $gr2p = $row[gr2]*100/$row[pt_cormo];
            $gr3p = $row[gr3]*100/$row[pt_cormo];
            $gr4p = $row[gr4]*100/$row[pt_cormo];
            $ptcormo = $row[pt_cormo];
            $ptcormo_hos = $row[pt_cormo_hos];
            $gr1_hos = $row[gr1_hos];
            $gr2_hos = $row[gr2_hos];
            $gr3_hos = $row[gr3_hos];
            $gr4_hos = $row[gr4_hos];
        }

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

							<tr>
								<th class="text-xs-center"><i class="icon-tags deep-orange font-large-2 float-xs-left"></i>การควบคุมระดับ<br>น้ำตาลในเลือด<br><h5 class="deep-orange"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=sugar">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">HbA1c < 7 % และ CBS < 180 mg%<br>(Capillary Blood Sugar)
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=sugar&level=1">'; } else {} ?><div class='tag tag-pill bg-green'>รพ.=<?php echo $gr1_hos ;?> รพ.สต.=<?php echo $gr1-$gr1_hos ;?></div></a></td>
								<td class="text-xs-center">LAB  HbA1c 7 - 7.9 % <br>และ CBS >= 180 mg%
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=sugar&level=2">'; } else {} ?><div class='tag tag-pill bg-yellow'>รพ.=<?php echo $gr2_hos ;?> รพ.สต.=<?php echo $gr2-$gr2_hos ;?></div></a></td>
								<td class="text-xs-center">LAB  HbA1c >= 8 % และ <br>CBS >= 250 mg% > 3 ครั้งติดต่อกัน
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=sugar&level=3">'; } else {} ?><div class='tag tag-pill bg-orange bg-darken-2'>รพ.=<?php echo $gr3_hos ;?> รพ.สต.=<?php echo $gr3-$gr3_hos ;?></div></a></td>
								<td class="text-xs-center">LAB  HbA1c >= 8 % และ <br>CBS >= 250 mg% > 3 ครั้งติดต่อกัน
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=sugar&level=4">'; } else {} ?><div class='tag tag-pill bg-red'>รพ.=<?php echo $gr4_hos ;?> รพ.สต.=<?php echo $gr4-$gr4_hos ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT 'cormo_kidney' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.micro_albumin_value IS NOT NULL AND c.egfr_value IS NOT NULL),1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.micro_albumin_value IS NOT NULL AND c.egfr_value IS NOT NULL) AND p.tmbpart = '01',1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 0 AND c.egfr_value >= 60,1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 1 AND c.egfr_value BETWEEN 30 AND 59,1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value BETWEEN 15 AND 29,1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value <= 15,1,0))
AS gr4
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 0 AND c.egfr_value >= 60 AND p.tmbpart = '01',1,0))
AS gr1_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 1 AND c.egfr_value BETWEEN 30 AND 59 AND p.tmbpart = '01',1,0))
AS gr2_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value BETWEEN 15 AND 29 AND p.tmbpart = '01',1,0))
AS gr3_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value <= 15 AND p.tmbpart = '01',1,0))
AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
$gr1 = $row[gr1];
$gr2 = $row[gr2];
$gr3 = $row[gr3];
$gr4 = $row[gr4];
$gr1p = $row[gr1]*100/$row[pt_cormo];
$gr2p = $row[gr2]*100/$row[pt_cormo];
$gr3p = $row[gr3]*100/$row[pt_cormo];
$gr4p = $row[gr4]*100/$row[pt_cormo];
$ptcormo = $row[pt_cormo];
$ptcormo_hos = $row[pt_cormo_hos];
$gr1_hos = $row[gr1_hos];
$gr2_hos = $row[gr2_hos];
$gr3_hos = $row[gr3_hos];
$gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
                        <tr>
								<th class="text-xs-center" rowspan="2"><i class="icon-flask teal font-large-2 float-xs-left"></i>ภาวะแทรกซ้อน<br>ทางไต<br><h5 class="teal"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=kidney">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">MAU < 30 mg/d <br>และ eGFR >= 60 ml/min/1.73 m&sup2;
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=kidney&level=1">'; } else {} ?><div class='tag tag-pill tag-success'>รพ.=<?php echo $gr1_hos ;?> รพ.สต.=<?php echo $gr1-$gr1_hos ;?></div></a></td>
								<td class="text-xs-center">MAU 30 - 300 mg/d <br>และ eGFR 30 - 59 ml/min/1.73 m&sup2;
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=kidney&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'>รพ.=<?php echo $gr2_hos ;?> รพ.สต.=<?php echo $gr2-$gr2_hos ;?></div></a></td>
								<td class="text-xs-center">MAU > 300 mg/d <br>และ eGFR 15 - 29 ml/min/1.73 m&sup2;
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=kidney&level=3">'; } else {} ?><div class='tag tag-pill bg-orange bg-darken-2'>รพ.=<?php echo $gr3_hos ;?> รพ.สต.=<?php echo $gr3-$gr3_hos ;?></div></a></td>
								<td class="text-xs-center">MAU > 300 mg/d <br>และ eGFR < 15 ml/min/1.73 m&sup2;
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=kidney&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'>รพ.=<?php echo $gr4_hos ;?> รพ.สต.=<?php echo $gr4-$gr4_hos ;?></div></a></td>
							</tr>
							<tr>
								<td colspan="2" class="text-xs-center">อัตราการลดลงของ eGFR < 7 ml/min/1.73 m&sup2;/year
								<br><div class='tag tag-warning'><?php if ($login_ok == 1) { echo '<a href="#">'; } else {} ?>?</a></div></td>
								<td colspan="2" class="text-xs-center">อัตราการลดลงของ eGFR >= 7 ml/min/1.73 m&sup2;/year
								<br><div class='tag tag-danger'><?php if ($login_ok == 1) { echo '<a href="#">'; } else {} ?>?</a></div></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT 'cormo_eye' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id <> 0 OR e.dmht_eye_screen_result_right_id <> 0),1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id <> 0 OR e.dmht_eye_screen_result_right_id <> 0) AND p.tmbpart = '01',1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id = 1 AND e.dmht_eye_screen_result_right_id = 1),1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL),1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL),1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_dm' AND ((e.dmht_eye_screen_result_left_id = 3 AND e.dmht_eye_screen_macular_id IN (2,3,4))
OR (e.dmht_eye_screen_result_left_id IN (4,5) OR e.dmht_eye_screen_result_right_id IN (4,5))),1,0))
AS gr4
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id = 1 AND e.dmht_eye_screen_result_right_id = 1) AND p.tmbpart = '01',1,0))
AS gr1_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL) AND p.tmbpart = '01',1,0))
AS gr2_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL) AND p.tmbpart = '01',1,0))
AS gr3_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND ((e.dmht_eye_screen_result_left_id = 3 AND e.dmht_eye_screen_macular_id IN (2,3,4))
OR (e.dmht_eye_screen_result_left_id IN (4,5) OR e.dmht_eye_screen_result_right_id IN (4,5))) AND p.tmbpart = '01',1,0))
AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
LEFT JOIN clinicmember_cormobidity_eye e ON e.clinicmember_id = c.clinicmember_id
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
$gr1 = $row[gr1];
$gr2 = $row[gr2];
$gr3 = $row[gr3];
$gr4 = $row[gr4];
$gr1p = $row[gr1]*100/$row[pt_cormo];
$gr2p = $row[gr2]*100/$row[pt_cormo];
$gr3p = $row[gr3]*100/$row[pt_cormo];
$gr4p = $row[gr4]*100/$row[pt_cormo];
$ptcormo = $row[pt_cormo];
$ptcormo_hos = $row[pt_cormo_hos];
$gr1_hos = $row[gr1_hos];
$gr2_hos = $row[gr2_hos];
$gr3_hos = $row[gr3_hos];
$gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
                        <tr>
								<th class="text-xs-center"><i class="icon-low-vision teal font-large-2 float-xs-left"></i>ภาวะแทรกซ้อน<br>ทางตา<br><h5 class="teal"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=eye">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">No DR <br>(Diabetic retinopathy)
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=eye&level=1">'; } else {} ?><div class='tag tag-pill tag-success'>รพ.=<?php echo $gr1_hos ;?> รพ.สต.=<?php echo $gr1-$gr1_hos ;?></div></a></td>
								<td colspan="2" class="text-xs-center">Mild to moderate NPDR (non-proliferative diabetic retinopathy) <br>และ no DME (Diabetic macular edema) หรือ VA ปกติ
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=eye&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'>รพ.=<?php echo $gr2_hos ;?> รพ.สต.=<?php echo $gr2-$gr2_hos ;?></div></a></td>
								<td class="text-xs-center">Moderate NPDR with DME หรือ <br>severe NPDR หรือ PDR <br>(Proliferative diabetic retinopathy)
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=eye&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'>รพ.=<?php echo $gr4_hos ;?> รพ.สต.=<?php echo $gr4-$gr4_hos ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT 'cormo_foot' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id IS NOT NULL OR c.dmht_foot_screen_result_left_id IS NOT NULL),1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id IS NOT NULL OR c.dmht_foot_screen_result_left_id IS NOT NULL) AND p.tmbpart = '01',1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id NOT IN (2,3,4) OR c.dmht_foot_screen_result_left_id NOT IN (2,3,4))
AND c.dmht_foot_screen_ulcer_id NOT IN (1,2,3),1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id IN (2) OR c.dmht_foot_screen_result_left_id IN (2))
AND c.dmht_foot_screen_ulcer_id IN (1,2,3),1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_history_amputation_id = 1 AND c.dmht_foot_screen_sensory_id IN (2,3,4)
AND c.dmht_foot_screen_ulcer_id IN (1,2,3),1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_die_skin_id = 2,1,0))
AS gr4
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id NOT IN (2,3,4) OR c.dmht_foot_screen_result_left_id NOT IN (2,3,4))
AND c.dmht_foot_screen_ulcer_id NOT IN (1,2,3) AND p.tmbpart = '01',1,0))
AS gr1_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id IN (2) OR c.dmht_foot_screen_result_left_id IN (2))
AND c.dmht_foot_screen_ulcer_id IN (1,2,3) AND p.tmbpart = '01',1,0))
AS gr2_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_history_amputation_id = 1 AND c.dmht_foot_screen_sensory_id IN (2,3,4)
AND c.dmht_foot_screen_ulcer_id IN (1,2,3) AND p.tmbpart = '01',1,0))
AS gr3_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_die_skin_id = 2 AND p.tmbpart = '01',1,0))
AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
$gr1 = $row[gr1];
$gr2 = $row[gr2];
$gr3 = $row[gr3];
$gr4 = $row[gr4];
$gr1p = $row[gr1]*100/$row[pt_cormo];
$gr2p = $row[gr2]*100/$row[pt_cormo];
$gr3p = $row[gr3]*100/$row[pt_cormo];
$gr4p = $row[gr4]*100/$row[pt_cormo];
$ptcormo = $row[pt_cormo];
$ptcormo_hos = $row[pt_cormo_hos];
$gr1_hos = $row[gr1_hos];
$gr2_hos = $row[gr2_hos];
$gr3_hos = $row[gr3_hos];
$gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
                        <tr>
								<th class="text-xs-center"><i class="icon-paw teal font-large-2 float-xs-left"></i>ภาวะแทรกซ้อน<br>ทางเท้า<br><h5 class="teal"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=foot">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">Protective sensation ปกติ, <br>Peripheral pulse ปกติ, <br>ไม่พบแผลที่เท้า
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=foot&level=1">'; } else {} ?><div class='tag tag-pill tag-success'>รพ.=<?php echo $gr1_hos ;?> รพ.สต.=<?php echo $gr1-$gr1_hos ;?></div></a></td>
								<td class="text-xs-center">Protective sensation, <br>Peripheral pulse ลดลง, <br>พบแผลที่เท้า
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=foot&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'>รพ.=<?php echo $gr2_hos ;?> รพ.สต.=<?php echo $gr2-$gr2_hos ;?></div></a></td>
								<td class="text-xs-center">Previous amputation, <br>มี Intermittent claudication, <br>แผลที่เท้าติดเชื้อรุนแรง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=foot&level=3">'; } else {} ?><div class='tag tag-pill bg-orange bg-darken-2'>รพ.=<?php echo $gr3_hos ;?> รพ.สต.=<?php echo $gr3-$gr3_hos ;?></div></a></td>
								<td class="text-xs-center">มี Rest pain <br>พบ gangrene
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=foot&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'>รพ.=<?php echo $gr4_hos ;?> รพ.สต.=<?php echo $gr4-$gr4_hos ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT 'cormo_cardio' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_bp_bps_value IS NOT NULL AND c.ldl_value IS NOT NULL,1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_dm' AND c.last_bp_bps_value IS NOT NULL AND c.ldl_value IS NOT NULL AND p.tmbpart = '01',1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value < 140 AND c.last_bp_bpd_value < 90) AND c.ldl_value < 100,1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 140 OR c.last_bp_bpd_value >= 90) AND c.ldl_value BETWEEN 100 AND 159
AND c.last_diag_ihd_date >= '2014-10-01',1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110) AND c.ldl_value >= 160
AND c.last_diag_ihd2c_date >= '2014-10-01',1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_diag_mi >= '2014-10-01' OR c.last_diag_cad >= '2014-10-01' OR c.last_diag_hf_date >= '2014-10-01'),1,0))
AS gr4
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value < 140 AND c.last_bp_bpd_value < 90) AND c.ldl_value < 100 AND p.tmbpart = '01',1,0))
AS gr1_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 140 OR c.last_bp_bpd_value >= 90) AND c.ldl_value BETWEEN 100 AND 159
AND c.last_diag_ihd_date >= '2014-10-01' AND p.tmbpart = '01',1,0))
AS gr2_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110) AND c.ldl_value >= 160
AND c.last_diag_ihd2c_date >= '2014-10-01' AND p.tmbpart = '01',1,0))
AS gr3_hos
,SUM(IF(c.clinic = '$c_clinic_dm' AND (c.last_diag_mi >= '2014-10-01' OR c.last_diag_cad >= '2014-10-01' OR c.last_diag_hf_date >= '2014-10-01') AND p.tmbpart = '01',1,0))
AS gr4_hos
,d_update
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
$gr1 = $row[gr1];
$gr2 = $row[gr2];
$gr3 = $row[gr3];
$gr4 = $row[gr4];
$gr1p = $row[gr1]*100/$row[pt_cormo];
$gr2p = $row[gr2]*100/$row[pt_cormo];
$gr3p = $row[gr3]*100/$row[pt_cormo];
$gr4p = $row[gr4]*100/$row[pt_cormo];
$ptcormo = $row[pt_cormo];
$ptcormo_hos = $row[pt_cormo_hos];
$gr1_hos = $row[gr1_hos];
$gr2_hos = $row[gr2_hos];
$gr3_hos = $row[gr3_hos];
$gr4_hos = $row[gr4_hos];
$d_update = $row[d_update];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
                        <tr>
								<th class="text-xs-center"><i class="icon-heartbeat red font-large-2 float-xs-left"></i>ภาวะแทรกซ้อน<br>ทางหัวใจ<br>และหลอดเลือด<br><h5 class="red"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=cardio">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">HT (BP < 140/90 mmHg), <br>Dyslipidemia (LDL < 100 mg%)
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=cardio&level=1">'; } else {} ?><div class='tag tag-pill tag-success'>รพ.=<?php echo $gr1_hos ;?> รพ.สต.=<?php echo $gr1-$gr1_hos ;?></div></a></td>
								<td class="text-xs-center">HT (BP >= 140/90 mmHg), <br>Dyslipidemia <br>(LDL 100-159 mg%), <br>ประวัติ IHD without chest pain
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=cardio&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'>รพ.=<?php echo $gr2_hos ;?> รพ.สต.=<?php echo $gr2-$gr2_hos ;?></div></a></td>
								<td class="text-xs-center">HT (BP >= 180/110 mmHg), <br>Dyslipidemia <br>(LDL >= 160 mg%), <br>IHD with chest pain
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=cardio&level=3">'; } else {} ?><div class='tag tag-pill bg-orange bg-darken-2'>รพ.=<?php echo $gr3_hos ;?> รพ.สต.=<?php echo $gr3-$gr3_hos ;?></div></a></td>
								<td class="text-xs-center">MI, CAD,<br> Post-CABG, <br>HF, Stroke
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=cardio&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'>รพ.=<?php echo $gr4_hos ;?> รพ.สต.=<?php echo $gr4-$gr4_hos ;?></div></a></td>
							</tr>
						</tbody>
					</table>

				</div></div>
			</div>
		</div>
	</div>
</div>