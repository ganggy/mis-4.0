<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

if ($_POST['pregnancy'] == null) {
} else {
	$myearb = $_POST['myearb'];
	$myeare = $_POST['myeare'];
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['doctor'] || NULL) {
  $tab_active8 = "active ";
} else {
  if ($_GET['profile'] == "1") {
    $tab_active5 = "active ";
  } else {
	  if ($_POST['pregnancy'] == "OK") {
		$tab_active3 = "active ";
	  } else {
		$tab_active1 = "active ";
		$tab_active4 = "";
		$tab_active9 = "";
	  }
  }
}

$ward_custom_tab_guest = "<li class='bg-warning'><a href='#tab_2-2' data-toggle='tab'>[ ตารางข้อมูล ]</a></li>";
$ward_custom_tab_user = "<li class='".$tab_active3."bg-warning'><a href='#tab_3-3' data-toggle='tab'>[ รายชื่อ ]</a></li>";
$ward_custom_tab_register = "";
$ward_custom_tab_head = "";
$ward_info_id = $_GET['ward'];

try {
	include '_cfg_hos.php';
	$sql = "SELECT ward,`name` AS wardname FROM ward WHERE ward_active = 'Y' AND ward = '$ward_info_id' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$ward_info_name = $data['wardname'];
	}
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  <?php include 'ipt_ward_header.php';?>

<form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(o.vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS ipd
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0
			GROUP BY DATE_FORMAT(o.vstdate,'%Y-%m')
			ORDER BY DATE_FORMAT(o.vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[ipd]);
		}
		if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
		if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
		if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
		if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
		if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
		if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
		if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
		if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
		if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
		if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
		if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
		if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$countipd10 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myearb-10-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd10,$row[wcount]);
		}
		if(empty($countipd10[0])){$countipd100 = 0;}else{$countipd100 = $countipd10[0];}
		if(empty($countipd10[1])){$countipd101 = 0;}else{$countipd101 = $countipd10[1];}
		if(empty($countipd10[2])){$countipd102 = 0;}else{$countipd102 = $countipd10[2];}
		if(empty($countipd10[3])){$countipd103 = 0;}else{$countipd103 = $countipd10[3];}

		$countipd11 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myearb-11-01' AND '$myearb-11-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd11,$row[wcount]);
		}
		if(empty($countipd11[0])){$countipd110 = 0;}else{$countipd110 = $countipd11[0];}
		if(empty($countipd11[1])){$countipd111 = 0;}else{$countipd111 = $countipd11[1];}
		if(empty($countipd11[2])){$countipd112 = 0;}else{$countipd112 = $countipd11[2];}
		if(empty($countipd11[3])){$countipd113 = 0;}else{$countipd113 = $countipd11[3];}

		$countipd12 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myearb-12-01' AND '$myearb-12-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd12,$row[wcount]);
		}
		if(empty($countipd12[0])){$countipd120 = 0;}else{$countipd120 = $countipd12[0];}
		if(empty($countipd12[1])){$countipd121 = 0;}else{$countipd121 = $countipd12[1];}
		if(empty($countipd12[2])){$countipd122 = 0;}else{$countipd122 = $countipd12[2];}
		if(empty($countipd12[3])){$countipd123 = 0;}else{$countipd123 = $countipd12[3];}

		$countipd01 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-01-01' AND '$myeare-01-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd01,$row[wcount]);
		}
		if(empty($countipd01[0])){$countipd010 = 0;}else{$countipd010 = $countipd01[0];}
		if(empty($countipd01[1])){$countipd011 = 0;}else{$countipd011 = $countipd01[1];}
		if(empty($countipd01[2])){$countipd012 = 0;}else{$countipd012 = $countipd01[2];}
		if(empty($countipd01[3])){$countipd013 = 0;}else{$countipd013 = $countipd01[3];}

		$countipd02 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-02-01' AND '$myeare-02-29' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd02,$row[wcount]);
		}
		if(empty($countipd02[0])){$countipd020 = 0;}else{$countipd020 = $countipd02[0];}
		if(empty($countipd02[1])){$countipd021 = 0;}else{$countipd021 = $countipd02[1];}
		if(empty($countipd02[2])){$countipd022 = 0;}else{$countipd022 = $countipd02[2];}
		if(empty($countipd02[3])){$countipd023 = 0;}else{$countipd023 = $countipd02[3];}

		$countipd03 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-03-01' AND '$myeare-03-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd03,$row[wcount]);
		}
		if(empty($countipd03[0])){$countipd030 = 0;}else{$countipd030 = $countipd03[0];}
		if(empty($countipd03[1])){$countipd031 = 0;}else{$countipd031 = $countipd03[1];}
		if(empty($countipd03[2])){$countipd032 = 0;}else{$countipd032 = $countipd03[2];}
		if(empty($countipd03[3])){$countipd033 = 0;}else{$countipd033 = $countipd03[3];}

		$countipd04 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-04-01' AND '$myeare-04-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd04,$row[wcount]);
		}
		if(empty($countipd04[0])){$countipd040 = 0;}else{$countipd040 = $countipd04[0];}
		if(empty($countipd04[1])){$countipd041 = 0;}else{$countipd041 = $countipd04[1];}
		if(empty($countipd04[2])){$countipd042 = 0;}else{$countipd042 = $countipd04[2];}
		if(empty($countipd04[3])){$countipd043 = 0;}else{$countipd043 = $countipd04[3];}

		$countipd05 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-05-01' AND '$myeare-05-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd05,$row[wcount]);
		}
		if(empty($countipd05[0])){$countipd050 = 0;}else{$countipd050 = $countipd05[0];}
		if(empty($countipd05[1])){$countipd051 = 0;}else{$countipd051 = $countipd05[1];}
		if(empty($countipd05[2])){$countipd052 = 0;}else{$countipd052 = $countipd05[2];}
		if(empty($countipd05[3])){$countipd053 = 0;}else{$countipd053 = $countipd05[3];}

		$countipd06 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-06-01' AND '$myeare-06-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd06,$row[wcount]);
		}
		if(empty($countipd06[0])){$countipd060 = 0;}else{$countipd060 = $countipd06[0];}
		if(empty($countipd06[1])){$countipd061 = 0;}else{$countipd061 = $countipd06[1];}
		if(empty($countipd06[2])){$countipd062 = 0;}else{$countipd062 = $countipd06[2];}
		if(empty($countipd06[3])){$countipd063 = 0;}else{$countipd063 = $countipd06[3];}

		$countipd07 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-07-01' AND '$myeare-07-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd07,$row[wcount]);
		}
		if(empty($countipd07[0])){$countipd070 = 0;}else{$countipd070 = $countipd07[0];}
		if(empty($countipd07[1])){$countipd071 = 0;}else{$countipd071 = $countipd07[1];}
		if(empty($countipd07[2])){$countipd072 = 0;}else{$countipd072 = $countipd07[2];}
		if(empty($countipd07[3])){$countipd073 = 0;}else{$countipd073 = $countipd07[3];}

		$countipd08 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-08-01' AND '$myeare-08-31' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd08,$row[wcount]);
		}
		if(empty($countipd08[0])){$countipd080 = 0;}else{$countipd080 = $countipd08[0];}
		if(empty($countipd08[1])){$countipd081 = 0;}else{$countipd081 = $countipd08[1];}
		if(empty($countipd08[2])){$countipd082 = 0;}else{$countipd082 = $countipd08[2];}
		if(empty($countipd08[3])){$countipd083 = 0;}else{$countipd083 = $countipd08[3];}

		$countipd09 = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type,COUNT(*) AS wcount
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myeare-09-01' AND '$myeare-09-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd09,$row[wcount]);
		}
		if(empty($countipd09[0])){$countipd090 = 0;}else{$countipd090 = $countipd09[0];}
		if(empty($countipd09[1])){$countipd091 = 0;}else{$countipd091 = $countipd09[1];}
		if(empty($countipd09[2])){$countipd092 = 0;}else{$countipd092 = $countipd09[2];}
		if(empty($countipd09[3])){$countipd093 = 0;}else{$countipd093 = $countipd09[3];}

		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT ip.deliver_type AS delivertype,dt.deliver_name AS delivername,COUNT(*) AS ptotal
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			LEFT OUTER JOIN deliver_type dt ON dt.deliver_type = ip.deliver_type
			WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY COUNT(*) DESC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[ptotal]);
			 array_push($delinamepie,$row[delivername]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div>


<script type="text/javascript">
// Create the chart
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'จำนวนมารดาคลอด ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวนมารดาคลอด(ราย)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f} ราย</b><br/>'
    },

    "series": [
        {
            "name": "จำนวนมารดาคลอด",
            "colorByPoint": true,
            "data": [
                {
                    "name": "ตุลาคม",
                    "y": <?= $ptipd0; ?>,
                    "drilldown": "ตุลาคม"
                },
                {
                    "name": "พฤศจิกายน",
                    "y": <?= $ptipd1; ?>,
                    "drilldown": "พฤศจิกายน"
                },
                {
                    "name": "ธันวาคม",
                    "y": <?= $ptipd2; ?>,
                    "drilldown": "ธันวาคม"
                },
                {
                    "name": "มกราคม",
                    "y": <?= $ptipd3; ?>,
                    "drilldown": "มกราคม"
                },
                {
                    "name": "กุมภาพันธ์",
                    "y": <?= $ptipd4; ?>,
                    "drilldown": "กุมภาพันธ์"
                },
                {
                    "name": "มีนาคม",
                    "y": <?= $ptipd5; ?>,
                    "drilldown": "มีนาคม"
                },
                {
                    "name": "เมษายน",
                    "y": <?= $ptipd6; ?>,
                    "drilldown": "เมษายน"
                },
                {
                    "name": "พฤษภาคม",
                    "y": <?= $ptipd7; ?>,
                    "drilldown": "พฤษภาคม"
                },
                {
                    "name": "มิถุนายน",
                    "y": <?= $ptipd8; ?>,
                    "drilldown": "มิถุนายน"
                },
                {
                    "name": "กรกฎาคม",
                    "y": <?= $ptipd9; ?>,
                    "drilldown": "กรกฎาคม"
                },
                {
                    "name": "สิงหาคม",
                    "y": <?= $ptipd10; ?>,
                    "drilldown": "สิงหาคม"
                },
                {
                    "name": "กันยายน",
                    "y": <?= $ptipd11; ?>,
                    "drilldown": "กันยายน"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "ตุลาคม",
                "id": "ตุลาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd100; ?>],
                    ['F/E ใช้คีม',<?= $countipd101; ?>],
                    ['N/D คลอดปกติ',<?= $countipd102; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd103; ?>]
                ]
            },
            {
                "name": "พฤศจิกายน",
                "id": "พฤศจิกายน",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd110; ?>],
                    ['F/E ใช้คีม',<?= $countipd111; ?>],
                    ['N/D คลอดปกติ',<?= $countipd112; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd113; ?>]
                ]
            },
            {
                "name": "ธันวาคม",
                "id": "ธันวาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd120; ?>],
                    ['F/E ใช้คีม',<?= $countipd121; ?>],
                    ['N/D คลอดปกติ',<?= $countipd122; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd123; ?>]
                ]
            },
            {
                "name": "มกราคม",
                "id": "มกราคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd010; ?>],
                    ['F/E ใช้คีม',<?= $countipd011; ?>],
                    ['N/D คลอดปกติ',<?= $countipd012; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd013; ?>]
                ]
            },
            {
                "name": "กุมภาพันธ์",
                "id": "กุมภาพันธ์",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd020; ?>],
                    ['F/E ใช้คีม',<?= $countipd021; ?>],
                    ['N/D คลอดปกติ',<?= $countipd022; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd023; ?>]
                ]
            },
            {
                "name": "มีนาคม",
                "id": "มีนาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd030; ?>],
                    ['F/E ใช้คีม',<?= $countipd031; ?>],
                    ['N/D คลอดปกติ',<?= $countipd032; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd033; ?>]
                ]
            },
            {
                "name": "เมษายน",
                "id": "เมษายน",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd040; ?>],
                    ['F/E ใช้คีม',<?= $countipd041; ?>],
                    ['N/D คลอดปกติ',<?= $countipd042; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd043; ?>]
                ]
            },
            {
                "name": "พฤษภาคม",
                "id": "พฤษภาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd050; ?>],
                    ['F/E ใช้คีม',<?= $countipd051; ?>],
                    ['N/D คลอดปกติ',<?= $countipd052; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd053; ?>]
                ]
            },
            {
                "name": "มิถุนายน",
                "id": "มิถุนายน",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd060; ?>],
                    ['F/E ใช้คีม',<?= $countipd061; ?>],
                    ['N/D คลอดปกติ',<?= $countipd062; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd063; ?>]
                ]
            },
            {
                "name": "กรกฎาคม",
                "id": "กรกฎาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd070; ?>],
                    ['F/E ใช้คีม',<?= $countipd071; ?>],
                    ['N/D คลอดปกติ',<?= $countipd072; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd073; ?>]
                ]
            },
            {
                "name": "สิงหาคม",
                "id": "สิงหาคม",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd080; ?>],
                    ['F/E ใช้คีม',<?= $countipd081; ?>],
                    ['N/D คลอดปกติ',<?= $countipd082; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd083; ?>]
                ]
            },
            {
                "name": "กันยายน",
                "id": "กันยายน",
                "data": [
                    ['C/S ผ่าตัดคลอด',<?= $countipd090; ?>],
                    ['F/E ใช้คีม',<?= $countipd091; ?>],
                    ['N/D คลอดปกติ',<?= $countipd092; ?>],
                    ['V/E เครื่องดูดสูญญากาศ',<?= $countipd093; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนประเภทของการคลอด'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
			{
                name: '<?= $delinamepie[0]; ?>',
                y: <?= $totalpie[0]; ?>,
                sliced: true,
                selected: true
			},
            ['<?= $delinamepie[1]; ?>',<?= $totalpie[1]; ?>],
            ['<?= $delinamepie[2]; ?>',<?= $totalpie[2]; ?>],
            ['<?= $delinamepie[3]; ?>',<?= $totalpie[3]; ?>]
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนมารดาคลอด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class="text-center">ประเภทการคลอด</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT ip.deliver_type AS delivertype,dt.deliver_name AS delivername,COUNT(*) AS total
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			LEFT OUTER JOIN deliver_type dt ON dt.deliver_type = ip.deliver_type
			WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0
			GROUP BY ip.deliver_type
			ORDER BY ip.deliver_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			switch ($row[delivertype]) {
				case "1":
					$rowward = 0;
					break;
				case "2":
					$rowward = 1;
					break;
				case "3":
					$rowward = 2;
					break;
				case "4":
					$rowward = 3;
					break;
				default:
					$rowward = '';
			}

			echo "      <tr>";
			echo "        <td>".$row[delivername]."</td>";
			echo "        <td class='text-right'>".number_format($countipd10[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd11[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd12[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd01[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd02[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd03[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd04[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd05[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd06[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd07[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd08[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd09[$rowward],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(o.vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS total
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0
			GROUP BY DATE_FORMAT(o.vstdate,'%Y-%m')
			ORDER BY DATE_FORMAT(o.vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[total]);
		}

		echo "</tbody><tfoot><tr class='warning'>";
		echo "        <td class='text-center'><b>รวม</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
		echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
		echo "</tr></tfoot>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
				<div class="panel-heading">
					<b>รายชื่อมารดาคลอด </b> ปีงบประมาณ <?php echo $myeare+543;?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>
				<div class="panel-heading">
					<form method="post" action="<?php echo $PHP_SELF ?>">
						<input type="hidden" name="myearb" value="<?php echo $myearb; ?>">
						<input type="hidden" name="myeare" value="<?php echo $myeare; ?>">
						<button type="submit" name="pregnancy" value="OK" class="btn btn-primary">คลิกแสดงรายชื่อ ปีงบประมาณ <?php echo $myeare+543; ?></button>
					</form>
				</div>
	        <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>วันที่คลอด</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>วิธีการคลอด</b></th>
						<th class='text-center'>&nbsp;</th>
					  </tr>
					</thead>
				  <tbody>
<?php
if ($_POST['pregnancy'] == "OK") {
	$preg_where = " o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0 ";
} else {
	$preg_where = " ip.an = '0' ";
}

	try {
		include '_cfg_hos.php';
		$sql = "SELECT o.vstdate,p.pname,p.fname,p.lname,a.age_y,p.addrpart,p.road,p.moopart,t.full_name,pt.name AS pttypename
			,ip.deliver_type AS delivertype,dt.deliver_name AS delivername,ip.an,ip.preg_number,o.hn,s.name AS sexname,d.name AS infantdoctor,ip.*,w.*,pg.*,ilf.*
			FROM ipt_pregnancy ip
			LEFT OUTER JOIN ovst o ON ip.an = o.an
			LEFT OUTER JOIN an_stat a ON a.an = o.an
			LEFT OUTER JOIN deliver_type dt ON dt.deliver_type = ip.deliver_type
			LEFT OUTER JOIN patient p ON p.hn = o.hn
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			LEFT OUTER JOIN pttype pt ON pt.pttype = o.pttype
			left outer join ward w on w.ward = a.ward 
			left outer join ipt_pregnancy pg on pg.an = ip.an  
			left outer join ipt_pregnancy_deliver_type it on it.id = pg.deliver_type  
			left outer join labor l on l.an = ip.an   
			left outer join ipt_labour il on il.an = ip.an  
			left outer join ipt_labour_infant ilf on ilf.ipt_labour_id = il.ipt_labour_id and ilf.infant_number >= 1
			left outer join sex s ON s.code = ilf.sex
			left outer join doctor d ON d.code = ilf.labour_doctor
			WHERE $preg_where ";
			// WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[vstdate]."</td>";
			echo "<td>".$row[birth_date]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[delivername]."</td>";
			echo "<td class='text-center'><a data-toggle='modal' href='#myOBS".$row[an]."'><span class='glyphicon glyphicon-search' aria-hidden='true'></span>&nbsp;</a></td>";
			echo "</tr>";
?>

<!-- Modal -->
<div id="myOBS<?php echo $row[an];?>" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h2 class="modal-title">รายละเอียดการคลอด</h2>
      </div>
      <div class="modal-body">
        <p><kbd>ชื่อแม่</kbd> <?php echo $row[pname]."".$row[fname]."  ".$row[lname];?></p>
        <p><kbd>ครรภ์ที่</kbd> <?php echo $row[preg_number];?></p>
        <p><kbd>วันคลอด</kbd> <?php echo DateThaiShort($row[birth_date]);?></p>
        <p><kbd>เวลาคลอด</kbd> <?php echo substr($row[birth_time],0,5);?> น.</p>
        <p><kbd>เพศ</kbd> <?php echo $row[sexname];?></p>
        <p><kbd>จำนวนเด็กเกิด</kbd> <?php echo $row[infant_number];?> คน</p>
        <p><kbd>น้ำหนัก</kbd> <?php echo number_format($row[birth_weight],0);?> กรัม</p>
        <p><kbd>ความยาว</kbd> <?php echo number_format($row[body_length],0);?> ซม.</p>
        <p><kbd>รอบศีรษะ</kbd> <?php echo number_format($row[head_length],0);?> ซม.</p>
        <p><kbd>ผู้ทำคลอด</kbd> <?php echo $row[infantdoctor];?></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal"> ปิด </button>
      </div>
    </div>
    <!-- Modal content-->
  </div>
</div>
<!-- Modal -->

<?php	
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

<?php include 'ipt_ward_info.php'; ?>
<?php include 'ipt_ward_info_doctor.php'; ?>
<?php include 'ipt_ward_med_profile.php'; ?>

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p>ประมวลจากวันที่คลอดใน รพ. ในช่วงเวลาที่กำหนดแยกรายเดือน แยกประเภทการคลอด</p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT ip.deliver_type AS delivertype,dt.deliver_name AS delivername,COUNT(*) AS total 
							FROM ipt_pregnancy ip 
							LEFT OUTER JOIN ovst o ON ip.an = o.an 
							LEFT OUTER JOIN deliver_type dt ON dt.deliver_type = ip.deliver_type 
							WHERE o.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ip.deliver_type <> 0 
							GROUP BY ip.deliver_type 
							ORDER BY ip.deliver_type ASC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #0080c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำแนะนำ</h3>
						</div>
						<div class="box-footer text-black">
							<p><u><b>สำหรับสมาชิก</b></u>ให้เข้าระบบสมาชิก หากต้องการดูข้อมูลรายชื่อมารดาคลอด ให้คลิกที่แท็บ [ รายชื่อ ] แล้วคลิกปุ่ม "คลิกแสดงรายชื่อ ปีงบประมาณ xxxx"
							เพื่อดูหรือค้นหาได้ สามารถดูข้อมูลรายละเอียดการคลอดของเด็กทารก และหากต้องการดูข้อมูลย้อนหลังก็สามารถประมวลผลเป็นปีงบประมาณที่ต้องการได้
							<br><br><u><i><b>หมายเหตุ</b></i></u>  เพื่อให้การเรียกดูข้อมูล ไม่ต้องประมวลผลข้อมูลมากเกินไปจึงจำเป็นต้องกรองข้อมูลก่อนนำมาแสดงผล
							</p>
						</div>
					</div>
				</div>

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->


            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


