				<div class="col-md-6">
                  <p class="text-center"><br><br>
                    <strong><font size="4" color="#000000">มูลค่าใช้จ่ายรวมทั้งตึก</font> <font size="6" color="#ff0000"><?php echo number_format($ipt_sumincome,2);?></font> <font size="4" color="#000000">บาท</font></strong>
                  </p>
                </div>
                <!-- /.col -->

				<div class="col-md-6">
				  <!-- Widget: user widget style 1 -->
				  <div class="box box-widget widget-user-2">
					<!-- Add the bg color to the header using any of the bg-* classes -->
					<div class="widget-user-header bg-red">
					  <div class="widget-user-image">
						<img class="img-circle" src="../dist/img/ipd_icon.png" alt="">
					  </div>
					  <!-- /.widget-user-image -->
					  <h3 class="widget-user-username">สรุปข้อมูล<?php echo $ward_info_name;?> วันนี้</h3>
					  <h5 class="widget-user-desc">จำนวนเตียงทั้งหมด <?php echo $ward_info_bed;?> เตียง</h5>
					</div>
					<div class="box-footer no-padding">
						<div class="row">
							<div class="col-sm-6">
							  <ul class="nav nav-stacked">
								<li><a>รับใหม่วันนี้ <span class="pull-right badge bg-red"><?php echo number_format($ipt_admittoday,0);?> เตียง</span></a></li>
								<li><a>จำหน่ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_dchtoday,0);?> เตียง</span></a></li>
								<li><a>Admit อยู่ <span class="pull-right badge bg-blue"><?php echo number_format($ipt_wardn,0);?> เตียง</span></a></li>
								<li><a>เตียงว่าง <span class="pull-right badge bg-green"><?php echo number_format($ipt_wardnb,0);?> เตียง</span></a></li>
							  </ul>
							</div>
							<div class="col-sm-6">
							  <ul class="nav nav-stacked">
								<li><a>ย้ายออก/รับย้ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_movetoday,0);?> ราย</span></a></li>
								<li><a>? <span class="pull-right badge bg-green"> 0 </span></a></li>
								<li><a>? <span class="pull-right badge bg-green"> 0 </span></a></li>
								<li><a>ค่าใช้จ่ายรวม <span class="pull-right badge bg-red"><?php echo number_format($ipt_sumincome,2);?> บาท</span></a></li>
							  </ul>
							</div>
						</div>
					</div>
				  </div>
                </div>
                <!-- /.col -->
