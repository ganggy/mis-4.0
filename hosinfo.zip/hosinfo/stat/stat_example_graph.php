<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        สถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ตัวชี้วัด</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="active bg-warning"><a href="#tab_1-1" data-toggle="tab">[ GRAPH ]</a></li>
              <li class="bg-warning"><a href="#tab_2-2" data-toggle="tab">[ DATA ]</a></li>

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>จำนวนผู้ป่วยนอก </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
 $amonth = array(); //ตัวแปรแกน y
 $ptvisit = array(); //ตัวแปรแกน y
 $ptopd = array(); //ตัวแปรแกน y
 $ptipd = array(); //ตัวแปรแกน y
	try {
		$host2 = "203.157.220.244";
		$user2 = "ghost";
		$pwd2 = "ghUD2gES";
		$db2 = "hos";
		$myPDO = new PDO("mysql:host=$host2;dbname=$db2", $user2, $pwd2);
		$myPDO -> exec("set names utf8");
		$myPDO -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visit
,SUM(IF(an IS NULL,1,0)) AS opd 
,SUM(IF(an IS NOT NULL,1,0)) AS ipd 
,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM 
FROM ovst 
WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
		 array_push($amonth,$row[AMONTH]);
		 array_push($ptvisit,$row[visit]);
		 array_push($ptopd,$row[opd]);
		 array_push($ptipd,$row[ipd]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>


<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>



		<script type="text/javascript">

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'แสดงจำนวนผู้ป่วยนอก ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '(รายเดือน)'
    },
    xAxis: {
        categories: ['ตุลาคม', 'พฤศจิกายน','ธํนวาคม','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฏาคม','สิงหาคม','กันยายน'],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'จำนวน(ราย)'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'ผู้ป่วยใน',
        data: [<?= implode(',', $ptipd) ?>]

    }, {
        name: 'ผู้ป่วยนอก',
        data: [<?= implode(',', $ptopd) ?>]

    }]
});
		</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="tab_2-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT1" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>เดือน-ปี</b></th>
						<th class='text-center'><b>จำนวนผู้ป่วยนอก (ราย)</b></th>
						<th class='text-center'><b>จำนวนผู้ป่วยใน (ราย)</b></th>
						<th class='text-center'><b>จำนวนผู้รับบริการรวม (ราย)</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		$host2 = "203.157.220.244";
		$user2 = "ghost";
		$pwd2 = "ghUD2gES";
		$db2 = "hos";
		$myPDO = new PDO("mysql:host=$host2;dbname=$db2", $user2, $pwd2);
		$myPDO -> exec("set names utf8");
		$myPDO -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visit
,SUM(IF(an IS NULL,1,0)) AS opd 
,SUM(IF(an IS NOT NULL,1,0)) AS ipd 
,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM
FROM ovst 
WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			switch ($row[AM]) {
				case "10":
					$mythai = 'ตุลาคม '.$row[AY];
					break;
				case "11":
					$mythai = 'พฤศจิกายน '.$row[AY];
					break;
				case "12":
					$mythai = 'ธันวาคม '.$row[AY];
					break;
				case "01":
					$mythai = 'มกราคม '.$row[AY];
					break;
				case "02":
					$mythai = 'กุมภาพันธ์ '.$row[AY];
					break;
				case "03":
					$mythai = 'มีนาคม '.$row[AY];
					break;
				case "04":
					$mythai = 'เมษายน '.$row[AY];
					break;
				case "05":
					$mythai = 'พฤษภาคม '.$row[AY];
					break;
				case "06":
					$mythai = 'มิถุนายน '.$row[AY];
					break;
				case "07":
					$mythai = 'กรกฎาคม '.$row[AY];
					break;
				case "08":
					$mythai = 'สิงหาคม '.$row[AY];
					break;
				case "09":
					$mythai = 'กันยายน '.$row[AY];
					break;
				default:
					$mythai = '';
			}

			echo "<tr>";
			echo "<td>".$mythai."</td>";
			echo "<td class='text-right'>".number_format($row[opd],0)."</td>";
			echo "<td class='text-right'>".number_format($row[ipd],0)."</td>";
			echo "<td class='text-right'>".number_format($row[visit],0)."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->




            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


