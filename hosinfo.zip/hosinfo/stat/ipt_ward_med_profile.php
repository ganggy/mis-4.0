	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

<div class="tab-pane <?php echo $tab_active5;?>" id="tab_5-5">
        <!-- /.box-header -->
        <div class="box-body">

  <!-- Direct Chat -->
  <div class="row">
  <div class="col-xs-12 col-sm-12 col-md-12 col-lg-3">

<?php
$an = $_GET['an'];
try {
    include '_cfg_hos.php';

    $sql = "SELECT i.*,a.*,p.*,s.*,t.full_name,pt.name AS pttypename,pm.image,d.name AS doctorname
        FROM ipt i 
        LEFT OUTER JOIN an_stat s ON s.an = i.an
        LEFT OUTER JOIN iptadm a ON a.an = i.an
        LEFT OUTER JOIN patient p ON p.hn = i.hn
        LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
        LEFT OUTER JOIN patient_image pm ON pm.hn = i.hn
        LEFT OUTER JOIN doctor d ON d.code = i.admdoctor
        LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        WHERE i.an = '$an' ";
    $query = $myPDO->query($sql);
    foreach($query as $row) {
        if ($row['income'] < 10000) {
            $col_income = "badge bg-green";
            $col_head = "success";
        } else if ($row['income'] <= 20000) {
            $col_income = "badge bg-blue";
            $col_head = "primary";
        } else if ($row['income'] <= 30000) {
            $col_income = "badge bg-yellow";
            $col_head = "warning";
        } else {
            $col_income = "badge bg-red";
            $col_head = "danger";
        }

        if ($row['sex'] == '1') {
            $pt_sex = "<i class='fa fa-mars'></i>";
        } else {
            $pt_sex = "<i class='fa fa-venus'></i>";
        }

        if ($row['admdate'] > 30) {
            $col_admdate = "badge bg-red";
        } else {
            $col_admdate = "badge bg-gray";
        }

        if ($row['image'] || NULL) {
            $pic = "show_image.php?hn=".$row['hn']."";
        } else {
            switch ($row['sex']) {
                case 1 : if ($row['age_y']<=15) $pic="images/boy.jpg"; else $pic="images/male.jpg";break;
                case 2 : if ($row['age_y']<=15) $pic="images/girl.jpg"; else $pic="images/female.jpg";break;
                default : $pic="images/boy.jpg";break;
            }
        }
?>
    <!-- IPT WARD INFO -->
    
    <div class="box box-<?php echo $col_head;?> collapsed-box direct-chat direct-chat-warning">
        <div class="box-header with-border">

          <div class="user-block">
            <img class="img-circle" src="<?php echo $pic; ?>" alt="">
            <span class="username"><h3 class="box-title"><?php echo $pt_sex;?> <?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></h3></span>
            <span class="description">Admit <?php echo DateThaiShort($row['regdate']);?></span>
                            <div class="box-tools pull-right">
                                <span class="badge bg-light-blue">เตียง <?php echo $row['bedno'];?></span>
                            </div>

              <div>
                วันนอน <span class="<?php echo $col_admdate;?>"><?php echo number_format($row['admdate'],0);?></span> วัน
                <a class="pull-right">AN <?php echo $row['an'];?></a>
              </div>
              <div>
                ค่าใช้จ่าย <span class="<?php echo $col_income;?>"><?php echo number_format($row['income'],2);?></span> บาท
                <a class="pull-right">อายุ <?php echo $row['age_y'];?></span> ปี</a>
              </div>
              <div>
                แพ้ยา : <span class="label label-danger"><?php echo $row['drugallergy'];?></span>
              </div>
              <div>
                แพทย์ : <a href="<?php echo $link."&doctor=".$row['admdoctor'];?>"><?php echo $row['doctorname'];?></a>
              </div>

          </div>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
            </button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <!-- Conversations are loaded here -->
          <div class="direct-chat-messages">

            <!-- Message to the right -->
            <div class="direct-chat-msg right">
              <div class="direct-chat-info clearfix">
                <span class="direct-chat-name pull-right">วัน Admit <?php echo DateThaiShort($row['regdate']);?></span>
                <span class="direct-chat-timestamp pull-left">รายละเอียดผู้ป่วย</span>
              </div>
              <!-- /.direct-chat-info -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                    <!-- <img class="profile-user-img img-responsive img-circle" src="../dist/img/user3-128x128.jpg" alt=""> -->
                    <img class="profile-user-img img-responsive img-circle" src="<?php echo $pic; ?>" alt="">

                </div>
                <!-- /.col -->
                <div class="col-sm-8 invoice-col">
                    <strong><?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></strong><br>
                    วันเกิด : <?php echo DateThaiShort($row['birthday']);?><br>
                    มารดา : <?php echo $row['mathername']."  ".$row['motherlname'];?><br>
                    บิดา : <?php echo $row['fathername']."  ".$row['fatherlname'];?><br>
                    เบอร์โทรศัพท์ : <?php echo $row['hometel'].", ".$row['informtel'].", ".$row['worktel'];?>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
              <div class="direct-chat-info clearfix">
                <br><span class="direct-chat-timestamp pull-left">อาการสำคัญ</span>
              </div>
              <div class="direct-chat-text">
                <?php echo $row['prediag'];?>
              </div>

              <!-- /.direct-chat-text -->
            </div>
            <!-- /.direct-chat-msg -->

            <!-- Message. Default to the left -->
            <div class="direct-chat-msg">

      <!-- About Me Box -->
        <div class="box-body">
          <strong><i class="fa fa-book margin-r-5"></i> สิทธิรักษาพยาบาล</strong>
          <p class="text-muted">
            <?php echo $row['pttypename'];?>  เลขที่ "<?php echo $row['pttypeno'];?>"
          </p>
          <hr>
          <strong><i class="fa fa-map-marker margin-r-5"></i> ที่อยู่</strong>
          <p class="text-muted"><?php echo $row['addrpart']." ".$row['road']." ม.".$row['moopart']." ".$row['full_name'];?></p>
          <hr>
          <strong><i class="fa fa-pencil margin-r-5"></i> โรคประจำตัว</strong>
          <p>
            โรคประจำตัว : <span class="label label-warning"><?php echo $row['clinic'];?></span>
          </p>

        </div>
        <!-- /.box-body -->

            </div>
            <!-- /.direct-chat-msg -->
          </div>
          <!--/.direct-chat-messages-->

          <!-- Contacts are loaded here -->
          <div class="direct-chat-contacts">
            <ul class="contacts-list">
              <li>
                <a href="#">
                  <!-- <img class="contacts-list-img" src="../dist/img/user1-128x128.jpg" alt=""> -->
                  <div class="contacts-list-info">
                        <span class="contacts-list-name">
                          ข้อมูลการรักษา
                          <small class="contacts-list-date pull-right">วันที่</small>
                        </span>
                    <span class="contacts-list-msg">รายการ</span>
                  </div>
                  <!-- /.contacts-list-info -->
                </a>
              </li>
              <!-- End Contact Item -->
            </ul>
            <!-- /.contatcts-list -->
          </div>
          <!-- /.direct-chat-pane -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <strong><i class="fa fa-file-text-o margin-r-5"></i> Note </strong>
        </div>
        <!-- /.box-footer-->
      </div>
    <!--/.IPT WARD INFO -->
<?php
    }

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

?>


<?php
$an = $_GET['an'];
?>
    <!-- IPT WARD INFO -->
    
      <div class="box box-<?php echo $col_head;?> box-solid direct-chat direct-chat-warning">
        <div class="box-header with-border">
          <i class="fa fa-calendar"></i><span class="username"><h3 class="box-title">วันที่-เวลา/ใบสั่งยา</h3></span>
          <div class="box-tools pull-right">
          <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <!-- Conversations are loaded here -->
          <div class="direct-chat-messages">

            <!-- Message to the right -->
            <div class="direct-chat-msg right">
              <!-- /.direct-chat-text -->
            </div>
            <!-- /.direct-chat-msg -->

            <!-- Message. Default to the left -->
            <div class="direct-chat-msg">

      <!-- About Me Box -->
        <div class="box-body">
        <table class="table no-margin table-hover">
            <tbody>
        <!-- <ul class="nav nav-stacked"> -->
<?php
try {
    include '_cfg_hos.php';
    $sql = "SELECT order_no,order_type,rxdate,rxtime FROM ipt_order_no WHERE an = '$an' ORDER BY rxdate DESC,rxtime DESC ";
    $query = $myPDO->query($sql);
    foreach($query as $row) {
?>
    <!-- <li><a href="<?php echo $link;?>&order=<?php echo $row['order_no'];?>"><?php echo $row['order_type'];?> : <?php echo DateThaiShort($row['rxdate']);?> เวลา <?php echo $row['rxtime'];?></a></li> -->
    <tr>
        <td><a href="<?php echo $link;?>&order=<?php echo $row['order_no'];?>"><?php echo $row['order_type'];?></a></td>
        <td class='text-center'><a href="<?php echo $link;?>&order=<?php echo $row['order_no'];?>"><?php echo DateThaiShort($row['rxdate']);?></a></td>
        <td><a href="<?php echo $link;?>&order=<?php echo $row['order_no'];?>"><?php echo $row['rxtime'];?></a></td>
    </tr>
<?php
    }
} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
        <!-- </ul> -->
            </tbody>
        </table>

        </div>
        <!-- /.box-body -->

            </div>
            <!-- /.direct-chat-msg -->
          </div>
          <!--/.direct-chat-messages-->

          <!-- /.direct-chat-pane -->
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
            <strong><i class="fa fa-file-text-o margin-r-5"></i> คลิกดูรายการใบสั่งยา </strong>
        </div>
        <!-- /.box-footer-->
      </div>
    <!--/.IPT WARD INFO -->
  
  </div>


    <!-- IPT WARD INFO -->
<?php
$order = $_GET['order'];
$an = $_GET['an'];
try {
    include '_cfg_hos.php';
    $sql = "SELECT order_no,order_type,rxdate,rxtime FROM ipt_order_no WHERE an = '$an' AND order_no = '$order' ";
    $query = $myPDO->query($sql);
    foreach($query as $row) {
      $order_info = $row['order_no']." (".DateThaiShort($row['rxdate'])." เวลา ".$row['rxtime'].")";
    }
} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>

    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-9">
      <div class="box box-<?php echo $col_head;?> box-solid">
        <div class="box-header with-border">
          <i class="fa fa-hospital-o"></i><h3 class="box-title"> รายการเวชภัณฑ์ เลขที่ : <?php echo $order_info;?></h3>
          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
            </button>
          </div>
        </div>

        <div class="box-body">
        <div class="table-responsive">
          <table class="table no-margin table-hover">
            <tbody>
              <thead>
                <th>ชื่อเวชภัณฑ์</th>
                <th>จำนวนเบิก</th>
                <th>วิธีใช้</th>
            </thead>

<?php
$order = $_GET['order'];
$an = $_GET['an'];
try {
    include '_cfg_hos.php';

    $sql = "SELECT d.name AS named,n.name AS namen,o.qty,u.name1,u.name2,u.name3
    FROM opitemrece o 
    LEFT OUTER JOIN drugitems d ON d.icode = o.icode
    LEFT OUTER JOIN nondrugitems n ON n.icode = o.icode
    LEFT OUTER JOIN drugusage u ON u.drugusage = o.drugusage
    WHERE o.an = '$an' AND o.order_no = '$order' ";
    $query = $myPDO->query($sql);
    foreach($query as $row) {

?>
    <tr>
        <td><?php echo $row['named'].$row['namen'];?></td>
        <td><?php echo $row['qty'];?></td>
        <td><?php echo $row['name1']." ".$row['name2']." ".$row['name3'];?></td>
    </tr>

<?php
    }

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
            </tbody>
        </table>
      </div>
    </div>
    <!-- /.box-body -->

        <div class="box-footer">
            <strong><i class="fa fa-file-text-o margin-r-5"></i> Note </strong>
        </div>
        <!-- /.box-footer-->
      </div>
    </div>
    <!--/.IPT WARD INFO -->
  </div>
        </div>
        <!-- /.box-body -->
          </div>
          <!-- /.tab-pane -->

<?php } else { }?>
<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
