<div class="row">
    <div class="col-md-12">
		<div class="card">
			<div class="card-header">
				<h3 class="info"><a data-toggle="collapse" data-parent="#accordionWrap112" href="#accordion112" aria-expanded="false" aria-controls="accordion112" class="h6 indigo">Guideline / Service delivery HT กลุ่มผู้ป่วยคลินิกความดันโลหิตสูง</a></h4>
				<a class="heading-elements-toggle"><i class="icon-ellipsis font-medium-3"></i></a>
				<div class="heading-elements">
					<ul class="list-inline mb-0">
						<li><a data-action="reload"><i class="icon-reload"></i></a></li>
						<li><a data-action="expand"><i class="icon-expand2"></i></a></li>
						<li><a data-action="close"><i class="icon-cross2"></i></a></li>
					</ul>
				</div>
			</div>
			<div class="card-body collapse in collapse in">
			<div id="accordion112" role="tabpanel" aria-labelledby="heading112" class="card-collapse collapse" aria-expanded="false">
				<div class="card-block">
					<table class="table table-bordered">
						<thead>
							<tr>
								<th class="text-xs-center">
									ปัจจัยเสี่ยง
								</th>
								<th class="text-xs-center">
									High normal<br>
									<small>(130/85 - 139-89)</small>
								</th>
								<th class="text-xs-center">
									ระดับที่ 1<br>
									<small>(140/90 - 159/99)</small>
								</th>
								<th class="text-xs-center">
									ระดับที่ 2<br>
									<small>(160/100 - 179/109)</small>
								</th>
								<th class="text-xs-center">
									ระดับที่ 3<br>
									<small>(>= 180/110)</small>
								</th>
							</tr>
						</thead>
						<tbody>
<?php
	try {
		include '_cfg_hos.php';
$sql = "SELECT 'cormo1' AS cormo_name
    ,SUM(IF(c.clinic = '$c_clinic_ht'AND c.last_bp_bps_value IS NOT NULL,1,0))
    AS pt_cormo
    ,SUM(IF(c.clinic = '$c_clinic_ht'AND c.last_bp_bps_value IS NOT NULL AND p.tmbpart = '01',1,0))
    AS pt_cormo_hos
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89,1,0))
    AS gr1
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99,1,0))
    AS gr2
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109,1,0))
    AS gr3
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110,1,0))
    AS gr4
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89 AND p.tmbpart = '01',1,0))
    AS gr1_hos
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99 AND p.tmbpart = '01',1,0))
    AS gr2_hos
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109 AND p.tmbpart = '01',1,0))
    AS gr3_hos
    ,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110 AND p.tmbpart = '01',1,0))
    AS gr4_hos
    FROM clinicmember_all_lab c
    LEFT OUTER JOIN patient p ON p.hn = c.hn
    WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
    AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
    AND p.tmbpart NOT IN ('00','99')
    GROUP BY p.chwpart,p.amppart";
$query = $myPDO->query($sql);
foreach($query as $row) {
    $gr1 = $row[gr1];
    $gr2 = $row[gr2];
    $gr3 = $row[gr3];
    $gr4 = $row[gr4];
    $gr1p = $row[gr1]*100/$row[pt_cormo];
    $gr2p = $row[gr2]*100/$row[pt_cormo];
    $gr3p = $row[gr3]*100/$row[pt_cormo];
    $gr4p = $row[gr4]*100/$row[pt_cormo];
    $ptcormo = $row[pt_cormo];
    $ptcormo_hos = $row[pt_cormo_hos];
    $gr1_hos = $row[gr1_hos];
    $gr2_hos = $row[gr2_hos];
    $gr3_hos = $row[gr3_hos];
    $gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
							<tr>
								<th class="text-xs-center"><i class="icon-smile success font-large-2 float-xs-left"></i>ไม่มีปัจจัยเสี่ยงใดๆ<br><h5 class="success"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht1">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">ปกติ
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht1&level=1">'; } else {} ?><div class='tag tag-pill tag-default'><?php echo $gr1 ;?></div></a></td>
								<td class="text-xs-center">ต่ำ
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht1&level=2">'; } else {} ?><div class='tag tag-pill tag-success'><?php echo $gr2 ;?></div></a></td>
								<td class="text-xs-center">ปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht1&level=3">'; } else {} ?><div class='tag tag-pill tag-warning'><?php echo $gr3 ;?></div></a></td>
								<td class="text-xs-center">สูง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht1&level=4">'; } else {} ?><div class='tag tag-pill tag-info'><?php echo $gr4 ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
$sql = "SELECT 'cormo1' AS cormo_name
,SUM(IF(IF(c.clinic = $c_clinic_ht AND c.last_bp_bps_value IS NOT NULL,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS pt_cormo
,SUM(IF(IF(c.clinic = '$c_clinic_ht'AND c.last_bp_bps_value IS NOT NULL AND p.tmbpart = '01',1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS pt_cormo_hos
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS gr1
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS gr2
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS gr3
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) BETWEEN 1 AND 2,1,0))
AS gr4

,'' AS gr1_hos
,'' AS gr2_hos
,'' AS gr3_hos
,'' AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
$query = $myPDO->query($sql);
foreach($query as $row) {
    $gr1 = $row[gr1];
    $gr2 = $row[gr2];
    $gr3 = $row[gr3];
    $gr4 = $row[gr4];
    $gr1p = $row[gr1]*100/$row[pt_cormo];
    $gr2p = $row[gr2]*100/$row[pt_cormo];
    $gr3p = $row[gr3]*100/$row[pt_cormo];
    $gr4p = $row[gr4]*100/$row[pt_cormo];
    $ptcormo = $row[pt_cormo];
    $ptcormo_hos = $row[pt_cormo_hos];
    $gr1_hos = $row[gr1_hos];
    $gr2_hos = $row[gr2_hos];
    $gr3_hos = $row[gr3_hos];
    $gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
							<tr>
								<th class="text-xs-center"><i class="icon-neutral info font-large-2 float-xs-left"></i>มี 1-2 ปัจจัยเสี่ยงอื่น<br><h5 class="info"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht2">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">ต่ำ
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht2&level=1">'; } else {} ?><div class='tag tag-pill tag-success'><?php echo $gr1 ;?></div></a></td>
								<td class="text-xs-center">ปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht2&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'><?php echo $gr2 ;?></div></a></td>
								<td class="text-xs-center">ปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht2&level=3">'; } else {} ?><div class='tag tag-pill bg-warning'><?php echo $gr3 ;?></div></a></td>
								<td class="text-xs-center">สูง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht2&level=4">'; } else {} ?><div class='tag tag-pill tag-info'><?php echo $gr4 ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
$sql = "SELECT 'cormo1' AS cormo_name
,SUM(IF(IF(c.clinic = $c_clinic_ht AND c.last_bp_bps_value IS NOT NULL,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS pt_cormo
,SUM(IF(IF(c.clinic = '$c_clinic_ht'AND c.last_bp_bps_value IS NOT NULL AND p.tmbpart = '01',1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS pt_cormo_hos
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS gr1
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS gr2
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS gr3
,SUM(IF(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110,1,0) AND
IF((c.last_bp_bps_value - c.last_bp_bpd_value)>60,1,0)
+IF(c.smoking_type_id=2,1,0)
+IF((p.sex=1 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>55) OR (p.sex=2 AND TIMESTAMPDIFF(YEAR,p.birthday,NOW())>65),1,0)
+IF((tc_value>200 AND ldl_value>130 AND ((p.sex=1 AND hdl_value<40) OR (p.sex=2 AND hdl_value<50))) OR tg_value>150,1,0)
+IF(((p.sex=1 AND c.waist_value>90) OR (p.sex=2 AND c.waist_value>80) OR c.bmi_value>30),1,0) >= 3,1,0))
AS gr4

,'' AS gr1_hos
,'' AS gr2_hos
,'' AS gr3_hos
,'' AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
$query = $myPDO->query($sql);
foreach($query as $row) {
    $gr1 = $row[gr1];
    $gr2 = $row[gr2];
    $gr3 = $row[gr3];
    $gr4 = $row[gr4];
    $gr1p = $row[gr1]*100/$row[pt_cormo];
    $gr2p = $row[gr2]*100/$row[pt_cormo];
    $gr3p = $row[gr3]*100/$row[pt_cormo];
    $gr4p = $row[gr4]*100/$row[pt_cormo];
    $ptcormo = $row[pt_cormo];
    $ptcormo_hos = $row[pt_cormo_hos];
    $gr1_hos = $row[gr1_hos];
    $gr2_hos = $row[gr2_hos];
    $gr3_hos = $row[gr3_hos];
    $gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
							<tr>
								<th class="text-xs-center"><i class="icon-sad2 danger font-large-2 float-xs-left"></i>มีตั้งแต่ 3 ปัจจัยเสี่ยงอื่นขึ้นไป<br><h5 class="danger"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht3">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">ปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht3&level=1">'; } else {} ?><div class='tag tag-pill tag-warning'><?php echo $gr1 ;?></div></a></td>
								<td class="text-xs-center">ปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht3&level=2">'; } else {} ?><div class='tag tag-pill tag-warning'><?php echo $gr2 ;?></div></a></td>
								<td class="text-xs-center">สูง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht3&level=3">'; } else {} ?><div class='tag tag-pill bg-info'><?php echo $gr3 ;?></div></a></td>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht3&level=4">'; } else {} ?><div class='tag tag-pill tag-info'><?php echo $gr4 ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
$sql = "SELECT 'cormo4' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value IS NOT NULL 
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value IS NOT NULL AND p.tmbpart = '01'
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89) 
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99) 
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109) 
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110) 
AND (c.with_hypertension = 'Y' OR c.last_diag_ihd2c IS NOT NULL OR c.egfr_value BETWEEN 30 AND 60),1,0))
AS gr4
,'' AS gr1_hos
,'' AS gr2_hos
,'' AS gr3_hos
,'' AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
$query = $myPDO->query($sql);
foreach($query as $row) {
    $gr1 = $row[gr1];
    $gr2 = $row[gr2];
    $gr3 = $row[gr3];
    $gr4 = $row[gr4];
    $gr1p = $row[gr1]*100/$row[pt_cormo];
    $gr2p = $row[gr2]*100/$row[pt_cormo];
    $gr3p = $row[gr3]*100/$row[pt_cormo];
    $gr4p = $row[gr4]*100/$row[pt_cormo];
    $ptcormo = $row[pt_cormo];
    $ptcormo_hos = $row[pt_cormo_hos];
    $gr1_hos = $row[gr1_hos];
    $gr2_hos = $row[gr2_hos];
    $gr3_hos = $row[gr3_hos];
    $gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
							<tr>
								<th class="text-xs-center"><i class="icon-droplet deep-orange font-large-2 float-xs-left"></i>TOD , CKD III หรือ DM<br><h5 class="deep-orange"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht4">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">สูงปานกลาง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht4&level=1">'; } else {} ?><div class='tag tag-pill tag-default'><?php echo $gr1 ;?></div></a></td>
								<td class="text-xs-center">สูง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht4&level=2">'; } else {} ?><div class='tag tag-pill tag-info'><?php echo $gr2 ;?></div></a></td>
								<td class="text-xs-center">สูง
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht4&level=3">'; } else {} ?><div class='tag tag-pill bg-info'><?php echo $gr3 ;?></div></a></td>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht4&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'><?php echo $gr4 ;?></div></a></td>
							</tr>
<?php
	try {
		include '_cfg_hos.php';
$sql = "SELECT 'cormo5' AS cormo_name
,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value IS NOT NULL 
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS pt_cormo
,SUM(IF(c.clinic = '$c_clinic_ht' AND c.last_bp_bps_value IS NOT NULL AND p.tmbpart = '01'
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS pt_cormo_hos
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 130 AND 139 OR c.last_bp_bpd_value BETWEEN 85 AND 89) 
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS gr1
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 140 AND 159 OR c.last_bp_bpd_value BETWEEN 90 AND 99) 
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS gr2
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value BETWEEN 160 AND 179 OR c.last_bp_bpd_value BETWEEN 100 AND 109) 
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS gr3
,SUM(IF(c.clinic = '$c_clinic_ht' AND (c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110) 
AND (c.last_diag_ihd2c IS NOT NULL OR c.egfr_value < 30),1,0))
AS gr4
,'' AS gr1_hos
,'' AS gr2_hos
,'' AS gr3_hos
,'' AS gr4_hos
FROM clinicmember_all_lab c
LEFT OUTER JOIN patient p ON p.hn = c.hn
WHERE c.clinic IN ('$c_clinic_ht','$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'  
AND (c.discharge IS NULL OR c.discharge='N') AND p.chwpart='$c_chwpart' AND p.amppart='$c_amppart'
AND p.tmbpart NOT IN ('00','99')
GROUP BY p.chwpart,p.amppart";
$query = $myPDO->query($sql);
foreach($query as $row) {
    $gr1 = $row[gr1];
    $gr2 = $row[gr2];
    $gr3 = $row[gr3];
    $gr4 = $row[gr4];
    $gr1p = $row[gr1]*100/$row[pt_cormo];
    $gr2p = $row[gr2]*100/$row[pt_cormo];
    $gr3p = $row[gr3]*100/$row[pt_cormo];
    $gr4p = $row[gr4]*100/$row[pt_cormo];
    $ptcormo = $row[pt_cormo];
    $ptcormo_hos = $row[pt_cormo_hos];
    $gr1_hos = $row[gr1_hos];
    $gr2_hos = $row[gr2_hos];
    $gr3_hos = $row[gr3_hos];
    $gr4_hos = $row[gr4_hos];
}

} catch (PDOException $e) {
    echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}
?>
							<tr>
								<th class="text-xs-center"><i class="icon-heart-broken2 red font-large-2 float-xs-left"></i>เป็นโรคหลอดเลือดหัวใจ,<br>ไต CKD IV ขึ้นไป<br>หรือเบาหวานที่มี TOD<br><h5 class="teal"><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht5">'; } else {} ?><?php echo $ptcormo ;?></a></h5></th>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht5&level=1">'; } else {} ?><div class='tag tag-pill tag-danger'><?php echo $gr1 ;?></div></a></td>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht5&level=2">'; } else {} ?><div class='tag tag-pill tag-danger'><?php echo $gr2 ;?></div></a></td>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht5&level=3">'; } else {} ?><div class='tag tag-pill tag-danger'><?php echo $gr3 ;?></div></a></td>
								<td class="text-xs-center">สูงมาก
								<br><?php if ($login_ok == 1) { echo '<a href="?kpi=0504&cormo=ht5&level=4">'; } else {} ?><div class='tag tag-pill tag-danger'><?php echo $gr4 ;?></div></a></td>
							</tr>
						</tbody>
					</table>

				</div></div>
			</div>
		</div>
	</div>
</div>
<p><i>ประมวลผล : <?php echo $d_update;?></i></p>
