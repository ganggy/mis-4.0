	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

	<div class="tab-pane <?php echo $tab_active4;?>" id="tab_4-4">
            <!-- /.box-header -->
            <div class="box-body">
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT COUNT(*) AS wtotal,(SELECT SUM(bedcount) FROM ward WHERE ward = '$ward_info_id') AS bedcount
,(SELECT SUM(bedcount) FROM ward WHERE ward = '$ward_info_id')-COUNT(*) AS wblank
,SUM(IF(ward = '$ward_info_id',1,0)) AS wardn
,(SELECT SUM(bedcount) FROM ward WHERE ward = '$ward_info_id')-SUM(IF(ward = '$ward_info_id',1,0)) AS wardnb
FROM ipt WHERE dchdate IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_bedcount = $data['bedcount'];
			$ipt_wardn = $data['wardn'];
			$ipt_wardnb = $data['wardnb'];
			}

		$sql = "SELECT COUNT(*) AS admittoday FROM ipt WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d') AND ward = '$ward_info_id' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admittoday = $data['admittoday'];
			}

		$sql = "SELECT COUNT(*) AS dchtoday FROM ipt WHERE dchdate = DATE_FORMAT(NOW(),'%Y-%m-%d') AND ward = '$ward_info_id' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_dchtoday = $data['dchtoday'];
			}

		$sql = "SELECT COUNT(*) AS movetoday FROM iptbedmove WHERE movedate = DATE_FORMAT(NOW(),'%Y-%m-%d') AND (nward = '$ward_info_id' OR oward = '$ward_info_id') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_movetoday = $data['movetoday'];
			}

		$sql = "SELECT SUM(income) AS sumincome FROM an_stat WHERE dchdate IS NULL  AND ward = '$ward_info_id' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_sumincome = $data['sumincome'];
			}

		$sql = "SELECT SUM(inc01) AS 'inc01',SUM(inc02) AS 'inc02',SUM(inc03) AS 'inc03',SUM(inc04) AS 'inc04',SUM(inc05) AS 'inc05'
		,SUM(inc06) AS 'inc06',SUM(inc07) AS 'inc07',SUM(inc08) AS 'inc08',SUM(inc09) AS 'inc09',SUM(inc10) AS 'inc10'
		,SUM(inc11) AS 'inc11',SUM(inc12) AS 'inc12',SUM(inc13) AS 'inc13',SUM(inc14) AS 'inc14',SUM(inc15) AS 'inc15'
		,SUM(inc16) AS 'inc16',SUM(inc17) AS 'inc17'
		,SUM(income) AS inc_total
		FROM an_stat WHERE dchdate IS NULL AND ward = '$ward_info_id' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
						$inc01 = $row['inc01'];
						$inc02 = $row['inc02'];
						$inc03 = $row['inc03'];
						$inc04 = $row['inc04'];
						$inc05 = $row['inc05'];
						$inc06 = $row['inc06'];
						$inc07 = $row['inc07'];
						$inc08 = $row['inc08'];
						$inc09 = $row['inc09'];
						$inc10 = $row['inc10'];
						$inc11 = $row['inc11'];
						$inc12 = $row['inc12'];
						$inc13 = $row['inc13'];
						$inc14 = $row['inc14'];
						$inc15 = $row['inc15'];
						$inc16 = $row['inc16'];
						$inc17 = $row['inc17'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

      <div class="row">
        <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">สรุป<?php echo $ward_info_name;?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">

				<div class="col-md-6">
                  <p class="text-center"><br><br>
                    <strong><font size="4" color="#000000">ค่าใช้จ่ายรวมทั้งตึก</font> <font size="6" color="#ff0000"><?php echo number_format($ipt_sumincome,2);?></font> <font size="4" color="#000000">บาท</font></strong>
                  </p>
                <!-- /.col -->
					<div class="box-footer no-padding">
						<div class="row">
							<div class="col-sm-6">
							  <ul class="nav nav-stacked">
								<li><a>ค่าใช้จ่าย > 30,000 <span class="pull-right badge bg-red">สีแดง</span></a></li>
								<li><a>ค่าใช้จ่าย 20,000 - 30,000 <span class="pull-right badge bg-yellow">สีเหลือง</span></a></li>
								<li><a>ค่าใช้จ่าย 10,000 - 20,000 <span class="pull-right badge bg-blue">สีฟ้า</span></a></li>
								<li><a>ค่าใช้จ่าย < 10,000 <span class="pull-right badge bg-green">สีเขียว</span></a></li>
							  </ul>
							</div>
							<div class="col-sm-6">
							</div>
						</div>
					</div>
                </div>

				<div class="col-md-6">
				  <!-- Widget: user widget style 1 -->
				  <div class="box box-widget widget-user-2">
					<!-- Add the bg color to the header using any of the bg-* classes -->
					<div class="widget-user-header bg-red">
					  <div class="widget-user-image">
						<img class="img-circle" src="dist/img/ipd_icon.png" alt="">
					  </div>
					  <!-- /.widget-user-image -->
					  <h3 class="widget-user-username">สรุปข้อมูล<?php echo $ward_info_name;?> วันนี้</h3>
					  <h5 class="widget-user-desc">จำนวนเตียงทั้งหมด <?php echo $ipt_bedcount;?> เตียง</h5>
					</div>
					<div class="box-footer no-padding">
						<div class="row">
							<div class="col-sm-6">
							  <ul class="nav nav-stacked">
								<li><a>รับใหม่วันนี้ <span class="pull-right badge bg-red"><?php echo number_format($ipt_admittoday,0);?> เตียง</span></a></li>
								<li><a>จำหน่ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_dchtoday,0);?> เตียง</span></a></li>
								<li><a>Admit อยู่ <span class="pull-right badge bg-blue"><?php echo number_format($ipt_wardn,0);?> เตียง</span></a></li>
								<li><a>เตียงว่าง <span class="pull-right badge bg-green"><?php echo number_format($ipt_wardnb,0);?> เตียง</span></a></li>
							  </ul>
							</div>
							<div class="col-sm-6">
							  <ul class="nav nav-stacked">
								<li><a>ย้ายออก/รับย้ายวันนี้ <span class="pull-right badge"><?php echo number_format($ipt_movetoday,0);?> ราย</span></a></li>
								<li><a>ค่ายา+เวชภัณฑ์ <span class="pull-right badge bg-yellow"><?php echo number_format($inc05,2);?> บาท</span></a></li>
								<li><a>ค่าบริการทางการพยาบาล <span class="pull-right badge bg-yellow"><?php echo number_format($inc09+$inc12,2);?> บาท</span></a></li>
								<li><a>ค่าใช้จ่ายรวม <span class="pull-right badge bg-red"><?php echo number_format($ipt_sumincome,2);?> บาท</span></a></li>
							  </ul>
							</div>
						</div>
					</div>
				  </div>
                </div>
                <!-- /.col -->

              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>


	  <!-- Direct Chat -->
      <div class="row">

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT i.*,a.*,p.*,s.*,t.full_name,pt.name AS pttypename,pm.image,d.name AS doctorname
			FROM ipt i 
			LEFT OUTER JOIN an_stat s ON s.an = i.an
			LEFT OUTER JOIN iptadm a ON a.an = i.an
			LEFT OUTER JOIN patient p ON p.hn = i.hn
			LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
			LEFT OUTER JOIN patient_image pm ON pm.hn = i.hn
			LEFT OUTER JOIN doctor d ON d.code = i.admdoctor
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			WHERE i.dchdate IS NULL AND i.ward = '$ward_info_id'
			ORDER BY a.bedno ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			if ($row['income'] < 10000) {
				$col_income = "badge bg-green";
				$col_head = "success";
			} else if ($row['income'] <= 20000) {
				$col_income = "badge bg-blue";
				$col_head = "primary";
			} else if ($row['income'] <= 30000) {
				$col_income = "badge bg-yellow";
				$col_head = "warning";
			} else {
				$col_income = "badge bg-red";
				$col_head = "danger";
			}

			if ($row['sex'] == '1') {
				$pt_sex = "<i class='fa fa-mars'></i>";
			} else {
				$pt_sex = "<i class='fa fa-venus'></i>";
			}

			if ($row['admdate'] > 30) {
				$col_admdate = "badge bg-red";
			} else {
				$col_admdate = "badge bg-gray";
			}

			if ($row['image'] || NULL) {
				$pic = "show_image.php?hn=".$row['hn']."";
			} else {
				switch ($row['sex']) {
					case 1 : if ($row['age_y']<=15) $pic="images/boy.jpg"; else $pic="images/male.jpg";break;
					case 2 : if ($row['age_y']<=15) $pic="images/girl.jpg"; else $pic="images/female.jpg";break;
					default : $pic="images/boy.jpg";break;
				}
			}
?>
		<!-- IPT WARD INFO -->
        <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3">
          <div class="box box-<?php echo $col_head;?> collapsed-box direct-chat direct-chat-warning">
            <div class="box-header with-border">

              <div class="user-block">
                <img class="img-circle" src="<?php echo $pic; ?>" alt="">
                <span class="username"><h3 class="box-title"><?php echo $pt_sex;?> <a href="<?php echo $wwwurl."/?ward=".$ward_info_id;?>&profile=1&an=<?php echo $row['an'];?>"><?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></a></h3></span>
                <span class="description">Admit <?php echo DateThaiShort($row['regdate']);?></span>
								<div class="box-tools pull-right">
									<span class="badge bg-light-blue">เตียง <?php echo $row['bedno'];?></span>
								</div>

				  <div>
                    วันนอน <span class="<?php echo $col_admdate;?>"><?php echo number_format($row['admdate'],0);?></span> วัน
                    <a class="pull-right">AN <?php echo $row['an'];?></a>
                  </div>
                  <div>
                    ค่าใช้จ่าย <span class="<?php echo $col_income;?>"><?php echo number_format($row['income'],2);?></span> บาท
                    <a class="pull-right">อายุ <?php echo $row['age_y'];?></span> ปี</a>
                  </div>
                  <div>
                    แพ้ยา : <span class="label label-danger"><?php echo $row['drugallergy'];?></span>
                  </div>
                  <div>
                    แพทย์ : <a href="<?php echo $wwwurl."/?ward=".$ward_info_id."&doctor=".$row['admdoctor'];?>"><?php echo $row['doctorname'];?></a>
                  </div>

			  </div>

			  <div class="box-tools pull-right">
                <!-- <span class="badge bg-light-blue">เตียง <?php echo $row['bedno'];?></span> -->
                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="เพิ่มเติม" data-widget="chat-pane-toggle">
                  <i class="fa fa-comments"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <!-- Conversations are loaded here -->
              <div class="direct-chat-messages">

                <!-- Message to the right -->
                <div class="direct-chat-msg right">
                  <div class="direct-chat-info clearfix">
                    <span class="direct-chat-name pull-right">วัน Admit <?php echo DateThaiShort($row['regdate']);?></span>
                    <span class="direct-chat-timestamp pull-left">รายละเอียดผู้ป่วย</span>
                  </div>
                  <!-- /.direct-chat-info -->
				  <div class="row invoice-info">
					<div class="col-sm-4 invoice-col">
						<!-- <img class="profile-user-img img-responsive img-circle" src="../dist/img/user3-128x128.jpg" alt=""> -->
						<img class="profile-user-img img-responsive img-circle" src="<?php echo $pic; ?>" alt="">

					</div>
					<!-- /.col -->
					<div class="col-sm-8 invoice-col">
						<strong><?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></strong><br>
						วันเกิด : <?php echo DateThaiShort($row['birthday']);?><br>
						มารดา : <?php echo $row['mathername']."  ".$row['motherlname'];?><br>
						บิดา : <?php echo $row['fathername']."  ".$row['fatherlname'];?><br>
						เบอร์โทรศัพท์ : <?php echo $row['hometel'].", ".$row['informtel'].", ".$row['worktel'];?>
					</div>
					<!-- /.col -->
				  </div>
				  <!-- /.row -->
                  <div class="direct-chat-info clearfix">
                    <br><span class="direct-chat-timestamp pull-left">อาการสำคัญ</span>
                  </div>
				  <div class="direct-chat-text">
                    <?php echo $row['prediag'];?>
                  </div>

                  <!-- /.direct-chat-text -->
                </div>
                <!-- /.direct-chat-msg -->

                <!-- Message. Default to the left -->
                <div class="direct-chat-msg">

          <!-- About Me Box -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> สิทธิรักษาพยาบาล</strong>
              <p class="text-muted">
                <?php echo $row['pttypename'];?>  เลขที่ "<?php echo $row['pttypeno'];?>"
              </p>
              <hr>
              <strong><i class="fa fa-map-marker margin-r-5"></i> ที่อยู่</strong>
              <p class="text-muted"><?php echo $row['addrpart']." ".$row['road']." ม.".$row['moopart']." ".$row['full_name'];?></p>
              <hr>
              <strong><i class="fa fa-pencil margin-r-5"></i> โรคประจำตัว</strong>
              <p>
                โรคประจำตัว : <span class="label label-warning"><?php echo $row['clinic'];?></span>
              </p>

            </div>
            <!-- /.box-body -->

                </div>
                <!-- /.direct-chat-msg -->
              </div>
              <!--/.direct-chat-messages-->

              <!-- Contacts are loaded here -->
              <div class="direct-chat-contacts">
                <ul class="contacts-list">
                  <li>
                    <a href="#">
                      <!-- <img class="contacts-list-img" src="../dist/img/user1-128x128.jpg" alt=""> -->
                      <div class="contacts-list-info">
                            <span class="contacts-list-name">
                              ข้อมูลการรักษา
                              <small class="contacts-list-date pull-right">วันที่</small>
                            </span>
                        <span class="contacts-list-msg">รายการ</span>
                      </div>
                      <!-- /.contacts-list-info -->
                    </a>
                  </li>
                  <!-- End Contact Item -->
                </ul>
                <!-- /.contatcts-list -->
              </div>
              <!-- /.direct-chat-pane -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
				<strong><i class="fa fa-file-text-o margin-r-5"></i> Note </strong>
            </div>
            <!-- /.box-footer-->
          </div>
        </div>
		<!--/.IPT WARD INFO -->
<?php
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
	  </div>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
