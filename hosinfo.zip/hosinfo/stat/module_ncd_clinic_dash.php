<!-- // Bootstrap Panels 21  -->
<?php
$c_chwpart = "66";
$c_amppart = "04";
$c_clinic_dm = "041";
$c_clinic_ht = "040";

$c_clinic_member_status = "3";
	try {
		include '_cfg_hos.php';
		$sql = "SELECT SUM(IF(t.dmgroup = 'gr1',1,0)) AS gr1
        ,SUM(IF(t.dmgroup = 'gr2',1,0)) AS gr2
        ,SUM(IF(t.dmgroup = 'gr3',1,0)) AS gr3
        ,SUM(IF(t.dmgroup = 'gr4',1,0)) AS gr4 
        
        FROM (
        
        SELECT 'gr1' AS dmgroup,p.hn,p.cid,p.pname,fname,p.lname,p.chwpart,p.amppart,p.tmbpart,p.moopart,p.addrpart,t.full_name
        ,CONCAT(DATE_FORMAT(c.lastvisit,'%d/%m/'),DATE_FORMAT(c.lastvisit,'%Y')+543) AS lastvisit
        FROM clinicmember_all_lab c
        LEFT JOIN patient p ON p.hn = c.hn
        LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT JOIN clinicmember_cormobidity_eye e ON e.clinicmember_id = c.clinicmember_id
        WHERE c.clinic IN ('$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'
        AND p.chwpart = '$c_chwpart' AND p.amppart = '$c_amppart' AND p.tmbpart NOT IN ('00','99')
        
        AND ((c.clinic = '$c_clinic_dm' AND c.last_hba1c_value < 7 AND c.last_fbs_value < 180)
        OR (c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value < 140 AND c.last_bp_bpd_value < 90) AND c.ldl_value < 100)
        OR (c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id = 1 AND e.dmht_eye_screen_result_right_id = 1))
        OR (c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 0 AND c.egfr_value >= 60)
        OR (c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id NOT IN (2,3,4) OR c.dmht_foot_screen_result_left_id NOT IN (2,3,4))
        AND c.dmht_foot_screen_ulcer_id NOT IN (1,2,3)))
        
        UNION ALL
        
        SELECT 'gr2' AS dmgroup,p.hn,p.cid,p.pname,fname,p.lname,p.chwpart,p.amppart,p.tmbpart,p.moopart,p.addrpart,t.full_name
        ,CONCAT(DATE_FORMAT(c.lastvisit,'%d/%m/'),DATE_FORMAT(c.lastvisit,'%Y')+543) AS lastvisit
        FROM clinicmember_all_lab c
        LEFT JOIN patient p ON p.hn = c.hn
        LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT JOIN clinicmember_cormobidity_eye e ON e.clinicmember_id = c.clinicmember_id
        WHERE c.clinic IN ('$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'
        AND p.chwpart = '$c_chwpart' AND p.amppart = '$c_amppart' AND p.tmbpart NOT IN ('00','99')
        
        AND ((c.clinic = '$c_clinic_dm' AND c.last_hba1c_value BETWEEN 7 AND 7.9 AND c.last_fbs_value >= 180)
        OR (c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 140 OR c.last_bp_bpd_value >= 90) AND c.ldl_value BETWEEN 100 AND 159
        AND c.last_diag_ihd_date >= '2014-10-01')
        OR (c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
        AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL))
        OR (c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 1 AND c.egfr_value BETWEEN 30 AND 59)
        OR (c.clinic = '$c_clinic_dm' AND (c.dmht_foot_screen_result_left_id IN (2) OR c.dmht_foot_screen_result_left_id IN (2))
        AND c.dmht_foot_screen_ulcer_id IN (1,2,3)))
        
        UNION ALL
        
        SELECT 'gr3' AS dmgroup,p.hn,p.cid,p.pname,fname,p.lname,p.chwpart,p.amppart,p.tmbpart,p.moopart,p.addrpart,t.full_name
        ,CONCAT(DATE_FORMAT(c.lastvisit,'%d/%m/'),DATE_FORMAT(c.lastvisit,'%Y')+543) AS lastvisit
        FROM clinicmember_all_lab c
        LEFT JOIN patient p ON p.hn = c.hn
        LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT JOIN clinicmember_cormobidity_eye e ON e.clinicmember_id = c.clinicmember_id
        WHERE c.clinic IN ('$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'
        AND p.chwpart = '$c_chwpart' AND p.amppart = '$c_amppart' AND p.tmbpart NOT IN ('00','99')
        
        AND ((c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250)
        OR (c.clinic = '$c_clinic_dm' AND (c.last_bp_bps_value >= 180 OR c.last_bp_bpd_value >= 110) AND c.ldl_value >= 160
        AND c.last_diag_ihd2c_date >= '2014-10-01')
        OR (c.clinic = '$c_clinic_dm' AND (e.dmht_eye_screen_result_left_id IN (2,3) OR e.dmht_eye_screen_result_right_id IN (2,3))
        AND (e.dmht_eye_screen_macular_id NOT IN (2,3,4) OR e.dmht_eye_screen_macular_id IS NULL))
        OR (c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value BETWEEN 15 AND 29)
        OR (c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_history_amputation_id = 1 AND c.dmht_foot_screen_sensory_id IN (2,3,4)
        AND c.dmht_foot_screen_ulcer_id IN (1,2,3)))
        
        UNION ALL
        
        SELECT 'gr4' AS dmgroup,p.hn,p.cid,p.pname,fname,p.lname,p.chwpart,p.amppart,p.tmbpart,p.moopart,p.addrpart,t.full_name
        ,CONCAT(DATE_FORMAT(c.lastvisit,'%d/%m/'),DATE_FORMAT(c.lastvisit,'%Y')+543) AS lastvisit
        FROM clinicmember_all_lab c
        LEFT JOIN patient p ON p.hn = c.hn
        LEFT JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT JOIN clinicmember_cormobidity_eye e ON e.clinicmember_id = c.clinicmember_id
        WHERE c.clinic IN ('$c_clinic_dm') AND (c.discharge <> 'Y' OR c.discharge IS NULL) AND c.clinic_member_status_id = '$c_clinic_member_status'
        AND p.chwpart = '$c_chwpart' AND p.amppart = '$c_amppart' AND p.tmbpart NOT IN ('00','99')
        
        AND ((c.clinic = '$c_clinic_dm' AND c.last_hba1c_value >= 8 AND c.last_fbs_value >= 250)
        OR (c.clinic = '$c_clinic_dm' AND (c.last_diag_mi >= '2014-10-01' OR c.last_diag_cad >= '2014-10-01' OR c.last_diag_hf_date >= '2014-10-01'))
        OR (c.clinic = '$c_clinic_dm' AND ((e.dmht_eye_screen_result_left_id = 3 AND e.dmht_eye_screen_macular_id IN (2,3,4))
        OR (e.dmht_eye_screen_result_left_id IN (4,5) OR e.dmht_eye_screen_result_right_id IN (4,5))))
        OR (c.clinic = '$c_clinic_dm' AND c.micro_albumin_value = 2 AND c.egfr_value <= 15)
        OR (c.clinic = '$c_clinic_dm' AND c.dmht_foot_screen_die_skin_id = 2))
        ) AS t
        
        GROUP BY t.chwpart,t.amppart";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $gr1 = $row[gr1];
            $gr2 = $row[gr2];
            $gr3 = $row[gr3];
            $gr4 = $row[gr4];
            $grtotal = $row[gr1]+$row[gr2]+$row[gr3]+$row[gr4];
		}


	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<!-- stats group-->
<div class="row">
    <!-- กลุ่ม 1 -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box bg-green">
            <span class="info-box-icon"><i class="fa fa-home"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">กลุ่มที่ 1 ความเสี่ยงต่ำ</span>
                <span class="info-box-number"><?php echo $gr1;?> คน</span>
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $gr1*100/$grtotal;?>%"></div>
                </div>
                <span class="progress-description"><?php echo number_format($gr1*100/$grtotal,2);?>% กระบวนการดูแล กลุ่มที่ 1</span>
            </div>
        </div>
    </div>

    <!-- กลุ่ม 2 -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box bg-yellow">
            <span class="info-box-icon"><i class="fa fa-stethoscope"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">กลุ่มที่ 2 ความเสี่ยงปานกลาง</span>
                <span class="info-box-number"><?php echo $gr2;?> คน</span>
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $gr2*100/$grtotal;?>%"></div>
                </div>
                <span class="progress-description"><?php echo number_format($gr2*100/$grtotal,2);?>% กระบวนการดูแล กลุ่มที่ 2</span>
            </div>
        </div>
    </div>

    <!-- กลุ่ม 3 -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box bg-orange">
            <span class="info-box-icon"><i class="fa fa-user-md"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">กลุ่มที่ 3 ความเสี่ยงสูง</span>
                <span class="info-box-number"><?php echo $gr3;?> คน</span>
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $gr3*100/$grtotal;?>%"></div>
                </div>
                <span class="progress-description"><?php echo number_format($gr3*100/$grtotal,2);?>% กระบวนการดูแล กลุ่มที่ 3</span>
            </div>
        </div>
    </div>

    <!-- กลุ่ม 4 -->
    <div class="col-md-3 col-sm-6 col-xs-12">
        <div class="info-box bg-red">
            <span class="info-box-icon"><i class="fa fa-ambulance"></i></span>
            <div class="info-box-content">
                <span class="info-box-text">กลุ่มที่ 4 มีโรคแทรกซ้อน</span>
                <span class="info-box-number"><?php echo $gr4;?> คน</span>
                <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $gr4*100/$grtotal;?>%"></div>
                </div>
                <span class="progress-description"><?php echo number_format($gr4*100/$grtotal,2);?>% กระบวนการดูแล กลุ่มที่ 4</span>
            </div>
        </div>
    </div>

</div>
<!--/ stats group -->

<!-- Modal-g1 -->
<div class="modal fade text-xs-left" id="dash-modal-g1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="success">กระบวนการดูแลผู้ป่วย DM/HT กลุ่มที่ 1 เสี่ยงต่ำ<h4>
			</div>
			<div class="modal-body">
				<blockquote class="blockquote border-left-success border-left-3">
					<h5>PCU ตรวจโดยพยาบาล</h5>
				</blockquote>
				<ul>
					<li>จัดมุมเรียนรู้โดยมีแผ่นพับ โปสเตอร์ และflow chart เกี่ยวกับโรค DM/HT/CKD/ Stroke/STEMI
					<li>เสริมสร้างแรงจูงใจ หาบุคคลต้นแบบแต่ละพื้นที่
					<li>สาธิตเมนูอาหารเพื่อสุขภาพ
					<li>เยี่ยมเสริมพลังโดยกลุ่มจิตอาสา อสม. CG และเจ้าหน้าที่ (ทีมFCTชุมชน)
				</ul>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"> ปิด </button>
			</div>
		</div>
	</div>
</div>
<!-- Modal-g1 // -->

<!-- Modal-g2 -->
<div class="modal fade text-xs-left" id="dash-modal-g2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="warning">กระบวนการดูแลผู้ป่วย DM/HT กลุ่มที่ 2 เสี่ยงปานกลาง<h4>
			</div>
			<div class="modal-body">
				<blockquote class="blockquote border-left-warning border-left-3">
					<h5>PCC / PCU ตรวจโดยแพทย์</h5>
				</blockquote>
				<ul>
					<li>ให้สุขศึกษารายกลุ่ม (self-help group)
					<li>พบพยาบาลให้คำปรึกษาและร่วมกันแก้ไขปัญหา
					<li>จัดโครงการอบรมปรับเปลี่ยนพฤติกรรมสุขภาพตามหลัก 3อ3ส
					<li>พิจารณาเยี่ยมบ้านโดยทีมFCTตำบล
				</ul>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"> ปิด </button>
			</div>
		</div>
	</div>
</div>
<!-- Modal-g2 // -->

<!-- Modal-g3 -->
<div class="modal fade text-xs-left" id="dash-modal-g3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="orange">กระบวนการดูแลผู้ป่วย DM/HT กลุ่มที่ 3 เสี่ยงสูง<h4>
			</div>
			<div class="modal-body">
				<blockquote class="blockquote border-left-orange border-left-3">
					<h5>ตรวจโดยอายุรแพทย์</h5>
				</blockquote>
				<ul>
					<li>มี Green Channel สำหรับการส่งต่อ
					<li>พิจารณาเยี่ยมบ้านโดยทีมFCTอำเภอ อย่างน้อยปีละ 2 ครั้ง หรือตาม COC
					<li>ให้สุขศึกษารายบุคคลทั้งผู้ป่วย และ CG
					<li>จัดให้ อสม.ประกบเป็นคู่บัดดี้ในการดูแลเรื่องการทานยา และการรับประทานอาหาร
				</ul>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"> ปิด </button>
			</div>
		</div>
	</div>
</div>
<!-- Modal-g3 // -->

<!-- Modal-g4 -->
<div class="modal fade text-xs-left" id="dash-modal-g4" tabindex="-1" role="dialog" aria-labelledby="myModalLabel17" aria-hidden="true">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="danger">กระบวนการดูแลผู้ป่วย DM/HT กลุ่มที่ 4 มีโรคแทรกซ้อน<h4>
			</div>
			<div class="modal-body">
				<blockquote class="blockquote border-left-danger border-left-3">
					<h5>ส่งต่อ รพ.ท.</h5>
				</blockquote>
				<ul>
					<li>ติดตามเยี่ยมบ้านโดยทีมFCT อำเภอ อย่างน้อยไตรมาสละ 1 ครั้ง
					<li>พิจารณาเยี่ยมบ้านโดยทีม palliative care ในผู้ป่วย End-of-life อย่างน้อยเดือนละ 2 ครั้ง
					<li>Intermediate careในผู้ป่วย DM ที่เป็น Stroke ในช่วง Sub-acute (น้อยกว่า 6 เดือน)
					<li>LTC ในผู้ป่วยติดบ้านติดเตียง
				</ul>

			</div>
			<div class="modal-footer">
				<button type="button" class="btn grey btn-outline-secondary" data-dismiss="modal"> ปิด </button>
			</div>
		</div>
	</div>
</div>
<!-- Modal-g4 // -->
