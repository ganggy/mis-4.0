<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['ym'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">ผู้ป่วยใน</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?>bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?>bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?>bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อ ]</a></li>
			  <li class="<?php echo $tab_active4;?>bg-warning"><a href="#tab_4-4" data-toggle="tab">[ สรุปผู้ป่วยใน ]</a></li>
			  <li class="<?php echo $tab_active5;?>bg-warning"><a href="#tab_5-5" data-toggle="tab">[ สรุปค่าใช้จ่าย ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?>bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>ผู้ป่วยใน </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(regdate,'%Y-%m') AS AMONTH,COUNT(an) AS ipd
FROM ipt
WHERE regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY DATE_FORMAT(regdate,'%Y-%m')
ORDER BY DATE_FORMAT(regdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[ipd]);
		}
if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$countipd10 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myearb-10-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd10,$row[wcount]);
		}

		$countipd11 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myearb-11-01' AND '$myearb-11-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd11,$row[wcount]);
		}

		$countipd12 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myearb-12-01' AND '$myearb-12-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd12,$row[wcount]);
		}

		$countipd01 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-01-01' AND '$myeare-01-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd01,$row[wcount]);
		}

		$countipd02 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-02-01' AND '$myeare-02-29'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd02,$row[wcount]);
		}

		$countipd03 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-03-01' AND '$myeare-03-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd03,$row[wcount]);
		}

		$countipd04 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-04-01' AND '$myeare-04-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd04,$row[wcount]);
		}

		$countipd05 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-05-01' AND '$myeare-05-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd05,$row[wcount]);
		}

		$countipd06 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-06-01' AND '$myeare-06-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd06,$row[wcount]);
		}

		$countipd07 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-07-01' AND '$myeare-07-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd07,$row[wcount]);
		}

		$countipd08 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-08-01' AND '$myeare-08-31'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd08,$row[wcount]);
		}

		$countipd09 = array(); //ตัวแปรแกน y
		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount
FROM ipt i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myeare-09-01' AND '$myeare-09-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd09,$row[wcount]);
		}

// กราฟอัตราการครองเตียง
		 $a_month = array(); //ตัวแปรแกน y
		 $a_percent = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(dchdate,'%Y-%m') AS amonth,(SUM(i.admdate)*100)/(115*30) AS admsum
			FROM an_stat i
			LEFT OUTER JOIN ward w ON w.ward = i.ward
			WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY DATE_FORMAT(dchdate,'%Y-%m')
			ORDER BY DATE_FORMAT(dchdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($a_month,$row[0]);
			 array_push($a_percent,$row[1]);
		}

		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT s.name,COUNT(*) AS ptotal 
			FROM an_stat i
			LEFT OUTER JOIN sex s ON s.code = i.sex
			WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY i.sex";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[ptotal]);
			 array_push($delinamepie,$row[name]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div>


<script type="text/javascript">
// Create the chart
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'จำนวนผู้ป่วยใน ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวนผู้ป่วยใน(ราย)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f} ราย</b><br/>'
    },

    "series": [
        {
            "name": "จำนวนผู้ป่วยใน",
            "colorByPoint": true,
            "data": [
                {
                    "name": "ตุลาคม",
                    "y": <?= $ptipd0; ?>,
                    "drilldown": "ตุลาคม"
                },
                {
                    "name": "พฤศจิกายน",
                    "y": <?= $ptipd1; ?>,
                    "drilldown": "พฤศจิกายน"
                },
                {
                    "name": "ธันวาคม",
                    "y": <?= $ptipd2; ?>,
                    "drilldown": "ธันวาคม"
                },
                {
                    "name": "มกราคม",
                    "y": <?= $ptipd3; ?>,
                    "drilldown": "มกราคม"
                },
                {
                    "name": "กุมภาพันธ์",
                    "y": <?= $ptipd4; ?>,
                    "drilldown": "กุมภาพันธ์"
                },
                {
                    "name": "มีนาคม",
                    "y": <?= $ptipd5; ?>,
                    "drilldown": "มีนาคม"
                },
                {
                    "name": "เมษายน",
                    "y": <?= $ptipd6; ?>,
                    "drilldown": "เมษายน"
                },
                {
                    "name": "พฤษภาคม",
                    "y": <?= $ptipd7; ?>,
                    "drilldown": "พฤษภาคม"
                },
                {
                    "name": "มิถุนายน",
                    "y": <?= $ptipd8; ?>,
                    "drilldown": "มิถุนายน"
                },
                {
                    "name": "กรกฎาคม",
                    "y": <?= $ptipd9; ?>,
                    "drilldown": "กรกฎาคม"
                },
                {
                    "name": "สิงหาคม",
                    "y": <?= $ptipd10; ?>,
                    "drilldown": "สิงหาคม"
                },
                {
                    "name": "กันยายน",
                    "y": <?= $ptipd11; ?>,
                    "drilldown": "กันยายน"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "ตุลาคม",
                "id": "ตุลาคม",
                "data": [
                    ['ตึก1',<?= $countipd10[0]; ?>],
                    ['ตึก2',<?= $countipd10[1]; ?>],
                    ['ตึก3',<?= $countipd10[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd10[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd10[4]; ?>],
                    ['ตึก4',<?= $countipd10[5]; ?>]
                ]
            },
            {
                "name": "พฤศจิกายน",
                "id": "พฤศจิกายน",
                "data": [
                    ['ตึก1',<?= $countipd11[0]; ?>],
                    ['ตึก2',<?= $countipd11[1]; ?>],
                    ['ตึก3',<?= $countipd11[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd11[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd11[4]; ?>],
                    ['ตึก4',<?= $countipd11[5]; ?>]
                ]
            },
            {
                "name": "ธันวาคม",
                "id": "ธันวาคม",
                "data": [
                    ['ตึก1',<?= $countipd12[0]; ?>],
                    ['ตึก2',<?= $countipd12[1]; ?>],
                    ['ตึก3',<?= $countipd12[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd12[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd12[4]; ?>],
                    ['ตึก4',<?= $countipd12[5]; ?>]
                ]
            },
            {
                "name": "มกราคม",
                "id": "มกราคม",
                "data": [
                    ['ตึก1',<?= $countipd01[0]; ?>],
                    ['ตึก2',<?= $countipd01[1]; ?>],
                    ['ตึก3',<?= $countipd01[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd01[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd01[4]; ?>],
                    ['ตึก4',<?= $countipd01[5]; ?>]
                ]
            },
            {
                "name": "กุมภาพันธ์",
                "id": "กุมภาพันธ์",
                "data": [
                    ['ตึก1',<?= $countipd02[0]; ?>],
                    ['ตึก2',<?= $countipd02[1]; ?>],
                    ['ตึก3',<?= $countipd02[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd02[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd02[4]; ?>],
                    ['ตึก4',<?= $countipd02[5]; ?>]
                ]
            },
            {
                "name": "มีนาคม",
                "id": "มีนาคม",
                "data": [
                    ['ตึก1',<?= $countipd03[0]; ?>],
                    ['ตึก2',<?= $countipd03[1]; ?>],
                    ['ตึก3',<?= $countipd03[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd03[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd03[4]; ?>],
                    ['ตึก4',<?= $countipd03[5]; ?>]
                ]
            },
            {
                "name": "เมษายน",
                "id": "เมษายน",
                "data": [
                    ['ตึก1',<?= $countipd04[0]; ?>],
                    ['ตึก2',<?= $countipd04[1]; ?>],
                    ['ตึก3',<?= $countipd04[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd04[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd04[4]; ?>],
                    ['ตึก4',<?= $countipd04[5]; ?>]
                ]
            },
            {
                "name": "พฤษภาคม",
                "id": "พฤษภาคม",
                "data": [
                    ['ตึก1',<?= $countipd05[0]; ?>],
                    ['ตึก2',<?= $countipd05[1]; ?>],
                    ['ตึก3',<?= $countipd05[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd05[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd05[4]; ?>],
                    ['ตึก4',<?= $countipd05[5]; ?>]
                ]
            },
            {
                "name": "มิถุนายน",
                "id": "มิถุนายน",
                "data": [
                    ['ตึก1',<?= $countipd06[0]; ?>],
                    ['ตึก2',<?= $countipd06[1]; ?>],
                    ['ตึก3',<?= $countipd06[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd06[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd06[4]; ?>],
                    ['ตึก4',<?= $countipd06[5]; ?>]
                ]
            },
            {
                "name": "กรกฎาคม",
                "id": "กรกฎาคม",
                "data": [
                    ['ตึก1',<?= $countipd07[0]; ?>],
                    ['ตึก2',<?= $countipd07[1]; ?>],
                    ['ตึก3',<?= $countipd07[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd07[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd07[4]; ?>],
                    ['ตึก4',<?= $countipd07[5]; ?>]
                ]
            },
            {
                "name": "สิงหาคม",
                "id": "สิงหาคม",
                "data": [
                    ['ตึก1',<?= $countipd08[0]; ?>],
                    ['ตึก2',<?= $countipd08[1]; ?>],
                    ['ตึก3',<?= $countipd08[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd08[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd08[4]; ?>],
                    ['ตึก4',<?= $countipd08[5]; ?>]
                ]
            },
            {
                "name": "กันยายน",
                "id": "กันยายน",
                "data": [
                    ['ตึก1',<?= $countipd09[0]; ?>],
                    ['ตึก2',<?= $countipd09[1]; ?>],
                    ['ตึก3',<?= $countipd09[2]; ?>],
                    ['ตึกผู้ป่วยหนัก',<?= $countipd09[3]; ?>],
                    ['ตึกสูติกรรม',<?= $countipd09[4]; ?>],
                    ['ตึก4',<?= $countipd09[5]; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        zoomType: 'xy'
    },
    title: {
        text: 'อัตราการครองเตียง ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: [{
        categories: ['ตุลาคม', 'พฤศจิกายน', 'ธันวาคม', 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
                'กรกฎาคม', 'สิงหาคม', 'กันยายน'],
        crosshair: true
    }],
    yAxis: [{ // Primary yAxis
        labels: {
            format: '{value}%',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
        },
        title: {
            text: 'แนวโน้ม',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
        }
    }, { // Secondary yAxis
        title: {
            text: 'อัตราครองเตียง',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        labels: {
            format: '{value}%',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        opposite: true
    }],
    tooltip: {
        shared: true
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        x: 120,
        verticalAlign: 'top',
        y: 100,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || 'rgba(255,255,255,0.25)'
    },
    series: [{
        name: 'อัตราครองเตียง',
        type: 'column',
		colorByPoint: true,
        yAxis: 1,
        data: [<?= implode(',', $a_percent) ?>],
        tooltip: {
            valueSuffix: '%'
        }

    }, {
        name: 'แนวโน้ม',
        type: 'spline',
		color: 'red',
        data: [<?= implode(',', $a_percent) ?>],
        tooltip: {
            valueSuffix: '%'
        }
    }]
});
</script>
<div><br></div>
<div><br></div>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
		<div id="container3" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <i class="fa fa-bar-chart"></i><h3 class="box-title"> 10 อันดับโรคผู้ป่วยใน</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>ICD10</th>
                    <th class='text-center'>Diag</th>
                    <th class='text-center'>ชื่อโรค</th>
                    <th class='text-center'>ชาย</th>
                    <th class='text-center'>หญิง</th>
                    <th class='text-center'>รวม(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT i.pdx,d.name AS diag,d.tname,COUNT(*) AS countdiag
,SUM(IF(i.sex = '1',1,0)) AS male
,SUM(IF(i.sex = '2',1,0)) AS female
FROM an_stat i
LEFT OUTER JOIN sex s ON s.code = i.sex
LEFT OUTER JOIN icd101 d ON d.code = i.pdx
WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND pdx <> ''
GROUP BY i.pdx
ORDER BY COUNT(*) DESC
LIMIT 10 ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['pdx']."</a></td>";
            echo "        <td>".$row['diag']."</td>";
            echo "        <td>".$row['tname']."</td>";
            echo "        <td class='text-center'>".$row['male']."</td>";
            echo "        <td class='text-center'>".$row['female']."</td>";
            echo "        <td class='text-center'><span class='label label-success'>".$row['countdiag']."</span></td>";
            echo "      </tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <!-- <div class="box-footer clearfix">
              <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">icd10</a>
              <a href="javascript:void(0)" class="btn btn-sm btn-default btn-flat pull-right">View All</a>
            </div>
 -->            <!-- /.box-footer -->
          </div>
          <!-- /.box -->


	</div>
</div>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนเพศชาย-หญิงที่นอนโรงพยาบาล'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie[0]; ?>',   <?= $totalpie[0]; ?>],
            ['<?= $delinamepie[1]; ?>',       <?= $totalpie[1]; ?>]
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนผู้ป่วยใน </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class="text-center">ตึก</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT w.ward,w.name AS wname,COUNT(*) AS wcount
FROM an_stat i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

// case รหัส ward ของ รพ.
switch ($row[ward]) {
    case "01":
        $rowward = 0;
        break;
    case "02":
        $rowward = 1;
        break;
    case "03":
        $rowward = 2;
        break;
    case "04":
        $rowward = 3;
        break;
    case "05":
        $rowward = 4;
        break;
    case "07":
        $rowward = 5;
        break;
    default:
        $rowward = '';
}

echo "      <tr>";
echo "        <td>".$row[wname]."</td>";
echo "        <td class='text-right'>".number_format($countipd10[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd11[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd12[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd01[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd02[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd03[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd04[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd05[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd06[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd07[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd08[$rowward],0)."</td>";
echo "        <td class='text-right'>".number_format($countipd09[$rowward],0)."</td>";
echo "        <td class='text-right'><b>".number_format($row[wcount],0)."</b></td>";
echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(regdate,'%Y-%m') AS amonth,COUNT(*) AS wcount
FROM an_stat i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY DATE_FORMAT(regdate,'%Y-%m')
ORDER BY DATE_FORMAT(regdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[wcount]);
			array_push($YM,$row[amonth]);
        }
        
        echo "</tbody><tfoot><tr class='warning'>";
        echo "        <td class='text-center'><b>รวม</b></td>";

        if ($login_ok == 1) {
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[0]."&itype=m'><b>".number_format($smonth[0],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[1]."&itype=m'><b>".number_format($smonth[1],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[2]."&itype=m'><b>".number_format($smonth[2],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[3]."&itype=m'><b>".number_format($smonth[3],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[4]."&itype=m'><b>".number_format($smonth[4],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[5]."&itype=m'><b>".number_format($smonth[5],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[6]."&itype=m'><b>".number_format($smonth[6],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[7]."&itype=m'><b>".number_format($smonth[7],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[8]."&itype=m'><b>".number_format($smonth[8],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[9]."&itype=m'><b>".number_format($smonth[9],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[10]."&itype=m'><b>".number_format($smonth[10],0)."</b></a></td>";
            echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ipd&ym=".$YM[11]."&itype=m'><b>".number_format($smonth[11],0)."</b></a></td>";
        } else {
            echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
            echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
        }

        echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
        echo "      </tr></tfoot>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </table>
            </div>
            <!-- /.box-body -->

				<div class="panel-heading">
					<b>อัตราการครองเตียง </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class="text-center">ตึก</th>
						<th class="text-center">จำนวนผู้ป่วย</th>
						<th class="text-center">จำนวนวันนอน</th>
						<th class="text-center">เฉลี่ยวันนอนต่อคน</th>
						<th class="text-center">อัตราการครองเตียง</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount,SUM(i.admdate) AS dayadm,SUM(i.admdate)/COUNT(*) AS daypt,(SUM(i.admdate)*100)/(w.bedcount*DATEDIFF('$enddate','$myearb-10-01')+1) AS admsum
FROM an_stat i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
GROUP BY i.ward
ORDER BY i.ward ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "      <tr>";
			echo "        <td>".$row[wname]."</td>";
			echo "        <td class='text-center'>".number_format($row[wcount],0)."</td>";
			echo "        <td class='text-center'>".number_format($row[dayadm],0)."</td>";
			echo "        <td class='text-center'>".number_format($row[daypt],2)."</td>";
			echo "        <td class='text-center'>".number_format($row[admsum],2)."</td>";
			echo "      </tr>";
		}

		$sql = "SELECT w.name AS wname,COUNT(*) AS wcount,SUM(i.admdate) AS dayadm,SUM(i.admdate)/COUNT(*) AS daypt,(SUM(i.admdate)*100)/(90*DATEDIFF('$enddate','$myearb-10-01')+1) AS admsum
FROM an_stat i
LEFT OUTER JOIN ward w ON w.ward = i.ward
WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "</tbody><tfoot><tr class='warning'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
			echo "        <td class='text-center'><b>".number_format($row[wcount],0)."</b></td>";
			echo "        <td class='text-center'><b>".number_format($row[dayadm],0)."</b></td>";
			echo "        <td class='text-center'><b>".number_format($row[daypt],2)."</b></td>";
			echo "        <td class='text-center'><font color='#ff0000'><b>".number_format($row[admsum],2)."</b><br>(คิดจาก 90 เตียง)</font></td>";
			echo "</tr></tfoot>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </table>
            </div>
            <!-- /.box-body -->

			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
    <?php
        if ($_GET['itype'] == "today") {
            $ipd_type = "(รับใหม่วันนี้)";
            $ipd_get_where = "DATE_FORMAT(i.regdate,'%Y-%m-%d') = '".$_GET['ym']."' ";
        } else if ($_GET['itype'] == "discharge") {
            $ipd_type = "(จำหน่ายวันนี้)";
            $ipd_get_where = "DATE_FORMAT(i.dchdate,'%Y-%m-%d') = '".$_GET['ym']."' ";
        } else if ($_GET['itype'] == "admit") {
            $ipd_type = "(Admit ขณะนี้)";
            $ipd_get_where = "ip.dchdate IS NULL ";
        } else if ($_GET['itype'] == "mo") {
            $ipd_type = "(สิทธิ์ชำระเงินและเบิกได้)";
            $ipd_get_where = "ip.dchdate IS NULL AND i.pttype IN (SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')) ";
        } else if ($_GET['itype'] == "uc") {
            $ipd_type = "(สิทธิ์ UC)";
            $ipd_get_where = "ip.dchdate IS NULL AND i.pttype IN (SELECT pttype FROM pttype WHERE pcode IN (SELECT code FROM pcode WHERE tph_pttype_group = 'UC')) ";
        } else if ($_GET['itype'] == "ot") {
            $ipd_type = "(สิทธิอื่นๆ)";
            $ipd_get_where = "ip.dchdate IS NULL AND i.pttype NOT IN (SELECT pttype FROM pttype WHERE pcode IN (SELECT code FROM pcode WHERE tph_pttype_group = 'UC') UNION SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')) ";
        } else if ($_GET['itype'] == "m") {
            $ipd_type = "(เดือน ".$_GET['ym'].")";
            $ipd_get_where = "DATE_FORMAT(i.regdate,'%Y-%m') = '".$_GET['ym']."' ";
        } else {
            $ipd_type = "(แสดงข้อมูลจากตัวเลือก...)";
            $ipd_get_where = "DATE_FORMAT(i.regdate,'%Y-%m') = '".$_GET['ym']."' ";
        }
    ?>

	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
				<div class="panel-heading">
                <h3 class="box-title">รายชื่อผู้ป่วยใน <?php echo $ipd_type; ?></h3>
				</div>
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class='text-center'><b>วัน admit</b></th>
						<th class='text-center'><b>HN / AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>ตึก</b></th>
						<!-- <th class='text-center'><b>วัน discharge</b></th> -->
						<th class='text-center'><b>จำนวนวันนอน</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
        include '_cfg_hos.php';

		$sql = "SELECT i.regdate,i.dchdate,i.admdate,i.admdate_cut24,w.name AS wardname,i.hn,i.an,i.pdx,i.income,i.pttype
        ,p.pname,p.fname,p.lname,i.age_y,p.addrpart,p.road,p.moopart,t.full_name,pt.name AS pttypename
        FROM ipt ip
        LEFT OUTER JOIN an_stat i ON i.an = ip.an
        LEFT OUTER JOIN ward w ON w.ward = i.ward
        LEFT OUTER JOIN patient p ON p.hn = i.hn
        LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
        WHERE $ipd_get_where ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[regdate]."</td>";
			echo "<td>".$row[hn]." / ".$row[an]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td class='text-center'>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[wardname]."</td>";
			// echo "<td>".$row[dchdate]."</td>";
			echo "<td class='text-center'>".$row[admdate]."</td>";
			echo "<td class='text-right'>".number_format($row[income],2)."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

              <div class="tab-pane <?php echo $tab_active4;?>" id="tab_4-4">

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT COUNT(*) AS wtotal,(SELECT SUM(bedcount) FROM ward) AS bedcount
        ,(SELECT SUM(bedcount) FROM ward)-COUNT(*) AS wblank
        FROM ipt WHERE dchdate IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_bedcount = $data['bedcount'];
			$ipt_wardn = $data['wtotal'];
			$ipt_wardnb = $data['wblank'];
			}

        $sql = "SELECT COUNT(IF(pttype IN (SELECT pttype FROM pttype WHERE pcode IN (SELECT `code` FROM pcode WHERE tph_pttype_group = 'UC')),an,NULL)) AS 'uc'
        ,COUNT(IF(pttype IN (SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')),an,NULL)) AS 'mm'
        ,COUNT(IF(pttype NOT IN (
        SELECT pttype FROM pttype WHERE pcode IN (SELECT `code` FROM pcode WHERE tph_pttype_group = 'UC')
        UNION
        SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')
        ),an,NULL)) AS 'ot'
        FROM ipt WHERE dchdate IS NULL";
            $query = $myPDO->query($sql);
            foreach($query as $data) {
            $ipt_mm = $data['mm'];
            $ipt_uc = $data['uc'];
            $ipt_ot = $data['ot'];
            }

		$sql = "SELECT COUNT(*) AS admittoday FROM ipt WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admittoday = $data['admittoday'];
			}

		$sql = "SELECT COUNT(*) AS dchtoday FROM ipt WHERE dchdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_dchtoday = $data['dchtoday'];
			}

		$sql = "SELECT COUNT(*) AS movetoday FROM iptbedmove WHERE movedate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_movetoday = $data['movetoday'];
			}

		$sql = "SELECT SUM(income) AS sumincome FROM an_stat WHERE dchdate IS NULL  ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_sumincome = $data['sumincome'];
			}

        $sql = "SELECT (SUM(i.admdate)*100)/((SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')*DATEDIFF('$enddate','$myearb-10-01')+1) AS admsum
			FROM an_stat i
			WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admsum = $data['admsum'];
            }

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

      <div class="row">
        <div class="col-md-12">
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">สรุปผู้ป่วยใน</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">

              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
				  <!-- Widget: user widget style 1 -->
				  <div class="box box-widget widget-user-2">
					<!-- Add the bg color to the header using any of the bg-* classes -->
					<div class="widget-user-header bg-red">
					  <div class="widget-user-image">
						<img class="img-circle" src="../dist/img/ipd_icon.png" alt="">
					  </div>
					  <!-- /.widget-user-image -->
					  <h3 class="widget-user-username">สรุปข้อมูลผู้ป่วยใน วันนี้</h3>
					  <h5 class="widget-user-desc">จำนวนเตียงทั้งหมด <?php echo $ipt_bedcount;?> เตียง</h5>
					</div>
					<div class="box-footer no-padding">
						<div class="row">
							<div class="col-sm-12">
							  <ul class="nav nav-stacked">
								<li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=today' ;?>">รับใหม่วันนี้ <span class="pull-right badge bg-red"><?php echo number_format($ipt_admittoday,0);?> เตียง</span></a></li>
								<li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=discharge' ;?>">จำหน่ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_dchtoday,0);?> เตียง</span></a></li>
								<li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=admit' ;?>">Admit อยู่ <span class="pull-right badge bg-blue"><?php echo number_format($ipt_wardn,0);?> เตียง</span></a></li>
								<li><a>เตียงว่าง <span class="pull-right badge bg-green"><?php echo number_format($ipt_wardnb,0);?> เตียง</span></a></li>
								<li><a>ย้ายเตียงวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_movetoday,0);?> ราย</span></a></li>
                                <li><a>อัตราการครองเตียง <span class="pull-right badge bg-red"><?php echo number_format($ipt_admsum,2);?> %</span></a></li>
                                <li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=mo' ;?>">สิทธิ์ชำระเงินและเบิกได้ <span class="pull-right badge"> <?php echo number_format($ipt_mm,0);?> เตียง</span></a></li>
                                <li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=uc' ;?>">สิทธิ์ UC<span class="pull-right badge"> <?php echo number_format($ipt_uc,0);?> เตียง</span></a></li>
                                <li><a href="<?php echo $wwwurl.'/?stat=ipd&ym='.date("Y-m-d").'&itype=ot' ;?>">สิทธิอื่นๆ <span class="pull-right badge"> <?php echo number_format($ipt_ot,0);?> เตียง</span></a></li>
							  </ul>
							</div>
						</div>
					</div>
				  </div>
                </div>
                <!-- /.col -->


				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">
                  <p class="text-center">
                    <strong><font size="4" color="#000000">ค่าใช้จ่ายผู้ป่วยในรวม</font> <font size="6" color="#ff0000"><?php echo number_format($ipt_sumincome,2);?></font> <font size="4" color="#000000">บาท</font></strong>
                  </p>
                <!-- /.col -->
					<div class="box-footer no-padding">
						<div class="row">
							<div class="col-sm-12">

            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>รหัสหมวด</th>
                    <th class='text-center'>หมวดค่าใช้จ่าย (Income)</th>
                    <th class='text-right'>มูลค่า</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT SUM(inc01) AS 'inc01',SUM(inc02) AS 'inc02',SUM(inc03) AS 'inc03',SUM(inc04) AS 'inc04',SUM(inc05) AS 'inc05'
        ,SUM(inc06) AS 'inc06',SUM(inc07) AS 'inc07',SUM(inc08) AS 'inc08',SUM(inc09) AS 'inc09',SUM(inc10) AS 'inc10'
        ,SUM(inc11) AS 'inc11',SUM(inc12) AS 'inc12',SUM(inc13) AS 'inc13',SUM(inc14) AS 'inc14',SUM(inc15) AS 'inc15'
        ,SUM(inc16) AS 'inc16',SUM(inc17) AS 'inc17'
        ,SUM(income) AS inc_total
        FROM an_stat WHERE dchdate IS NULL AND ward IS NOT NULL";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $inc01 = $row['inc01'];
            $inc02 = $row['inc02'];
            $inc03 = $row['inc03'];
            $inc04 = $row['inc04'];
            $inc05 = $row['inc05'];
            $inc06 = $row['inc06'];
            $inc07 = $row['inc07'];
            $inc08 = $row['inc08'];
            $inc09 = $row['inc09'];
            $inc10 = $row['inc10'];
            $inc11 = $row['inc11'];
            $inc12 = $row['inc12'];
            $inc13 = $row['inc13'];
            $inc14 = $row['inc14'];
            $inc15 = $row['inc15'];
            $inc16 = $row['inc16'];
            $inc17 = $row['inc17'];
		}

        $sql = "SELECT i.income_group,GROUP_CONCAT(i.name) AS income_name,g.name AS group_name
        FROM income i
        LEFT OUTER JOIN income_group g ON g.income_group = i.income_group
        GROUP BY i.income_group
        ORDER BY i.income_group ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $incomesum = "inc".$row['income_group']."";
            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['income_group']."</a></td>";
            echo "        <td>".$row['income_name']."</td>";
            echo "        <td class='text-right'>".number_format($$incomesum,2)."</td>";
            echo "      </tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->


							</div>
						</div>
					</div>
                </div>


              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>

            </div>
            <!-- /.box-body -->




          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">รายชื่อผู้ป่วยใน Admit ขณะนี้ <b><?php echo number_format($ipt_wardn,0);?></b> เตียง</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT1" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วัน admit</b></th>
						<th class='text-center'><b>HN / AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>ตึก</b></th>
						<th class='text-center'><b>จำนวนวันนอน</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT i.regdate,i.dchdate,i.admdate,i.admdate_cut24,w.name AS wardname,i.hn,i.an,i.pdx,i.income,i.pttype
,p.pname,p.fname,p.lname,i.age_y,p.addrpart,p.road,p.moopart,t.full_name,pt.name AS pttypename
FROM ipt ip
LEFT OUTER JOIN an_stat i ON i.an = ip.an
LEFT OUTER JOIN ward w ON w.ward = i.ward
LEFT OUTER JOIN patient p ON p.hn = i.hn
LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
WHERE ip.dchdate IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[regdate]."</td>";
			echo "<td>".$row[hn]." / ".$row[an]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td class='text-center'>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[wardname]."</td>";
			echo "<td class='text-center'>".$row[admdate]."</td>";
			echo "<td class='text-right'>". number_format($row[income],2)."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div></div>
              <!-- /.tab-pane -->

              <div class="tab-pane <?php echo $tab_active5;?>" id="tab_5-5">
				<div class="panel-heading">
                <h3 class="box-title">สรุปค่าใช้จ่ายผู้ป่วยใน</h3> ตามหมวดค่ารักษาแยกกลุ่มสิทธิ์
				</div>

                <div class="box-body">
                <table id="DataTableExport" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
                        <th class='text-center'>รหัสหมวด</th>
                        <th class='text-center'>หมวดค่าใช้จ่าย (Income)</th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT code,name FROM pcode ORDER BY code ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th colspan='2' scope='col' class='text-center'>".$row['name']."</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th colspan='2' scope='col' class='text-center'>รวม</th>
					  </tr>
					  <tr class="info">
                        <th colspan='2' scope='col'></th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT code,name FROM pcode ORDER BY code ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th scope='col' class='text-center'>ครั้ง</th>";
            echo "<th scope='col' class='text-center'>ค่าใช้จ่าย</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th class='text-center'>ครั้ง</th>
                        <th class='text-center'>ค่าใช้จ่าย</th>
					  </tr>
					</thead>
                    <tbody>


                    </tbody>

                </table>
            </div>
            <!-- /.box-body -->

            <div class="box-body">
            <table id="DataTableExport2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
                        <th scope='col' class='text-center'>pcode</th>
                        <th scope='col' class='text-center'>สิทธิ์</th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
        FROM income_group g
        LEFT OUTER JOIN income i ON i.income_group = g.income_group
        GROUP BY g.income_group
        ORDER BY g.income_group ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th colspan='2' scope='col' class='text-center'>".$row['group_name']."</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th colspan='2' scope='col' class='text-center'>รวม</th>
					  </tr>
					  <tr class="info">
                        <th colspan='2' scope='col'></th>
<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
        FROM income_group g
        LEFT OUTER JOIN income i ON i.income_group = g.income_group
        GROUP BY g.income_group
        ORDER BY g.income_group ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "<th scope='col' class='text-center'>".$row['group_name']."(ครั้ง)</th>";
            echo "<th scope='col' class='text-center'>(บาท)</th>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                        <th scope='col' class='text-center'>รวมครั้ง</th>
                        <th scope='col' class='text-center'>รวมค่าใช้จ่าย</th>
					  </tr>
					</thead>
                    <tbody>

<?php
	try {
		include '_cfg_hos.php';
        $sql = "SELECT a.pcode,p.name
,COUNT(IF(a.inc01 > 0,a.an,NULL)) AS 'vis01',SUM(a.inc01) AS 'inc01'
,COUNT(IF(a.inc02 > 0,a.an,NULL)) AS 'vis02',SUM(a.inc02) AS 'inc02'
,COUNT(IF(a.inc03 > 0,a.an,NULL)) AS 'vis03',SUM(a.inc03) AS 'inc03'
,COUNT(IF(a.inc04 > 0,a.an,NULL)) AS 'vis04',SUM(a.inc04) AS 'inc04'
,COUNT(IF(a.inc05 > 0,a.an,NULL)) AS 'vis05',SUM(a.inc05) AS 'inc05'
,COUNT(IF(a.inc06 > 0,a.an,NULL)) AS 'vis06',SUM(a.inc06) AS 'inc06'
,COUNT(IF(a.inc07 > 0,a.an,NULL)) AS 'vis07',SUM(a.inc07) AS 'inc07'
,COUNT(IF(a.inc08 > 0,a.an,NULL)) AS 'vis08',SUM(a.inc08) AS 'inc08'
,COUNT(IF(a.inc09 > 0,a.an,NULL)) AS 'vis09',SUM(a.inc09) AS 'inc09'
,COUNT(IF(a.inc10 > 0,a.an,NULL)) AS 'vis10',SUM(a.inc10) AS 'inc10'
,COUNT(IF(a.inc11 > 0,a.an,NULL)) AS 'vis11',SUM(a.inc11) AS 'inc11'
,COUNT(IF(a.inc12 > 0,a.an,NULL)) AS 'vis12',SUM(a.inc12) AS 'inc12'
,COUNT(IF(a.inc13 > 0,a.an,NULL)) AS 'vis13',SUM(a.inc13) AS 'inc13'
,COUNT(IF(a.inc14 > 0,a.an,NULL)) AS 'vis14',SUM(a.inc14) AS 'inc14'
,COUNT(IF(a.inc15 > 0,a.an,NULL)) AS 'vis15',SUM(a.inc15) AS 'inc15'
,COUNT(IF(a.inc16 > 0,a.an,NULL)) AS 'vis16',SUM(a.inc16) AS 'inc16'
,COUNT(IF(a.inc17 > 0,a.an,NULL)) AS 'vis17',SUM(a.inc17) AS 'inc17'
,COUNT(*) AS 'vis_total2',SUM(income) AS inc_total2
        FROM an_stat a
        LEFT OUTER JOIN pcode p ON p.code = a.pcode
        WHERE a.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND a.ward IS NOT NULL
        GROUP BY a.pcode
        ORDER BY a.pcode ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $inc01 = $row['inc01'];
            $inc02 = $row['inc02'];
            $inc03 = $row['inc03'];
            $inc04 = $row['inc04'];
            $inc05 = $row['inc05'];
            $inc06 = $row['inc06'];
            $inc07 = $row['inc07'];
            $inc08 = $row['inc08'];
            $inc09 = $row['inc09'];
            $inc10 = $row['inc10'];
            $inc11 = $row['inc11'];
            $inc12 = $row['inc12'];
            $inc13 = $row['inc13'];
            $inc14 = $row['inc14'];
            $inc15 = $row['inc15'];
            $inc16 = $row['inc16'];
            $inc17 = $row['inc17'];
            $inc_total2 = $row['inc_total2'];

            $vis01 = $row['vis01'];
            $vis02 = $row['vis02'];
            $vis03 = $row['vis03'];
            $vis04 = $row['vis04'];
            $vis05 = $row['vis05'];
            $vis06 = $row['vis06'];
            $vis07 = $row['vis07'];
            $vis08 = $row['vis08'];
            $vis09 = $row['vis09'];
            $vis10 = $row['vis10'];
            $vis11 = $row['vis11'];
            $vis12 = $row['vis12'];
            $vis13 = $row['vis13'];
            $vis14 = $row['vis14'];
            $vis15 = $row['vis15'];
            $vis16 = $row['vis16'];
            $vis17 = $row['vis17'];
            $vis_total2 = $row['vis_total2'];

            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['pcode']."</a></td>";
            echo "        <td>".$row['name']."</td>";

            $sql = "SELECT g.income_group,g.name AS group_name,GROUP_CONCAT(i.income) AS income,GROUP_CONCAT(i.name) AS income_name
            FROM income_group g
            LEFT OUTER JOIN income i ON i.income_group = g.income_group
            GROUP BY g.income_group
            ORDER BY g.income_group ASC";
            $query = $myPDO->query($sql);
            $pcodexx = $row['pcode'];
            foreach($query as $row) {
                $incomecol = "inc".$row['income_group']."";
                $visitcol = "vis".$row['income_group']."";
                echo "    <td class='text-right'>".number_format($$visitcol,0)."</td>";
                echo "    <td class='text-right'>".number_format($$incomecol,2)."</td>";
            }
    
            echo "        <td class='text-right'>".number_format($vis_total2,0)."</td>";
            echo "        <td class='text-right'>".number_format($inc_total2,2)."</td>";
            echo "      </tr>";
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->


			  </div>
              <!-- /.tab-pane -->

	<?php } else { }?>

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p>ประมวลจากวันที่รับไว้รักษาใน รพ. ในช่วงเวลาที่กำหนด แยกรายเดือน แยกรายหอผู้ป่วย</p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT i.regdate,i.dchdate,i.admdate,i.admdate_cut24,w.name AS wardname,i.hn,i.an,i.pdx,i.income,i.pttype
,p.pname,p.fname,p.lname,i.age_y,p.addrpart,p.road,p.moopart,t.full_name,pt.name AS pttypename
FROM an_stat i
LEFT OUTER JOIN ward w ON w.ward = i.ward
LEFT OUTER JOIN patient p ON p.hn = i.hn
LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
WHERE DATE_FORMAT(i.regdate,'%Y-%m') = '$yearmonth'</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #0080c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำแนะนำ</h3>
						</div>
						<div class="box-footer text-black">
							<p><u><b>สำหรับสมาชิก</b></u>ให้เข้าระบบสมาชิก หากต้องการดูข้อมูลรายชื่อ ให้คลิกที่แท็บ [ ตารางข้อมูล ] แล้วคลิกลิงค์ที่ตัวเลขผลรวมแต่ละเดือนก่อน เพื่อให้โปรแกรมประมวลผลเรียกรายชื่อสำหรับเดือนนั้นๆมาแสดงผล
							ที่แท็บ [ รายชื่อ ] เพื่อดูหรือค้นหาได้
							<br><br><u><i><b>หมายเหตุ</b></i></u>  เพื่อให้การเรียกดูข้อมูล ไม่ต้องประมวลผลข้อมูลมากเกินไปจึงจำเป็นต้องกรองข้อมูลก่อนนำมาแสดงผล
							</p>
						</div>
					</div>
				</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->


            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


