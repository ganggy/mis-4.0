<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$dnowy = date("Y");

$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

$ncd_clinic_code_copd = "043"; //รหัสคลินิกโรคปอด
$ncd_clinic_code_asthma = "044"; //รหัสคลินิกโรคหอบหืด
$ncd_clinic_code_tb = "051"; //รหัสคลินิกวัณโรค
$ncd_clinic_code_dm = $dm_clinic_code; //รหัสคลินิกเบาหวาน
$ncd_clinic_code_ht = $ht_clinic_code; //รหัสคลินิกความดัน
$ncd_code_chwpart = $hos_chwpart; //รหัสจังหวัด
$ncd_code_amppart = $hos_amppart; //รหัสอำเภอ

/*
if (isset($_POST['cxrdaterange'])) {
    $tab_active4 = "active";
}
*/
if ($_POST['cxrdaterange'] || NULL) {
    $tab_active4 = "active ";
} else if ($_POST['smdaterange'] || NULL) {
    $tab_active5 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active3 = "";
    $tab_active4 = "";
    $tab_active5 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">โรคไม่ติดต่อ NCD</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?>bg-warning"><a href="#tab_1-1" data-toggle="tab">[ Dash ]</a></li>
					<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
					<?php if ($login_ok == 1) { ?>
              <li class="<?php echo $tab_active2;?>bg-warning"><a href="#tab_2-2" data-toggle="tab">[ NCD Clinic Plus ]</a></li>
							<li class="<?php echo $tab_active3;?>bg-warning"><a href="#tab_3-3" data-toggle="tab">[ ความดัน ]</a></li>
							<li class="<?php echo $tab_active5;?>bg-danger"><a href="#tab_5-5" data-toggle="tab">[ การคัดกรอง ]</a></li>
							<li class="<?php echo $tab_active4;?>bg-danger"><a href="#tab_4-4" data-toggle="tab">[ Dx CANCER ]</a></li>
					<?php } else { }?>
							<li class="<?php echo $tab_active9;?>bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>

							<li class="pull-left header"><i class="fa fa-th"></i> <b>โรคไม่ติดต่อ NCD</b></li>

<div class="panel-body">
  <!-- <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>
 -->
			</ul>
            <div class="tab-content">

		<!-- /.tab-pane -->
		<div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		// ******* NCD ******* //
		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT cm.clinic AS clinic,c.`name` AS ncdname,COUNT(*) AS ptotal
		FROM clinicmember cm
		LEFT OUTER JOIN clinic c ON c.clinic = cm.clinic
		LEFT OUTER JOIN patient p ON p.hn = cm.hn
		WHERE p.death <> 'Y' AND cm.clinic IN ('$ncd_clinic_code_dm','$ncd_clinic_code_ht','$ncd_clinic_code_copd')
		AND cm.discharge <> 'N' AND p.chwpart = '$ncd_code_chwpart' AND p.amppart = '$ncd_code_amppart'
		GROUP BY cm.clinic

		UNION

		SELECT '$ncd_clinic_code_dm' AS clinic,'มะเร็ง' AS ncdname,COUNT(*)  AS ptotal
		FROM patient_cancer_registeration pc
		LEFT OUTER JOIN patient p ON p.hn = pc.hn
		WHERE pc.cancer_person_live_status_id <> '2'
		AND p.chwpart = '$ncd_code_chwpart' AND p.amppart = '$ncd_code_amppart'";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[ptotal]);
			 array_push($delinamepie,$row[ncdname]);
		}

		// ******* DM ******* //
		$h_dm_0_19 = array();
		$h_dm_20_34 = array();
		$h_dm_35_59 = array();
		$h_dm_60_69 = array();
		$h_dm_70_79 = array();
		$h_dm_80up = array();
		$sql = "SELECT SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 0 AND 19 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_0_19
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 20 AND 34 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_20_34
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 35 AND 59 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_35_59
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 60 AND 69 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_60_69
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 70 AND 79 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_70_79
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) >= 80 THEN 1 ELSE 0 END)*100/COUNT(*) AS dm_80up
		FROM clinicmember cm
		LEFT OUTER JOIN patient p ON p.hn = cm.hn
		WHERE p.chwpart = '$ncd_code_chwpart' AND p.amppart = '$ncd_code_amppart' AND p.death <> 'Y' AND cm.discharge <> 'Y' AND cm.clinic = '$ncd_clinic_code_dm'
		AND cm.clinic_member_status_id NOT IN (1,2)
		GROUP BY cm.clinic ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($h_dm_0_19,$row[dm_0_19]);
			 array_push($h_dm_20_34,$row[dm_20_34]);
			 array_push($h_dm_35_59,$row[dm_35_59]);
			 array_push($h_dm_60_69,$row[dm_60_69]);
			 array_push($h_dm_70_79,$row[dm_70_79]);
			 array_push($h_dm_80up,$row[dm_80up]);
		}

		// ******* HT ******* //
		$h_ht_0_19 = array();
		$h_ht_20_34 = array();
		$h_ht_35_59 = array();
		$h_ht_60_69 = array();
		$h_ht_70_79 = array();
		$h_ht_80up = array();
		$sql = "SELECT 'จำนวน(คน)' AS agecount
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 0 AND 19 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_0_19
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 20 AND 34 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_20_34
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 35 AND 59 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_35_59
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 60 AND 69 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_60_69
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) BETWEEN 70 AND 79 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_70_79
		,SUM(CASE WHEN TIMESTAMPDIFF(YEAR,p.birthday,CURDATE()) >= 80 THEN 1 ELSE 0 END)*100/COUNT(*) AS ht_80up
		,COUNT(*) AS httotal
		FROM clinicmember cm
		LEFT OUTER JOIN patient p ON p.hn = cm.hn
		WHERE p.chwpart = '$ncd_code_chwpart' AND p.amppart = '$ncd_code_amppart' AND p.death <> 'Y' AND cm.discharge <> 'Y' AND cm.clinic = '$ncd_clinic_code_ht'
		AND cm.clinic_member_status_id NOT IN (1,2)
		GROUP BY cm.clinic ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
		 array_push($h_ht_0_19,$row[ht_0_19]);
		 array_push($h_ht_20_34,$row[ht_20_34]);
		 array_push($h_ht_35_59,$row[ht_35_59]);
		 array_push($h_ht_60_69,$row[ht_60_69]);
		 array_push($h_ht_70_79,$row[ht_70_79]);
		 array_push($h_ht_80up,$row[ht_80up]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>


<!-- <div class="row">
	<div class="col-sm-6">
		<div id="container3" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-sm-6">
		<div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div> -->
<div class="row">
	<div class="col-sm-6">
		<div id="container1" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-sm-6">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div>

<script type="text/javascript">
Highcharts.chart('container1', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนโรคไม่ติดต่อสำคัญ'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
				['<?= $delinamepie[0]; ?>', <?= $totalpie[0]; ?>],
				['<?= $delinamepie[1]; ?>', <?= $totalpie[1]; ?>],
				['<?= $delinamepie[2]; ?>', <?= $totalpie[2]; ?>],
				{
					name: '<?= $delinamepie[3]; ?>',
					y: <?= $totalpie[3]; ?>,
					sliced: true,
					selected: true
				}
			]
    }]
});
</script>


<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'เปรียบเทียบผู้ป่วยเบาหวาน-ความดัน ตามกลุ่มอายุ'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        categories: ['ต่ำกว่า 20 ปี', '20-34 ปี', '35-59 ปี', '60-69 ปี', '70-79 ปี', '80 ปีขึ้นไป'],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'ร้อยละ'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y:.2f}%</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'ความดัน',
        data: [
					['ต่ำกว่า 20 ปี',   <?= $h_ht_0_19[0]; ?>],
					['20-34 ปี',   <?= $h_ht_20_34[0]; ?>],
					['35-59 ปี',   <?= $h_ht_35_59[0]; ?>],
					['60-69 ปี',   <?= $h_ht_60_69[0]; ?>],
					['70-79 ปี',   <?= $h_ht_70_79[0]; ?>],
					['80 ปีขึ้นไป',   <?= $h_ht_80up[0]; ?>]
			]

    }, {
        name: 'เบาหวาน',
        data: [
					['ต่ำกว่า 20 ปี',   <?= $h_dm_0_19[0]; ?>],
					['20-34 ปี',   <?= $h_dm_20_34[0]; ?>],
					['35-59 ปี',   <?= $h_dm_35_59[0]; ?>],
					['60-69 ปี',   <?= $h_dm_60_69[0]; ?>],
					['70-79 ปี',   <?= $h_dm_70_79[0]; ?>],
					['80 ปีขึ้นไป',   <?= $h_dm_80up[0]; ?>]
			]

    }]
});
</script>


			</div>
		</div>
		<!-- /.tab-pane -->

		<!-- /.tab-pane -->
		<div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
            <!-- /.box-header -->
            <div class="box-body">
							<?php include 'module_ncd_clinic_dash.php';?>
							<?php include 'module_ncd_clinic_dm.php';?>
							<?php include 'module_ncd_clinic_ht.php';?>

						</div>
		</div>
		<!-- /.tab-pane -->

		<!-- /.tab-pane -->
		<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
            <!-- /.box-header -->
            <div class="box-body">
			<b>ทะเบียนผู้ป่วยในคลินิกความดันโลหิตสูง</b> (สถานะยังรักษาอยู่)
                <table id="DataTableT2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>HN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php

?>
                  </tbody>
                </table>
			</div>
		</div>
		<!-- /.tab-pane -->



	<!-- สำหรับสมาชิก HOSxP -->
	<?php if ($login_ok == 1) { ?>

        <div class="tab-pane <?php echo $tab_active4;?>" id="tab_4-4">
			<!-- /.box-header -->
            <div class="box-body">

            <div class="box-body">
  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
              <div class="row">
					<div class="form-group">
					  <label for="cxrdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange-btn" name="cxrdaterange">
					</div>
					<button type="submit" class="btn btn-default"> ประมวลผล </button>
					<?php
						$datenow_start = date("Y-m-01");

						$date1d = substr($_POST['cxrdaterange'],3,2);
						$date1m = substr($_POST['cxrdaterange'],0,2);
						$date1y = substr($_POST['cxrdaterange'],6,4);
						$date2d = substr($_POST['cxrdaterange'],16,2);
						$date2m = substr($_POST['cxrdaterange'],13,2);
						$date2y = substr($_POST['cxrdaterange'],19,4);

						if ($_POST['cxrdaterange'] == '') {
							$cxrdate1 = $datenow_start;
							$cxrdate2 = $nowdate;
						} else {
							$cxrdate1 = $date1y."-".$date1m."-".$date1d;
							$cxrdate2 = $date2y."-".$date2m."-".$date2d;
						}

					?>
              </div>
  </form>
            </div>

			<h5><b>ข้อมูลผู้รับบริการ Diag มะเร็งทุกชนิด</b> (<?php echo DateThaiShort($cxrdate1); ?> - <?php echo DateThaiShort($cxrdate2); ?>)</h5>

				<table id="DataTableExport" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>วินิจฉัย pdx</b></th>
						<th class='text-center'><b>วินิจฉัย como</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>ขึ้นทะเบียน</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT GROUP_CONCAT(vstdate) AS vstdate,v.hn,p.pname,p.fname,p.lname,p.addrpart,p.road,p.moopart,t.full_name,v.age_y,GROUP_CONCAT(DISTINCT(pdx)) AS diag_pdx
,GROUP_CONCAT(DISTINCT(dx0)) AS diag_como0,GROUP_CONCAT(DISTINCT(dx1)) AS diag_como1,GROUP_CONCAT(DISTINCT(dx2)) AS diag_como2,GROUP_CONCAT(DISTINCT(dx3)) AS diag_como3
,GROUP_CONCAT(DISTINCT(dx4)) AS diag_como4,GROUP_CONCAT(DISTINCT(dx5)) AS diag_como5,DATE_FORMAT(c.create_date,'%Y-%m-%d') AS create_date
FROM vn_stat v
LEFT OUTER JOIN patient p ON p.hn = v.hn
LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
LEFT OUTER JOIN data_cancer c ON c.hn_code = v.hn
WHERE v.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' 
AND (pdx LIKE 'C%' OR dx0 LIKE 'C%' OR dx1 LIKE 'C%' OR dx2 LIKE 'C%'
OR dx3 LIKE 'C%' OR dx4 LIKE 'C%' OR dx5 LIKE 'C%'
)
GROUP BY v.hn ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			if ($row[create_date] == NULL) {
				$status_red1 = "";
				$status_red2 = "";
			} else {
				$status_red1 = "<font color='#ff0000'>";
				$status_red2 = "</font>";
			}

			echo "<tr>";
			echo "<td>$status_red1".$row[vstdate]."$status_red2</td>";
			echo "<td>$status_red1".$row[hn]."$status_red2</td>";
			echo "<td>$status_red1".$row[pname]."".$row[fname]."  ".$row[lname]."$status_red2</td>";
			echo "<td class='text-center'>$status_red1".$row[age_y]."$status_red2</td>";
			echo "<td>$status_red1".$row[diag_pdx]."$status_red2</td>";
			echo "<td>$status_red1".$row[diag_como0].",".$row[diag_como1].",".$row[diag_como2].",".$row[diag_como3].",".$row[diag_como4].",".$row[diag_como5]."$status_red2</td>";
			echo "<td>$status_red1".$row[addrpart]." ม.".$row[moo]." ".$row[full_name]."$status_red2</td>";
			echo "<td>$status_red1".$row[create_date]."$status_red2</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>

				<p><i>(ประมวลผลจากผู้รับบริการที่วินิจฉัย icd10 ที่ขึ้นต้นด้วย C ทุกรหัส)</i></p>

			</div>
            <!-- /.box-body -->

		</div>
        <!-- /.tab-pane -->

        <div class="tab-pane <?php echo $tab_active5;?>" id="tab_5-5">
			<!-- /.box-header -->
            <div class="box-body">

            <div class="box-body">
  <form class="form-inline" method="post" action="<?php echo $PHP_SELF ?>">
              <div class="row">
					<div class="form-group">
					  <label for="smdaterange">เลือกช่วงวันที่: </label>
					  <input type="text" class="form-control" id="daterange2-btn" name="smdaterange">
					</div>
					<button type="submit" class="btn btn-default"> ประมวลผล </button>
					<?php
						$datenow_start = date("Y-m-d");

						$date1d = substr($_POST['smdaterange'],3,2);
						$date1m = substr($_POST['smdaterange'],0,2);
						$date1y = substr($_POST['smdaterange'],6,4);
						$date2d = substr($_POST['smdaterange'],16,2);
						$date2m = substr($_POST['smdaterange'],13,2);
						$date2y = substr($_POST['smdaterange'],19,4);

						if ($_POST['smdaterange'] == '') {
							$cxrdate1 = $datenow_start;
							$cxrdate2 = $nowdate;
						} else {
							$cxrdate1 = $date1y."-".$date1m."-".$date1d;
							$cxrdate2 = $date2y."-".$date2m."-".$date2d;
						}

					?>
              </div>
  </form>
            </div>

			<h5><b>ข้อมูลผู้รับบริการได้รับการคัดกรอง สูบบุหรี่ สุรา</b> (<?php echo DateThaiShort($cxrdate1); ?> - <?php echo DateThaiShort($cxrdate2); ?>)</h5>

				<table id="DataTableExport2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>เขตรับผิดชอบ</b></th>
						<th class='text-center'><b>การสูบบุหรี่</b></th>
						<th class='text-center'><b>การดื่มสุรา</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT o.vstdate,o.hn,p.pname,p.fname,p.lname,sex.name,v.age_y,p.addrpart,p.road,p.moopart,t.full_name,st.smoking_type_name,dt.drinking_type_name
,IF(p.type_area IN (1,3),'ในเขต','นอกเขต') AS typearea
FROM ovst o
LEFT OUTER JOIN vn_stat v ON v.vn = o.vn
LEFT OUTER JOIN opdscreen s ON s.vn = o.vn
LEFT OUTER JOIN patient p ON p.hn = o.hn
LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
LEFT OUTER JOIN sex ON sex.code = p.sex
LEFT OUTER JOIN smoking_type st ON st.smoking_type_id = s.smoking_type_id
LEFT OUTER JOIN drinking_type dt ON dt.drinking_type_id = s.drinking_type_id
WHERE s.vstdate BETWEEN '$cxrdate1' AND '$cxrdate2' AND (s.smoking_type_id IS NOT NULL OR s.drinking_type_id IS NOT NULL) ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			if ($row[typearea] == "ในเขต") {
				$status_red1 = "<font color='#ff0000'>";
				$status_red2 = "</font>";
			} else {
				$status_red1 = "";
				$status_red2 = "";
			}

			echo "<tr>";
			echo "<td>$status_red1".$row[vstdate]."$status_red2</td>";
			echo "<td>$status_red1".$row[hn]."$status_red2</td>";
			echo "<td>$status_red1".$row[pname]."".$row[fname]."  ".$row[lname]."$status_red2</td>";
			echo "<td class='text-center'>$status_red1".$row[age_y]."$status_red2</td>";
			echo "<td>$status_red1".$row[addrpart]." ม.".$row[moo]." ".$row[full_name]."$status_red2</td>";
			echo "<td>$status_red1".$row[typearea]."$status_red2</td>";
			echo "<td>$status_red1".$row[smoking_type_name]."$status_red2</td>";
			echo "<td>$status_red1".$row[drinking_type_name]."$status_red2</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>

				<p><i>(ประมวลผลจากผู้รับบริการที่วินิจฉัย icd10 ที่ขึ้นต้นด้วย C ทุกรหัส)</i></p>

			</div>
            <!-- /.box-body -->

		</div>
        <!-- /.tab-pane -->

	<?php } else { }?>

		<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>


			</div>
            <!-- /.box-body -->
		</div>
		<!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


