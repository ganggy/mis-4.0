		<!-- IPT WARD INFO -->
        <div class="col-md-3">
          <div class="box box-<?php echo $col_head;?> collapsed-box direct-chat direct-chat-warning">
            <div class="box-header with-border">

              <div class="user-block">
                <img class="img-circle" src="<?php echo $pic; ?>" alt="">
                <span class="username"><h3 class="box-title"><?php echo $pt_sex;?> <?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></h3></span>
                <span class="description">วัน Admit <?php echo DateThaiShort($row['regdate']);?></span>

				  <div>
                    วันนอน <span class="<?php echo $col_admdate;?>"><?php echo number_format($row['admdate'],0);?></span> วัน
                    <a class="pull-right">AN <?php echo $row['an'];?></a>
                  </div>
                  <div>
                    ค่าใช้จ่าย <span class="<?php echo $col_income;?>"><?php echo number_format($row['income'],2);?></span> บาท
                    <a class="pull-right">อายุ <?php echo $row['age_y'];?></span> ปี</a>
                  </div>
                  <div>
                    แพ้ยา : <span class="label label-danger"><?php echo $row['drugallergy'];?></span>
                  </div>
                  <div>
                    แพทย์ : <?php echo $row['doctorname'];?>
                  </div>

			  </div>

			  <div class="box-tools pull-right">
                <span class="badge bg-light-blue">เตียง <?php echo $row['bedno'];?></span>
                <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="เพิ่มเติม" data-widget="chat-pane-toggle">
                  <i class="fa fa-comments"></i></button>
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <!-- Conversations are loaded here -->
              <div class="direct-chat-messages">

                <!-- Message to the right -->
                <div class="direct-chat-msg right">
                  <div class="direct-chat-info clearfix">
                    <span class="direct-chat-name pull-right">วัน Admit <?php echo DateThaiShort($row['regdate']);?></span>
                    <span class="direct-chat-timestamp pull-left">รายละเอียดผู้ป่วย</span>
                  </div>
                  <!-- /.direct-chat-info -->
				  <div class="row invoice-info">
					<div class="col-sm-4 invoice-col">
						<!-- <img class="profile-user-img img-responsive img-circle" src="../dist/img/user3-128x128.jpg" alt=""> -->
						<img class="profile-user-img img-responsive img-circle" src="<?php echo $pic; ?>" alt="">

					</div>
					<!-- /.col -->
					<div class="col-sm-8 invoice-col">
						<strong><?php echo $row['pname'].$row['fname']."  ".$row['lname'];?></strong><br>
						วันเกิด : <?php echo DateThaiShort($row['birthday']);?><br>
						มารดา : <?php echo $row['mathername']."  ".$row['motherlname'];?><br>
						บิดา : <?php echo $row['fathername']."  ".$row['fatherlname'];?><br>
						เบอร์โทรศัพท์ : <?php echo $row['hometel'].", ".$row['informtel'].", ".$row['worktel'];?>
					</div>
					<!-- /.col -->
				  </div>
				  <!-- /.row -->
                  <div class="direct-chat-info clearfix">
                    <br><span class="direct-chat-timestamp pull-left">อาการสำคัญ</span>
                  </div>
				  <div class="direct-chat-text">
                    <?php echo $row['prediag'];?>
                  </div>

                  <!-- /.direct-chat-text -->
                </div>
                <!-- /.direct-chat-msg -->

                <!-- Message. Default to the left -->
                <div class="direct-chat-msg">

          <!-- About Me Box -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i> สิทธิรักษาพยาบาล</strong>
              <p class="text-muted">
                <?php echo $row['pttypename'];?>  เลขที่ "<?php echo $row['pttypeno'];?>"
              </p>
              <hr>
              <strong><i class="fa fa-map-marker margin-r-5"></i> ที่อยู่</strong>
              <p class="text-muted"><?php echo $row['addrpart']." ".$row['road']." ม.".$row['moopart']." ".$row['full_name'];?></p>
              <hr>
              <strong><i class="fa fa-pencil margin-r-5"></i> โรคประจำตัว</strong>
              <p>
                โรคประจำตัว : <span class="label label-warning"><?php echo $row['clinic'];?></span>
              </p>

            </div>
            <!-- /.box-body -->

                </div>
                <!-- /.direct-chat-msg -->
              </div>
              <!--/.direct-chat-messages-->

              <!-- Contacts are loaded here -->
              <div class="direct-chat-contacts">
                <ul class="contacts-list">
                  <li>
                    <a href="#">
                      <!-- <img class="contacts-list-img" src="../dist/img/user1-128x128.jpg" alt=""> -->
                      <div class="contacts-list-info">
                            <span class="contacts-list-name">
                              ข้อมูลการรักษา
                              <small class="contacts-list-date pull-right">วันที่</small>
                            </span>
                        <span class="contacts-list-msg">รายการ</span>
                      </div>
                      <!-- /.contacts-list-info -->
                    </a>
                  </li>
                  <!-- End Contact Item -->
                </ul>
                <!-- /.contatcts-list -->
              </div>
              <!-- /.direct-chat-pane -->
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
				<strong><i class="fa fa-file-text-o margin-r-5"></i> Note </strong>
            </div>
            <!-- /.box-footer-->
          </div>
        </div>
		<!--/.IPT WARD INFO -->
