<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

$ward_custom_tab_guest = "";
$ward_custom_tab_user = "";
$ward_custom_tab_register = "";
$ward_custom_tab_head = "";
$ward_info_id = $_GET['ward'];

try {
	include '_cfg_hos.php';
	$sql = "SELECT ward,`name` AS wardname FROM ward WHERE ward_active = 'Y' AND ward = '$ward_info_id' ";
	$result = $myPDO->query($sql);
	foreach ($result AS $data) {
		$ward_info_name = $data['wardname'];
	}
}
catch(PDOException $e) {echo "Connection failed: " . $e->getMessage();}
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

  <?php include 'ipt_ward_header.php';?>

            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';
		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT s.name,COUNT(*) AS ptotal 
			FROM an_stat i
			LEFT OUTER JOIN sex s ON s.code = i.sex
			WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ward = '$ward_info_id'
			GROUP BY i.sex";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[ptotal]);
			 array_push($delinamepie,$row[name]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-4">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-8">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <i class="fa fa-pie-chart"></i><h3 class="box-title"> 10 อันดับโรคผู้ป่วยนอนโรงพยาบาล <?php echo $ward_info_name;?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>ICD10</th>
                    <th class='text-center'>Diag</th>
                    <th class='text-center'>ชื่อโรค</th>
                    <th class='text-center'>ชาย</th>
                    <th class='text-center'>หญิง</th>
                    <th class='text-center'>รวม(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT i.pdx,d.name AS diag,d.tname,COUNT(*) AS countdiag
,SUM(IF(i.sex = '1',1,0)) AS male
,SUM(IF(i.sex = '2',1,0)) AS female
FROM an_stat i
LEFT OUTER JOIN sex s ON s.code = i.sex
LEFT OUTER JOIN icd101 d ON d.code = i.pdx
WHERE i.regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND ward = '$ward_info_id' AND pdx <> ''
GROUP BY i.pdx
ORDER BY COUNT(*) DESC
LIMIT 10 ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row['pdx']."</a></td>";
            echo "        <td>".$row['diag']."</td>";
            echo "        <td>".$row['tname']."</td>";
            echo "        <td class='text-center'>".$row['male']."</td>";
            echo "        <td class='text-center'>".$row['female']."</td>";
            echo "        <td class='text-center'><span class='label label-success'>".$row['countdiag']."</span></td>";
            echo "      </tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
          </div>
          <!-- /.box -->
	</div>
</div>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนเพศชาย-หญิงที่นอนโรงพยาบาล'
    },
    subtitle: {
        text: '<?= $ward_info_name;?>'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie[0]; ?>',   <?= $totalpie[0]; ?>],
            ['<?= $delinamepie[1]; ?>',       <?= $totalpie[1]; ?>]
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

<?php include 'ipt_ward_info.php'; ?>
<?php include 'ipt_ward_info_doctor.php'; ?>
<?php include 'ipt_ward_med_profile.php'; ?>

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT i.*,a.*,p.*,s.*,t.full_name,pt.name AS pttypename,pm.image,d.name AS doctorname
			FROM ipt i 
			LEFT OUTER JOIN an_stat s ON s.an = i.an
			LEFT OUTER JOIN iptadm a ON a.an = i.an
			LEFT OUTER JOIN patient p ON p.hn = i.hn
			LEFT OUTER JOIN pttype pt ON pt.pttype = i.pttype
			LEFT OUTER JOIN patient_image pm ON pm.hn = i.hn
			LEFT OUTER JOIN doctor d ON d.code = i.incharge_doctor
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			WHERE i.dchdate IS NULL AND i.ward = '$ward_info_id'
			ORDER BY a.bedno ASC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->


            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>
