<?php
if ($_GET['doctor'] || NULL) {
  $tab_active8 = "active ";
} else {
  if ($_GET['profile'] == "1") {
    $tab_active5 = "active ";
  } else {
	  if ($_POST['pregnancy'] == "OK") {
		$tab_active3 = "active ";
	  } else {
		$tab_active1 = "active ";
		$tab_active4 = "";
		$tab_active9 = "";
	  }
	  
  }
}
?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li>ข้อมูลและสถิติ</li>
        <li class="active"><?php echo $ward_info_name;?></li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?>bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <?php echo $ward_custom_tab_guest;?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
              <?php echo $ward_custom_tab_user;?>
			  <li class="<?php echo $tab_active4;?>bg-warning"><a href="#tab_4-4" data-toggle="tab">[ คนไข้ในตึก ]</a></li>
			  <li class="<?php echo $tab_active8;?>bg-warning"><a href="#tab_8-8" data-toggle="tab">[ คนไข้ของแพทย์ ]</a></li>
			  <li class="<?php echo $tab_active5;?>bg-warning"><a href="#tab_5-5" data-toggle="tab">[ IPD Med Profile ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?>bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<?php if ($mis_user_level >= 1) { ?>
              <?php echo $ward_custom_tab_register;?>
	<?php } else { }?>
	<?php if ($mis_user_level >= 3) { ?>
              <?php echo $ward_custom_tab_head;?>
	<?php } else { }?>

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b><?php echo $ward_info_name;?> 
              <!-- </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>) -->
              </li>

            </ul>
<div class="panel-body">

  <!-- <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form> -->
