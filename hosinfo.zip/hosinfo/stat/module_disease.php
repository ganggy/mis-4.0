<div class="row">
        <div class="col-md-12">
          <div class="box box-danger">
            <div class="box-header with-border">
            <i class="fa fa-yelp"></i><h3 class="box-title">โรคติดต่อที่สำคัญ</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				        <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="?kpi=508">ข้อมูลโรคติดต่อ</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">

<?php
		include 'module_disease_chart.php';
?>

                </div>
                <!-- /.col -->
                <div class="col-md-4">
                  <p class="text-center">
                  <h4 class="box-title text-center">อันดับโรคติดต่อที่ต้องรายงานเดือนนี้</h4>
                  </p>

                <table class="table table-hover table no-margin">
                  <thead>
                  <tr>
                    <th>รหัส506</th>
                    <th>ชื่อโรค</th>
                    <th>จำนวน(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT n.code506,p.name AS namee,n.name AS namet,COUNT(*) AS count506
		FROM surveil_member s 
		LEFT OUTER JOIN provis_code506 p ON p.code = s.code506
		LEFT OUTER JOIN name506 n ON n.code = s.code506
		WHERE DATE_FORMAT(s.vstdate,'%Y-%m') = DATE_FORMAT(NOW(),'%Y-%m') 
		GROUP BY s.code506 
		ORDER BY COUNT(*) DESC
		LIMIT 10";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

            echo "      <tr>";
            echo "        <td class='text-center'>".$row[code506]."</td>";
            echo "        <td>".$row[namet]." ".$row[namee]."</td>";
            echo "        <td class='text-right'><span class='label label-danger'> ".$row[count506]." </span></td>";
            echo "      </tr>";

		}
		$sql2 = "SELECT t.vstyear,SUM(t.count506) AS count506,SUM(t.dhf) AS dhf,SUM(t.fu) AS fu,SUM(t.food) AS food,SUM(t.diarrhea) AS diarrhea
    ,SUM(t.count5062) AS count5062,SUM(t.dhf2) AS dhf2,SUM(t.fu2) AS fu2,SUM(t.food2) AS food2,SUM(t.diarrhea2) AS diarrhea2 FROM (
    SELECT DATE_FORMAT(vstdate,'%Y') AS vstyear
        ,COUNT(*) AS count506
        ,SUM(IF(code506 = '66',1,0)) AS dhf
        ,SUM(IF(code506 = '15',1,0)) AS fu
        ,SUM(IF(code506 = '3',1,0)) AS food
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea
        ,'' AS count5062,'' AS dhf2,'' AS fu2,'' AS food2,'' AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')
    UNION
    SELECT DATE_FORMAT(vstdate,'%Y')+1 AS vstyear
        ,'' AS count506,'' AS dhf,'' AS fu,'' AS food,'' AS diarrhea
        ,COUNT(*) AS count5062
        ,SUM(IF(code506 = '66',1,0)) AS dhf2
        ,SUM(IF(code506 = '15',1,0)) AS fu2
        ,SUM(IF(code506 = '3',1,0)) AS food2
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-01-01')) AND CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-%m-%d'))
    ) AS t
    GROUP BY vstyear ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $row2) {
			$cd_year = $row2[vstyear];
			$cd_count506 = $row2[count506];
			$cd_dhf = $row2[dhf];
			$cd_fu = $row2[fu];
			$cd_food = $row2[food];
      $cd_diarrhea = $row2[diarrhea];
      $cd_count5062 = $row2[count5062];
			$cd_dhf2 = $row2[dhf2];
			$cd_fu2 = $row2[fu2];
			$cd_food2 = $row2[food2];
			$cd_diarrhea2 = $row2[diarrhea2];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_dhf >= $cd_dhf2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_dhf >= $cd_dhf2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_dhf >= $cd_dhf2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_dhf*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_dhf;?></h5>
                    <span class="description-text">Dengue Fever</span> (<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_fu >= $cd_fu2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_fu >= $cd_fu2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_fu >= $cd_fu2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_fu*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_fu;?></h5>
                    <span class="description-text">Influenza,(FU)</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_food >= $cd_food2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_food >= $cd_food2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_food >= $cd_food2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_food*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_food;?></h5>
                    <span class="description-text">Food Poisoning</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                  <a data-toggle="tooltip" title="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_diarrhea*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_diarrhea;?></h5>
                    <span class="description-text">Diarrhea</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->

