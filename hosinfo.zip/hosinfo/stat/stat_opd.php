<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['y'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">ผู้ป่วยนอก</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?>bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?>bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?>bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อผู้ป่วย ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?>bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>ผู้ป่วยนอก </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
 $amonth = array(); //ตัวแปรแกน y
 $ptvisit = array(); //ตัวแปรแกน y
 $ptopd = array(); //ตัวแปรแกน y
 $ptipd = array(); //ตัวแปรแกน y
	try {
		include '_cfg_hos.php';
		$sql = "SELECT vn,vstdate,vsttime
					FROM ovst
					WHERE vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d') 
					AND vn = (SELECT MAX(vn) FROM ovst WHERE vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d'))";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$opd_vn = $data['vn'];
			$opd_vstdate = $data['vstdate'];
			$opd_vsttime = $data['vsttime'];
			}
		
		$sql = "SELECT an,regdate,regtime
					FROM ipt
					WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d') 
					AND an = (SELECT MAX(an) FROM ipt WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d'))";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipd_an = $data['an'];
			$ipd_regdate = $data['regdate'];
			$ipd_regtime = $data['regtime'];
			}
		
		$sql = "SELECT t.AMONTH,SUM(t.visitopd) AS opd,SUM(t.visitipd) AS ipd,t.AY,t.AM FROM (
					SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visitopd,'' AS visitipd
					,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM
					FROM vn_stat 
					WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
					UNION
					SELECT DATE_FORMAT(regdate,'%Y-%m') AS AMONTH,'' AS visitopd,COUNT(*) AS visitipd
					,DATE_FORMAT(regdate,'%Y')+543 AS AY,DATE_FORMAT(regdate,'%m') AS AM
					FROM an_stat 
					WHERE regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(regdate,'%Y-%m')
					) AS t
					GROUP BY t.AMONTH ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
		 array_push($amonth,$row[AMONTH]);
//		 array_push($ptvisit,$row[visit]);
		 array_push($ptopd,$row[opd]);
		 array_push($ptipd,$row[ipd]);
		}
		if(empty($ptopd[0])){$ptopd0 = 0;}else{$ptopd0 = $ptopd[0];}
		if(empty($ptopd[1])){$ptopd1 = 0;}else{$ptopd1 = $ptopd[1];}
		if(empty($ptopd[2])){$ptopd2 = 0;}else{$ptopd2 = $ptopd[2];}
		if(empty($ptopd[3])){$ptopd3 = 0;}else{$ptopd3 = $ptopd[3];}
		if(empty($ptopd[4])){$ptopd4 = 0;}else{$ptopd4 = $ptopd[4];}
		if(empty($ptopd[5])){$ptopd5 = 0;}else{$ptopd5 = $ptopd[5];}
		if(empty($ptopd[6])){$ptopd6 = 0;}else{$ptopd6 = $ptopd[6];}
		if(empty($ptopd[7])){$ptopd7 = 0;}else{$ptopd7 = $ptopd[7];}
		if(empty($ptopd[8])){$ptopd8 = 0;}else{$ptopd8 = $ptopd[8];}
		if(empty($ptopd[9])){$ptopd9 = 0;}else{$ptopd9 = $ptopd[9];}
		if(empty($ptopd[10])){$ptopd10 = 0;}else{$ptopd10 = $ptopd[10];}
		if(empty($ptopd[11])){$ptopd11 = 0;}else{$ptopd11 = $ptopd[11];}

		if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
		if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
		if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
		if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
		if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
		if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
		if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
		if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
		if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
		if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
		if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
		if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<div style="min-width: 310px; margin: 0 auto">Visit ผู้ป่วยนอกล่าสุดของวันนี้ : <?php echo $opd_vstdate." ".$opd_vsttime." (VN ".$opd_vn.")" ;?></div>
<div style="min-width: 310px; margin: 0 auto">Admit ผู้ป่วยยในล่าสุดของวันนี้ : <?php echo $ipd_regdate." ".$ipd_regtime." (AN ".$ipd_an.")" ;?></div>

<script type="text/javascript">
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'แสดงจำนวนผู้รับบริการ ปีงบประมาณ <?= $myeare+543; ?>'
    },
    xAxis: {
        categories: ['ตุลาคม', 'พฤศจิกายน','ธํนวาคม','มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฏาคม','สิงหาคม','กันยายน']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'จำนวน(ราย)'
        },
        stackLabels: {
            enabled: true,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    legend: {
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    },
    tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>ผู้รับบริการรวม : {point.stackTotal}'
    },
    plotOptions: {
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }
        }
    },
    series: [{
        name: 'ผู้ป่วยใน',
		color: '#ff0000',
		data: [<?= $ptipd0;?>, <?= $ptipd1;?>, <?= $ptipd2;?>, <?= $ptipd3;?>, <?= $ptipd4;?>, <?= $ptipd5;?>, <?= $ptipd6;?>, <?= $ptipd7;?>, <?= $ptipd8;?>, <?= $ptipd9;?>, <?= $ptipd10;?>, <?= $ptipd11;?>]
    }, {
        name: 'ผู้ป่วยนอก',
		color: '#3399cc',
		data: [<?= $ptopd0;?>, <?= $ptopd1;?>, <?= $ptopd2;?>, <?= $ptopd3;?>, <?= $ptopd4;?>, <?= $ptopd5;?>, <?= $ptopd6;?>, <?= $ptopd7;?>, <?= $ptopd8;?>, <?= $ptopd9;?>, <?= $ptopd10;?>, <?= $ptopd11;?>]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<h4><b>จำนวนผู้รับบริการ</b></h4>
				</div>
            <!-- /.box-header -->
        <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class='text-center'><b>เดือน-ปี</b></th>
						<th class='text-center'><b>จำนวนผู้ป่วยนอก (ราย)</b></th>
						<th class='text-center'><b>จำนวนผู้ป่วยใน (ราย)</b></th>
						<th class='text-center'><b>จำนวนผู้รับบริการรวม (ราย)</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT t.AMONTH,SUM(t.visitopd) AS opd,SUM(t.visitipd) AS ipd,t.AY,t.AM FROM (
					SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visitopd,'' AS visitipd
					,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM
					FROM vn_stat 
					WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
					UNION
					SELECT DATE_FORMAT(regdate,'%Y-%m') AS AMONTH,'' AS visitopd,COUNT(*) AS visitipd
					,DATE_FORMAT(regdate,'%Y')+543 AS AY,DATE_FORMAT(regdate,'%m') AS AM
					FROM an_stat 
					WHERE regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(regdate,'%Y-%m')
					) AS t
					GROUP BY t.AMONTH ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			switch ($row[AM]) {
				case "10":
					$mythai = $row[AY].$row[AM].' (ตุลาคม '.$row[AY].')';
					break;
				case "11":
					$mythai = $row[AY].$row[AM].' (พฤศจิกายน '.$row[AY].')';
					break;
				case "12":
					$mythai = $row[AY].$row[AM].' (ธันวาคม '.$row[AY].')';
					break;
				case "01":
					$mythai = $row[AY].$row[AM].' (มกราคม '.$row[AY].')';
					break;
				case "02":
					$mythai = $row[AY].$row[AM].' (กุมภาพันธ์ '.$row[AY].')';
					break;
				case "03":
					$mythai = $row[AY].$row[AM].' (มีนาคม '.$row[AY].')';
					break;
				case "04":
					$mythai = $row[AY].$row[AM].' (เมษายน '.$row[AY].')';
					break;
				case "05":
					$mythai = $row[AY].$row[AM].' (พฤษภาคม '.$row[AY].')';
					break;
				case "06":
					$mythai = $row[AY].$row[AM].' (มิถุนายน '.$row[AY].')';
					break;
				case "07":
					$mythai = $row[AY].$row[AM].' (กรกฎาคม '.$row[AY].')';
					break;
				case "08":
					$mythai = $row[AY].$row[AM].' (สิงหาคม '.$row[AY].')';
					break;
				case "09":
					$mythai = $row[AY].$row[AM].' (กันยายน '.$row[AY].')';
					break;
				default:
					$mythai = '';
			}

			echo "<tr>";
			echo "<td>".$mythai."</td>";
			if ($login_ok == 1) {
				echo "<td class='text-center'><a href='?stat=opd&y=".$row[AY]."&m=".$row[AM]." '>".number_format($row[opd],0)."</a></td>";
			} else {
				echo "<td class='text-center'>".number_format($row[opd],0)."</td>";
			}
			echo "<td class='text-center'>".number_format($row[ipd],0)."</td>";
			echo "<td class='text-center'>".number_format($row[opd]+$row[ipd],0)."</td>";
			echo "</tr>";
		}

		$sql = "SELECT t.AMONTH,SUM(t.visitopd) AS opd,SUM(t.visitipd) AS ipd,t.AY,t.AM FROM (
					SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visitopd,'' AS visitipd
					,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM
					FROM vn_stat 
					WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
					UNION
					SELECT DATE_FORMAT(regdate,'%Y-%m') AS AMONTH,'' AS visitopd,COUNT(*) AS visitipd
					,DATE_FORMAT(regdate,'%Y')+543 AS AY,DATE_FORMAT(regdate,'%m') AS AM
					FROM an_stat 
					WHERE regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(regdate,'%Y-%m')
					) AS t ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "</tbody><tfoot><tr class='warning'>";
			echo "<td class='text-center'><b>รวม</b></td>";
			echo "<td class='text-center'><b>".number_format($row[opd],0)."</b></td>";
			echo "<td class='text-center'><b>".number_format($row[ipd],0)."</b></td>";
			echo "<td class='text-center'><b>".number_format($row[opd]+$row[ipd],0)."</b></td>";
			echo "</tr></tfoot>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
	<?php
		$myeari = $_GET['y']-543;
		$mmonth = $_GET['m'];
	?>	
      <div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
				<div class="panel-heading">
				<h4 class="box-title"><b>รายชื่อผู้ป่วยนอก (<?php echo $_GET['m']."-".$_GET['y']; ?>)</b></h4>
				</div>
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN/AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>แผนกรับบริการ</b></th>
						<th class='text-center'><b>การวินิจฉัย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php

	try {
		include '_cfg_hos.php';
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT o.vstdate,o.hn,o.an,o.vn,CONCAT(p.pname,p.fname,p.lname) AS ptname,v.age_y,p.addrpart,p.addr_soi,p.moopart
					,t.full_name,ptt.name AS pttypename,i.code AS icd10,i.name AS diag,s.name AS spclty
					FROM ovst o
					LEFT OUTER JOIN patient p ON p.hn = o.hn
					LEFT OUTER JOIN vn_stat v ON v.vn = o.vn
					LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
					LEFT OUTER JOIN pttype ptt ON ptt.pttype = o.pttype
					LEFT OUTER JOIN icd101 i ON i.code = v.pdx
					LEFT OUTER JOIN spclty s ON s.spclty = o.spclty
					WHERE DATE_FORMAT(o.vstdate,'%Y-%m') = '$myeari-$mmonth' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[vstdate]."</td>";
			echo "<td>".$row[hn].$row[an]."</td>";
			echo "<td>".$row[ptname]."</td>";
			echo "<td class='text-center'>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ซ.".$row[addr_soi]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttypename]."</td>";
			echo "<td>".$row[spclty]."</td>";
			echo "<td>".$row[icd10]." ".$row[diag]."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT t.AMONTH,SUM(t.visitopd) AS opd,SUM(t.visitipd) AS ipd,t.AY,t.AM FROM (
					SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS visitopd,'' AS visitipd
					,DATE_FORMAT(vstdate,'%Y')+543 AS AY,DATE_FORMAT(vstdate,'%m') AS AM
					FROM vn_stat 
					WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
					UNION
					SELECT DATE_FORMAT(regdate,'%Y-%m') AS AMONTH,'' AS visitopd,COUNT(*) AS visitipd
					,DATE_FORMAT(regdate,'%Y')+543 AS AY,DATE_FORMAT(regdate,'%m') AS AM
					FROM an_stat 
					WHERE regdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
					GROUP BY DATE_FORMAT(regdate,'%Y-%m')
					) AS t
					GROUP BY t.AMONTH</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


