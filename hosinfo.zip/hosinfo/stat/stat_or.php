<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">ตึกผ่าตัดและวิสัญญี</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="active bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อ ]</a></li>
	<?php } else { }?>
			  <li class="bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>จำนวนผู้ป่วยผ่าตัด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS ipd
			FROM operation_list
			WHERE operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY DATE_FORMAT(operation_date,'%Y-%m')
			ORDER BY DATE_FORMAT(operation_date,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[ipd]);
		}
		if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
		if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
		if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
		if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
		if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
		if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
		if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
		if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
		if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
		if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
		if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
		if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$countipd10 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myearb-10-01' AND '$myearb-10-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd10,$row[wcount]);
		}

		$countipd11 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myearb-11-01' AND '$myearb-11-30'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd11,$row[wcount]);
		}

		$countipd12 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myearb-12-01' AND '$myearb-12-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd12,$row[wcount]);
		}

		$countipd01 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-01-01' AND '$myeare-01-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd01,$row[wcount]);
		}

		$countipd02 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-02-01' AND '$myeare-02-29'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd02,$row[wcount]);
		}

		$countipd03 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-03-01' AND '$myeare-03-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd03,$row[wcount]);
		}

		$countipd04 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-04-01' AND '$myeare-04-30'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd04,$row[wcount]);
		}

		$countipd05 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-05-01' AND '$myeare-05-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd05,$row[wcount]);
		}

		$countipd06 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-06-01' AND '$myeare-06-30'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd06,$row[wcount]);
		}

		$countipd07 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-07-01' AND '$myeare-07-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd07,$row[wcount]);
		}

		$countipd08 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-08-01' AND '$myeare-08-31'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd08,$row[wcount]);
		}

		$countipd09 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM operation_list
			WHERE operation_date BETWEEN '$myeare-09-01' AND '$myeare-09-30'
			GROUP BY operation_type_id
			ORDER BY operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd09,$row[wcount]);
		}

		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT o.operation_type_id AS operationid,ot.name AS operationname,COUNT(*) AS ocount
			FROM operation_list o
			LEFT OUTER JOIN operation_type ot ON ot.operation_type_id = o.operation_type_id
			WHERE o.operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND o.operation_type_id IS NOT NULL
			GROUP BY o.operation_type_id
			ORDER BY o.operation_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[ocount]);
			 array_push($delinamepie,$row[operationname]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>


<div class="row">
	<div class="col-sm-6">
		<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-sm-6">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div>


<script type="text/javascript">
// Create the chart
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'จำนวนผู้ป่วยผ่าตัด ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวนผู้ป่วยผ่าตัด(ราย)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f} ราย</b><br/>'
    },

    "series": [
        {
            "name": "จำนวนผู้ป่วยผ่าตัด",
            "colorByPoint": true,
            "data": [
                {
                    "name": "ตุลาคม",
                    "y": <?= $ptipd0; ?>,
                    "drilldown": "ตุลาคม"
                },
                {
                    "name": "พฤศจิกายน",
                    "y": <?= $ptipd1; ?>,
                    "drilldown": "พฤศจิกายน"
                },
                {
                    "name": "ธันวาคม",
                    "y": <?= $ptipd2; ?>,
                    "drilldown": "ธันวาคม"
                },
                {
                    "name": "มกราคม",
                    "y": <?= $ptipd3; ?>,
                    "drilldown": "มกราคม"
                },
                {
                    "name": "กุมภาพันธ์",
                    "y": <?= $ptipd4; ?>,
                    "drilldown": "กุมภาพันธ์"
                },
                {
                    "name": "มีนาคม",
                    "y": <?= $ptipd5; ?>,
                    "drilldown": "มีนาคม"
                },
                {
                    "name": "เมษายน",
                    "y": <?= $ptipd6; ?>,
                    "drilldown": "เมษายน"
                },
                {
                    "name": "พฤษภาคม",
                    "y": <?= $ptipd7; ?>,
                    "drilldown": "พฤษภาคม"
                },
                {
                    "name": "มิถุนายน",
                    "y": <?= $ptipd8; ?>,
                    "drilldown": "มิถุนายน"
                },
                {
                    "name": "กรกฎาคม",
                    "y": <?= $ptipd9; ?>,
                    "drilldown": "กรกฎาคม"
                },
                {
                    "name": "สิงหาคม",
                    "y": <?= $ptipd10; ?>,
                    "drilldown": "สิงหาคม"
                },
                {
                    "name": "กันยายน",
                    "y": <?= $ptipd11; ?>,
                    "drilldown": "กันยายน"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "ตุลาคม",
                "id": "ตุลาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd10[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd10[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd10[3]; ?>]
                ]
            },
            {
                "name": "พฤศจิกายน",
                "id": "พฤศจิกายน",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd11[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd11[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd11[3]; ?>]
                ]
            },
            {
                "name": "ธันวาคม",
                "id": "ธันวาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd12[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd12[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd12[3]; ?>]
                ]
            },
            {
                "name": "มกราคม",
                "id": "มกราคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd01[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd01[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd01[3]; ?>]
                ]
            },
            {
                "name": "กุมภาพันธ์",
                "id": "กุมภาพันธ์",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd02[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd02[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd02[3]; ?>]
                ]
            },
            {
                "name": "มีนาคม",
                "id": "มีนาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd03[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd03[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd03[3]; ?>]
                ]
            },
            {
                "name": "เมษายน",
                "id": "เมษายน",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd04[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd04[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd04[3]; ?>]
                ]
            },
            {
                "name": "พฤษภาคม",
                "id": "พฤษภาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd05[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd05[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd05[3]; ?>]
                ]
            },
            {
                "name": "มิถุนายน",
                "id": "มิถุนายน",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd06[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd06[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd06[3]; ?>]
                ]
            },
            {
                "name": "กรกฎาคม",
                "id": "กรกฎาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd07[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd07[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd07[3]; ?>]
                ]
            },
            {
                "name": "สิงหาคม",
                "id": "สิงหาคม",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd08[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd08[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd08[3]; ?>]
                ]
            },
            {
                "name": "กันยายน",
                "id": "กันยายน",
                "data": [
                    ['ผ่าตัดเล็ก',<?= $countipd09[1]; ?>],
                    ['ผ่าตัดใหญ่',<?= $countipd09[2]; ?>],
                    ['ส่องกล้อง',<?= $countipd09[3]; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนประเภทผ่าตัด'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie[0]; ?>', <?= $totalpie[0]; ?>],
            ['<?= $delinamepie[1]; ?>', <?= $totalpie[1]; ?>],
			{
                name: '<?= $delinamepie[2]; ?>',
                y: <?= $totalpie[2]; ?>,
                sliced: true,
                selected: true
			},
            ['<?= $delinamepie[3]; ?>', <?= $totalpie[3]; ?>]
		]
    }]
});
</script>


			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนผู้ป่วยผ่าตัด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class="text-center">ประเภทผ่าตัด</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql2 = "SELECT opl.operation_type_id AS oprtype,opt.name AS typename,COUNT(*) AS total
			FROM operation_list opl
			LEFT OUTER JOIN operation_type opt ON opt.operation_type_id = opl.operation_type_id
			WHERE opl.operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY opl.operation_type_id
			ORDER BY opl.operation_type_id ASC";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $row2) {
			switch ($row2[oprtype]) {
				case "":
					$rowward = 0;
					$optypename = "ไม่ระบุ";
					break;
				case "1":
					$rowward = 1;
					$optypename = "ผ่าตัดเล็ก";
					break;
				case "2":
					$rowward = 2;
					$optypename = "ผ่าตัดใหญ่";
					break;
				case "3":
					$rowward = 3;
					$optypename = "ส่องกล้อง";
					break;
				default:
					$rowward = "";
					$optypename = "";
			}

			echo "      <tr>";
			echo "        <td>".$optypename."</td>";
			echo "        <td class='text-right'>".number_format($countipd10[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd11[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd12[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd01[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd02[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd03[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd04[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd05[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd06[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd07[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd08[$rowward],0)."</td>";
			echo "        <td class='text-right'>".number_format($countipd09[$rowward],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row2[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(operation_date,'%Y-%m') AS AMONTH,COUNT(*) AS total
			FROM operation_list
			WHERE operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY DATE_FORMAT(operation_date,'%Y-%m')
			ORDER BY DATE_FORMAT(operation_date,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[total]);
		}

			echo "      <tr class='warning'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
	<div class="tab-pane" id="tab_3-3">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วันที่ผ่าตัด</b></th>
						<th class='text-center'><b>HN / AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>ประเภทผ่าตัด</b></th>
						<th class='text-center'><b>การผ่าตัด</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT o.operation_date,o.hn,o.an,p.pname,p.fname,p.lname,o.age_text,p.addrpart,p.road,p.moopart,t.full_name
			,pt.pttype,pt.name AS pttypename,opt.name AS typename,o.operation_name,o.operation_sum_price
			FROM operation_list o
			LEFT OUTER JOIN operation_type opt ON opt.operation_type_id = o.operation_type_id
			LEFT OUTER JOIN patient p ON p.hn = o.hn
			LEFT OUTER JOIN vn_stat ov ON ov.vn = o.vn
			LEFT OUTER JOIN pttype pt ON pt.pttype = ov.pttype
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			WHERE o.operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[operation_date]."</td>";
			echo "<td>".$row[hn]." / ".$row[an]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[age_text]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[typename]."</td>";
			echo "<td>".$row[operation_name]."</td>";
			echo "<td class='text-right'>".number_format($row[operation_sum_price],2)."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p>ผู้ป่วยผ่าตัดและดมยา</p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT opl.operation_type_id AS oprtype,opt.name AS typename,COUNT(*) AS total 
								FROM operation_list opl 
								LEFT OUTER JOIN operation_type opt ON opt.operation_type_id = opl.operation_type_id 
								WHERE opl.operation_date BETWEEN '$myearb-10-01' AND '$myeare-09-30' 
								GROUP BY opl.operation_type_id 
								ORDER BY opl.operation_type_id ASC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->


            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->



