<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['ym'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li>ข้อมูลและสถิติ</li>
        <li class="active">ผู้รับบริการทันตกรรม</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-info">
              <li class="<?php echo $tab_active1;?> bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?> bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?> bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อ ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?> bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>ผู้รับบริการทันตกรรม </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			<div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(DISTINCT vn) AS ipd
		FROM dtmain
		WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
		GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
		ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[ipd]);
		}
			if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
			if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
			if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
			if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
			if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
			if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
			if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
			if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
			if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
			if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
			if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
			if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$amonthh = array(); //ตัวแปรแกน y
		$ptipdh = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(DISTINCT hn) AS ipd
		FROM dtmain
		WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
		GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
		ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonthh,$row[AMONTH]);
			array_push($ptipdh,$row[ipd]);
		}
			if(empty($ptipdh[0])){$ptipdh0 = 0;}else{$ptipdh0 = $ptipdh[0];}
			if(empty($ptipdh[1])){$ptipdh1 = 0;}else{$ptipdh1 = $ptipdh[1];}
			if(empty($ptipdh[2])){$ptipdh2 = 0;}else{$ptipdh2 = $ptipdh[2];}
			if(empty($ptipdh[3])){$ptipdh3 = 0;}else{$ptipdh3 = $ptipdh[3];}
			if(empty($ptipdh[4])){$ptipdh4 = 0;}else{$ptipdh4 = $ptipdh[4];}
			if(empty($ptipdh[5])){$ptipdh5 = 0;}else{$ptipdh5 = $ptipdh[5];}
			if(empty($ptipdh[6])){$ptipdh6 = 0;}else{$ptipdh6 = $ptipdh[6];}
			if(empty($ptipdh[7])){$ptipdh7 = 0;}else{$ptipdh7 = $ptipdh[7];}
			if(empty($ptipdh[8])){$ptipdh8 = 0;}else{$ptipdh8 = $ptipdh[8];}
			if(empty($ptipdh[9])){$ptipdh9 = 0;}else{$ptipdh9 = $ptipdh[9];}
			if(empty($ptipdh[10])){$ptipdh10 = 0;}else{$ptipdh10 = $ptipdh[10];}
			if(empty($ptipdh[11])){$ptipdh11 = 0;}else{$ptipdh11 = $ptipdh[11];}

		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT pt.nhso_code,pt.hipdata_code,pt.name,COUNT(DISTINCT d.vn) AS vn_count
        FROM dtmain d
        LEFT OUTER JOIN vn_stat v ON v.vn = d.vn
        LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
        WHERE d.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY pt.hipdata_code
        ORDER BY COUNT(DISTINCT d.vn) DESC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[vn_count]);
			 array_push($delinamepie,$row[name]);
		}

        $totalpie2 = array(); //ตัวแปรแกน y
		$delinamepie2 = array(); //ตัวแปรแกน y
		$sql = "SELECT d.group_name,COUNT(n.vn) AS vn_count
        FROM dtdetail_name2  d
        LEFT OUTER JOIN dtdetail2 n ON n.dtcode = d.dtcode 
        AND n.vn IN (SELECT vn FROM dtmain WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30')
        GROUP BY d.group_name HAVING COUNT(n.vn) > 0
        ORDER BY COUNT(n.vn) DESC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie2,$row[vn_count]);
			 array_push($delinamepie2,$row[group_name]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div id="container4" style="min-width: 510px; height: 500px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container3" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
</div>

<script type="text/javascript">
Highcharts.chart('container4', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'จำนวนผู้รับบริการทันตกรรม ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        categories: ["ตุลาคม","พฤศจิกายน","ธันวาคม","มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน"],
        crosshair: true
    },
    yAxis: {
        min: 0,
        title: {
            text: 'จำนวน'
        }
    },
    tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="color:{series.color};padding:0"><b>{point.y:.0f}</b> </td>' +
            '<td style="padding:0">  {series.name}</td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
    },
    plotOptions: {
        column: {
            pointPadding: 0.2,
            borderWidth: 0
        }
    },
    series: [{
        name: 'คน',
        data: [<?= $ptipdh0;?>, <?= $ptipdh1;?>, <?= $ptipdh2;?>, <?= $ptipdh3;?>, <?= $ptipdh4;?>, <?= $ptipdh5;?>, <?= $ptipdh6;?>, <?= $ptipdh7;?>, <?= $ptipdh8;?>, <?= $ptipdh9;?>, <?= $ptipdh10;?>, <?= $ptipdh11;?>]
    }, {
        name: 'ครั้ง',
        data: [<?= $ptipd0;?>, <?= $ptipd1;?>, <?= $ptipd2;?>, <?= $ptipd3;?>, <?= $ptipd4;?>, <?= $ptipd5;?>, <?= $ptipd6;?>, <?= $ptipd7;?>, <?= $ptipd8;?>, <?= $ptipd9;?>, <?= $ptipd10;?>, <?= $ptipd11;?>]
    }]
});
</script>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนการรักษา แยกตามกลุ่มทันตกรรม'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie2[0]; ?>',   <?= $totalpie2[0]; ?>],
            ['<?= $delinamepie2[1]; ?>',   <?= $totalpie2[1]; ?>],
            ['<?= $delinamepie2[2]; ?>',   <?= $totalpie2[2]; ?>],
            ['<?= $delinamepie2[3]; ?>',   <?= $totalpie2[3]; ?>],
            ['<?= $delinamepie2[4]; ?>',   <?= $totalpie2[4]; ?>],
            ['<?= $delinamepie2[5]; ?>',   <?= $totalpie2[5]; ?>],
            ['<?= $delinamepie2[6]; ?>',   <?= $totalpie2[6]; ?>],
            ['<?= $delinamepie2[7]; ?>',   <?= $totalpie2[7]; ?>],
            ['<?= $delinamepie2[8]; ?>',   <?= $totalpie2[8]; ?>],
            ['<?= $delinamepie2[9]; ?>',   <?= $totalpie2[9]; ?>],
            ['<?= $delinamepie2[10]; ?>',   <?= $totalpie2[10]; ?>]
		]
    }]
});
</script>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนผู้รับบริการทันตกรรม แยกตามกลุ่มสิทธิรักษาพยาบาล'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie[0]; ?>',   <?= $totalpie[0]; ?>],
            ['<?= $delinamepie[1]; ?>',   <?= $totalpie[1]; ?>],
            ['<?= $delinamepie[2]; ?>',   <?= $totalpie[2]; ?>],
            ['<?= $delinamepie[3]; ?>',   <?= $totalpie[3]; ?>],
            ['<?= $delinamepie[4]; ?>',   <?= $totalpie[4]; ?>],
            ['<?= $delinamepie[5]; ?>',   <?= $totalpie[5]; ?>],
            ['<?= $delinamepie[6]; ?>',   <?= $totalpie[6]; ?>],
            ['<?= $delinamepie[7]; ?>',   <?= $totalpie[7]; ?>],
            ['<?= $delinamepie[8]; ?>',   <?= $totalpie[8]; ?>],
            ['<?= $delinamepie[9]; ?>',   <?= $totalpie[9]; ?>],
            ['<?= $delinamepie[10]; ?>',   <?= $totalpie[10]; ?>]
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->
			  
            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
            <div class="box box-info collapsed-box">
            <div class="box-header with-border">
              <i class="fa fa-table"></i><h3 class="box-title"> <b>จำนวนผู้รับบริการทันตกรรม (คน) แยกตามสิทธิรักษาพยาบาล </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class="text-center">สิทธิรักษาพยาบาล</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT pt.nhso_code,pt.name
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-10-01' AND '$myearb-10-31',d.hn,0)))-1 AS m10
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-11-01' AND '$myearb-11-30',d.hn,0)))-1 AS m11
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-12-01' AND '$myearb-12-31',d.hn,0)))-1 AS m12
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-01-01' AND '$myeare-01-31',d.hn,0)))-1 AS m01
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-02-01' AND '$myeare-02-28',d.hn,0)))-1 AS m02
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-03-01' AND '$myeare-03-31',d.hn,0)))-1 AS m03
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-04-01' AND '$myeare-04-30',d.hn,0)))-1 AS m04
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-05-01' AND '$myeare-05-31',d.hn,0)))-1 AS m05
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-06-01' AND '$myeare-06-30',d.hn,0)))-1 AS m06
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-07-01' AND '$myeare-07-31',d.hn,0)))-1 AS m07
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-08-01' AND '$myeare-08-31',d.hn,0)))-1 AS m08
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-09-01' AND '$myeare-09-30',d.hn,0)))-1 AS m09
        ,COUNT(DISTINCT d.hn) AS hn_count
        FROM dtmain d
        LEFT OUTER JOIN vn_stat v ON v.vn = d.vn
        LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
        WHERE d.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY pt.nhso_code
        ORDER BY pt.nhso_code ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[nhso_code]." : ".$row[name]."</td>";
			echo "        <td class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[hn_count],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS yyyymm,COUNT(DISTINCT hn) AS khon,COUNT(DISTINCT vn) AS krung,SUM(fee) AS fee,SUM(fee) / COUNT(DISTINCT vn) AS avgkrung
		FROM dtmain
		WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
		GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
		ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[khon]);
			array_push($YM,$row[yyyymm]);
		}

			echo "      <tr class='info'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
            <div class="box box-info">
            <div class="box-header with-border">
              <i class="fa fa-table"></i><h3 class="box-title"> <b>จำนวนผู้รับบริการทันตกรรม (ครั้ง) แยกตามสิทธิรักษาพยาบาล </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th class="text-center">สิทธิรักษาพยาบาล</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT pt.nhso_code,pt.`name`
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-10-01' AND '$myearb-10-31',d.vn,0)))-1 AS m10
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-11-01' AND '$myearb-11-30',d.vn,0)))-1 AS m11
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myearb-12-01' AND '$myearb-12-31',d.vn,0)))-1 AS m12
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-01-01' AND '$myeare-01-31',d.vn,0)))-1 AS m01
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-02-01' AND '$myeare-02-28',d.vn,0)))-1 AS m02
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-03-01' AND '$myeare-03-31',d.vn,0)))-1 AS m03
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-04-01' AND '$myeare-04-30',d.vn,0)))-1 AS m04
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-05-01' AND '$myeare-05-31',d.vn,0)))-1 AS m05
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-06-01' AND '$myeare-06-30',d.vn,0)))-1 AS m06
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-07-01' AND '$myeare-07-31',d.vn,0)))-1 AS m07
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-08-01' AND '$myeare-08-31',d.vn,0)))-1 AS m08
        ,COUNT(DISTINCT (IF(d.vstdate BETWEEN '$myeare-09-01' AND '$myeare-09-30',d.vn,0)))-1 AS m09
        ,COUNT(DISTINCT d.vn) AS vn_count
        FROM dtmain d
        LEFT OUTER JOIN vn_stat v ON v.vn = d.vn
        LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
        WHERE d.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY pt.nhso_code
        ORDER BY pt.nhso_code ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[nhso_code]." : ".$row[name]."</td>";
			echo "        <td class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[vn_count],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS yyyymm,COUNT(DISTINCT hn) AS khon,COUNT(DISTINCT vn) AS krung,SUM(fee) AS fee,SUM(fee) / COUNT(DISTINCT vn) AS avgkrung
		FROM dtmain
		WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
		-- WHERE vstdate BETWEEN IF(DATE_FORMAT(NOW(),'%m') <= 10,CONCAT(DATE_FORMAT(NOW(),'%Y')-1,'-10-01'),DATE_FORMAT(NOW(),'%Y-10-01')) AND DATE_FORMAT(NOW(),'%Y-%m-%d')
		GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
		ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[krung]);
			array_push($YM,$row[yyyymm]);
		}

			echo "      <tr class='info'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
		if ($login_ok == 1) {
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[0]."&itype=m'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[1]."&itype=m'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[2]."&itype=m'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[3]."&itype=m'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[4]."&itype=m'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[5]."&itype=m'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[6]."&itype=m'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[7]."&itype=m'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[8]."&itype=m'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[9]."&itype=m'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[10]."&itype=m'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=dent&ym=".$YM[11]."&itype=m'><b>".number_format($smonth[11],0)."</b></td>";
        } else {
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
        }

			echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>


<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-danger">
            <div class="box-header with-border">
              <i class="fa fa-sort-amount-desc"></i><h3 class="box-title"> จำนวนการรักษา แยกตามการรักษา</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table id="DataTableT1" class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>รหัส DTcode</th>
                    <th class='text-center'>รายการรักษาทันตกรรม</th>
                    <th class='text-center'>จำนวนการรักษา</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT d.dtcode,d.name,COUNT(n.vn) AS vn_count
        FROM dtdetail_name  d
        LEFT OUTER JOIN dtdetail n
        ON n.dtcode = d.dtcode AND n.vn IN (SELECT vn FROM dtmain WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30')
        GROUP BY d.dtcode,d.name HAVING COUNT(n.vn) > 0 
        ORDER BY d.dtcode,d.name ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tr>";
            echo "        <td>".$row['dtcode']."</td>";
            echo "        <td>".$row['name']."</td>";
            echo "        <td class='text-center'>".$row['vn_count']."</td>";
            echo "      </tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
          </div>
          <!-- /.box -->
    <!-- /.col -->
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <i class="fa fa-sort-amount-desc"></i><h3 class="box-title"> จำนวนการรักษา แยกตามกลุ่มทันตกรรม</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table id="DataTableT2" class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>กลุ่มทันตกรรม</th>
                    <th class='text-center'>รายการทันตกรรม</th>
                    <th class='text-center'>จำนวนการรักษา</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT d.group_name,d.name,COUNT(n.vn) AS vn_count
        FROM dtdetail_name2  d
        LEFT OUTER JOIN dtdetail2 n ON n.dtcode = d.dtcode 
        AND n.vn IN (SELECT vn FROM dtmain WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30')
        GROUP BY d.group_name,d.name HAVING COUNT(n.vn) > 0
        ORDER BY d.group_name,d.name ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tr>";
            echo "        <td>".$row['group_name']."</td>";
            echo "        <td>".$row['name']."</td>";
            echo "        <td class='text-center'>".$row['vn_count']."</td>";
            echo "      </tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
              </div>
              <!-- /.table-responsive -->
            </div>
            <!-- /.box-body -->
            <!-- <div class="box-footer clearfix">
              <a href="javascript:void(0)" class="btn btn-sm btn-info btn-flat pull-left">icd10</a>
              <a href="javascript:void(0)" class="btn btn-sm btn-default btn-flat pull-right">View All</a>
            </div>
 -->            <!-- /.box-footer -->
          </div>
          <!-- /.box -->

    <!-- /.col -->
	</div>
<!-- /.row -->
</div>

			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

		<?php
        if ($_GET['itype'] == "m") {
            $i_type = "(เดือน ".$_GET['ym'].")";
            $i_get_where = "DATE_FORMAT(d.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        } else {
            $i_type = "(แสดงข้อมูลจากลิงค์ตารางข้อมูล)";
            $i_get_where = "DATE_FORMAT(d.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        }
    ?>

	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
			<div class="panel-heading">
				<b>รายชื่อผู้รับบริการทันตกรรม </b> ปีงบประมาณ <?php echo $myeare+543; ?> <?php echo $i_type; ?>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
					  	<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN/AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>การวินิจฉัย</b></th>
						<th class='text-center'><b>ค่าใช้จ่ายทันตกรรม</b></th>
						<th class='text-center'><b>ค่าใช้จ่ายรวมครั้งนี้</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT d.vn,d.vstdate,d.hn,p.pname,p.fname,p.lname,v.age_y,p.addrpart,p.road,p.moopart,t.full_name
			,GROUP_CONCAT(d.icd) AS icd,v.pdx,i.name AS dxname,v.pttype,pt.name AS pttypename,v.income,SUM(d.fee) AS dent_fee
			FROM dtmain d
			LEFT OUTER JOIN vn_stat v ON v.vn = d.vn
			LEFT OUTER JOIN patient p ON p.hn = d.hn
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
			LEFT OUTER JOIN icd101 i ON i.code = v.pdx
			WHERE $i_get_where
			GROUP BY d.vn ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[vstdate]."</td>";
			echo "<td>".$row[hn]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[icd]." (PDx = ".$row[pdx].":".$row[dxname].")</td>";
			echo "<td>".$row[dent_fee]."</td>";
			echo "<td>".$row[income]."</td>";
			echo "</tr>";
		}
		
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
	
	?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p>ผู้รับบริการทันตกรรม</p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT er.er_pt_type AS ertype,et.name AS typename,COUNT(*) AS total FROM er_regist er LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = er.er_pt_type WHERE er.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' GROUP BY er.er_pt_type ORDER BY er.er_pt_type ASC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


