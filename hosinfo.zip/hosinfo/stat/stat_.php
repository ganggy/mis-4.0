<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

$dnowy = date("Y");

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">Module Name</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="active bg-warning"><a href="#tab_0-0" data-toggle="tab">[ Dashboard ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
              <li class="bg-warning"><a href="#tab_1-1" data-toggle="tab">[ User HOSxP ]</a></li>
	<?php } else { }?>
	<?php if ($mis_user_level >= 1) { ?>
			  <li class="bg-warning"><a href="#tab_2-2" data-toggle="tab">[ Register MIS4.0 ]</a></li>
	<?php } else { }?>
	<?php if ($mis_user_level >= 3) { ?>
			  <li class="bg-warning"><a href="#tab_3-3" data-toggle="tab">[ Head ]</a></li>
	<?php } else { }?>
	<?php if ($mis_user_level >= 4) { ?>
			  <li class="bg-warning"><a href="#tab_4-4" data-toggle="tab">[ Admin ]</a></li>
	<?php } else { }?>
			  <li class="bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <li class="pull-left header"><i class="fa fa-th"></i> <b>โรคไม่ติดต่อ NCD</b></li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

			</ul>
	<div class="tab-content">

		<!-- tab-pane -->
		<div class="tab-pane active" id="tab_0-0">
            <div class="box-body">

	<div class="col-sm-12">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box">
            <div class="box-header ui-sortable-handle" style="background-color: #f0f0f0;">
              <i class="fa fa-bar-chart-o"></i><h3 class="box-title"> 10 อันดับโรคผู้ป่วยนอนโรงพยาบาล <?php echo $ward_info_name;?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">
                <table class="table no-margin table-hover">
                  <thead>
                  <tr>
                    <th class='text-center'>ลำดับที่</th>
                    <th class='text-center'>Diag</th>
                    <th class='text-center'>ชื่อโรค</th>
                    <th class='text-center'>ชาย</th>
                    <th class='text-center'>หญิง</th>
                    <th class='text-center'>รวม(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT * FROM doctor LIMIT 10 ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tr>";
            echo "        <td class='text-center'><a>".$row[code]."</a></td>";
            echo "        <td>Diag</td>";
            echo "        <td>ชื่อโรค</td>";
            echo "        <td class='text-center'>ชาย</td>";
            echo "        <td class='text-center'>หญิง</td>";
            echo "        <td class='text-center'><span class='label label-success'>รวม(ราย)</span></td>";
            echo "      </tr>";
		}

		$sql = "SELECT * FROM doctor LIMIT 1";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            echo "      <tfoot><tr>";
            echo "        <td class='text-center'>รวม</td>";
            echo "        <td>Diag</td>";
            echo "        <td>ชื่อโรค</td>";
            echo "        <td class='text-center'>ชาย</td>";
            echo "        <td class='text-center'>หญิง</td>";
            echo "        <td class='text-center'><span class='label label-danger'>รวม(ราย)</span></td>";
            echo "      </tr></tfoot>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  </tbody>
                </table>

			  </div>
              <!-- /.table-responsive -->
            </div>
          </div>
          <!-- /.box -->
	</div>

			</div>
		</div>
		<!-- /.tab-pane -->

	<!-- สำหรับสมาชิก HOSxP -->
	<?php if ($login_ok == 1) { ?>
		<!-- tab-pane -->
		<div class="tab-pane" id="tab_1-1">
            <div class="box-body">


	<div class="col-sm-12">

          <!-- TABLE: LATEST ORDERS -->
          <div class="box box-info">
            <div class="box-header with-border">
              <i class="fa fa-pie-chart"></i><h3 class="box-title"> 10 อันดับโรคผู้ป่วยนอนโรงพยาบาล <?php echo $ward_info_name;?></h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="table-responsive">

			  </div>
              <!-- /.table-responsive -->
            </div>
          </div>
          <!-- /.box -->
	</div>


			</div>
		</div>
		<!-- /.tab-pane -->
	<?php } else { }?>

	<!-- สำหรับสมาชิก HOSxP -->
	<?php if ($login_ok == 1) { ?>
		<!-- tab-pane -->
		<div class="tab-pane" id="tab_2-2">
            <div class="box-body">

<br><br><h3>Register MIS4.0</h3><br><br>

			</div>
		</div>
		<!-- /.tab-pane -->
	<?php } else { }?>

	<!-- สำหรับสมาชิก HOSxP -->
	<?php if ($login_ok == 1) { ?>
		<!-- tab-pane -->
		<div class="tab-pane" id="tab_3-3">
            <div class="box-body">

<br><br><h3>Head</h3><br><br>

			</div>
		</div>
		<!-- /.tab-pane -->
	<?php } else { }?>

	<!-- สำหรับสมาชิก HOSxP -->
	<?php if ($login_ok == 1) { ?>
		<!-- tab-pane -->
		<div class="tab-pane" id="tab_4-4">
            <div class="box-body">

<br><br><h3>Admin</h3><br><br>

			</div>
		</div>
		<!-- /.tab-pane -->
	<?php } else { }?>


		<div class="tab-pane" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำจำกัดความ</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>

			</div>


			</div>
            <!-- /.box-body -->
		</div>
		<!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
