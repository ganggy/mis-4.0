<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

$dnowy = date("Y");

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">โรคติดต่อ</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="active bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
              <li class="bg-warning"><a href="#tab_3-3" data-toggle="tab">[ โรคที่ต้องรายงาน ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="bg-warning"><a href="#tab_4-4" data-toggle="tab">[ รายชื่อผู้ป่วย ]</a></li>
	<?php } else { }?>
	<?php if ($mis_user_level >= 3) { ?>
			  <li class="bg-warning"><a href="#tab_8-8" data-toggle="tab">[ ปรับปรุงข้อมูล ]</a></li>
	<?php } else { }?>
			  <li class="bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>โรคติดต่อที่สำคัญ</b></li>
            </ul>
            <div class="tab-content">

			  <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
if ($_POST['submit_dhf'] == "submit_dhf_update") {
$last_update = date("Y-m-d H:i:s");
try {
	include '_cfg_mis40db.php';
	$sql = "UPDATE rep_506_dhf SET m01='".$_POST['md_m01']."',m02='".$_POST['md_m02']."',m03='".$_POST['md_m03']."',m04='".$_POST['md_m04']."',m05='".$_POST['md_m05']."',m06='".$_POST['md_m06']."',m07='".$_POST['md_m07']."',m08='".$_POST['md_m08']."',m09='".$_POST['md_m09']."',m10='".$_POST['md_m10']."',m11='".$_POST['md_m11']."',m12='".$_POST['md_m12']."',useredit = '".$ok_login_user."',lastupdate = '".$last_update."' WHERE year='median' AND code506 ='66' ";
	$myPDO->query($sql);

	$sql = "UPDATE rep_506_dhf SET m01='".$_POST['yr_m01']."',m02='".$_POST['yr_m02']."',m03='".$_POST['yr_m03']."',m04='".$_POST['yr_m04']."',m05='".$_POST['yr_m05']."',m06='".$_POST['yr_m06']."',m07='".$_POST['yr_m07']."',m08='".$_POST['yr_m08']."',m09='".$_POST['yr_m09']."',m10='".$_POST['yr_m10']."',m11='".$_POST['yr_m11']."',m12='".$_POST['yr_m12']."',useredit = '".$ok_login_user."',lastupdate = '".$last_update."' WHERE year='2562' AND code506 ='66' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลสำเร็จ');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! ไม่สำเร็จ');</script>";
	}

} catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();}

} else {}
?>

<?php
		include 'module_disease_chart.php';
?>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="tab_2-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>ปี / เดือน</b></th>
						<th class="text-center"><b>ม.ค.</b></th>
						<th class="text-center"><b>ก.พ.</b></th>
						<th class="text-center"><b>มี.ค.</b></th>
						<th class="text-center"><b>เม.ย.</b></th>
						<th class="text-center"><b>พ.ค.</b></th>
						<th class="text-center"><b>มิ.ย.</b></th>
						<th class="text-center"><b>ก.ค.</b></th>
						<th class="text-center"><b>ส.ค.</b></th>
						<th class="text-center"><b>ก.ย.</b></th>
						<th class="text-center"><b>ต.ค.</b></th>
						<th class="text-center"><b>พ.ย.</b></th>
						<th class="text-center"><b>ธ.ค.</b></th>
						<th class="text-center"><b>รวม</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php

	try {
		include '_cfg_mis40db.php';

		$sql = "SELECT *,(m01+m02+m03+m04+m05+m06+m07+m08+m09+m10+m11+m12) AS sumyear FROM rep_506_dhf WHERE year = 'median' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr class='danger'>";
			echo "<td class='text-center'><b>".$row[year]."</b></td>";
			echo "<td class='text-center'><b>".$row[m01]."</b></td>";
			echo "<td class='text-center'><b>".$row[m02]."</b></td>";
			echo "<td class='text-center'><b>".$row[m03]."</b></td>";
			echo "<td class='text-center'><b>".$row[m04]."</b></td>";
			echo "<td class='text-center'><b>".$row[m05]."</b></td>";
			echo "<td class='text-center'><b>".$row[m06]."</b></td>";
			echo "<td class='text-center'><b>".$row[m07]."</b></td>";
			echo "<td class='text-center'><b>".$row[m08]."</b></td>";
			echo "<td class='text-center'><b>".$row[m09]."</b></td>";
			echo "<td class='text-center'><b>".$row[m10]."</b></td>";
			echo "<td class='text-center'><b>".$row[m11]."</b></td>";
			echo "<td class='text-center'><b>".$row[m12]."</b></td>";
			echo "<td class='text-center'><b>".$row[sumyear]."</b></td>";
			echo "</tr>";
		}

		$sql = "SELECT *,(m01+m02+m03+m04+m05+m06+m07+m08+m09+m10+m11+m12) AS sumyear FROM rep_506_dhf WHERE year <> 'median' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td class='text-center'>".$row[year]."</td>";
			echo "<td class='text-center'>".$row[m01]."</td>";
			echo "<td class='text-center'>".$row[m02]."</td>";
			echo "<td class='text-center'>".$row[m03]."</td>";
			echo "<td class='text-center'>".$row[m04]."</td>";
			echo "<td class='text-center'>".$row[m05]."</td>";
			echo "<td class='text-center'>".$row[m06]."</td>";
			echo "<td class='text-center'>".$row[m07]."</td>";
			echo "<td class='text-center'>".$row[m08]."</td>";
			echo "<td class='text-center'>".$row[m09]."</td>";
			echo "<td class='text-center'>".$row[m10]."</td>";
			echo "<td class='text-center'>".$row[m11]."</td>";
			echo "<td class='text-center'>".$row[m12]."</td>";
			echo "<td class='text-center'>".$row[sumyear]."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
		</div>
        <!-- /.tab-pane -->



        <!-- tab-pane -->
        <div class="tab-pane" id="tab_3-3">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT1" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>รหัสโรค</b></th>
						<th class='text-center'><b>ชื่อโรค</b></th>
						<th class='text-center'><b>ชื่อโรค(ไทย)</b></th>
						<th class='text-center'><b>จำนวน(ราย)</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT n.code506,p.name AS namee,n.name AS namet,COUNT(*) AS count506
		FROM surveil_member s 
		LEFT OUTER JOIN provis_code506 p ON p.code = s.code506
		LEFT OUTER JOIN name506 n ON n.code = s.code506
		WHERE DATE_FORMAT(s.vstdate,'%Y') = '$dnowy' 
		GROUP BY s.code506 
		ORDER BY COUNT(*) DESC ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td class='text-center'>".$row[0]."</td>";
			echo "<td>".$row[1]."</td>";
			echo "<td>".$row[2]."</td>";
			echo "<td class='text-right'>".$row[3]."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
		</div>
        <!-- /.tab-pane -->




	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

        <!-- tab-pane -->
        <div class="tab-pane" id="tab_4-4">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT2" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>วันที่</b></th>
						<th><b>HN</b></th>
						<th><b>ชื่อ-นามสกุล</b></th>
						<th><b>รายงาน506</b></th>
						<th><b>วินิจฉัย</b></th>
						<th><b>ที่อยู่</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT s.vstdate,s.hn,p.pname,p.fname,p.lname,n.name AS name506,s.pdx,i.name,s.addr,s.moo,t.full_name
					FROM surveil_member s 
					LEFT OUTER JOIN patient p ON p.hn = s.hn 
					LEFT OUTER JOIN icd101 i ON i.code = s.pdx
					LEFT OUTER JOIN name506 n ON n.code = s.code506
					LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(s.chwpart,s.amppart,s.tmbpart)
					WHERE DATE_FORMAT(s.vstdate,'%Y') = '$dnowy'  ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td class='text-center'>".$row[vstdate]."</td>";
			echo "<td>".$row[hn]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[name506]."</td>";
			echo "<td>".$row[pdx]." ".$row[name]."</td>";
			echo "<td>".$row[addr]." ม.".$row[moo]." ".$row[full_name]."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
		</div>
        <!-- /.tab-pane -->
				<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<!-- สำหรับ หัวหน้า / สมาชิก -->
	<?php if ($mis_user_level >= 3) { ?>
	<div class="tab-pane" id="tab_8-8">
            <!-- /.box-header -->
            <div class="box-body">
			<form action="<?php echo $PHP_SELF ?>" method="POST">
			<div class="row">
				<div class="col-sm-12">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">แก้ไขปรับปรุงข้อมูล</h3>
						</div>
						<div class="box-footer text-black">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="warning">
						<th class='text-center'><b>ปี / เดือน</b></th>
						<th class="text-center"><b>ม.ค.</b></th>
						<th class="text-center"><b>ก.พ.</b></th>
						<th class="text-center"><b>มี.ค.</b></th>
						<th class="text-center"><b>เม.ย.</b></th>
						<th class="text-center"><b>พ.ค.</b></th>
						<th class="text-center"><b>มิ.ย.</b></th>
						<th class="text-center"><b>ก.ค.</b></th>
						<th class="text-center"><b>ส.ค.</b></th>
						<th class="text-center"><b>ก.ย.</b></th>
						<th class="text-center"><b>ต.ค.</b></th>
						<th class="text-center"><b>พ.ย.</b></th>
						<th class="text-center"><b>ธ.ค.</b></th>
						<th class="text-center"><b>รวม</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_mis40db.php';
		$sql = "SELECT *,(m01+m02+m03+m04+m05+m06+m07+m08+m09+m10+m11+m12) AS sumyear FROM rep_506_dhf WHERE year = 'median' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr class='danger'>";
			echo "<td class='text-center'><b>".$row[year]."</b></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m01' value='".$row[m01]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m02' value='".$row[m02]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m03' value='".$row[m03]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m04' value='".$row[m04]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m05' value='".$row[m05]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m06' value='".$row[m06]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m07' value='".$row[m07]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m08' value='".$row[m08]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m09' value='".$row[m09]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m10' value='".$row[m10]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m11' value='".$row[m11]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='md_m12' value='".$row[m12]."'></td>";
			echo "<td class='text-center'><b>".$row[sumyear]."</b></td>";
			echo "</tr>";
		}

		$sql = "SELECT *,(m01+m02+m03+m04+m05+m06+m07+m08+m09+m10+m11+m12) AS sumyear FROM rep_506_dhf WHERE year <> 'median' AND year <> '2562' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td class='text-center'>".$row[year]."</td>";
			echo "<td class='text-center'>".$row[m01]."</td>";
			echo "<td class='text-center'>".$row[m02]."</td>";
			echo "<td class='text-center'>".$row[m03]."</td>";
			echo "<td class='text-center'>".$row[m04]."</td>";
			echo "<td class='text-center'>".$row[m05]."</td>";
			echo "<td class='text-center'>".$row[m06]."</td>";
			echo "<td class='text-center'>".$row[m07]."</td>";
			echo "<td class='text-center'>".$row[m08]."</td>";
			echo "<td class='text-center'>".$row[m09]."</td>";
			echo "<td class='text-center'>".$row[m10]."</td>";
			echo "<td class='text-center'>".$row[m11]."</td>";
			echo "<td class='text-center'>".$row[m12]."</td>";
			echo "<td class='text-center'>".$row[sumyear]."</td>";
			echo "</tr>";
		}

		$sql = "SELECT *,(m01+m02+m03+m04+m05+m06+m07+m08+m09+m10+m11+m12) AS sumyear FROM rep_506_dhf WHERE year = '2562' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr class='danger'>";
			echo "<td class='text-center'><b>".$row[year]."</b></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m01' value='".$row[m01]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m02' value='".$row[m02]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m03' value='".$row[m03]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m04' value='".$row[m04]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m05' value='".$row[m05]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m06' value='".$row[m06]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m07' value='".$row[m07]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m08' value='".$row[m08]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m09' value='".$row[m09]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m10' value='".$row[m10]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m11' value='".$row[m11]."'></td>";
			echo "<td class='text-center'><input type='number' class='form-control' name='yr_m12' value='".$row[m12]."'></td>";
			echo "<td class='text-center'><b>".$row[sumyear]."</b></td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
						</div>
					</div>
				</div>

			</div>

              <div class="box-footer">
                <button type="submit" name="submit_dhf" value="submit_dhf_update" class="btn btn-danger pull-right"> ปรับปรุงข้อมูล </button>
              </div>
            </form>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>

	<div class="tab-pane" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT n.code506,p.name AS namee,n.name AS namet,COUNT(*) AS count506
		FROM surveil_member s 
		LEFT OUTER JOIN provis_code506 p ON p.code = s.code506
		LEFT OUTER JOIN name506 n ON n.code = s.code506
		WHERE DATE_FORMAT(s.vstdate,'%Y') = '$dnowy' 
		GROUP BY s.code506 
		ORDER BY COUNT(*) DESC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
			</div>


			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->







            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


