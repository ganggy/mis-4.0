<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT COUNT(*) AS wtotal
    ,(SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')-COUNT(*) AS wblank
    FROM ipt WHERE dchdate IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_wtotal = $data['wtotal'];
			$ipt_wblank = $data['wblank'];
			}

    $sql = "SELECT COUNT(IF(pttype IN (SELECT pttype FROM pttype WHERE pcode IN (SELECT `code` FROM pcode WHERE tph_pttype_group = 'UC')),an,NULL)) AS 'uc'
    ,COUNT(IF(pttype IN (SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')),an,NULL)) AS 'mo'
    ,COUNT(IF(pttype NOT IN (
    SELECT pttype FROM pttype WHERE pcode IN (SELECT `code` FROM pcode WHERE tph_pttype_group = 'UC')
    UNION
    SELECT pttype FROM pttype WHERE pcode IN ('A1','A2')
    ),an,NULL)) AS 'ot'
    FROM ipt WHERE dchdate IS NULL";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_mo = $data['mo'];
			$ipt_uc = $data['uc'];
			$ipt_ot = $data['ot'];
			}

		$sql = "SELECT COUNT(*) AS admittoday FROM ipt WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admittoday = $data['admittoday'];
			}

		$sql = "SELECT COUNT(*) AS dchtoday FROM ipt WHERE dchdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_dchtoday = $data['dchtoday'];
			}

		$sql = "SELECT COUNT(*) AS movetoday FROM iptbedmove WHERE movedate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_movetoday = $data['movetoday'];
			}

 		$sql = "SELECT SUM(bedcount) AS bedcount FROM ward WHERE ward_active = 'Y' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_bedcount = $data['bedcount'];
			}

if ($_POST['submitsend'] == null) {
	$myearb = date("Y")-1;
	$myeare = date("Y");
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
} else {
    $enddate = date("Y-m-d");
}

		$sql = "SELECT (SUM(i.admdate)*100)/((SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')*DATEDIFF('$enddate','$myearb-10-01')+1) AS admsum
			FROM an_stat i
			WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admsum = $data['admsum'];
			}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<div class="row">

		<div class="col-md-4">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-red">
              <div class="widget-user-image">
                <img class="img-circle" src="dist/img/ipd_icon.png" alt="">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username">สถิติผู้ป่วยในวันนี้</h3>
              <h5 class="widget-user-desc">จำนวนเตียงทั้งหมด <?php echo number_format($ipt_bedcount,0);?> เตียง</h5>
            </div>
            <div class="box-footer no-padding">
				<div class="row">
					<div class="col-sm-6">
              <ul class="nav nav-stacked">
                <li><a href="?stat=ipd">รับใหม่วันนี้ <span class="pull-right badge bg-red"><?php echo number_format($ipt_admittoday,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">จำหน่ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_dchtoday,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">Admit อยู่ <span class="pull-right badge bg-blue"><?php echo number_format($ipt_wtotal,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">เตียงว่าง <span class="pull-right badge bg-green"><?php echo number_format($ipt_wblank,0);?> เตียง</span></a></li>
              </ul>
					</div>
					<div class="col-sm-6">
              <ul class="nav nav-stacked">
                <li><a href="?stat=ipd">สิทธิ์ชำระเงินและเบิกได้ <span class="pull-right badge"> <?php echo number_format($ipt_mo,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">สิทธิ์ UC<span class="pull-right badge"> <?php echo number_format($ipt_uc,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">สิทธิอื่นๆ <span class="pull-right badge"> <?php echo number_format($ipt_ot,0);?> เตียง</span></a></li>
                <li><a href="?stat=ipd">อัตราการครองเตียง <span class="pull-right badge bg-red"><?php echo number_format($ipt_admsum,2);?> %</span></a></li>
              </ul>
					</div>
				</div>


            </div>
          </div>
        </div>
        <!-- /.col -->

    <!-- col -->
    <div class="col-md-8">
      <div class="row">

<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT w.ward,w.name,w.bedcount,COUNT(*) AS admitnow
    FROM ipt i
    LEFT OUTER JOIN ward w ON w.ward = i.ward
    WHERE dchdate IS NULL
    GROUP BY w.ward
    ORDER BY w.ward ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
      if ($data['admitnow']*100/$data['bedcount'] >= 100) {
        $bg_info_color = "bg-red";
      } else if ($data['admitnow']*100/$data['bedcount'] >= 75) {
        $bg_info_color = "bg-yellow";
      } else if ($data['admitnow']*100/$data['bedcount'] >= 50) {
        $bg_info_color = "bg-aqua";
      } else {
        $bg_info_color = "bg-green";
      }
      if ($data['bedcount']-$data['admitnow'] <= 0) {
        $bedblank = "เต็ม";
      } else {
        $bedblank1 = $data['bedcount']-$data['admitnow'];
        $bedblank = "ว่าง ".$bedblank1;
      }
      
?>

            <!-- /.ward-box -->
            <div class="col-sm-6">
              <div class="info-box <?php echo $bg_info_color;?>">
                <a data-toggle="tooltip" title="คลิกดูรายละเอียด --> <?php echo $data['name'];?>" style="color:white;" href="?ward=<?php echo $data['ward'];?>">
                <span class="info-box-icon"><i class="fa fa-bed"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text"><?php echo $data['name'];?></span>
                  <span class="info-box-number">Admit <?php echo $data['admitnow'];?> / <?php echo $data['bedcount'];?> เตียง (<?php echo $bedblank;?>)</span>
                  <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $data['admitnow']*100/$data['bedcount'] ;?>%"></div>
                  </div>
                  <span class="progress-description">ครองเตียง <?php echo number_format($data['admitnow']*100/$data['bedcount'],2) ;?>% </span></a>
                </div>
              </div>
            </div>
            <!-- ward-box./ -->

<?php
    }
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

      </div>
    </div>
    <!-- /.row -->

</div>
<!-- /.row -->