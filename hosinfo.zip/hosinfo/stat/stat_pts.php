<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['ym'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">งานกายภาพบำบัด</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?> bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?> bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?> bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อ ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?> bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <li class="pull-left header"><i class="fa fa-th"></i> <b>งานกายภาพบำบัด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT pg.physic_group_name
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '10',pm.vn,NULL)) AS m10
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '11',pm.vn,NULL)) AS m11
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '12',pm.vn,NULL)) AS m12
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '01',pm.vn,NULL)) AS m01
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '02',pm.vn,NULL)) AS m02
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '03',pm.vn,NULL)) AS m03
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '04',pm.vn,NULL)) AS m04
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '05',pm.vn,NULL)) AS m05
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '06',pm.vn,NULL)) AS m06
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '07',pm.vn,NULL)) AS m07
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '08',pm.vn,NULL)) AS m08
        ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '09',pm.vn,NULL)) AS m09
        ,COUNT(DISTINCT pm.vn) AS total
        FROM physic_main pm
        LEFT OUTER JOIN physic_list pl ON pl.vn = pm.vn
        LEFT OUTER JOIN physic_group pg ON pg.physic_group_id = pl.physic_group_id
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $g_m10 = $row['m10'];
            $g_m11 = $row['m11'];
            $g_m12 = $row['m12'];
            $g_m01 = $row['m01'];
            $g_m02 = $row['m02'];
            $g_m03 = $row['m03'];
            $g_m04 = $row['m04'];
            $g_m05 = $row['m05'];
            $g_m06 = $row['m06'];
            $g_m07 = $row['m07'];
            $g_m08 = $row['m08'];
            $g_m09 = $row['m09'];
		}

		$gtype1 = array(); //ตัวแปรแกน y
		$gtype2 = array(); //ตัวแปรแกน y
		$gtype3 = array(); //ตัวแปรแกน y
		$typenamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(pm.vstdate,'%Y-%m') AS AMONTH,COUNT(pm.type1) AS type1,COUNT(pm.type2) AS type2,COUNT(pm.type3) AS type3
        FROM physic_main pm
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY DATE_FORMAT(pm.vstdate,'%Y-%m')
        ORDER BY DATE_FORMAT(pm.vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($gtype1,$row[type1]);
			 array_push($gtype2,$row[type2]);
			 array_push($gtype3,$row[type3]);
            }
            $name_type1 = "ส่งเสริมและป้องกัน";
            $name_type2 = "รักษา";
            $name_type3 = "ฟื้นฟูสมรรถภาพ";

		$sql = "SELECT COUNT(pm.type1) AS type1,COUNT(pm.type2) AS type2,COUNT(pm.type3) AS type3
        FROM physic_main pm
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $graph_type1 = $row['type1'];
            $graph_type2 = $row['type2'];
            $graph_type3 = $row['type3'];
		}

        $totalpie3 = array(); //ตัวแปรแกน y
		$typenamepie3 = array(); //ตัวแปรแกน y
		$sql = "SELECT t1.pcode,t1.pttypename,t1.total FROM (
            SELECT v.pcode,p.name AS pttypename,COUNT(v.vn) AS total
            FROM physic_main pm
            LEFT OUTER JOIN vn_stat v ON v.vn = pm.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            GROUP BY v.pcode
            ORDER BY COUNT(v.vn) DESC
            LIMIT 10
            ) AS t1
            UNION
            SELECT '00' AS pcode,'*อื่นๆ*' AS pttypename,SUM(t1.total) AS total FROM (
            SELECT v.pcode,p.name AS pttypename,COUNT(v.vn) AS total
            FROM physic_main pm
            LEFT OUTER JOIN vn_stat v ON v.vn = pm.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            GROUP BY v.pcode
            ORDER BY COUNT(v.vn) DESC
            LIMIT 10,100
            ) AS t1";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie3,$row[total]);
			 array_push($typenamepie3,$row[pttypename]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div id="container1" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
</div>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container2" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container3" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
</div>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container1', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'ผู้รับบริการกายภาพบำบัด ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวน(ครั้ง)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b><br/>'
    },

    "series": [
        {
            "name": "ผู้รับบริการ",
            "colorByPoint": true,
            "data": [
                {
                    "name": '<?= $name_month_10; ?>',
                    "y": <?= $g_m10; ?>,
                    "drilldown": '<?= $name_month_10; ?>'
                },
                {
                    "name": '<?= $name_month_11; ?>',
                    "y": <?= $g_m11; ?>,
                    "drilldown": '<?= $name_month_11; ?>'
                },
                {
                    "name": '<?= $name_month_12; ?>',
                    "y": <?= $g_m12; ?>,
                    "drilldown": '<?= $name_month_12; ?>'
                },
                {
                    "name": '<?= $name_month_01; ?>',
                    "y": <?= $g_m01; ?>,
                    "drilldown": '<?= $name_month_01; ?>'
                },
                {
                    "name": '<?= $name_month_02; ?>',
                    "y": <?= $g_m02; ?>,
                    "drilldown": '<?= $name_month_02; ?>'
                },
                {
                    "name": '<?= $name_month_03; ?>',
                    "y": <?= $g_m03; ?>,
                    "drilldown": '<?= $name_month_03; ?>'
                },
                {
                    "name": '<?= $name_month_04; ?>',
                    "y": <?= $g_m04; ?>,
                    "drilldown": '<?= $name_month_04; ?>'
                },
                {
                    "name": '<?= $name_month_05; ?>',
                    "y": <?= $g_m05; ?>,
                    "drilldown": '<?= $name_month_05; ?>'
                },
                {
                    "name": '<?= $name_month_06; ?>',
                    "y": <?= $g_m06; ?>,
                    "drilldown": '<?= $name_month_06; ?>'
                },
                {
                    "name": '<?= $name_month_07; ?>',
                    "y": <?= $g_m07; ?>,
                    "drilldown": '<?= $name_month_07; ?>'
                },
                {
                    "name": '<?= $name_month_08; ?>',
                    "y": <?= $g_m08; ?>,
                    "drilldown": '<?= $name_month_08; ?>'
                },
                {
                    "name": '<?= $name_month_09; ?>',
                    "y": <?= $g_m09; ?>,
                    "drilldown": '<?= $name_month_09; ?>'
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": '<?= $name_month_10; ?>',
                "id": '<?= $name_month_10; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[0]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[0]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[0]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_11; ?>',
                "id": '<?= $name_month_11; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[1]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[1]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[1]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_12; ?>',
                "id": '<?= $name_month_12; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[2]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[2]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[2]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_01; ?>',
                "id": '<?= $name_month_01; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[3]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[3]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[3]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_02; ?>',
                "id": '<?= $name_month_02; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[4]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[4]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[4]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_03; ?>',
                "id": '<?= $name_month_03; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[5]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[5]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[5]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_04; ?>',
                "id": '<?= $name_month_04; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[6]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[6]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[6]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_05; ?>',
                "id": '<?= $name_month_05; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[7]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[7]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[7]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_06; ?>',
                "id": '<?= $name_month_06; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[8]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[8]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[8]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_07; ?>',
                "id": '<?= $name_month_07; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[9]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[9]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[9]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_08; ?>',
                "id": '<?= $name_month_08; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[10]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[10]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[10]; ?>]
                ]
            },
            {
                "name": '<?= $name_month_09; ?>',
                "id": '<?= $name_month_09; ?>',
                "data": [
                    ['<?= $name_type1;?>',<?= $gtype1[11]; ?>],
                    ['<?= $name_type2;?>',<?= $gtype2[11]; ?>],
                    ['<?= $name_type3;?>',<?= $gtype3[11]; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนประเภทผู้รับบริการกายภาพบำบัด'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $name_type1;?>', <?= $graph_type1; ?>],
            ['<?= $name_type2;?>', <?= $graph_type2; ?>],
			{
                name: '<?= $name_type3;?>',
                y: <?= $graph_type3; ?>,
                sliced: true,
                selected: true
			}
		]
    }]
});
</script>

<script type="text/javascript">
Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนสิทธิรักษาพยาบาล 10 อันดับ'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $typenamepie3[0]; ?>', <?= $totalpie3[0]; ?>],
            ['<?= $typenamepie3[1]; ?>', <?= $totalpie3[1]; ?>],
            ['<?= $typenamepie3[2]; ?>', <?= $totalpie3[2]; ?>],
            ['<?= $typenamepie3[3]; ?>', <?= $totalpie3[3]; ?>],
            ['<?= $typenamepie3[4]; ?>', <?= $totalpie3[4]; ?>],
            ['<?= $typenamepie3[5]; ?>', <?= $totalpie3[5]; ?>],
            ['<?= $typenamepie3[6]; ?>', <?= $totalpie3[6]; ?>],
            ['<?= $typenamepie3[7]; ?>', <?= $totalpie3[7]; ?>],
            ['<?= $typenamepie3[8]; ?>', <?= $totalpie3[8]; ?>],
            ['<?= $typenamepie3[9]; ?>', <?= $totalpie3[9]; ?>],
			{
                name: '<?= $typenamepie3[10]; ?>',
                y: <?= $totalpie3[10]; ?>,
                sliced: true,
                selected: true
			}
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนผู้รับบริการกายภาพบำบัด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="danger">
						<th rowspan='2' class="text-center">กลุ่มกายภาพ</th>
						<th colspan='2' scope='col' class='text-center'>ต.ค.</th>
						<th colspan='2' scope='col' class='text-center'>พ.ย.</th>
						<th colspan='2' scope='col' class='text-center'>ธ.ค.</th>
						<th colspan='2' scope='col' class='text-center'>ม.ค.</th>
						<th colspan='2' scope='col' class='text-center'>ก.พ.</th>
						<th colspan='2' scope='col' class='text-center'>มี.ค.</th>
						<th colspan='2' scope='col' class='text-center'>เม.ย.</th>
						<th colspan='2' scope='col' class='text-center'>พ.ค.</th>
						<th colspan='2' scope='col' class='text-center'>มิ.ย.</th>
						<th colspan='2' scope='col' class='text-center'>ก.ค.</th>
						<th colspan='2' scope='col' class='text-center'>ส.ค.</th>
						<th colspan='2' scope='col' class='text-center'>ก.ย.</th>
						<th colspan='2' scope='col' class='text-center'>รวม</th>
					  </tr>
					  <tr class="danger">
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
						<th scope='col' class='text-center'>คน</th>
						<th scope='col' class='text-center'>ครั้ง</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT pg.physic_group_name
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '10',pm.hn,NULL)) AS m10h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '11',pm.hn,NULL)) AS m11h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '12',pm.hn,NULL)) AS m12h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '01',pm.hn,NULL)) AS m01h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '02',pm.hn,NULL)) AS m02h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '03',pm.hn,NULL)) AS m03h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '04',pm.hn,NULL)) AS m04h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '05',pm.hn,NULL)) AS m05h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '06',pm.hn,NULL)) AS m06h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '07',pm.hn,NULL)) AS m07h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '08',pm.hn,NULL)) AS m08h
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '09',pm.hn,NULL)) AS m09h
            ,COUNT(DISTINCT pm.hn) AS totalh
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '10',pm.vn,NULL)) AS m10
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '11',pm.vn,NULL)) AS m11
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '12',pm.vn,NULL)) AS m12
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '01',pm.vn,NULL)) AS m01
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '02',pm.vn,NULL)) AS m02
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '03',pm.vn,NULL)) AS m03
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '04',pm.vn,NULL)) AS m04
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '05',pm.vn,NULL)) AS m05
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '06',pm.vn,NULL)) AS m06
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '07',pm.vn,NULL)) AS m07
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '08',pm.vn,NULL)) AS m08
            ,COUNT(DISTINCT IF(DATE_FORMAT(pm.vstdate,'%m') = '09',pm.vn,NULL)) AS m09
            ,COUNT(DISTINCT pm.vn) AS total
            FROM physic_main pm
            LEFT OUTER JOIN physic_list pl ON pl.vn = pm.vn
            LEFT OUTER JOIN physic_group pg ON pg.physic_group_id = pl.physic_group_id
            WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            GROUP BY pg.physic_group_name";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[physic_group_name]."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m10h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m11h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m12h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m01h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m02h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m03h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m04h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m05h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m06h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m07h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m08h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m09h],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($row[totalh],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($row[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonthh = array(); //ตัวแปรแกน y
		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(pm.vstdate,'%Y-%m') AS AMONTH,COUNT(DISTINCT pm.hn) AS totalh,COUNT(DISTINCT pm.vn) AS total
        FROM physic_main pm
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY DATE_FORMAT(pm.vstdate,'%Y-%m')
        ORDER BY DATE_FORMAT(pm.vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonthh,$row[totalh]);
			array_push($smonth,$row[total]);
			array_push($YM,$row[AMONTH]);
		}

			echo "      <tr class='danger'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
		if ($login_ok == 1) {
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[0],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[0]."&itype=m'><b>".number_format($smonth[0],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[1],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[1]."&itype=m'><b>".number_format($smonth[1],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[2],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[2]."&itype=m'><b>".number_format($smonth[2],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[3],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[3]."&itype=m'><b>".number_format($smonth[3],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[4],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[4]."&itype=m'><b>".number_format($smonth[4],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[5],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[5]."&itype=m'><b>".number_format($smonth[5],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[6],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[6]."&itype=m'><b>".number_format($smonth[6],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[7],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[7]."&itype=m'><b>".number_format($smonth[7],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[8],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[8]."&itype=m'><b>".number_format($smonth[8],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[9],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[9]."&itype=m'><b>".number_format($smonth[9],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[10],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[10]."&itype=m'><b>".number_format($smonth[10],0)."</b></a></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[11],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><a href='".$wwwurl."/?stat=pts&ym=".$YM[11]."&itype=m'><b>".number_format($smonth[11],0)."</b></a></td>";
        } else {
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[0],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[1],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[2],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[3],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[4],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[5],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[6],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[7],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[8],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[9],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[10],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[11],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
        }
		
			echo "        <td scope='col' class='text-right'><b>".number_format($smonthh[0]+$smonthh[1]+$smonthh[2]+$smonthh[3]+$smonthh[4]+$smonthh[5]+$smonthh[6]+$smonthh[7]+$smonthh[8]+$smonthh[9]+$smonthh[10]+$smonthh[11],0)."</b></td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

            <div class="panel-heading">
					<b>จำนวนผู้รับบริการกายภาพบำบัด </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
			</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="info">
						<th rowspan='2' class="text-center">กลุ่มกายภาพ</th>
						<th rowspan='2' class='text-center'>ประเภทเรื้อรัง</th>
						<th colspan='3' scope='col' class='text-center'>กลุ่มการรักษา (ครั้ง)</th>
						<th rowspan='2' class='text-center'>รับบริการ(คน)</th>
						<th rowspan='2' class='text-center'>รับบริการ(ครั้ง)</th>
						<th rowspan='2' class='text-center'>มูลค่า(บาท)</th>
					  </tr>
					  <tr class="info">
						<th scope='col' class='text-center'>ส่งเสริมและป้องกัน</th>
						<th scope='col' class='text-center'>รักษา</th>
						<th scope='col' class='text-center'>ฟื้นฟูสมรรถภาพ</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT pg.physic_group_name,pc.name AS physic_chronic_name
        ,COUNT(pm.type1) AS type1,COUNT(pm.type2) AS type2,COUNT(pm.type3) AS type3
        ,COUNT(DISTINCT pm.vn) AS c_visit,COUNT(DISTINCT pm.hn) AS c_pt,SUM(pi.price) AS phy_price
        FROM physic_main pm
        LEFT OUTER JOIN physic_list pl ON pl.vn = pm.vn
        LEFT OUTER JOIN physic_group pg ON pg.physic_group_id = pl.physic_group_id
        LEFT OUTER JOIN physic_chronic pc ON pc.physic_chronic_id = pm.physic_chronic_id
        LEFT OUTER JOIN physic_items pi ON pi.physic_items_id = pl.physic_items_id
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY pg.physic_group_name,pm.physic_chronic_id";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[physic_group_name]."</td>";
			echo "        <td>".$row[physic_chronic_name]."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type1],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type2],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type3],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[c_visit],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[c_pt],0)."</td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($row[phy_price],0)."</b></td>";
			echo "      </tr>";
		}

		$sql = "SELECT pg.physic_group_name,pc.name AS physic_chronic_name
        ,COUNT(pm.type1) AS type1,COUNT(pm.type2) AS type2,COUNT(pm.type3) AS type3
        ,COUNT(DISTINCT pm.vn) AS c_visit,COUNT(DISTINCT pm.hn) AS c_pt,SUM(pi.price) AS phy_price
        FROM physic_main pm
        LEFT OUTER JOIN physic_list pl ON pl.vn = pm.vn
        LEFT OUTER JOIN physic_group pg ON pg.physic_group_id = pl.physic_group_id
        LEFT OUTER JOIN physic_chronic pc ON pc.physic_chronic_id = pm.physic_chronic_id
        LEFT OUTER JOIN physic_items pi ON pi.physic_items_id = pl.physic_items_id
        WHERE pm.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
		}

			echo "      <tr class='info'>";
			echo "        <td colspan='2' class='text-right'><b>รวม</b></td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type1],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type2],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[type3],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[c_visit],0)."</td>";
			echo "        <td scope='col' class='text-right'>".number_format($row[c_pt],0)."</td>";
			echo "        <td scope='col' class='text-right'><b>".number_format($row[phy_price],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

	<?php
        if ($_GET['itype'] == "m") {
            $i_type = "(เดือน ".$_GET['ym'].")";
            $i_get_where = "WHERE DATE_FORMAT(pm.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        } else {
            $i_type = "(แสดงข้อมูลจากลิงค์ตารางข้อมูล)";
            $i_get_where = "WHERE DATE_FORMAT(pm.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        }
    ?>

	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
			<div class="panel-heading">
				<b>รายชื่อผู้รับบริการแพทย์แผนไทย </b> ปีงบประมาณ <?php echo $myeare+543; ?> <?php echo $i_type; ?>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>บริการกายภาพบำบัด</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT pm.vstdate,pm.vn,pm.hn,p.pname,p.fname,p.lname,v.age_y,v.pttype,ptt.name AS pttype_name,p.addrpart,p.road,p.moopart,t.full_name
,pm.type1,pm.type2,pm.type3,pc.name AS physic_chronic_name,pg.physic_group_name,pi.name AS physic_items_name,SUM(pi.price) AS pts_price,pm.type_text
FROM physic_main pm
LEFT OUTER JOIN physic_list pl ON pl.vn = pm.vn
LEFT OUTER JOIN physic_group pg ON pg.physic_group_id = pl.physic_group_id
LEFT OUTER JOIN physic_chronic pc ON pc.physic_chronic_id = pm.physic_chronic_id
LEFT OUTER JOIN vn_stat v ON v.vn = pm.vn
LEFT OUTER JOIN pttype ptt ON ptt.pttype = v.pttype
LEFT OUTER JOIN patient p ON p.hn = pm.hn
LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
LEFT OUTER JOIN physic_items pi ON pi.physic_items_id = pl.physic_items_id
$i_get_where
GROUP BY pm.vn ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $an_color = "<font color='#ff0000'>".$row[an]."</font>";
			echo "<tr>";
			echo "<td class='text-center'>".$row[vstdate]."</td>";
			echo "<td class='text-center'>".$row[hn].$an_color."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td class='text-center'>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttype_name]."</td>";
			echo "<td>".$row[type_text]." ".$row[physic_items_name]."</td>";
			echo "<td class='text-right'>".$row[pts_price]."</td>";
			echo "</tr>";
		}
		
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
	
	?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


