<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['ym'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">แพทย์แผนไทย</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?> bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?> bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?> bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อ ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?> bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <li class="pull-left header"><i class="fa fa-th"></i> <b>แพทย์แผนไทย </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS total
        FROM health_med_service hs
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY DATE_FORMAT(hs.service_date,'%Y-%m')
        ORDER BY DATE_FORMAT(hs.service_date,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[total]);
		}
			if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
			if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
			if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
			if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
			if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
			if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
			if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
			if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
			if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
			if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
			if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
			if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$countipd10 = array(); //ตัวแปรแกน y
		$ppttname10 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myearb-10-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd10,$row[wcount]);
			array_push($ppttname10,$row[ppttname]);
		}

		$countipd11 = array(); //ตัวแปรแกน y
		$ppttname11 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-11-01' AND '$myearb-11-30' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd11,$row[wcount]);
			array_push($ppttname11,$row[ppttname]);
		}

		$countipd12 = array(); //ตัวแปรแกน y
		$ppttname12 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-12-01' AND '$myearb-12-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd12,$row[wcount]);
			array_push($ppttname12,$row[ppttname]);
		}

		$countipd01 = array(); //ตัวแปรแกน y
		$ppttname01 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-01-01' AND '$myeare-01-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd01,$row[wcount]);
			array_push($ppttname01,$row[ppttname]);
		}

		$countipd02 = array(); //ตัวแปรแกน y
		$ppttname02 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-02-01' AND '$myeare-02-29' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd02,$row[wcount]);
			array_push($ppttname02,$row[ppttname]);
		}

		$countipd03 = array(); //ตัวแปรแกน y
		$ppttname03 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-03-01' AND '$myeare-03-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd03,$row[wcount]);
			array_push($ppttname03,$row[ppttname]);
		}

		$countipd04 = array(); //ตัวแปรแกน y
		$ppttname04 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-04-01' AND '$myeare-04-30' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd04,$row[wcount]);
			array_push($ppttname04,$row[ppttname]);
		}

		$countipd05 = array(); //ตัวแปรแกน y
		$ppttname05 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-05-01' AND '$myeare-05-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd05,$row[wcount]);
			array_push($ppttname05,$row[ppttname]);
		}

		$countipd06 = array(); //ตัวแปรแกน y
		$ppttname06 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-06-01' AND '$myeare-06-30' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd06,$row[wcount]);
			array_push($ppttname06,$row[ppttname]);
		}

		$countipd07 = array(); //ตัวแปรแกน y
		$ppttname07 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-07-01' AND '$myeare-07-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd07,$row[wcount]);
			array_push($ppttname07,$row[ppttname]);
		}

		$countipd08 = array(); //ตัวแปรแกน y
		$ppttname08 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-08-01' AND '$myeare-08-31' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd08,$row[wcount]);
			array_push($ppttname08,$row[ppttname]);
		}

		$countipd09 = array(); //ตัวแปรแกน y
		$ppttname09 = array(); //ตัวแปรแกน y
		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myeare-09-01' AND '$myeare-09-30' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd09,$row[wcount]);
			array_push($ppttname09,$row[ppttname]);
		}

		$totalpie = array(); //ตัวแปรแกน y
		$typenamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT hs.health_med_treatment_type_id AS ttype,ht.health_med_treatment_type_name AS typename
        ,COUNT(*) AS total
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND hs.health_med_treatment_type_id IS NOT NULL
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[total]);
			 array_push($typenamepie,$row[typename]);
		}

        $totalpie3 = array(); //ตัวแปรแกน y
		$typenamepie3 = array(); //ตัวแปรแกน y
		$sql = "SELECT t2.pcode,t2.pttypename,t2.total FROM (
            SELECT t.pcode,t.pttypename,t.total FROM (
            SELECT 'ZZ' AS pcode,'*ไม่ทราบสิทธิ*' AS pttypename,COUNT(*) AS total
            FROM health_med_service hs
            LEFT OUTER JOIN vn_stat v ON v.vn = hs.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            AND (v.pcode IS NULL OR v.pcode = '')
            GROUP BY v.pcode
            UNION
            SELECT v.pcode,p.`name` AS pttypename,COUNT(*) AS total
            FROM health_med_service hs
            LEFT OUTER JOIN vn_stat v ON v.vn = hs.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            AND (v.pcode IS NOT NULL OR v.pcode <> '')
            GROUP BY v.pcode
            ) AS t
            ORDER BY t.total DESC LIMIT 10
            ) AS t2
            
            UNION
            
            SELECT '00' AS pcode,'*อื่นๆ*' AS pttypename,SUM(t2.total) AS total FROM (
            SELECT t.pcode,t.pttypename,t.total FROM (
            SELECT 'ZZ' AS pcode,'*ไม่ทราบสิทธิ*' AS pttypename,COUNT(*) AS total
            FROM health_med_service hs
            LEFT OUTER JOIN vn_stat v ON v.vn = hs.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            AND (v.pcode IS NULL OR v.pcode = '')
            GROUP BY v.pcode
            UNION
            SELECT v.pcode,p.`name` AS pttypename,COUNT(*) AS total
            FROM health_med_service hs
            LEFT OUTER JOIN vn_stat v ON v.vn = hs.vn
            LEFT OUTER JOIN pcode p ON p.`code` = v.pcode
            LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
            WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
            AND (v.pcode IS NOT NULL OR v.pcode <> '')
            GROUP BY v.pcode
            ) AS t
            ORDER BY t.total DESC LIMIT 10,100
            ) AS t2";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie3,$row[total]);
			 array_push($typenamepie3,$row[pttypename]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div id="container1" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
</div>
<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container2" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container3" style="min-width: 310px; height: 500px; margin: 0 auto"></div>
	</div>
</div>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container1', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'ผู้รับบริการแพทย์แผนไทย ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวน(ครั้ง)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b><br/>'
    },

    "series": [
        {
            "name": "ผู้รับบริการ",
            "colorByPoint": true,
            "data": [
                {
                    "name": "ตุลาคม",
                    "y": <?= $ptipd0; ?>,
                    "drilldown": "ตุลาคม"
                },
                {
                    "name": "พฤศจิกายน",
                    "y": <?= $ptipd1; ?>,
                    "drilldown": "พฤศจิกายน"
                },
                {
                    "name": "ธันวาคม",
                    "y": <?= $ptipd2; ?>,
                    "drilldown": "ธันวาคม"
                },
                {
                    "name": "มกราคม",
                    "y": <?= $ptipd3; ?>,
                    "drilldown": "มกราคม"
                },
                {
                    "name": "กุมภาพันธ์",
                    "y": <?= $ptipd4; ?>,
                    "drilldown": "กุมภาพันธ์"
                },
                {
                    "name": "มีนาคม",
                    "y": <?= $ptipd5; ?>,
                    "drilldown": "มีนาคม"
                },
                {
                    "name": "เมษายน",
                    "y": <?= $ptipd6; ?>,
                    "drilldown": "เมษายน"
                },
                {
                    "name": "พฤษภาคม",
                    "y": <?= $ptipd7; ?>,
                    "drilldown": "พฤษภาคม"
                },
                {
                    "name": "มิถุนายน",
                    "y": <?= $ptipd8; ?>,
                    "drilldown": "มิถุนายน"
                },
                {
                    "name": "กรกฎาคม",
                    "y": <?= $ptipd9; ?>,
                    "drilldown": "กรกฎาคม"
                },
                {
                    "name": "สิงหาคม",
                    "y": <?= $ptipd10; ?>,
                    "drilldown": "สิงหาคม"
                },
                {
                    "name": "กันยายน",
                    "y": <?= $ptipd11; ?>,
                    "drilldown": "กันยายน"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "ตุลาคม",
                "id": "ตุลาคม",
                "data": [
                    ['<?= $ppttname10[0]; ?>',<?= $countipd10[0]; ?>],
                    ['<?= $ppttname10[1]; ?>',<?= $countipd10[1]; ?>],
                    ['<?= $ppttname10[2]; ?>',<?= $countipd10[2]; ?>]
                ]
            },
            {
                "name": "พฤศจิกายน",
                "id": "พฤศจิกายน",
                "data": [
                    ['<?= $ppttname11[0]; ?>',<?= $countipd11[0]; ?>],
                    ['<?= $ppttname11[1]; ?>',<?= $countipd11[1]; ?>],
                    ['<?= $ppttname11[2]; ?>',<?= $countipd11[2]; ?>]
                ]
            },
            {
                "name": "ธันวาคม",
                "id": "ธันวาคม",
                "data": [
                    ['<?= $ppttname12[0]; ?>',<?= $countipd12[0]; ?>],
                    ['<?= $ppttname12[1]; ?>',<?= $countipd12[1]; ?>],
                    ['<?= $ppttname12[2]; ?>',<?= $countipd12[2]; ?>]
                ]
            },
            {
                "name": "มกราคม",
                "id": "มกราคม",
                "data": [
                    ['<?= $ppttname01[0]; ?>',<?= $countipd01[0]; ?>],
                    ['<?= $ppttname01[1]; ?>',<?= $countipd01[1]; ?>],
                    ['<?= $ppttname01[2]; ?>',<?= $countipd01[2]; ?>]
                ]
            },
            {
                "name": "กุมภาพันธ์",
                "id": "กุมภาพันธ์",
                "data": [
                    ['<?= $ppttname02[0]; ?>',<?= $countipd02[0]; ?>],
                    ['<?= $ppttname02[1]; ?>',<?= $countipd02[1]; ?>],
                    ['<?= $ppttname02[2]; ?>',<?= $countipd02[2]; ?>]
                ]
            },
            {
                "name": "มีนาคม",
                "id": "มีนาคม",
                "data": [
                    ['<?= $ppttname03[0]; ?>',<?= $countipd03[0]; ?>],
                    ['<?= $ppttname03[1]; ?>',<?= $countipd03[1]; ?>],
                    ['<?= $ppttname03[2]; ?>',<?= $countipd03[2]; ?>]
                ]
            },
            {
                "name": "เมษายน",
                "id": "เมษายน",
                "data": [
                    ['<?= $ppttname04[0]; ?>',<?= $countipd04[0]; ?>],
                    ['<?= $ppttname04[1]; ?>',<?= $countipd04[1]; ?>],
                    ['<?= $ppttname04[2]; ?>',<?= $countipd04[2]; ?>]
                ]
            },
            {
                "name": "พฤษภาคม",
                "id": "พฤษภาคม",
                "data": [
                    ['<?= $ppttname05[0]; ?>',<?= $countipd05[0]; ?>],
                    ['<?= $ppttname05[1]; ?>',<?= $countipd05[1]; ?>],
                    ['<?= $ppttname05[2]; ?>',<?= $countipd05[2]; ?>]
                ]
            },
            {
                "name": "มิถุนายน",
                "id": "มิถุนายน",
                "data": [
                    ['<?= $ppttname06[0]; ?>',<?= $countipd06[0]; ?>],
                    ['<?= $ppttname06[1]; ?>',<?= $countipd06[1]; ?>],
                    ['<?= $ppttname06[2]; ?>',<?= $countipd06[2]; ?>]
                ]
            },
            {
                "name": "กรกฎาคม",
                "id": "กรกฎาคม",
                "data": [
                    ['<?= $ppttname07[0]; ?>',<?= $countipd07[0]; ?>],
                    ['<?= $ppttname07[1]; ?>',<?= $countipd07[1]; ?>],
                    ['<?= $ppttname07[2]; ?>',<?= $countipd07[2]; ?>]
                ]
            },
            {
                "name": "สิงหาคม",
                "id": "สิงหาคม",
                "data": [
                    ['<?= $ppttname08[0]; ?>',<?= $countipd08[0]; ?>],
                    ['<?= $ppttname08[1]; ?>',<?= $countipd08[1]; ?>],
                    ['<?= $ppttname08[2]; ?>',<?= $countipd08[2]; ?>]
                ]
            },
            {
                "name": "กันยายน",
                "id": "กันยายน",
                "data": [
                    ['<?= $ppttname09[0]; ?>',<?= $countipd09[0]; ?>],
                    ['<?= $ppttname09[1]; ?>',<?= $countipd09[1]; ?>],
                    ['<?= $ppttname09[2]; ?>',<?= $countipd09[2]; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนประเภทการรักษาแพทย์แผนไทย'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $typenamepie[0]; ?>',   <?= $totalpie[0]; ?>],
            ['<?= $typenamepie[1]; ?>',       <?= $totalpie[1]; ?>],
			{
                name: '<?= $typenamepie[2]; ?>',
                y: <?= $totalpie[2]; ?>,
                sliced: true,
                selected: true
			}
		]
    }]
});
</script>

<script type="text/javascript">
Highcharts.chart('container3', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนสิทธิรักษาพยาบาล 10 อันดับ'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $typenamepie3[0]; ?>', <?= $totalpie3[0]; ?>],
            ['<?= $typenamepie3[1]; ?>', <?= $totalpie3[1]; ?>],
            ['<?= $typenamepie3[2]; ?>', <?= $totalpie3[2]; ?>],
            ['<?= $typenamepie3[3]; ?>', <?= $totalpie3[3]; ?>],
            ['<?= $typenamepie3[4]; ?>', <?= $totalpie3[4]; ?>],
            ['<?= $typenamepie3[5]; ?>', <?= $totalpie3[5]; ?>],
            ['<?= $typenamepie3[6]; ?>', <?= $totalpie3[6]; ?>],
            ['<?= $typenamepie3[7]; ?>', <?= $totalpie3[7]; ?>],
            ['<?= $typenamepie3[8]; ?>', <?= $totalpie3[8]; ?>],
            ['<?= $typenamepie3[9]; ?>', <?= $totalpie3[9]; ?>],
			{
                name: '<?= $typenamepie3[10]; ?>',
                y: <?= $totalpie3[10]; ?>,
                sliced: true,
                selected: true
			}
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนครั้งรับบริการแพทย์แผนไทย </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="danger">
						<th class="text-center">ประเภทการรักษา</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT hs.health_med_treatment_type_id AS ttype,ht.health_med_treatment_type_name AS typename
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '10',hs.vn,NULL)) AS m10
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '11',hs.vn,NULL)) AS m11
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '12',hs.vn,NULL)) AS m12
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '01',hs.vn,NULL)) AS m01
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '02',hs.vn,NULL)) AS m02
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '03',hs.vn,NULL)) AS m03
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '04',hs.vn,NULL)) AS m04
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '05',hs.vn,NULL)) AS m05
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '06',hs.vn,NULL)) AS m06
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '07',hs.vn,NULL)) AS m07
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '08',hs.vn,NULL)) AS m08
        ,COUNT(IF(DATE_FORMAT(hs.service_date,'%m') = '09',hs.vn,NULL)) AS m09
        ,COUNT(*) AS total
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[typename]."</td>";
			echo "        <td class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(*) AS total
        FROM health_med_service hs
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY DATE_FORMAT(hs.service_date,'%Y-%m')
        ORDER BY DATE_FORMAT(hs.service_date,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[total]);
			array_push($YM,$row[AMONTH]);
		}

			echo "      <tr class='danger'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
		if ($login_ok == 1) {
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[0]."&itype=m'><b>".number_format($smonth[0],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[1]."&itype=m'><b>".number_format($smonth[1],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[2]."&itype=m'><b>".number_format($smonth[2],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[3]."&itype=m'><b>".number_format($smonth[3],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[4]."&itype=m'><b>".number_format($smonth[4],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[5]."&itype=m'><b>".number_format($smonth[5],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[6]."&itype=m'><b>".number_format($smonth[6],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[7]."&itype=m'><b>".number_format($smonth[7],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[8]."&itype=m'><b>".number_format($smonth[8],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[9]."&itype=m'><b>".number_format($smonth[9],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[10]."&itype=m'><b>".number_format($smonth[10],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=ppt&ym=".$YM[11]."&itype=m'><b>".number_format($smonth[11],0)."</b></a></td>";
        } else {
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
        }
		
			echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>

            <div class="panel-heading">
					<b>จำนวนคนรับบริการแพทย์แผนไทย </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class="text-center">ประเภทการรักษา</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT hs.health_med_treatment_type_id AS ttype,ht.health_med_treatment_type_name AS typename
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '10',hs.hn,NULL)) AS m10
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '11',hs.hn,NULL)) AS m11
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '12',hs.hn,NULL)) AS m12
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '01',hs.hn,NULL)) AS m01
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '02',hs.hn,NULL)) AS m02
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '03',hs.hn,NULL)) AS m03
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '04',hs.hn,NULL)) AS m04
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '05',hs.hn,NULL)) AS m05
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '06',hs.hn,NULL)) AS m06
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '07',hs.hn,NULL)) AS m07
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '08',hs.hn,NULL)) AS m08
        ,COUNT(DISTINCT IF(DATE_FORMAT(hs.service_date,'%m') = '09',hs.hn,NULL)) AS m09
        ,COUNT(DISTINCT hs.hn) AS total
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY hs.health_med_treatment_type_id
        ORDER BY hs.health_med_treatment_type_id ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[typename]."</td>";
			echo "        <td class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(hs.service_date,'%Y-%m') AS AMONTH,COUNT(DISTINCT hs.hn) AS total
        FROM health_med_service hs
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30'
        GROUP BY DATE_FORMAT(hs.service_date,'%Y-%m')
        ORDER BY DATE_FORMAT(hs.service_date,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[total]);
			array_push($YM,$row[AMONTH]);
		}

			echo "      <tr class='success'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";

        $sql = "SELECT COUNT(DISTINCT hs.hn) AS total
        FROM health_med_service hs
        WHERE hs.service_date BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			$distotal = $row[total];
		}

			echo "        <td class='text-right'><b>".number_format($distotal,0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

	<?php
        if ($_GET['itype'] == "m") {
            $i_type = "(เดือน ".$_GET['ym'].")";
            $i_get_where = "WHERE DATE_FORMAT(hs.service_date,'%Y-%m') = '".$_GET['ym']."' ";
        } else {
            $i_type = "(แสดงข้อมูลจากลิงค์ตารางข้อมูล)";
            $i_get_where = "WHERE DATE_FORMAT(hs.service_date,'%Y-%m') = '".$_GET['ym']."' ";
        }
    ?>

	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
			<div class="panel-heading">
				<b>รายชื่อผู้รับบริการแพทย์แผนไทย </b> ปีงบประมาณ <?php echo $myeare+543; ?> <?php echo $i_type; ?>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN/AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>ประเภทบริการ</b></th>
						<th class='text-center'><b>การวินิจฉัย</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT ht.health_med_treatment_type_name AS ppttname,hs.service_date,v.hn,hs.an,p.pname,p.fname,p.lname,v.age_y AS agev,a.age_y AS agea
        ,p.addrpart,p.road,p.moopart,t.full_name,v.pdx,i.name AS dxname,v.pttype,a.pttype,pt.name AS pttypename,pt2.name AS pttypename2,v.income
        FROM health_med_service hs
        LEFT OUTER JOIN health_med_treatment_type ht ON ht.health_med_treatment_type_id = hs.health_med_treatment_type_id
        LEFT OUTER JOIN vn_stat v ON v.vn = hs.vn
        LEFT OUTER JOIN an_stat a ON a.an = hs.an
        LEFT OUTER JOIN patient p ON p.hn = hs.hn
        LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
        LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
        LEFT OUTER JOIN pttype pt2 ON pt2.pttype = a.pttype
        LEFT OUTER JOIN icd101 i ON i.`code` = v.pdx $i_get_where ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            $an_color = "<font color='#ff0000'>".$row[an]."</font>";
			echo "<tr>";
			echo "<td>".$row[service_date]."</td>";
			echo "<td>".$row[hn].$an_color."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[agev].$row[agea]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype].$row[pttype2]." ".$row[pttypename].$row[pttypename2]."</td>";
			echo "<td>".$row[ppttname]."</td>";
			echo "<td>".$row[pdx]." ".$row[dxname]."</td>";
			echo "<td>".$row[income]."</td>";
			echo "</tr>";
		}
		
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
	
	?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


