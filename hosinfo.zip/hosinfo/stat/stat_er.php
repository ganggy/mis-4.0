<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($_POST['submitsend'] == null) {
	if (date("m") > 9) {
		$myearb = date("Y");
		$myeare = date("Y")+1;
	} else {
		$myearb = date("Y")-1;
		$myeare = date("Y");
	}
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
$TH_Month = array("ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
$nMonth = date("n")-1;
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
    $enddate2 = "30 ก.ย.";
} else {
    $enddate = date("Y-m-d");
    $enddate2 = date('j ').$TH_Month[$nMonth];
}

if ($_GET['ym'] || NULL) {
    $tab_active3 = "active ";
} else {
    $tab_active1 = "active ";
    $tab_active2 = "";
    $tab_active9 = "";
}

?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลและสถิติ 
        <small><?php echo $hospitalname;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลและสถิติ</li>
        <li class="active">งานอุบัติเหตุและฉุกเฉิน</li>

      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="<?php echo $tab_active1;?> bg-warning"><a href="#tab_1-1" data-toggle="tab">[ แผนภูมิ ]</a></li>
              <li class="<?php echo $tab_active2;?> bg-warning"><a href="#tab_2-2" data-toggle="tab">[ ตารางข้อมูล ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
			  <li class="<?php echo $tab_active3;?> bg-warning"><a href="#tab_3-3" data-toggle="tab">[ รายชื่อผู้ป่วย ]</a></li>
	<?php } else { }?>
			  <li class="<?php echo $tab_active9;?> bg-warning"><a href="#tab_9-9" data-toggle="tab">[ HELP ]</a></li>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> <b>งานอุบัติเหตุและฉุกเฉิน </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)</li>

<div class="panel-body">
  <form class="form-inline" role="form" method="post" name="search_form" action="<?php echo $PHP_SELF ?>" onsubmit="return check()">
	<div class="row">
	<div class="col-sm-12">
      <label for="email">ประมวลผลข้อมูลปีงบประมาณ </label>
      <input type="text" size="10" class="form-control" id="year" name="year" placeholder="ปีงบประมาณ">
	  <input name="submitsend" type="submit" class="btn btn-default btn-primary" value=" ตกลง ">
	 </div>
	 </div>
  </form>

            </ul>
            <div class="tab-content">

			  <div class="tab-pane <?php echo $tab_active1;?>" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">

<?php
	try {
		include '_cfg_hos.php';

		$amonth = array(); //ตัวแปรแกน y
		$ptipd = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS ipd
			FROM er_regist
			WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' AND er_pt_type IN (2,5)
			GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
			ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($amonth,$row[AMONTH]);
			array_push($ptipd,$row[ipd]);
		}
			if(empty($ptipd[0])){$ptipd0 = 0;}else{$ptipd0 = $ptipd[0];}
			if(empty($ptipd[1])){$ptipd1 = 0;}else{$ptipd1 = $ptipd[1];}
			if(empty($ptipd[2])){$ptipd2 = 0;}else{$ptipd2 = $ptipd[2];}
			if(empty($ptipd[3])){$ptipd3 = 0;}else{$ptipd3 = $ptipd[3];}
			if(empty($ptipd[4])){$ptipd4 = 0;}else{$ptipd4 = $ptipd[4];}
			if(empty($ptipd[5])){$ptipd5 = 0;}else{$ptipd5 = $ptipd[5];}
			if(empty($ptipd[6])){$ptipd6 = 0;}else{$ptipd6 = $ptipd[6];}
			if(empty($ptipd[7])){$ptipd7 = 0;}else{$ptipd7 = $ptipd[7];}
			if(empty($ptipd[8])){$ptipd8 = 0;}else{$ptipd8 = $ptipd[8];}
			if(empty($ptipd[9])){$ptipd9 = 0;}else{$ptipd9 = $ptipd[9];}
			if(empty($ptipd[10])){$ptipd10 = 0;}else{$ptipd10 = $ptipd[10];}
			if(empty($ptipd[11])){$ptipd11 = 0;}else{$ptipd11 = $ptipd[11];}

		$countipd10 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myearb-10-01' AND '$myearb-10-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd10,$row[wcount]);
		}

		$countipd11 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myearb-11-01' AND '$myearb-11-30' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd11,$row[wcount]);
		}

		$countipd12 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myearb-12-01' AND '$myearb-12-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd12,$row[wcount]);
		}

		$countipd01 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-01-01' AND '$myeare-01-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd01,$row[wcount]);
		}

		$countipd02 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-02-01' AND '$myeare-02-29' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd02,$row[wcount]);
		}

		$countipd03 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-03-01' AND '$myeare-03-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd03,$row[wcount]);
		}

		$countipd04 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-04-01' AND '$myeare-04-30' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd04,$row[wcount]);
		}

		$countipd05 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-05-01' AND '$myeare-05-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd05,$row[wcount]);
		}

		$countipd06 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-06-01' AND '$myeare-06-30' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd06,$row[wcount]);
		}

		$countipd07 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-07-01' AND '$myeare-07-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd07,$row[wcount]);
		}

		$countipd08 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-08-01' AND '$myeare-08-31' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd08,$row[wcount]);
		}

		$countipd09 = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS wcount
			FROM er_regist
			WHERE vstdate BETWEEN '$myeare-09-01' AND '$myeare-09-30' AND er_pt_type IN (1,2,5)
			GROUP BY er_pt_type
			ORDER BY er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($countipd09,$row[wcount]);
		}

		$totalpie = array(); //ตัวแปรแกน y
		$delinamepie = array(); //ตัวแปรแกน y
		$sql = "SELECT er.er_pt_type AS ertype,et.name AS typename,COUNT(*) AS total
			FROM er_regist er
			LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = er.er_pt_type
			WHERE er.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY er.er_pt_type
			ORDER BY COUNT(*) DESC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($totalpie,$row[total]);
			 array_push($delinamepie,$row[typename]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/data.js"></script>
<script src="https://code.highcharts.com/modules/drilldown.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
		<div id="container2" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
	</div>
</div>

<script type="text/javascript">
// Create the chart
Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'ผู้ป่วยอุบัติเหตุ ปีงบประมาณ <?= $myeare+543; ?>'
    },
    subtitle: {
        text: '<?= $hospitalname;?>'
    },
    xAxis: {
        type: 'category'
    },
    yAxis: {
        title: {
            text: 'จำนวน(ราย)'
        }

    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            dataLabels: {
                enabled: true,
                format: '{point.y:.0f}'
            }
        }
    },

    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}</b><br/>'
    },

    "series": [
        {
            "name": "ผู้ป่วยอุบัติเหตุ",
            "colorByPoint": true,
            "data": [
                {
                    "name": "ตุลาคม",
                    "y": <?= $ptipd0; ?>,
                    "drilldown": "ตุลาคม"
                },
                {
                    "name": "พฤศจิกายน",
                    "y": <?= $ptipd1; ?>,
                    "drilldown": "พฤศจิกายน"
                },
                {
                    "name": "ธันวาคม",
                    "y": <?= $ptipd2; ?>,
                    "drilldown": "ธันวาคม"
                },
                {
                    "name": "มกราคม",
                    "y": <?= $ptipd3; ?>,
                    "drilldown": "มกราคม"
                },
                {
                    "name": "กุมภาพันธ์",
                    "y": <?= $ptipd4; ?>,
                    "drilldown": "กุมภาพันธ์"
                },
                {
                    "name": "มีนาคม",
                    "y": <?= $ptipd5; ?>,
                    "drilldown": "มีนาคม"
                },
                {
                    "name": "เมษายน",
                    "y": <?= $ptipd6; ?>,
                    "drilldown": "เมษายน"
                },
                {
                    "name": "พฤษภาคม",
                    "y": <?= $ptipd7; ?>,
                    "drilldown": "พฤษภาคม"
                },
                {
                    "name": "มิถุนายน",
                    "y": <?= $ptipd8; ?>,
                    "drilldown": "มิถุนายน"
                },
                {
                    "name": "กรกฎาคม",
                    "y": <?= $ptipd9; ?>,
                    "drilldown": "กรกฎาคม"
                },
                {
                    "name": "สิงหาคม",
                    "y": <?= $ptipd10; ?>,
                    "drilldown": "สิงหาคม"
                },
                {
                    "name": "กันยายน",
                    "y": <?= $ptipd11; ?>,
                    "drilldown": "กันยายน"
                }
            ]
        }
    ],
    "drilldown": {
        "series": [
            {
                "name": "ตุลาคม",
                "id": "ตุลาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd10[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd10[2]; ?>]
                ]
            },
            {
                "name": "พฤศจิกายน",
                "id": "พฤศจิกายน",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd11[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd11[2]; ?>]
                ]
            },
            {
                "name": "ธันวาคม",
                "id": "ธันวาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd12[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd12[2]; ?>]
                ]
            },
            {
                "name": "มกราคม",
                "id": "มกราคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd01[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd01[2]; ?>]
                ]
            },
            {
                "name": "กุมภาพันธ์",
                "id": "กุมภาพันธ์",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd02[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd02[2]; ?>]
                ]
            },
            {
                "name": "มีนาคม",
                "id": "มีนาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd03[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd03[2]; ?>]
                ]
            },
            {
                "name": "เมษายน",
                "id": "เมษายน",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd04[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd04[2]; ?>]
                ]
            },
            {
                "name": "พฤษภาคม",
                "id": "พฤษภาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd05[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd05[2]; ?>]
                ]
            },
            {
                "name": "มิถุนายน",
                "id": "มิถุนายน",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd06[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd06[2]; ?>]
                ]
            },
            {
                "name": "กรกฎาคม",
                "id": "กรกฎาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd07[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd07[2]; ?>]
                ]
            },
            {
                "name": "สิงหาคม",
                "id": "สิงหาคม",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd08[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd08[2]; ?>]
                ]
            },
            {
                "name": "กันยายน",
                "id": "กันยายน",
                "data": [
                    ['ผู้ป่วยอุบัติเหตุ',<?= $countipd09[1]; ?>],
                    ['ผู้ป่วยอุบัติเหตุจราจร',<?= $countipd09[2]; ?>]
                ]
            }
        ]
    }
});
</script>

<script type="text/javascript">
Highcharts.chart('container2', {
    chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
    },
    title: {
        text: 'แสดงสัดส่วนผู้รับบริการงานอุบัติเหตุและฉุกเฉิน'
    },
    tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
    },
    plotOptions: {
        pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                style: {
                    color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
                }
            }
        }
    },
    series: [{
        name: 'ร้อยละ',
        colorByPoint: true,
        data: [
            ['<?= $delinamepie[0]; ?>', <?= $totalpie[0]; ?>],
            ['<?= $delinamepie[1]; ?>', <?= $totalpie[1]; ?>],
            ['<?= $delinamepie[2]; ?>', <?= $totalpie[2]; ?>],
            ['<?= $delinamepie[3]; ?>', <?= $totalpie[3]; ?>],
			{
                name: '<?= $delinamepie[4]; ?>',
                y: <?= $totalpie[4]; ?>,
                sliced: true,
                selected: true
			}
		]
    }]
});
</script>

			</div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->

            <div class="tab-pane <?php echo $tab_active2;?>" id="tab_2-2">
				<div class="panel-heading">
					<b>จำนวนผู้รับบริการงานอุบัติเหตุและฉุกเฉิน </b> ปีงบประมาณ <?php echo $myeare+543; ?> (1 ต.ค.<?php echo $myearb+543; ?> - <?php echo $enddate2."".($myeare+543); ?>)
				</div>

            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="danger">
						<th class="text-center">ประเภทผู้รับบริการ</th>
						<th class="text-center">ต.ค.</th>
						<th class="text-center">พ.ย.</th>
						<th class="text-center">ธ.ค.</th>
						<th class="text-center">ม.ค.</th>
						<th class="text-center">ก.พ.</th>
						<th class="text-center">มี.ค.</th>
						<th class="text-center">เม.ย.</th>
						<th class="text-center">พ.ค.</th>
						<th class="text-center">มิ.ย.</th>
						<th class="text-center">ก.ค.</th>
						<th class="text-center">ส.ค.</th>
						<th class="text-center">ก.ย.</th>
						<th class="text-center">รวม</th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT er.er_pt_type AS ertype,et.name AS typename
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '10',er.vn,NULL)) AS m10
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '11',er.vn,NULL)) AS m11
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '12',er.vn,NULL)) AS m12
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '01',er.vn,NULL)) AS m01
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '02',er.vn,NULL)) AS m02
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '03',er.vn,NULL)) AS m03
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '04',er.vn,NULL)) AS m04
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '05',er.vn,NULL)) AS m05
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '06',er.vn,NULL)) AS m06
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '07',er.vn,NULL)) AS m07
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '08',er.vn,NULL)) AS m08
			,COUNT(IF(DATE_FORMAT(er.vstdate,'%m') = '09',er.vn,NULL)) AS m09
			,COUNT(*) AS total
			FROM er_regist er
			LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = er.er_pt_type
			WHERE er.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY er.er_pt_type
			ORDER BY er.er_pt_type ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

			echo "      <tr>";
			echo "        <td>".$row[typename]."</td>";
			echo "        <td class='text-right'>".number_format($row[m10],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m11],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m12],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m01],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m02],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m03],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m04],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m05],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m06],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m07],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m08],0)."</td>";
			echo "        <td class='text-right'>".number_format($row[m09],0)."</td>";
			echo "        <td class='text-right'><b>".number_format($row[total],0)."</b></td>";
			echo "      </tr>";
		}

		$smonth = array(); //ตัวแปรแกน y
		$YM = array(); //ตัวแปรแกน y
		$sql = "SELECT DATE_FORMAT(vstdate,'%Y-%m') AS AMONTH,COUNT(*) AS total
			FROM er_regist
			WHERE vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30'
			GROUP BY DATE_FORMAT(vstdate,'%Y-%m')
			ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			array_push($smonth,$row[total]);
			array_push($YM,$row[AMONTH]);
		}

			echo "      <tr class='danger'>";
			echo "        <td class='text-center'><b>รวม</b></td>";
		if ($login_ok == 1) {
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[0]."&itype=m'><b>".number_format($smonth[0],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[1]."&itype=m'><b>".number_format($smonth[1],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[2]."&itype=m'><b>".number_format($smonth[2],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[3]."&itype=m'><b>".number_format($smonth[3],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[4]."&itype=m'><b>".number_format($smonth[4],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[5]."&itype=m'><b>".number_format($smonth[5],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[6]."&itype=m'><b>".number_format($smonth[6],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[7]."&itype=m'><b>".number_format($smonth[7],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[8]."&itype=m'><b>".number_format($smonth[8],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[9]."&itype=m'><b>".number_format($smonth[9],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[10]."&itype=m'><b>".number_format($smonth[10],0)."</b></a></td>";
			echo "        <td class='text-right'><a href='".$wwwurl."/?stat=er&ym=".$YM[11]."&itype=m'><b>".number_format($smonth[11],0)."</b></a></td>";
        } else {
			echo "        <td class='text-right'><b>".number_format($smonth[0],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[1],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[2],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[3],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[4],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[5],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[6],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[7],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[8],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[9],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[10],0)."</b></td>";
			echo "        <td class='text-right'><b>".number_format($smonth[11],0)."</b></td>";
        }
		
			echo "        <td class='text-right'><b>".number_format($smonth[0]+$smonth[1]+$smonth[2]+$smonth[3]+$smonth[4]+$smonth[5]+$smonth[6]+$smonth[7]+$smonth[8]+$smonth[9]+$smonth[10]+$smonth[11],0)."</b></td>";
			echo "      </tr>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->

	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>

	<?php
        if ($_GET['itype'] == "m") {
            $i_type = "(เดือน ".$_GET['ym'].")";
            $i_get_where = "AND DATE_FORMAT(e.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        } else {
            $i_type = "(แสดงข้อมูลจากลิงค์ตารางข้อมูล)";
            $i_get_where = "AND DATE_FORMAT(e.vstdate,'%Y-%m') = '".$_GET['ym']."' ";
        }
    ?>

	<div class="tab-pane <?php echo $tab_active3;?>" id="tab_3-3">
			<div class="panel-heading">
				<b>รายชื่อผู้ป่วยอุบัติเหตุและฉุกเฉิน </b> ปีงบประมาณ <?php echo $myeare+543; ?> <?php echo $i_type; ?>
			</div>
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
					<thead>
					  <tr class="success">
						<th class='text-center'><b>วันที่รับบริการ</b></th>
						<th class='text-center'><b>HN/AN</b></th>
						<th class='text-center'><b>ชื่อ-นามสกุล</b></th>
						<th class='text-center'><b>อายุ</b></th>
						<th class='text-center'><b>ที่อยู่</b></th>
						<th class='text-center'><b>สิทธิรักษาพยาบาล</b></th>
						<th class='text-center'><b>Emergency type</b></th>
						<th class='text-center'><b>การวินิจฉัย</b></th>
						<th class='text-center'><b>ค่าใช้จ่าย</b></th>
					  </tr>
					</thead>
				  <tbody>
<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT e.vstdate,v.hn,p.pname,p.fname,p.lname,v.age_y,p.addrpart,p.road,p.moopart,t.full_name
			,e.er_pt_type,e.er_doctor,e.er_emergency_type,e.er_emergency_level_id,e.er_list,et.name AS erpttype
			,v.pdx,i.name AS dxname,v.pttype,pt.name AS pttypename,v.income
			FROM er_regist e
			LEFT OUTER JOIN vn_stat v ON v.vn = e.vn
			LEFT OUTER JOIN patient p ON p.hn = v.hn
			LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart)
			LEFT OUTER JOIN pttype pt ON pt.pttype = v.pttype
			LEFT OUTER JOIN icd101 i ON i.`code` = v.pdx
			LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = e.er_pt_type
			WHERE e.er_pt_type IN (1,2,3,4,5) $i_get_where ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo "<tr>";
			echo "<td>".$row[vstdate]."</td>";
			echo "<td>".$row[hn]."</td>";
			echo "<td>".$row[pname]."".$row[fname]."  ".$row[lname]."</td>";
			echo "<td>".$row[age_y]."</td>";
			echo "<td>".$row[addrpart]." ".$row[road]." ม.".$row[moopart]." ".$row[full_name]."</td>";
			echo "<td>".$row[pttype]." ".$row[pttypename]."</td>";
			echo "<td>".$row[erpttype]."</td>";
			echo "<td>".$row[pdx]." ".$row[dxname]."</td>";
			echo "<td>".$row[income]."</td>";
			echo "</tr>";
		}
		
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
	
	?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

	<div class="tab-pane <?php echo $tab_active9;?>" id="tab_9-9">
            <!-- /.box-header -->
            <div class="box-body">
			<div class="row">
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">ความหมาย</h3>
						</div>
						<div class="box-footer text-black">
							<p></p>
						</div>
					</div>
				</div>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->
	<?php if ($login_ok == 1) { ?>
				<div class="col-sm-6">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-bookmark"></i><h3 class="box-title">คำสั่ง SQL</h3>
						</div>
						<div class="box-footer text-black">
							<p>SELECT er.er_pt_type AS ertype,et.name AS typename,COUNT(*) AS total FROM er_regist er LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = er.er_pt_type WHERE er.vstdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' GROUP BY er.er_pt_type ORDER BY er.er_pt_type ASC</p>
						</div>
					</div>
				</div>
	<?php } else { }?>
	<!-- สำหรับสมาชิกที่ลงทะเบียน MIS -->

			</div>

			</div>
            <!-- /.box-body -->
			  </div>
              <!-- /.tab-pane -->



            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>


