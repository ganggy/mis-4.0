<?php

	try {
		include '_cfg_mis40db.php';

          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab1' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab1_name = $row['sys_show_name'];
            $tab1_value = $row['sys_value'];
            $tab1_status = $row['sys_status'];
            $tab1_include = $row['sys_include'];
          }
          
          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab2' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab2_name = $row['sys_show_name'];
            $tab2_value = $row['sys_value'];
            $tab2_status = $row['sys_status'];
            $tab2_include = $row['sys_include'];
          }
          
          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab3' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab3_name = $row['sys_show_name'];
            $tab3_value = $row['sys_value'];
            $tab3_status = $row['sys_status'];
            $tab3_include = $row['sys_include'];
          }

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

          <!-- Custom tabs (Charts with tabs)-->
          <div class="nav-tabs-custom">
            <!-- Tabs within a box -->
            <ul class="nav nav-tabs pull-right">
              <li class="active bg-danger"><a href="#container-tab1" data-toggle="tab"><?php echo $tab1_name ;?></a></li>
              <?php if($tab2_status == 'Y'){;?><li><a href="#container-tab2" data-toggle="tab"><?php echo $tab2_name ;?></a></li><?php } ?>
              <?php if($tab3_status == 'Y'){;?><li><a href="#container-tab3" data-toggle="tab"><?php echo $tab3_name ;?></a></li><?php } ?>
              <li class="pull-left header"><i class="fa fa-line-chart"></i> สถานการณ์โรคที่ต้องเฝ้าระวัง</li>
            </ul>
            <div class="tab-content no-padding">
              <!-- Morris chart - Sales -->
              <div class="chart tab-pane active" id="container-tab1" style="position: relative; height: 400px;"></div>
              <?php if($tab2_status == 'Y'){;?><div class="chart tab-pane" id="container-tab2" style="position: relative; height: 400px;"></div><?php } ?>
              <?php if($tab3_status == 'Y'){;?><div class="chart tab-pane" id="container-tab3" style="position: relative; height: 400px;"></div><?php } ?>
            </div>
          </div>
          <!-- /.nav-tabs-custom -->

<?php

$monthx = array(); // ตัวแปรแกน x
$median = array(); //ตัวแปรแกน y
$y2557 = array(); //ตัวแปรแกน y
$y2558 = array(); //ตัวแปรแกน y
$y2559 = array(); //ตัวแปรแกน y
$y2560 = array(); //ตัวแปรแกน y
$y2561 = array(); //ตัวแปรแกน y
$y2562 = array(); //ตัวแปรแกน y
try {
    include '_cfg_mis40db.php';
    
    $sql = "SELECT '01 มกราคม' AS monthname
,SUM(IF(year = 'median',m01,0)) AS median
,SUM(IF(year = '2556',m01,0)) AS y2556
,SUM(IF(year = '2557',m01,0)) AS y2557
,SUM(IF(year = '2558',m01,0)) AS y2558
,SUM(IF(year = '2559',m01,0)) AS y2559
,SUM(IF(year = '2560',m01,0)) AS y2560
,SUM(IF(year = '2561',m01,0)) AS y2561
,SUM(IF(year = '2562',m01,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '02 กุมภาพันธ์' AS monthname
,SUM(IF(year = 'median',m02,0)) AS median
,SUM(IF(year = '2556',m02,0)) AS y2556
,SUM(IF(year = '2557',m02,0)) AS y2557
,SUM(IF(year = '2558',m02,0)) AS y2558
,SUM(IF(year = '2559',m02,0)) AS y2559
,SUM(IF(year = '2560',m02,0)) AS y2560
,SUM(IF(year = '2561',m02,0)) AS y2561
,SUM(IF(year = '2562',m02,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '03 มีนาคม' AS monthname
,SUM(IF(year = 'median',m03,0)) AS median
,SUM(IF(year = '2556',m03,0)) AS y2556
,SUM(IF(year = '2557',m03,0)) AS y2557
,SUM(IF(year = '2558',m03,0)) AS y2558
,SUM(IF(year = '2559',m03,0)) AS y2559
,SUM(IF(year = '2560',m03,0)) AS y2560
,SUM(IF(year = '2561',m03,0)) AS y2561
,SUM(IF(year = '2562',m03,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '04 เมษายน' AS monthname
,SUM(IF(year = 'median',m04,0)) AS median
,SUM(IF(year = '2556',m04,0)) AS y2556
,SUM(IF(year = '2557',m04,0)) AS y2557
,SUM(IF(year = '2558',m04,0)) AS y2558
,SUM(IF(year = '2559',m04,0)) AS y2559
,SUM(IF(year = '2560',m04,0)) AS y2560
,SUM(IF(year = '2561',m04,0)) AS y2561
,SUM(IF(year = '2562',m04,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '05 พฤษภาคม' AS monthname
,SUM(IF(year = 'median',m05,0)) AS median
,SUM(IF(year = '2556',m05,0)) AS y2556
,SUM(IF(year = '2557',m05,0)) AS y2557
,SUM(IF(year = '2558',m05,0)) AS y2558
,SUM(IF(year = '2559',m05,0)) AS y2559
,SUM(IF(year = '2560',m05,0)) AS y2560
,SUM(IF(year = '2561',m05,0)) AS y2561
,SUM(IF(year = '2562',m05,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '06 มิถุนายน' AS monthname
,SUM(IF(year = 'median',m06,0)) AS median
,SUM(IF(year = '2556',m06,0)) AS y2556
,SUM(IF(year = '2557',m06,0)) AS y2557
,SUM(IF(year = '2558',m06,0)) AS y2558
,SUM(IF(year = '2559',m06,0)) AS y2559
,SUM(IF(year = '2560',m06,0)) AS y2560
,SUM(IF(year = '2561',m06,0)) AS y2561
,SUM(IF(year = '2562',m06,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '07 กรกฎาคม' AS monthname
,SUM(IF(year = 'median',m07,0)) AS median
,SUM(IF(year = '2556',m07,0)) AS y2556
,SUM(IF(year = '2557',m07,0)) AS y2557
,SUM(IF(year = '2558',m07,0)) AS y2558
,SUM(IF(year = '2559',m07,0)) AS y2559
,SUM(IF(year = '2560',m07,0)) AS y2560
,SUM(IF(year = '2561',m07,0)) AS y2561
,SUM(IF(year = '2562',m07,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '08 สิงหาคม' AS monthname
,SUM(IF(year = 'median',m08,0)) AS median
,SUM(IF(year = '2556',m08,0)) AS y2556
,SUM(IF(year = '2557',m08,0)) AS y2557
,SUM(IF(year = '2558',m08,0)) AS y2558
,SUM(IF(year = '2559',m08,0)) AS y2559
,SUM(IF(year = '2560',m08,0)) AS y2560
,SUM(IF(year = '2561',m08,0)) AS y2561
,SUM(IF(year = '2562',m08,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '09 กันยายน' AS monthname
,SUM(IF(year = 'median',m09,0)) AS median
,SUM(IF(year = '2556',m09,0)) AS y2556
,SUM(IF(year = '2557',m09,0)) AS y2557
,SUM(IF(year = '2558',m09,0)) AS y2558
,SUM(IF(year = '2559',m09,0)) AS y2559
,SUM(IF(year = '2560',m09,0)) AS y2560
,SUM(IF(year = '2561',m09,0)) AS y2561
,SUM(IF(year = '2562',m09,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '10 ตุลาคม' AS monthname
,SUM(IF(year = 'median',m10,0)) AS median
,SUM(IF(year = '2556',m10,0)) AS y2556
,SUM(IF(year = '2557',m10,0)) AS y2557
,SUM(IF(year = '2558',m10,0)) AS y2558
,SUM(IF(year = '2559',m10,0)) AS y2559
,SUM(IF(year = '2560',m10,0)) AS y2560
,SUM(IF(year = '2561',m10,0)) AS y2561
,SUM(IF(year = '2562',m10,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '11 พฤศจิกายน' AS monthname
,SUM(IF(year = 'median',m11,0)) AS median
,SUM(IF(year = '2556',m11,0)) AS y2556
,SUM(IF(year = '2557',m11,0)) AS y2557
,SUM(IF(year = '2558',m11,0)) AS y2558
,SUM(IF(year = '2559',m11,0)) AS y2559
,SUM(IF(year = '2560',m11,0)) AS y2560
,SUM(IF(year = '2561',m11,0)) AS y2561
,SUM(IF(year = '2562',m11,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '12 ธันวาคม' AS monthname
,SUM(IF(year = 'median',m12,0)) AS median
,SUM(IF(year = '2556',m12,0)) AS y2556
,SUM(IF(year = '2557',m12,0)) AS y2557
,SUM(IF(year = '2558',m12,0)) AS y2558
,SUM(IF(year = '2559',m12,0)) AS y2559
,SUM(IF(year = '2560',m12,0)) AS y2560
,SUM(IF(year = '2561',m12,0)) AS y2561
,SUM(IF(year = '2562',m12,0)) AS y2562
FROM rep_506_dhf ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($median,$row[median]);
           array_push($y2557,$row[y2557]);
           array_push($y2558,$row[y2558]);
           array_push($y2559,$row[y2559]);
           array_push($y2560,$row[y2560]);
           array_push($y2561,$row[y2561]);
           array_push($y2562,$row[y2562]);
           array_push($monthx,$row[month]);
       }
       
   } catch (PDOException $e) {
       echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
   }
   
?>

<script type="text/javascript">
Highcharts.chart('container-tab1', {
   chart: {
       type: 'spline'
   },
   title: {
       text: ''
   },
   subtitle: {
       text: 'จำนวนผู้ป่วยโรคไข้เลือดออกของประชากร <?= $amp_name." ".$chw_name;?>'
   },
   xAxis: {
       categories: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน','กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
   },
   yAxis: {
       title: {
           text: 'จำนวนผู้ป่วย (ราย)'
       }
   },
   tooltip: {
       crosshairs: true,
       shared: true
   },
   plotOptions: {
       line: {
           dataLabels: {
               enabled: true
           },
           marker: {
               radius: 4,
               lineColor: '#666666',
               lineWidth: 1
           },
           enableMouseTracking: false
       }
   },
   series: [{
       name: 'Medien',
       color: '#ff9900',
       type: 'areaspline',
       marker: {
           symbol: 'square'
       },
       data: [<?= implode(',', $median) ?>]
   }, {
       name: 'ปี 2557',
       data: [<?= implode(',', $y2557) ?>]
   }, {
       name: 'ปี 2558',
       data: [<?= implode(',', $y2558) ?>]
   }, {
       name: 'ปี 2559',
       data: [<?= implode(',', $y2559) ?>]
   }, {
       name: 'ปี 2560',
       data: [<?= implode(',', $y2560) ?>]
   }, {
       name: 'ปี 2561',
       data: [<?= implode(',', $y2561) ?>]
   }, {
       name: 'ปี 2562',
       data: [<?= implode(',', $y2562) ?>]
   }]
});
</script>

<?php
   $tab3a00 = array();

   $tab3j00 = array();
   $tab3j00month = array();
   $tab3j09 = array();
   $tab3j09month = array();
   $tab3b30 = array();
   $tab3b30month = array();
   $tab3b08 = array();
   $tab3b08month = array();
   try {
       include '_cfg_hos.php';

       $sql = "SELECT CONCAT('[`',vstdate,'`,',COUNT(*),']') AS disease_arr
       FROM ovstdiag 
       WHERE vstdate BETWEEN SUBDATE(NOW(),INTERVAL 365 DAY) AND DATE_FORMAT(NOW(),'%Y-%m-%d') 
       AND (icd10 BETWEEN 'A040' AND 'A049' OR icd10 BETWEEN 'A090' AND 'A090' OR icd10 BETWEEN 'A099' AND 'A099' OR icd10 BETWEEN 'A080' 
       AND 'A085' OR icd10 BETWEEN 'A020' AND 'A020')
       GROUP BY vstdate ORDER BY vstdate ASC ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($tab3a00,$row['disease_arr']);
       }

       $sql = "SELECT DATE_FORMAT(vstdate,'%m') AS mmonth,COUNT(*) AS disease_arr
       FROM ovstdiag 
       WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-12-31')
       AND (icd10 BETWEEN 'J100' AND 'J101' OR icd10 BETWEEN 'J108' AND 'J108' OR icd10 BETWEEN 'J110' AND 'J111' OR icd10 BETWEEN 'J118' AND 'J118')
       GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($tab3j00month,$row['mmonth']);
           array_push($tab3j00,$row['disease_arr']);
       }

       $sql = "SELECT DATE_FORMAT(vstdate,'%m') AS mmonth,COUNT(*) AS disease_arr
       FROM ovstdiag 
       WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-12-31')
       AND (icd10 BETWEEN 'J09' AND 'J09')
       GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($tab3j09month,$row['mmonth']);
           array_push($tab3j09,$row['disease_arr']);
       }

       $sql = "SELECT DATE_FORMAT(vstdate,'%m') AS mmonth,COUNT(*) AS disease_arr
       FROM ovstdiag 
       WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-12-31')
       AND (icd10 BETWEEN 'B300' AND 'B303' OR icd10 BETWEEN 'B308' AND 'B309')
       GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($tab3b30month,$row['mmonth']);
           array_push($tab3b30,$row['disease_arr']);
       }

       $sql = "SELECT DATE_FORMAT(vstdate,'%m') AS mmonth,COUNT(*) AS disease_arr
       FROM ovstdiag 
       WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-12-31')
       AND (icd10 BETWEEN 'B084' AND 'B085')
       GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY DATE_FORMAT(vstdate,'%Y-%m') ASC ";
       $query = $myPDO->query($sql);
       foreach($query as $row) {
           array_push($tab3b08month,$row['mmonth']);
           array_push($tab3b08,$row['disease_arr']);
       }

   } catch (PDOException $e) {
       echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
   }

?>

<script type="text/javascript">

       Highcharts.chart('container-tab2', {
           chart: {
               zoomType: 'x'
           },
           title: {
               text: ''
           },
           subtitle: {
               text: document.ontouchstart === undefined ?
                       '(คลิกเลือกเพื่อขยาย)' : 'Pinch the chart to zoom in'
           },
           xAxis: {
               type: 'date'
           },
           yAxis: {
               title: {
                   text: 'จำนวนผู้ป่วย(คน)'
               }
           },
           legend: {
               enabled: false
           },
           plotOptions: {
               area: {
                   fillColor: {
                       linearGradient: {
                           x1: 0,
                           y1: 0,
                           x2: 0,
                           y2: 1
                       },
                       stops: [
                           [0, Highcharts.getOptions().colors[0]],
                           [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                       ]
                   },
                   marker: {
                       radius: 2
                   },
                   lineWidth: 1,
                   states: {
                       hover: {
                           lineWidth: 1
                       }
                   },
                   threshold: null
               }
           },

           series: [{
               type: 'area',
               name: 'จำนวนผู้ป่วย(คน)',
               data: [<?= implode(',', $tab3a00)?>]
           }]
       });

</script>

<script type="text/javascript">
Highcharts.chart('container-tab3', {
   chart: {
       type: 'spline'
   },
   title: {
       text: ''
   },
   subtitle: {
       text: '(ผลวินิจฉัยจาก <?= $hos_name;?>)'
   },
   xAxis: {
       categories: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน','กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
   },
   yAxis: {
       title: {
           text: 'จำนวนผู้ป่วย(ราย)'
       }
   },
   tooltip: {
       crosshairs: true,
       shared: true
   },
   plotOptions: {
       line: {
           dataLabels: {
               enabled: true
           },
           marker: {
               radius: 4,
               lineColor: '#666666',
               lineWidth: 1
           },
           enableMouseTracking: false
       }
   },
   series: [{
       name: 'ไข้ไวัดนก',
       data: [<?= implode(',', $tab3j09) ?>]
   }, {
       name: 'ไข้หวัดใหญ่',
       data: [<?= implode(',', $tab3j00) ?>]
   }, {
       name: 'ตาแดงจากไวรัส',
       data: [<?= implode(',', $tab3b30) ?>]
   }, {
       name: 'มือเท้าปาก',
       data: [<?= implode(',', $tab3b08) ?>]
   }]
});
</script>
