          <!-- /. box -->
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">P ด้านกระบวนการภายใน</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li><a href="?main=kpimanage&bsc=P&m=new"><i class="fa fa-circle-o text-yellow"></i> สร้างตัวชี้วัดใหม่</a></li>
                <li><a href="?main=kpimanage&bsc=P"><i class="fa fa-circle-o text-blue"></i> ดูตัวชี้วัด ด้านกระบวนการภายใน</a></li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
