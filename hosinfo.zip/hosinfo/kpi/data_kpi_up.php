<?php
if ($mis_user_level >= 3 OR $_POST['i_kpi_owner'] == $ok_login_user) {
?>

<!-- // Upload file -->
<?php
$target_dir = "kpi/files/";
$fndate = date("YmdHis");
$target_file = $target_dir.$_POST['kpi_code']."_".$fndate."-".basename($_FILES["fileToUpload"]["name"]);
$target_file_name = basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit_data_kpi"])) {
	$checkfiletype= strrchr($target_file_name,".");
    if($checkfiletype == ".pdf") {
        echo "File is an image - " . $checkfiletype . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image. " . $checkfiletype . ".";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5120000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
		$firename_kpi_template = $_POST['kpi_code']."_".$fndate."-".basename($_FILES["fileToUpload"]["name"]);
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
<!-- Upload file // -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php

if ($_POST['submit_data_kpi'] == "create") {

$last_update = date("Y-m-d H:i:s");

try {
	include "_cfg_mis40db.php";
	$sql = "INSERT INTO kpi (kpi_dpid,kpi_year,bsc_code,kpi_code,qp_code,kpi_number,kpi_name_t,kpi_name_e,kpi_meaning,kpi_object,kpi_cal_a,kpi_cal_b,kpi_cal_c,kpi_source,kpi_unit
	,kpi_translate,kpi_duration_type,kpi_baseline1,kpi_baseline2,kpi_baseline3,kpi_weight,kpi_target_type,kpi_targeta,kpi_targetb,kpi_target,kpi_result,kpi_owner,kpi_input_type,kpi_type,kpi_sql1,kpi_sql2
	,kpi_sql3,kpi_sql4,kpi_view,kpi_status,kpi_template_file,kpi_last_update,kpi_user_update)
	VALUES ('".$_POST['kpi_dpid']."','".$_POST['kpi_year']."','".$_POST['bsc_code']."','".$_POST['kpi_code']."','".$_POST['qp_code']."','".$_POST['kpi_number']."','".$_POST['kpi_name_t']."'
	,'".$_POST['kpi_name_e']."','".$_POST['kpi_meaning']."','".$_POST['kpi_object']."','".$_POST['kpi_cal_a']."','".$_POST['kpi_cal_b']."','".$_POST['kpi_cal_c']."','".$_POST['kpi_source']."'
	,'".$_POST['kpi_unit']."','".$_POST['kpi_translate']."','".$_POST['kpi_duration_type']."','".$_POST['kpi_baseline1']."','".$_POST['kpi_baseline2']."','".$_POST['kpi_baseline3']."'
	,'".$_POST['kpi_weight']."','".$_POST['kpi_target_type']."','".$_POST['kpi_targeta']."','".$_POST['kpi_targetb']."','".$_POST['kpi_target']."','".$_POST['kpi_result']."','".$_POST['kpi_owner']."','".$_POST['kpi_input_type']."'
	,'".$_POST['kpi_type']."','".$_POST['kpi_sql1']."','".$_POST['kpi_sql2']."','".$_POST['kpi_sql3']."','".$_POST['kpi_sql4']."','3','1','".$firename_kpi_template."'
	,'".$last_update."','".$_POST['kpi_user_update']."') ";

	if ($myPDO->query($sql)) {
		echo "OK";
	} else {
		echo "ERROR!!!";
	}

	$sql2 = "INSERT INTO kpi_data (data_year,kpi_code) VALUES ('".$_POST['kpi_year']."','".$_POST['kpi_code']."') ";

	if ($myPDO->query($sql2)) {
		echo "<script type= 'text/javascript'>alert('เพิ่มตัวชี้วัดเรียบร้อยแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}


//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>


<?php

if ($_POST['submit_data_kpi'] == "update") {

$last_update = date("Y-m-d H:i:s");

if ($firename_kpi_template == "") {
	$f_kpi_template = $_POST['kpi_template_file'];
} else {
	$f_kpi_template = $firename_kpi_template;
}

try {
	include "_cfg_mis40db.php";
	$sql = "UPDATE kpi SET kpi_name_t='".$_POST['kpi_name_t']."',kpi_name_e='".$_POST['kpi_name_e']."',
	kpi_meaning='".$_POST['kpi_meaning']."',kpi_object='".$_POST['kpi_object']."',kpi_cal_a='".$_POST['kpi_cal_a']."',
	kpi_cal_b='".$_POST['kpi_cal_b']."',kpi_source='".$_POST['kpi_source']."',kpi_unit='".$_POST['kpi_unit']."',
	kpi_translate='".$_POST['kpi_translate']."',kpi_duration_type='".$_POST['kpi_duration_type']."',
	kpi_baseline1='".$_POST['kpi_baseline1']."',kpi_baseline2='".$_POST['kpi_baseline2']."',
	kpi_baseline3='".$_POST['kpi_baseline3']."',kpi_weight='".$_POST['kpi_weight']."',
	kpi_target_type='".$_POST['kpi_target_type']."',kpi_targeta='".$_POST['kpi_targeta']."',
	kpi_targetb='".$_POST['kpi_targetb']."',kpi_target='".$_POST['kpi_target']."',
	kpi_owner='".$_POST['kpi_owner']."',kpi_input_type='".$_POST['kpi_input_type']."',
	kpi_type='".$_POST['kpi_type']."',kpi_sql1='".$_POST['kpi_sql1']."',kpi_sql2='".$_POST['kpi_sql2']."',
	kpi_sql3='".$_POST['kpi_sql3']."',kpi_sql4='".$_POST['kpi_sql4']."',kpi_view='".$_POST['kpi_view']."',
	kpi_status='".$_POST['kpi_status']."',kpi_template_file='".$f_kpi_template."',
	kpi_last_update='".$last_update."',kpi_user_update='".$_POST['kpi_user_update']."' 
	WHERE kpi_id='".$_POST['kpi_id']."' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลสำเร็จ');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<?php

if ($_POST['submit_data_kpi'] == "delete") {

$kpi_id = $_POST['kpi_id'];
$kpi_code = $_POST['kpi_code'];

try {
	include "_cfg_mis40db.php";
	$sql = "DELETE FROM kpi WHERE kpi_id='$kpi_id'; DELETE FROM kpi_data WHERE kpi_code='$kpi_code' ; ";
	$myPDO->exec($sql);
		echo "<script type= 'text/javascript'>alert('ลบข้อมูลเรียบร้อยแล้ว');</script>";
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<?php

if ($_POST['submit_result'] == "submit_result") {

$last_update = date("Y-m-d H:i:s");

$i_data_approved = $_POST['data_iy'].$_POST['data_it1'].$_POST['data_it2'].$_POST['data_it3'].$_POST['data_it4'].$_POST['data_im1'].$_POST['data_im2'].$_POST['data_im3'].$_POST['data_im4'].$_POST['data_im5'].$_POST['data_im6'].$_POST['data_im7'].$_POST['data_im8'].$_POST['data_im9'].$_POST['data_im10'].$_POST['data_im11'].$_POST['data_im12'];

if ($i_data_approved == $_POST['i_data_appr']) {
	$data_approve_update = $_POST['i_data_appr_update'];
	$a_ok_login_user = $_POST['i_data_appr_user'];
} else {
	$data_approve_update = date("Y-m-d H:i:s");
	$a_ok_login_user = $ok_login_user;
}

if ($mis_user_level >= 3) {
	$data_field = ",data_approve_user='".$a_ok_login_user."',data_approve_update='".$data_approve_update."',data_approved='".$i_data_approved."' ";
} else {
	$data_field = " ";
}

try {
	include "_cfg_mis40db.php";
	$sql = "UPDATE kpi_data SET data_m1='".$_POST['data_m1']."',data_m2='".$_POST['data_m2']."',data_m3='".$_POST['data_m3']."',data_m4='".$_POST['data_m4']."',data_m5='".$_POST['data_m5']."',data_m6='".$_POST['data_m6']."',data_m7='".$_POST['data_m7']."',data_m8='".$_POST['data_m8']."',data_m9='".$_POST['data_m9']."',data_m10='".$_POST['data_m10']."',data_m11='".$_POST['data_m11']."',data_m12='".$_POST['data_m12']."',data_t1='".$_POST['data_t1']."',data_t2='".$_POST['data_t2']."',data_t3='".$_POST['data_t3']."',data_t4='".$_POST['data_t4']."',data_y='".$_POST['data_y']."',data_last_update='".$last_update."',data_user_update='".$ok_login_user."' ".$data_field." WHERE data_id='".$_POST['data_id']."' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงผลงานสำเร็จ');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL="?main=kpimanage">
</head>
<body>
</body>
</html>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505own.php';} ?>
