<?php
if ($mis_user_level >= 4) {
?>

		<div class="col-md-9">

		  <!-- general form elements disabled -->
          <div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">สร้างตัวชี้วัดใหม่</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form role="form">
                <!-- text input -->
                <div class="form-group">
                  <label>KPI Code</label>
					<div class="row">
					  <div class="col-xs-1">ID:<input type="text" class="form-control" name="kpi_id" placeholder="id" disabled></div>
					  <div class="col-xs-4">หน่วยงาน:<input type="text" class="form-control" name="kpi_dpid" placeholder="dpid" disabled></div>
					  <div class="col-xs-2">รหัสตัวชี้วัด:<input type="text" class="form-control" name="kpi_code" placeholder="code" disabled></div>
					  <div class="col-xs-5">กำหนดผู้รับผิดชอบ:
						  <select class="form-control">
							<option>option 1</option>
							<option>option 2</option>
							<option>option 3</option>
							<option>option 4</option>
							<option>option 5</option>
						  </select>
					  </div>
					</div>
                </div>

                <div class="form-group has-error">
                  <label class="control-label" for="kpi_name_t"><i class="fa fa-check"></i> ชื่อตัวชี้วัด (ภาษาไทย)</label>
                  <input type="text" name="kpi_name_t" class="form-control" id="kpi_name_t" placeholder="ชื่อตัวชี้วัด ภาษาไทย">
                  <span class="help-block">(* ต้องกรอกข้อมูลให้ครบถ้วน *)</span>
                </div>
				<div class="form-group">
                  <label> ชื่อตัวชี้วัด (English)</label>
                  <input type="text" name="kpi_name_e" class="form-control" placeholder="ชื่อตัวชี้วัด ภาษาอังกฤษ">
                </div>

                <div class="form-group has-success">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> คำอธิบายความหมายของตัวชี้วัด</label>
                  <textarea class="form-control" name="kpi_meaning" rows="3" placeholder="คำอธิบายความหมายของตัวชี้วัด"></textarea>
                </div>
				<div class="form-group">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> วัตถุประสงค์</label>
                  <input type="text" name="kpi_object" class="form-control" placeholder="วัตถุประสงค์">
                </div>
                <div class="form-group">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> สูตรคำนวณ</label>
					<div class="row">
					  <div class="col-xs-6">A ตัวตั้ง (ผลงาน)
					  <textarea class="form-control" name="kpi_cal_a" rows="3" placeholder="ตัวตั้ง"></textarea></div>
					  <div class="col-xs-6">B ตัวหาร (เป้าหมาย)
					  <textarea class="form-control" name="kpi_cal_b" rows="3" placeholder="ตัวหาร"></textarea></div>
					</div>
                </div>
				<div class="form-group">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> แหล่งที่มาของข้อมูล</label>
                  <input type="text" name="kpi_source" class="form-control" placeholder="แหล่งที่มาของข้อมูล">
                </div>
				<div class="form-group">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> หน่วยวัด</label>
                  <input type="text" name="kpi_unit" class="form-control" placeholder="หน่วยวัด">
                </div>
				<div class="form-group">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> การแปรผล</label>
                  <input type="text" name="kpi_translate" class="form-control" placeholder="การแปรผล">
                </div>
				<div class="form-group has-success">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> การได้มาของข้อมูล</label>
				  <br><input type="radio" name="kpi_input_type" value="1" class="minimal" checked> ประมวลผล
				  <br><input type="radio" name="kpi_input_type" value="2"  class="minimal"> Key In
				</div>
				<div class="form-group has-success">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> ระยะเวลารายงาน</label>
				  <br><input type="radio" name="kpi_duration_type" value="1" class="minimal"> รายปี
				  <br><input type="radio" name="kpi_duration_type" value="2"  class="minimal"> รายงวด
				  <br><input type="radio" name="kpi_duration_type" value="3"  class="minimal" checked> รายเดือน
				  <br><input type="radio" name="kpi_duration_type" value="4"  class="minimal"> รายสัปดาห์
				</div>

                <div class="form-group has-warning">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> Baseline</label> (3 ปีย้อนหลัง)
					<div class="row">
					  <div class="col-xs-2">ปี 2560<input type="text" class="form-control" name="kpi_"></div>
					  <div class="col-xs-2">ปี 2559<input type="text" class="form-control" name="kpi_"></div>
					  <div class="col-xs-2">ปี 2558<input type="text" class="form-control" name="kpi_"></div>
					</div>
                </div>

                <div class="form-group has-warning">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> เป้าหมาย</label> (ตามหน่วยวัด)
					<div class="row">
					  <div class="col-xs-2"><input type="text" class="form-control" name="kpi_"></div>
					</div>
                </div>
                <div class="form-group has-warning">
                  <label class="control-label" for="inputSuccess"><i class="fa fa-check"></i> น้ำหนัก</label>
					<div class="row">
					  <div class="col-xs-2"><input type="text" class="form-control" name="kpi_"></div>
					</div>
                </div>
                  <span class="help-block">(ผลรวมทุกตัวชี้วัดต้องได้ 100 หรือถ้าหากกำหนดเป็นคะแนน ระบบจะคำนวนสัดส่วนออกมาให้ได้ผลรวม 100%)</span>

              </form>
            </div>
            <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default"> ยกเลิก </button> -->
                <button type="submit" class="btn btn-info pull-right"> สร้างตัวชี้วัดใหม่ </button>
              </div>
              <!-- /.box-footer -->
          </div>


		
		</div>

<?php } else {include 'error505.php';} ?>
