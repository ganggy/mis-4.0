<?php
if ($mis_user_level >= 4) {
	$dpart_adm = " ";
} else {
	$dpart_adm = "WHERE dpid = ".$mis_u_m_depart."";
}

if ($mis_user_level >= 1) {

?>

		<div class="col-md-9">

		  <!-- general form elements disabled -->
          <div class="box box-success">
            <div class="box-header with-border bg-success">
              <h3 class="box-title"><i class="fa fa-edit"></i> แก้ไขชี้วัด --> <?php echo $bsc_menu_name;?></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">


<?php if ($_GET['dtype'] == "1") {;?>
        <form action="?main=kpimanage&m=up" method="POST">
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?></font>
              </div>
			  <div class="modal-body">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="form-group"><label>ปี </label><input id="data_y" type="text" name="data_y" value="<?php echo $data['data_y'];?>" <?php echo $k_data_y_approved;?>><label><input type="checkbox" name="data_iy" value="y" <?php echo $checked_y;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			</div>
			  </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-success pull-right" name="submit_result" value="submit_result"> บันทึก </button>
              </div>
		</form>
<?php } else if ($_GET['dtype'] == "2") {;?>
        <form action="?main=kpimanage&m=up" method="POST">
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?></font>
              </div>
              <div class="modal-body">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส1</label><input type="text" name="data_t1" value="<?php echo $data['data_t1'];?>" <?php echo $k_data_t1_approved;?>><label><input type="checkbox" name="data_it1" value="1" <?php echo $checked_t1;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส2</label><input type="text" name="data_t2" value="<?php echo $data['data_t2'];?>" <?php echo $k_data_t2_approved;?>><label><input type="checkbox" name="data_it2" value="2" <?php echo $checked_t2;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส3</label><input type="text" name="data_t3" value="<?php echo $data['data_t3'];?>" <?php echo $k_data_t3_approved;?>><label><input type="checkbox" name="data_it3" value="3" <?php echo $checked_t3;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส4</label><input type="text" name="data_t4" value="<?php echo $data['data_t4'];?>" <?php echo $k_data_t4_approved;?>><label><input type="checkbox" name="data_it4" value="4" <?php echo $checked_t4;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			</div>
              </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-info pull-right" name="submit_result" value="submit_result"> บันทึก </button>
			  </div>
		</form>
<?php } else if ($_GET['dtype'] == "3") {;?>
        <form action="?main=kpimanage&m=up" method="POST">
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?></font>
              </div>
              <div class="modal-body">
			<div class="row">
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ม.ค.</label><input type="text" name="data_m1" value="<?php echo $data['data_m1'];?>" <?php echo $k_data_m1_approved;?>><label><input type="checkbox" name="data_im1" value="a" <?php echo $checked_m1;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.พ.</label><input type="text" name="data_m2" value="<?php echo $data['data_m2'];?>" <?php echo $k_data_m2_approved;?>><label><input type="checkbox" name="data_im2" value="b" <?php echo $checked_m2;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>มี.ค.</label><input type="text" name="data_m3" value="<?php echo $data['data_m3'];?>" <?php echo $k_data_m3_approved;?>><label><input type="checkbox" name="data_im3" value="c" <?php echo $checked_m3;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>เม.ย.</label><input type="text" name="data_m4" value="<?php echo $data['data_m4'];?>" <?php echo $k_data_m4_approved;?>><label><input type="checkbox" name="data_im4" value="d" <?php echo $checked_m4;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>พ.ค.</label><input type="text" name="data_m5" value="<?php echo $data['data_m5'];?>" <?php echo $k_data_m5_approved;?>><label><input type="checkbox" name="data_im5" value="e" <?php echo $checked_m5;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>มิ.ย.</label><input type="text" name="data_m6" value="<?php echo $data['data_m6'];?>" <?php echo $k_data_m6_approved;?>><label><input type="checkbox" name="data_im6" value="f" <?php echo $checked_m6;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.ค.</label><input type="text" name="data_m7" value="<?php echo $data['data_m7'];?>" <?php echo $k_data_m7_approved;?>><label><input type="checkbox" name="data_im7" value="g" <?php echo $checked_m7;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ส.ค.</label><input type="text" name="data_m8" value="<?php echo $data['data_m8'];?>" <?php echo $k_data_m8_approved;?>><label><input type="checkbox" name="data_im8" value="h" <?php echo $checked_m8;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.ย.</label><input type="text" name="data_m9" value="<?php echo $data['data_m9'];?>" <?php echo $k_data_m9_approved;?>><label><input type="checkbox" name="data_im9" value="i" <?php echo $checked_m9;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ต.ค.</label><input type="text" name="data_m10" value="<?php echo $data['data_m10'];?>" <?php echo $k_data_m10_approved;?>><label><input type="checkbox" name="data_im10" value="j" <?php echo $checked_m10;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>พ.ย.</label><input type="text" name="data_m11" value="<?php echo $data['data_m11'];?>" <?php echo $k_data_m11_approved;?>><label><input type="checkbox" name="data_im11" value="k" <?php echo $checked_m11;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ธ.ค.</label><input type="text" name="data_m12" value="<?php echo $data['data_m12'];?>" <?php echo $k_data_m12_approved;?>><label><input type="checkbox" name="data_im12" value="l" <?php echo $checked_m12;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			</div>
              </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-info pull-right" name="submit_result" value="submit_result"> บันทึก </button>
              </div>
		</form>
<?php } else {};?>

			</div>
		  </div>
		</div>


<?php } else {include 'error505.php';} ?>
