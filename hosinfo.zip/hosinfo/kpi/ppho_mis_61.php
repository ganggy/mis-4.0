<?php
if ($mis_user_level >= 1) {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        MIS สสจ.พิจิตร :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">MIS สสจ.พิจิตร</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box box-danger">
            <div class="box-header with-border">
              <h3 class="box-title">รายการตัวชี้วัด MIS สสจ.พิจิตร</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="DataTable" class="table table-bordered table-striped table-hover table-condensed">
                <thead>
                <tr>
                  <th>KPI/PI/RW</th>
                  <th>ตัวชี้วัด</th>
                  <th>kpi type</th>
                  <th>เกณฑ์เป้าหมาย</th>
                  <th>หน่วยนับ</th>
                  <th>เป้าหมาย</th>
                  <th>ผลงาน</th>
                  <th>ผู้รับผิดชอบ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_mis40db.php";
		// คำสั่ง SQL
		$sql = "SELECT * FROM moph_and_kp_target_description_2561 ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td>".$data['kp_report_no']."</td>";
			echo "<td>".$data['titletext']."</td>";
			echo "<td>".$data['kpi_type']."</td>";
			echo "<td>".$data['target_des']."</td>";
			echo "<td>".$data['targetunit']."</td>";
			echo "<td>".$data['target_value']."</td>";
			echo "<td></td>";
			echo "<td></td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
<!--
				<tfoot>
                <tr>
                  <th>รหัส</th>
                  <th>Login</th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง</th>
                  <th>หน่วยงาน</th>
                </tr>
                </tfoot>
  -->
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
