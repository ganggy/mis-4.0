  <script language="JavaScript">
	   var HttPRequest = true;

	   function doCallAjax(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	   function doCallAjax2(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage2").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage2').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	</script>

 <body>
<?php
if ($mis_user_level >= 4) {
	$kpi_count = " ";
} else {
	$kpi_count = " AND kpi_dpid = '".$mis_u_m_depart."' ";
}

if ($mis_user_level >= 1) {
?>

<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT SUM(IF(bsc_code = 'F',1,0)) AS count_f,SUM(IF(bsc_code = 'C',1,0)) AS count_c,SUM(IF(bsc_code = 'P'
,1,0)) AS count_p,SUM(IF(bsc_code = 'O',1,0)) AS count_o FROM kpi WHERE kpi_year = (SELECT yearprocess FROM sys_config) $kpi_count ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$f_count = $data['count_f'];
			$c_count = $data['count_c'];
			$p_count = $data['count_p'];
			$o_count = $data['count_o'];
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<!-- <body Onload="JavaScript:doCallAjax('data_kpi100_dash.php');"> -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ตัวชี้วัดหน่วยงาน
        <small>&nbsp;</small>
		<a href="?main=kpimanage" class="btn btn-success"><i class="fa fa-bars"></i> ตัวชี้วัดทั้งหมด</a>
		<?php if ($mis_user_level >= 4) { ?>
			<a href="?main=kpimanage&bsc=Q&m=new" class="btn btn-warning"><i class="fa fa-plus"></i> เพิ่มตัวชี้วัด</a>
		<?php } ?>
		
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ตัวชี้วัดหน่วยงาน</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
	  

<?php
if ($_GET['m'] == "new") {
	include 'kpi/data_kpi_new.php';
} else if ($_GET['m'] == "edit") {
	include 'kpi/data_kpi_edit.php';
} else if ($_GET['m'] == "up") {
	include 'kpi/data_kpi_up.php';
} else if ($_GET['m'] == "data") {
	include 'kpi/data_kpi_data.php';
} else {
	include 'kpi/data_kpi_list.php';
}
?>

        <!-- /.col -->
      </div>

	</section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>

 </body>
</html>
