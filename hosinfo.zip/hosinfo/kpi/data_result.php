              <table class="table table-bordered">
                <tr>
                  <th class='text-center'>เดือน</th>
                  <th class='text-center'>ม.ค.</th>
                  <th class='text-center'>ก.พ.</th>
                  <th class='text-center'>มี.ค.</th>
                  <th class='text-center'>เม.ย.</th>
                  <th class='text-center'>พ.ค.</th>
                  <th class='text-center'>มิ.ย.</th>
                  <th class='text-center'>ก.ค.</th>
                  <th class='text-center'>ส.ค.</th>
                  <th class='text-center'>ก.ย.</th>
                  <th class='text-center'>ต.ค.</th>
                  <th class='text-center'>พ.ย.</th>
                  <th class='text-center'>ธ.ค.</th>
                </tr>
                <tr>
                  <td class='text-center'>ผลงาน</td>
                  <td class='text-center'><?php echo $data['data_m1'];?></td>
                  <td class='text-center'><?php echo $data['data_m2'];?></td>
                  <td class='text-center'><?php echo $data['data_m3'];?></td>
                  <td class='text-center'><?php echo $data['data_m4'];?></td>
                  <td class='text-center'><?php echo $data['data_m5'];?></td>
                  <td class='text-center'><?php echo $data['data_m6'];?></td>
                  <td class='text-center'><?php echo $data['data_m7'];?></td>
                  <td class='text-center'><?php echo $data['data_m8'];?></td>
                  <td class='text-center'><?php echo $data['data_m9'];?></td>
                  <td class='text-center'><?php echo $data['data_m10'];?></td>
                  <td class='text-center'><?php echo $data['data_m11'];?></td>
                  <td class='text-center'><?php echo $data['data_m12'];?></td>
                </tr>
              </table>
