<?php

$depart_select = $_POST['mdp'];

if ($_POST['mdp'] == "") {$depart_select_id = "LIMIT 0";} else {$depart_select_id ="WHERE id = ".$_POST['mdp']."";}

	try {
		$sql = "SELECT * FROM depart $depart_select_id ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$depart_select_name = $data['dp_name'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

if ($mis_user_level >= 4) {
//	$kpi_search_adm = " ";
	if ($_POST['mdp'] == "") {
		$kpi_search_adm = " kpi_year = $s_year AND ";
	} else {
		$kpi_search_adm = " kpi_year = $s_year AND k.kpi_dpid = '".$_POST['mdp']."' AND ";
	}
} else {
	$kpi_search_adm = " kpi_year = $s_year AND k.kpi_dpid = '".$mis_u_m_depart."' AND ";
}

if ($mis_user_level >= 1) {

	switch ($_GET['bsc']) {
		case "F":
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "(F ด้านการเงิน)";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code = 'F' ";
			break;
		case "C":
			$bsc_menu_load = "kpi/data_kpi_menu_c.php";
			$bsc_menu_name = "(C ด้านลูกค้า)";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code = 'C' ";
			break;
		case "P":
			$bsc_menu_load = "kpi/data_kpi_menu_p.php";
			$bsc_menu_name = "(P ด้านกระบวนการภายใน)";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code = 'P' ";
			break;
		case "O":
			$bsc_menu_load = "kpi/data_kpi_menu_o.php";
			$bsc_menu_name = "(O ด้านการเรียนรู้และการเติบโต)";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code = 'O' ";
			break;
		case "Q":
			$bsc_menu_load = "kpi/data_kpi_menu_q.php";
			$bsc_menu_name = "(QP แผนคุณภาพ)";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code = 'Q' ";
			break;
		default:
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "";
			$kpi_search = " WHERE kpi_year = $s_year AND ".$kpi_search_adm." k.bsc_code <> '' ";
	}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
 </head>
 <body Onload="JavaScript:doCallAjax('<?php echo $bsc_menu_load;?>');">

		<div class="col-md-12">
          <div class="box box-primary">
            <div class="box-header">
              <h3 class="box-title"><i class="fa fa-th"></i> รายการตัวชี้วัด <?php echo $bsc_menu_name."<font color='#0000ff'>".$depart_select_name."</font> ";?></h3>
              <!-- /.box-tools -->
            </div>
			<!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
                <!-- Check all button -->

<?php if ($mis_user_level >= 4) { ?>

<form class="form-inline" action="#" method="POST">
<div class="form-group">
<?php
	try {
		$sql = "SELECT * FROM depart WHERE dp_status <> 0";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='mdp' name='mdp'>";

		foreach($query as $data) {
			echo "<option value='".$data['id']."'>".$data['dp_name']."</option>";
		}
			echo "</select>";
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
</div>
<button type="submit" class="btn btn-default btn-sm margin">แสดง KPI ของหน่วยงานที่เลือก</button>
</form>
<?php } ?>


                <!-- /.pull-right -->
              </div>
              <div class="box-body">
                <table id="DataTable" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <!-- <th class="text-center">BSC</th> -->
                  <th class="text-center">รหัสตัวชี้วัด</th>
                  <th class="text-center">Input</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center">เป้าหมาย</th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ผู้รับผิดชอบ</th>
                </tr>
                 </thead>
				  <tbody>

<?php

	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					$kpi_search ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='".$wwwurl."/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = "<i class='fa fa-refresh'></i>";
			} else {
//				$k_input_type = "<a href='?main=kpimanage&m=data&dtype=".$data['kpi_duration_type']."&dataid=".$data['data_id']."'><i class='fa fa-pencil'></i></a>";
				$k_input_type = "<a href='#".$data['data_id']."' data-toggle='modal' data-target='#modal-keyin-".$data['data_id']."'><i class='fa fa-pencil'></i></a>";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}


			if ($data['kpi_duration_type'] == "1") {
				if ($data['ndaday'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "2") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "3") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "4") {
				if ($data['ndadam'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			}
/*

			if ($data['nscore'] < 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 2) {
				$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 3) {
				$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 4) {
				$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] >= 5) {
				$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
			} else {
				$k_kpi_result_c = "";
			}
*/
			if (strpos($data['data_approved'], 'y') !== false) {$k_data_y_approved = "readonly='readonly' "; $checked_y = "checked";} else {$k_data_y_approved = ""; $checked_y = "";}
			if (strpos($data['data_approved'], '1') !== false) {$k_data_t1_approved = "readonly='readonly' "; $checked_t1 = "checked";} else {$k_data_t1_approved = ""; $checked_t1 = "";}
			if (strpos($data['data_approved'], '2') !== false) {$k_data_t2_approved = "readonly='readonly' "; $checked_t2 = "checked";} else {$k_data_t2_approved = ""; $checked_t2 = "";}
			if (strpos($data['data_approved'], '3') !== false) {$k_data_t3_approved = "readonly='readonly' "; $checked_t3 = "checked";} else {$k_data_t3_approved = ""; $checked_t3 = "";}
			if (strpos($data['data_approved'], '4') !== false) {$k_data_t4_approved = "readonly='readonly' "; $checked_t4 = "checked";} else {$k_data_t4_approved = ""; $checked_t4 = "";}
			if (strpos($data['data_approved'], 'a') !== false) {$k_data_m1_approved = "readonly='readonly' "; $checked_m1 = "checked";} else {$k_data_m1_approved = ""; $checked_m1 = "";}
			if (strpos($data['data_approved'], 'b') !== false) {$k_data_m2_approved = "readonly='readonly' "; $checked_m2 = "checked";} else {$k_data_m2_approved = ""; $checked_m2 = "";}
			if (strpos($data['data_approved'], 'c') !== false) {$k_data_m3_approved = "readonly='readonly' "; $checked_m3 = "checked";} else {$k_data_m3_approved = ""; $checked_m3 = "";}
			if (strpos($data['data_approved'], 'd') !== false) {$k_data_m4_approved = "readonly='readonly' "; $checked_m4 = "checked";} else {$k_data_m4_approved = ""; $checked_m4 = "";}
			if (strpos($data['data_approved'], 'e') !== false) {$k_data_m5_approved = "readonly='readonly' "; $checked_m5 = "checked";} else {$k_data_m5_approved = ""; $checked_m5 = "";}
			if (strpos($data['data_approved'], 'f') !== false) {$k_data_m6_approved = "readonly='readonly' "; $checked_m6 = "checked";} else {$k_data_m6_approved = ""; $checked_m6 = "";}
			if (strpos($data['data_approved'], 'g') !== false) {$k_data_m7_approved = "readonly='readonly' "; $checked_m7 = "checked";} else {$k_data_m7_approved = ""; $checked_m7 = "";}
			if (strpos($data['data_approved'], 'h') !== false) {$k_data_m8_approved = "readonly='readonly' "; $checked_m8 = "checked";} else {$k_data_m8_approved = ""; $checked_m8= "";}
			if (strpos($data['data_approved'], 'i') !== false) {$k_data_m9_approved = "readonly='readonly' "; $checked_m9 = "checked";} else {$k_data_m9_approved = ""; $checked_m9 = "";}
			if (strpos($data['data_approved'], 'j') !== false) {$k_data_m10_approved = "readonly='readonly' "; $checked_m10 = "checked";} else {$k_data_m10_approved = ""; $checked_m10 = "";}
			if (strpos($data['data_approved'], 'k') !== false) {$k_data_m11_approved = "readonly='readonly' "; $checked_m11 = "checked";} else {$k_data_m11_approved = ""; $checked_m11 = "";}
			if (strpos($data['data_approved'], 'l') !== false) {$k_data_m12_approved = "readonly='readonly' "; $checked_m12 = "checked";} else {$k_data_m12_approved = ""; $checked_m12 = "";}

			echo "<tr>";
			// echo "<td class='text-center'>".$data['bsc_code']."</td>";
			echo "<td class='text-center'>".$data['kpi_type_name']."-".$data['qp_code']."-".$data['kpi_number']."</td>";
			echo "<td class='text-center'>".$k_input_type."</td>";
			echo "<td><a href='?main=kpimanage&bsc=Q&m=edit&kpiid=".$data['kpi_id']."&userowner=".$data['kpi_owner']."'>".$data['kpi_name_t']."</a>&nbsp;".$k_template_f."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
//			echo "<td class='text-center'>".$k_kpi_status."</td>";
			echo "<td>".$data['m_namefull']."</td>";
			echo "</tr>";
?>

<?php if ($data['kpi_duration_type'] == "1") {;?>
        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-keyin-<?php echo $data['data_id'];?>">
        <form action="?main=kpimanage&m=up" method="POST">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?> x C:<?php echo $data['kpi_cal_c'];?></font>
              </div>
			  <div class="modal-body">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12">
					<div class="form-group"><label>ปี </label><input id="data_y" type="number" step="any" name="data_y" value="<?php echo $data['data_y'];?>" <?php echo $k_data_y_approved;?>><label><input type="checkbox" name="data_iy" value="y" <?php echo $checked_y;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			    <input type="hidden" name="i_kpi_owner" value="<?php echo $data['kpi_owner'];?>">
			    <input type="hidden" name="i_data_appr" value="<?php echo $data['data_approved'];?>">
			    <input type="hidden" name="i_data_appr_update" value="<?php echo $data['data_approve_update'];?>">
			    <input type="hidden" name="i_data_appr_user" value="<?php echo $data['data_approve_user'];?>">
			</div>
			  </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-success pull-right" name="submit_result" value="submit_result"> บันทึก </button>
              </div>
            </div>
          </div>
        </div>
		</form>
        <!-- modal1-content./ -->
<?php } else if ($data['kpi_duration_type'] == "2") {;?>
        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-keyin-<?php echo $data['data_id'];?>">
        <form action="?main=kpimanage&m=up" method="POST">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?> x C:<?php echo $data['kpi_cal_c'];?></font>
              </div>
              <div class="modal-body">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย min</label><input type="text" value="<?php echo $data['kpi_targeta'];?>" disabled></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย max</label><input type="text" value="<?php echo $data['kpi_target'];?>" disabled></div></div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส2</label><input type="number" step="any" name="data_t2" value="<?php echo $data['data_t2'];?>" <?php echo $k_data_t2_approved;?>><label><input type="checkbox" name="data_it2" value="2" <?php echo $checked_t2;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส4</label><input type="number" step="any" name="data_t4" value="<?php echo $data['data_t4'];?>" <?php echo $k_data_t4_approved;?>><label><input type="checkbox" name="data_it4" value="4" <?php echo $checked_t4;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			    <input type="hidden" name="i_kpi_owner" value="<?php echo $data['kpi_owner'];?>">
			    <input type="hidden" name="i_data_appr" value="<?php echo $data['data_approved'];?>">
			    <input type="hidden" name="i_data_appr_update" value="<?php echo $data['data_approve_update'];?>">
			    <input type="hidden" name="i_data_appr_user" value="<?php echo $data['data_approve_user'];?>">
			</div>
              </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-info pull-right" name="submit_result" value="submit_result"> บันทึก </button>
			  </div>
            </div>
          </div>
        </div>
		</form>

        <!-- modal1-content./ -->
<?php } else if ($data['kpi_duration_type'] == "3") {;?>
        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-keyin-<?php echo $data['data_id'];?>">
        <form action="?main=kpimanage&m=up" method="POST">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?> x C:<?php echo $data['kpi_cal_c'];?></font>
              </div>
              <div class="modal-body">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย min</label><input type="text" value="<?php echo $data['kpi_targeta'];?>" disabled></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย max</label><input type="text" value="<?php echo $data['kpi_target'];?>" disabled></div></div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส1</label><input type="number" step="any" name="data_t1" value="<?php echo $data['data_t1'];?>" <?php echo $k_data_t1_approved;?>><label><input type="checkbox" name="data_it1" value="1" <?php echo $checked_t1;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส2</label><input type="number" step="any" name="data_t2" value="<?php echo $data['data_t2'];?>" <?php echo $k_data_t2_approved;?>><label><input type="checkbox" name="data_it2" value="2" <?php echo $checked_t2;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส3</label><input type="number" step="any" name="data_t3" value="<?php echo $data['data_t3'];?>" <?php echo $k_data_t3_approved;?>><label><input type="checkbox" name="data_it3" value="3" <?php echo $checked_t3;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>ไตรมาส4</label><input type="number" step="any" name="data_t4" value="<?php echo $data['data_t4'];?>" <?php echo $k_data_t4_approved;?>><label><input type="checkbox" name="data_it4" value="4" <?php echo $checked_t4;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			    <input type="hidden" name="i_kpi_owner" value="<?php echo $data['kpi_owner'];?>">
			    <input type="hidden" name="i_data_appr" value="<?php echo $data['data_approved'];?>">
			    <input type="hidden" name="i_data_appr_update" value="<?php echo $data['data_approve_update'];?>">
			    <input type="hidden" name="i_data_appr_user" value="<?php echo $data['data_approve_user'];?>">
			</div>
              </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-info pull-right" name="submit_result" value="submit_result"> บันทึก </button>
			  </div>
            </div>
          </div>
        </div>
		</form>

        <!-- modal1-content./ -->

<?php } else if ($data['kpi_duration_type'] == "4") {;?>
        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-keyin-<?php echo $data['data_id'];?>">
        <form action="?main=kpimanage&m=up" method="POST">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?> x C:<?php echo $data['kpi_cal_c'];?></font>
              </div>
              <div class="modal-body">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย min</label><input type="text" value="<?php echo $data['kpi_targeta'];?>" disabled></div></div>
				<div class="col-lg-3 col-md-6 col-sm-12">
					<div class="form-group"><label>เป้าหมาย max</label><input type="text" value="<?php echo $data['kpi_target'];?>" disabled></div></div>
			</div>
			<div class="row">
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ม.ค.</label><input type="number" step="any" name="data_m1" value="<?php echo $data['data_m1'];?>" <?php echo $k_data_m1_approved;?>><label><input type="checkbox" name="data_im1" value="a" <?php echo $checked_m1;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.พ.</label><input type="number" step="any" name="data_m2" value="<?php echo $data['data_m2'];?>" <?php echo $k_data_m2_approved;?>><label><input type="checkbox" name="data_im2" value="b" <?php echo $checked_m2;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>มี.ค.</label><input type="number" step="any" name="data_m3" value="<?php echo $data['data_m3'];?>" <?php echo $k_data_m3_approved;?>><label><input type="checkbox" name="data_im3" value="c" <?php echo $checked_m3;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>เม.ย.</label><input type="number" step="any" name="data_m4" value="<?php echo $data['data_m4'];?>" <?php echo $k_data_m4_approved;?>><label><input type="checkbox" name="data_im4" value="d" <?php echo $checked_m4;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>พ.ค.</label><input type="number" step="any" name="data_m5" value="<?php echo $data['data_m5'];?>" <?php echo $k_data_m5_approved;?>><label><input type="checkbox" name="data_im5" value="e" <?php echo $checked_m5;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>มิ.ย.</label><input type="number" step="any" name="data_m6" value="<?php echo $data['data_m6'];?>" <?php echo $k_data_m6_approved;?>><label><input type="checkbox" name="data_im6" value="f" <?php echo $checked_m6;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.ค.</label><input type="number" step="any" name="data_m7" value="<?php echo $data['data_m7'];?>" <?php echo $k_data_m7_approved;?>><label><input type="checkbox" name="data_im7" value="g" <?php echo $checked_m7;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ส.ค.</label><input type="number" step="any" name="data_m8" value="<?php echo $data['data_m8'];?>" <?php echo $k_data_m8_approved;?>><label><input type="checkbox" name="data_im8" value="h" <?php echo $checked_m8;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ก.ย.</label><input type="number" step="any" name="data_m9" value="<?php echo $data['data_m9'];?>" <?php echo $k_data_m9_approved;?>><label><input type="checkbox" name="data_im9" value="i" <?php echo $checked_m9;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ต.ค.</label><input type="number" step="any" name="data_m10" value="<?php echo $data['data_m10'];?>" <?php echo $k_data_m10_approved;?>><label><input type="checkbox" name="data_im10" value="j" <?php echo $checked_m10;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>พ.ย.</label><input type="number" step="any" name="data_m11" value="<?php echo $data['data_m11'];?>" <?php echo $k_data_m11_approved;?>><label><input type="checkbox" name="data_im11" value="k" <?php echo $checked_m11;?>> รับรอง</label></div></div>
				<div class="col-lg-3 col-md-4 col-sm-12">
					<div class="form-group"><label>ธ.ค.</label><input type="number" step="any" name="data_m12" value="<?php echo $data['data_m12'];?>" <?php echo $k_data_m12_approved;?>><label><input type="checkbox" name="data_im12" value="l" <?php echo $checked_m12;?>> รับรอง</label></div></div>
			    <input type="hidden" name="data_id" value="<?php echo $data['data_id'];?>">
			    <input type="hidden" name="i_kpi_owner" value="<?php echo $data['kpi_owner'];?>">
			    <input type="hidden" name="i_data_appr" value="<?php echo $data['data_approved'];?>">
			    <input type="hidden" name="i_data_appr_update" value="<?php echo $data['data_approve_update'];?>">
			    <input type="hidden" name="i_data_appr_user" value="<?php echo $data['data_approve_user'];?>">
			</div>
              </div>
              <div class="modal-footer">
				<button type="submit" class="btn btn-info pull-right" name="submit_result" value="submit_result"> บันทึก </button>
              </div>
            </div>
          </div>
        </div>
		</form>
        <!-- modal1-content./ -->

<?php } else {};?>

<?php
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
<!-- 
				<tfoot>
                <tr>
                  <th><button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
                </tfoot>

 -->
                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>

          </div>
          <!-- /. box -->
        </div>


<?php } else {include 'error505.php';} ?>
