  <script language="JavaScript">
	   var HttPRequest = true;

	   function doCallAjax(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	   function doCallAjax2(url) {
		  HttPRequest = true;
		  if (window.XMLHttpRequest) { // Mozilla, Safari,...
			 HttPRequest = new XMLHttpRequest();
			 if (HttPRequest.overrideMimeType) {
				HttPRequest.overrideMimeType('text/html');
			 }
		  } else if (window.ActiveXObject) { // IE
			 try {
				HttPRequest = new ActiveXObject("Msxml2.XMLHTTP");
			 } catch (e) {
				try {
				   HttPRequest = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			 }
		  } 
		  
		  if (!HttPRequest) {
			 alert('Cannot create XMLHTTP instance');
			 return false;
		  }
	
		    var pmeters = "";

			HttPRequest.open('POST',url,true);

			HttPRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
			HttPRequest.setRequestHeader("Content-length", pmeters.length);
			HttPRequest.setRequestHeader("Connection", "close");
			HttPRequest.send(pmeters);
			
			
			HttPRequest.onreadystatechange = function()
			{

				 if(HttPRequest.readyState == 3)  // Loading Request
				  {
				   document.getElementById("myAjaxLoadPage2").innerHTML = "กำลังโหลดข้อมูล...";
				  }

				 if(HttPRequest.readyState == 4) // Return Request
				  {			  
					  document.getElementById('myAjaxLoadPage2').innerHTML = HttPRequest.responseText;
				  }				

			}

	   }

	</script>

 <body>

<?php
if ($mis_user_level >= 3) {
?>

<!-- <body Onload="JavaScript:doCallAjax('data_kpi100_dash.php');"> -->

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        BSC องค์กร
        <small>4 ด้าน</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">BSC องค์กร</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-md-3">
          <a href="JavaScript:doCallAjax2('kpi/data_kpi_create_menu1_list.php');" class="btn btn-primary btn-block margin-bottom">ตัวชี้วัดทั้งหมด</a>
          <div class="box box-solid">
            <div class="box-header with-border">
              <h3 class="box-title">BSC</h3>

              <div class="box-tools">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">
                <li class="active"><a href="JavaScript:doCallAjax('kpi/data_kpi_create_menu1.php');"><i class="fa fa-money"></i> F ด้านการเงิน
                  <span class="label label-primary pull-right">12</span></a></li>
                <li><a href="JavaScript:doCallAjax('data_kpi100_2.php');"><i class="fa fa-envelope-o"></i> C ด้านลูกค้า</a></li>
                <li><a href="JavaScript:doCallAjax('kpi/data_kpi_create_menu1.php');"><i class="fa fa-random"></i> P ด้านกระบวนการภายใน</a></li>
                <li><a href="JavaScript:doCallAjax('kpi/data_kpi_create_menu1.php');"><i class="fa fa-file-text-o"></i> O ด้านการเรียนรู้และการเติมโต <span class="label label-warning pull-right">65</span></a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
<span id="myAjaxLoadPage"></span>

		</div>
        <!-- /.col -->

<!-- <span id="myAjaxLoadPage2"></span> -->

<?php
	include 'kpi/data_kpi_list.php';
?>

        <!-- /.col -->
      </div>


	</section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>

 </body>
</html>
