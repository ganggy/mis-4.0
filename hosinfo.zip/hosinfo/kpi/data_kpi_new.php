<?php
if ($mis_user_level >= 3) {
	$dpart_adm = " ";
} else {
	$dpart_adm = "WHERE dpid = ".$mis_u_m_depart."";
}

if ($mis_user_level >= 3) {

	switch ($_GET['bsc']) {
		case "F":
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "F ด้านการเงิน";
			break;
		case "C":
			$bsc_menu_load = "kpi/data_kpi_menu_c.php";
			$bsc_menu_name = "C ด้านลูกค้า";
			break;
		case "P":
			$bsc_menu_load = "kpi/data_kpi_menu_p.php";
			$bsc_menu_name = "P ด้านกระบวนการภายใน";
			break;
		case "O":
			$bsc_menu_load = "kpi/data_kpi_menu_o.php";
			$bsc_menu_name = "O ด้านการเรียนรู้และการเติบโต";
			break;
		default:
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "(ทั้งหมดของหน่วยงาน)";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
 </head>
 <body Onload="JavaScript:doCallAjax('<?php echo $bsc_menu_load;?>');">

<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE id = $mis_u_m_depart ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$kpi_depart_name = $data['dp_name'];
		}
		$sql2 = "SELECT yearprocess FROM sys_config";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$kpi_year = $data2['yearprocess'];
			$kpiid = date("YmdHis");
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
		<div class="col-md-12">

		  <!-- general form elements disabled -->
          <div class="box box-warning">
            <div class="box-header with-border bg-warning">
              <h3 class="box-title"><i class="fa fa-plus-square-o"></i> เพิ่มตัวชี้วัดใหม่ --></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="?main=kpimanage&bsc=O&m=up" method="POST" enctype="multipart/form-data">
                <!-- text input -->
					<div class="row">
					<div class="col-lg-4 col-md-6 col-sm-12">
						<div class="form-group has-success">
						<label class="control-label"><i class="fa fa-check"></i> ประเภทตัวชี้วัด</label>
						<br><input type="radio" name="kpi_type" value="1" class="minimal"> AP แผนปฏิบัติ
						<br><input type="radio" name="kpi_type" value="2"  class="minimal"> QMP แผนพัฒนาคุณภาพ
						<br><input type="radio" name="kpi_type" value="3"  class="minimal" checked> QP แผนคุณภาพ
						<!-- <br><input type="radio" name="kpi_type" value="4"  class="minimal"> BSC องค์กร -->
						</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-12">
						<div class="form-group">
						<label>หน่วยงาน</label>
							<input type="hidden" name="kpi_user_update" value="<?php echo $ok_login_user;?>">
							<input type="hidden" name="kpi_year" value="<?php echo $kpi_year;?>">
							<input type="hidden" name="kpiid" value="<?php echo $kpiid;?>">
							<input type="hidden" name="bsc_code" value="<?php echo $_GET['bsc'];?>">
							<input type="hidden" name="kpi_code" value="<?php echo $kpi_year."-".$kpiid;?>">
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE dp_status <> 0";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='kpi_dpid' name='kpi_dpid'>";

		foreach($query as $data) {
			if ($data['id'] == $mis_u_m_depart) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['id']."'".$eselected.">".$data['dp_name']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

						</div>
					</div>

					<div class="col-lg-2 col-md-6 col-sm-12">
						<div class="form-group">
						<label>รหัสคุณภาพ</label>
							<input type="text" name="qp_code" class="form-control" required autofocus>
						</div>
					</div>
					<div class="col-lg-2 col-md-6 col-sm-12">
						<div class="form-group">
						<label>ลำดับตัวชี้วัด</label>
							<input type="number" step="any" name="kpi_number" class="form-control" required>
						</div>
					</div>
					</div><!-- row // -->

                <div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> ชื่อตัวชี้วัด (ภาษาไทย)</label>
                  <input type="text" name="kpi_name_t" class="form-control" id="kpi_name_t" placeholder="ชื่อตัวชี้วัด ภาษาไทย" required>
                </div>
				<!-- <div class="form-group">
                  <label class="control-label"> ชื่อตัวชี้วัด (English)</label>
                  <input type="text" name="kpi_name_e" class="form-control" placeholder="ชื่อตัวชี้วัด ภาษาอังกฤษ">
                </div> -->

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> คำอธิบายความหมายของตัวชี้วัด</label>
                  <textarea class="form-control" name="kpi_meaning" rows="3" placeholder="คำอธิบายความหมายของตัวชี้วัด"></textarea>
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> วัตถุประสงค์</label>
                  <input type="text" name="kpi_object" class="form-control" placeholder="วัตถุประสงค์">
                </div>
                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> สูตรคำนวณ</label>
					<div class="row">
					  <div class="col-lg-4 col-md-4 col-sm-12">A ตัวตั้ง (ผลงาน)
					  <textarea class="form-control" name="kpi_cal_a" rows="3" placeholder="คำอธิบายตัวตั้ง" required></textarea></div>
					  <div class="col-lg-4 col-md-4 col-sm-12">B ตัวหาร (เป้าหมาย)
					  <textarea class="form-control" name="kpi_cal_b" rows="3" placeholder="คำอธิบายตัวหาร" required></textarea></div>
					  <div class="col-lg-4 col-md-4 col-sm-12">C ตัวคูณ (อัตรา)
					  <input type="number" step="any" class="form-control" name="kpi_cal_c" placeholder="กรอกตัวเลข 100, 1000, 100000" required></div>
					</div>
                </div>
				<div class="form-group">
                  <label class="control-label"> แหล่งที่มาของข้อมูล</label>
                  <input type="text" name="kpi_source" class="form-control" placeholder="แหล่งที่มาของข้อมูล">
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> หน่วยวัด</label>
                  <input type="text" name="kpi_unit" class="form-control" placeholder="หน่วยวัด" required>
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> การแปรผล</label>
                  <input type="text" name="kpi_translate" class="form-control" placeholder="การแปรผล">
                </div>

		<div class="row">
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> การได้มาของข้อมูล</label>
				  <br><input type="radio" name="kpi_input_type" value="1" class="minimal"> ประมวลผล
				  <br><input type="radio" name="kpi_input_type" value="2"  class="minimal" checked> Key In
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> ความถี่ของการรายงาน</label>
				  <br><input type="radio" name="kpi_duration_type" value="1" class="minimal"> รายปี
				  <br><input type="radio" name="kpi_duration_type" value="2"  class="minimal"> รายงวด 6 เดือน
				  <br><input type="radio" name="kpi_duration_type" value="3"  class="minimal" checked> รายงวด 3 เดือน
				  <br><input type="radio" name="kpi_duration_type" value="4"  class="minimal"> รายเดือน
				</div>
			</div>
		</div>

                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> Baseline</label> (3 ปีย้อนหลัง)
					<div class="row">
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $kpi_year-3;?><input type="number" step="any" class="form-control" name="kpi_baseline1"></div>
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $kpi_year-2;?><input type="number" step="any" class="form-control" name="kpi_baseline2"></div>
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $kpi_year-1;?><input type="number" step="any" class="form-control" name="kpi_baseline3"></div>
					</div>
                </div>

                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> เป้าหมาย</label> (ตามหน่วยวัด) ประเมินผลจากค่า 
					<input type="radio" name="kpi_target_type" value="1" class="minimal"> ต่ำดี 
					<input type="radio" name="kpi_target_type" value="2" class="minimal" checked> สูงดี

					<div class="row">
					  <div class="col-lg-2 col-md-6 col-sm-12">เป้าหมาย</span>
					  <input type="number" step="any" class="form-control" name="kpi_target" placeholder="ตัวเลขเป้าหมาย" required></div>
					  <div class="col-lg-2 col-md-6 col-sm-12">ค่าต่ำ <span data-toggle="tooltip" title="(ต่ำดี &lt;= คือเขียว) (สูงดี &lt; คือแดง)"><i class="fa fa-commenting-o"></i>
					  <input type="number" step="any" class="form-control" name="kpi_targeta" placeholder="ตัวเลขค่าต่ำ" required></div>
					  <div class="col-lg-2 col-md-6 col-sm-12">ค่าสูง <span data-toggle="tooltip" title="(ต่ำดี &gt; คือแดง) (สูงดี &gt;= คือเขียว)"><i class="fa fa-commenting-o"></i>
					  <input type="number" step="any" class="form-control" name="kpi_targetb" placeholder="ตัวเลขค่าสูง" required></div>
					</div>
                </div>
                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> น้ำหนัก</label> (ผลรวมทุกตัวชี้วัดต้องได้ 100 หรือถ้าหากกำหนดเป็นคะแนน ระบบจะคำนวนสัดส่วนออกมาให้ได้ผลรวม 100%)
					<div class="row">
					  <div class="col-lg-4 col-md-6 col-sm-12"><input type="number" step="any" class="form-control" name="kpi_weight"></div>
					</div>
                </div>

				<div class="form-group">
					<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-12">
                  <label class="control-label"><i class="fa fa-check"></i>กำหนดผู้รับผิดชอบ</label>
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM mis_user $dpart_adm ";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='kpi_owner' name='kpi_owner'>";

		foreach($query as $data) {
			echo "<option value='".$data['m_login']."'>".$data['m_namefull']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
					</div>
					</div>
                </div>

            <div class="form-group">
				<label class="control-label"><i class="fa fa-file-pdf-o margin-r-5"></i> KPI Template (ไฟล์ PDF เท่านั้น)</label>
				<div class="input-group">
					<div class="input-group-addon">
						<i class="fa fa-file-pdf-o"></i>
					</div>
					<input id="fileToUpload" type="file" name="fileToUpload" />
					<script>
						$('#fileToUpload').fileselect({
							allowedFileExtensions: ['pdf'], // default: false, all extensions allowed
							allowedFileSize: 5120000 // 5MB, default: false, no limitation
						});
					</script>
				</div>
            </div>

            </div>
            <!-- /.box-body -->
              <div class="box-footer">
                <!-- <button type="submit" class="btn btn-default"> ยกเลิก </button> -->
                <button type="submit" class="btn btn-warning pull-right" name="submit_data_kpi" value="create"><i class='fa fa-plus'></i> ตกลงเพิ่มตัวชี้วัดใหม่ </button>
              </div>
              <!-- /.box-footer -->
          </div>
              </form>


		
		</div>

<?php } else {include 'error505.php';} ?>
