<?php
//if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {

if ($mis_user_level >= 3) {
	$s_kpi_view = "  AND k.kpi_view IN (1,2,3,4) ";
	$s_kpi_view_c = " k.kpi_view IN (1,2,3,4) ";
} else if ($mis_user_level >= 1) {
	$s_kpi_view = " AND k.kpi_view IN (2,3,4) ";
	$s_kpi_view_c = " k.kpi_view IN (2,3,4) ";
} else {
	if ($login_ok == 1) {
		$s_kpi_view = " AND k.kpi_view IN (3,4) ";
		$s_kpi_view_c = " k.kpi_view IN (3,4) ";
	} else {
		$s_kpi_view = " AND k.kpi_view = 4 ";
		$s_kpi_view_c = " k.kpi_view = 4 ";
	}
}

	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT yearprocess FROM sys_config ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$s_year = $data['yearprocess'];
			$s_yearb1 = $data['yearprocess']-3;
			$s_yearb2 = $data['yearprocess']-2;
			$s_yearb3 = $data['yearprocess']-1;
		}

		$sql2 = "SELECT COUNT(*) AS c_kpi,SUM(IF ($s_kpi_view_c,1,0)) AS c_kpi_view FROM kpi k WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code <> '' ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$count_kpi_t = $data2['c_kpi'];
			$count_kpi_v = $data2['c_kpi_view'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        สรุปผลการดำเนินงานตามตัวชี้วัด
        <small>รพร.ตะพานหิน</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ตัวชี้วัด</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- START CUSTOM TABS -->
      <div class="row">
        <div class="col-md-12">
          <!-- Custom Tabs (Pulled to the right) -->
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs pull-right bg-success">
              <li class="active bg-warning"><a href="#tab_1-1" data-toggle="tab">[ ALL ]</a></li>
              <!-- <li class="bg-warning"><a href="#tab_2-2" data-toggle="tab">[ F ด้านการเงิน ]</a></li>
              <li class="bg-warning"><a href="#tab_3-2" data-toggle="tab">[ C ด้านลูกค้า ]</a></li>
              <li class="bg-warning"><a href="#tab_4-2" data-toggle="tab">[ P ด้านกระบวนการ ]</a></li>
              <li class="bg-warning"><a href="#tab_5-2" data-toggle="tab">[ O ด้านการเรียนรู้ ]</a></li> -->
              <!-- <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                  อื่นๆ <span class="caret"></span>
                </a>
                <ul class="dropdown-menu">
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">จัดการ</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Another action</a></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Something else here</a></li>
                  <li role="presentation" class="divider"></li>
                  <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Separated link</a></li>
                </ul>
              </li> -->
              <li class="pull-left header"><i class="fa fa-th"></i> แสดงตัวชี้วัด <b><?php echo $count_kpi_v;?></b> ตัว จากทั้งหมด <b><?php echo $count_kpi_t;?></b> ตัว</li>
            </ul>
            <div class="tab-content">
              <div class="tab-pane active" id="tab_1-1">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT1" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <th class="text-center">รหัสตัวชี้วัด</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center">Baseline<br><?php echo $s_yearb1;?></th>
                  <th class="text-center">Baseline<br><?php echo $s_yearb2;?></th>
                  <th class="text-center">Baseline<br><?php echo $s_yearb3;?></th>
                  <th class="text-center">เป้าหมาย<br>ปี <?php echo $s_year;?></th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ปรับปรุง</th>
                  <th class="text-center">เพิ่มเติม</th>
                </tr>
                 </thead>
				  <tbody>
<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code <> '' $s_kpi_view ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['kpi_last_update']);

			if ($data['kpi_duration_type'] == "1") {
				if ($data['ndaday'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else if ($data['ndaday'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndaday']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "2") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "3") {
				if ($data['ndadat'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else if ($data['ndadat'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			} else if ($data['kpi_duration_type'] == "4") {
				if ($data['ndadam'] < $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*4)) {
					$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*3)) {
					$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4)*2)) {
					$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= ($data['kpi_targeta'] + (($data['kpi_target'] - $data['kpi_targeta'])/4))) {
					$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else if ($data['ndadam'] >= $data['kpi_targeta']) {
					$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadam']."</span></div>";
				} else {
					$k_kpi_result_c = "";
				}
			}

			echo "<tr>";
			echo "<td class='text-center'><a href='?main=kpimanage&bsc=F&m=edit&kpiid=".$data['kpi_id']."'>".$data['kpi_type_name']."-".$data['qp_code']."-".$data['kpi_number']."</a></td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline1']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline2']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline3']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "<td><a href='#".$data['kpi_id']."' data-toggle='modal' data-target='#modal-showdata-".$data['kpi_id']."'><i class='fa fa-table'></i></a> ".$k_input_type." ".$k_template_f."</td>";
			echo "</tr>";
?>

        <!-- /.modal1-content -->
        <div class="modal fade" id="modal-showdata-<?php echo $data['kpi_id'];?>">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><font color="#0000ff"><?php echo $data['kpi_name_t'];?></font></h4>
				<font color="#ff0000">A:<?php echo $data['kpi_cal_a'];?> / B:<?php echo $data['kpi_cal_b'];?></font>
              </div>
              <div class="modal-body">
                <p><?php echo $data['kpi_meaning'];?></p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"> ปิด </button>
              </div>
            </div>
          </div>
        </div>
        <!-- modal1-content./ -->

<?php
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  
			  </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_2-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT2" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <th class="text-center">BSC</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center"><?php echo $s_yearb3;?></th>
                  <th class="text-center"><?php echo $s_yearb2;?></th>
                  <th class="text-center"><?php echo $s_yearb1;?></th>
                  <th class="text-center">เป้าหมาย<br>ปี <?php echo $s_year;?></th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ปรับปรุง</th>
                  <th class="text-center">เพิ่มเติม</th>
                </tr>
                 </thead>
				  <tbody>
<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0)))))) AS nscore

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code = 'F' $s_kpi_view ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['kpi_last_update']);

			if ($data['nscore'] < 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 2) {
				$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 3) {
				$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 4) {
				$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] >= 5) {
				$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
			} else {
				$k_kpi_result_c = "";
			}

			echo "<tr>";
			echo "<td class='text-center'><a href='?main=kpimanage&bsc=F&m=edit&kpiid=".$data['kpi_id']."'>".$data['bsc_code']."</a></td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline1']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline2']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline3']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "<td><a href='#".$data['kpi_id']."' data-toggle='modal' data-target='#modal-showdata-".$data['kpi_id']."'><i class='fa fa-table'></i></a> ".$k_input_type." ".$k_template_f."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  
			  </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_3-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT3" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <th class="text-center">BSC</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center"><?php echo $s_yearb3;?></th>
                  <th class="text-center"><?php echo $s_yearb2;?></th>
                  <th class="text-center"><?php echo $s_yearb1;?></th>
                  <th class="text-center">เป้าหมาย<br>ปี <?php echo $s_year;?></th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ปรับปรุง</th>
                  <th class="text-center">เพิ่มเติม</th>
                </tr>
                 </thead>
				  <tbody>
<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0)))))) AS nscore

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code = 'C' $s_kpi_view ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['kpi_last_update']);

			if ($data['nscore'] < 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 2) {
				$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 3) {
				$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 4) {
				$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] >= 5) {
				$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
			} else {
				$k_kpi_result_c = "";
			}

			echo "<tr>";
			echo "<td class='text-center'><a href='?main=kpimanage&bsc=F&m=edit&kpiid=".$data['kpi_id']."'>".$data['bsc_code']."</a></td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline1']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline2']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline3']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "<td><a href='#".$data['kpi_id']."' data-toggle='modal' data-target='#modal-showdata-".$data['kpi_id']."'><i class='fa fa-table'></i></a> ".$k_input_type." ".$k_template_f."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  
			  </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_4-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT4" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <th class="text-center">BSC</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center"><?php echo $s_yearb3;?></th>
                  <th class="text-center"><?php echo $s_yearb2;?></th>
                  <th class="text-center"><?php echo $s_yearb1;?></th>
                  <th class="text-center">เป้าหมาย<br>ปี <?php echo $s_year;?></th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ปรับปรุง</th>
                  <th class="text-center">เพิ่มเติม</th>
                </tr>
                 </thead>
				  <tbody>
<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0)))))) AS nscore

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code = 'P' $s_kpi_view ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['kpi_last_update']);

			if ($data['nscore'] < 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 2) {
				$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 3) {
				$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 4) {
				$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] >= 5) {
				$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
			} else {
				$k_kpi_result_c = "";
			}

			echo "<tr>";
			echo "<td class='text-center'><a href='?main=kpimanage&bsc=F&m=edit&kpiid=".$data['kpi_id']."'>".$data['bsc_code']."</a></td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline1']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline2']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline3']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "<td><a href='#".$data['kpi_id']."' data-toggle='modal' data-target='#modal-showdata-".$data['kpi_id']."'><i class='fa fa-table'></i></a> ".$k_input_type." ".$k_template_f."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->

			  
			  </div>
              <!-- /.tab-pane -->
              <div class="tab-pane" id="tab_5-2">
            <!-- /.box-header -->
            <div class="box-body">
                <table id="DataTableT5" class="table table-bordered table-hover table-condensed">
                <thead>
                <tr>
                  <th class="text-center">BSC</th>
                  <th class="text-center">ตัวชี้วัด</th>
                  <th class="text-center">หน่วยวัด</th>
                  <th class="text-center"><?php echo $s_yearb3;?></th>
                  <th class="text-center"><?php echo $s_yearb2;?></th>
                  <th class="text-center"><?php echo $s_yearb1;?></th>
                  <th class="text-center">เป้าหมาย<br>ปี <?php echo $s_year;?></th>
                  <th class="text-center">ผลงาน</th>
                  <th class="text-center">ปรับปรุง</th>
                  <th class="text-center">เพิ่มเติม</th>
                </tr>
                 </thead>
				  <tbody>
<?php
	try {
		include "_cfg_mis40db.php";
		$ddm = date("m");
		// คำสั่ง SQL
		$sql = "SELECT k.*,t.*,v.*,i.*,d.*,b.*,u.m_namefull,a.*
,IF($ddm = '01',data_m1,IF($ddm = '02',data_m2,IF($ddm = '03',data_m3,IF($ddm = '04',data_m4,IF($ddm = '05',data_m5
,IF($ddm = '06',data_m6,IF($ddm = '07',data_m7,IF($ddm = '08',data_m8,IF($ddm = '09',data_m9,IF($ddm = '10',data_m10
,IF($ddm = '11',data_m11,IF($ddm = '12',data_m12,0)))))))))))) AS ndadam

,IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) AS ndadat
,data_y AS ndaday

,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) < kpi_targeta,0
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*4),5
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*3),4
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)*2),3
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= (kpi_targeta + ((kpi_target - kpi_targeta)/4)),2
,IF(IF($ddm BETWEEN '01' AND '03',data_t1,IF($ddm BETWEEN '04' AND '06',data_t2
,IF($ddm BETWEEN '07' AND '09',data_t3,IF($ddm BETWEEN '10' AND '12',data_t4,0)))) >= kpi_targeta,1
,0)))))) AS nscore

					FROM kpi k 
					LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type
					LEFT JOIN sys_kpi_view v ON v.kpi_view = k.kpi_view
					LEFT JOIN sys_kpi_input_type i ON i.kpi_input_type = k.kpi_input_type
					LEFT JOIN sys_kpi_duration_type d ON d.kpi_duration_type = k.kpi_duration_type
					LEFT JOIN sys_bsc b ON b.bsc_code = k.bsc_code
					LEFT JOIN kpi_data a ON a.kpi_code = k.kpi_code AND a.data_year = k.kpi_year
					LEFT JOIN mis_user u ON u.m_login = k.kpi_owner
					WHERE k.kpi_status <> '0' AND k.kpi_year = $s_year AND k.bsc_code = 'O' $s_kpi_view ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['kpi_template_file'] == "") {
				$k_template_f = "";
			} else {
				$k_template_f = " <a target='_blank' href='/kpi/files/".$data['kpi_template_file']."'><i class='fa fa-file-pdf-o'></i></a>";
			}

			if ($data['kpi_input_type'] == "1") {
				$k_input_type = " <i class='fa fa-refresh'></i> ";
			} else {
				$k_input_type = " <i class='fa fa-pencil'></i> ";
			}

			if ($data['kpi_status'] == "1") {
				$k_kpi_status = "<i class='fa fa-check'></i>";
			} else {
				$k_kpi_status = "<i class='fa fa-ban'></i>";
			}
			$kpi_last_update = DateThai($data['kpi_last_update']);

			if ($data['nscore'] < 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 1) {
				$k_kpi_result_c = "<div class='bg-red-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 2) {
				$k_kpi_result_c = "<div class='bg-orange-active color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 3) {
				$k_kpi_result_c = "<div class='bg-yellow color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] == 4) {
				$k_kpi_result_c = "<div class='bg-aqua color-palette'><span>".$data['ndadat']."</span></div>";
			} else if ($data['nscore'] >= 5) {
				$k_kpi_result_c = "<div class='bg-green color-palette'><span>".$data['ndadat']."</span></div>";
			} else {
				$k_kpi_result_c = "";
			}

			echo "<tr>";
			echo "<td class='text-center'><a href='?main=kpimanage&bsc=F&m=edit&kpiid=".$data['kpi_id']."'>".$data['bsc_code']."</a></td>";
			echo "<td>".$data['kpi_name_t']."</td>";
			echo "<td class='text-center'>".$data['kpi_unit']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline1']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline2']."</td>";
			echo "<td class='text-center'>".$data['kpi_baseline3']."</td>";
			echo "<td class='text-center'>".$data['kpi_target']."</td>";
			echo "<td class='text-center'>".$k_kpi_result_c."</td>";
			echo "<td class='text-center'>".$kpi_last_update."</td>";
			echo "<td><a href='#".$data['kpi_id']."' data-toggle='modal' data-target='#modal-showdata-".$data['kpi_id']."'><i class='fa fa-table'></i></a> ".$k_input_type." ".$k_template_f."</td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>
            </div>
            <!-- /.box-body -->
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- nav-tabs-custom -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
      <!-- END CUSTOM TABS -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


<?php //} ?>