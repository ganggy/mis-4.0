<?php
if ($mis_user_level >= 3) {
	$dpart_adm = " ";
} else {
	$dpart_adm = "WHERE dpid = ".$mis_u_m_depart."";
}

if ($mis_user_level >= 3 OR $ok_login_user == $_GET['userowner']) {

	$kpiid = $_GET['kpiid'];

	switch ($_GET['bsc']) {
		case "F":
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "(F ด้านการเงิน)";
			break;
		case "C":
			$bsc_menu_load = "kpi/data_kpi_menu_c.php";
			$bsc_menu_name = "(C ด้านลูกค้า)";
			break;
		case "P":
			$bsc_menu_load = "kpi/data_kpi_menu_p.php";
			$bsc_menu_name = "(P ด้านกระบวนการภายใน)";
			break;
		case "O":
			$bsc_menu_load = "kpi/data_kpi_menu_o.php";
			$bsc_menu_name = "(O ด้านการเรียนรู้และการเติบโต)";
			break;
		case "Q":
			$bsc_menu_load = "kpi/data_kpi_menu_q.php";
			$bsc_menu_name = "(QP แผนคุณภาพ)";
			break;
		default:
			$bsc_menu_load = "kpi/data_kpi_menu_f.php";
			$bsc_menu_name = "(ทั้งหมดของหน่วยงาน)";
	}

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
 <head>
 </head>
 <body Onload="JavaScript:doCallAjax('<?php echo $bsc_menu_load;?>');">

<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE id = '$mis_u_m_depart' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$kpi_depart_name = $data['dp_name'];
			$kpi_year = date("Y");
		}
		$sql2 = "SELECT k.*,t.* FROM kpi k LEFT JOIN sys_kpi_type t ON t.kpi_type = k.kpi_type WHERE k.kpi_id = '$kpiid' ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {

			if ($data2['kpi_template_file'] == "") {
				$k_template_f = " <font color='#ff0000'>ยังไม่มีไฟล์ Template ... กรุณาเลือกไฟล์ PDF เพื่ออับโหลด</font>";
			} else {
				$k_template_f = " ไฟล์ Template --> <a target='_blank' href='".$wwwurl."/kpi/files/".$data2['kpi_template_file']."'> ".$data2['kpi_template_file']."</a> <font color='#ff0000'>(เลือกไฟล์ใหม่ถ้าต้องการเปลี่ยน)</font>";
			}

			if ($data2['kpi_type'] == 1) {
				$kpi_type_1 = "checked";
			} else if ($data2['kpi_type'] == 2) {
				$kpi_type_2 = "checked";
			} else if ($data2['kpi_type'] == 3) {
				$kpi_type_3 = "checked";
			} else if ($data2['kpi_type'] == 4) {
				$kpi_type_4 = "checked";
			}

			if ($data2['kpi_view'] == 1) {
				$kpi_view_1 = "checked";
			} else if ($data2['kpi_view'] == 2) {
				$kpi_view_2 = "checked";
			} else if ($data2['kpi_view'] == 3) {
				$kpi_view_3 = "checked";
			} else if ($data2['kpi_view'] == 4) {
				$kpi_view_4 = "checked";
			}

			if ($data2['kpi_input_type'] == 1) {
				$kpi_input_type_1 = "checked";
			} else if ($data2['kpi_input_type'] == 2) {
				$kpi_input_type_2 = "checked";
			}

			if ($data2['kpi_target_type'] == 1) {
				$kpi_target_type_1 = "checked";
			} else if ($data2['kpi_target_type'] == 2) {
				$kpi_target_type_2 = "checked";
			}

			if ($data2['kpi_status'] == 1) {
				$kpi_status_1 = "checked";
			} else if ($data2['kpi_status'] == 0) {
				$kpi_status_0 = "checked";
			}

			if ($data2['kpi_duration_type'] == 1) {
				$kpi_duration_type_1 = "checked";
			} else if ($data2['kpi_duration_type'] == 2) {
				$kpi_duration_type_2 = "checked";
			} else if ($data2['kpi_duration_type'] == 3) {
				$kpi_duration_type_3 = "checked";
			} else if ($data2['kpi_duration_type'] == 4) {
				$kpi_duration_type_4 = "checked";
			}
			$kpi_owner = $data2['kpi_owner'];

		$sql3 = "SELECT * FROM mis_user WHERE m_login = '$kpi_owner' ";
		$query3 = $myPDO->query($sql3);
		foreach($query3 as $data3) {
			if ($data3['user_picture'] || NULL) {
				$kpi_owner_pic = "images/users/".$data3['user_picture']."";
			} else {
				$kpi_owner_pic = "dist/img/guestuser.png";
			}
			
			$kpi_owner_name = $data3['m_namefull'];
		}
?>

		<div class="col-md-12">

		  <!-- general form elements disabled -->
          <div class="box box-success">
            <div class="box-header with-border bg-success">
              <h3 class="box-title"><i class="fa fa-edit"></i> แก้ไขตัวชี้วัด --></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <form action="?main=kpimanage&m=up" method="POST" enctype="multipart/form-data">
                <!-- text input -->

			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12">
				<div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> สถานะการใช้งาน</label><br>
					  <input type="radio" name="kpi_status" value="1" class="minimal" <?php echo $kpi_status_1;?>> <i class='fa fa-check'></i> <font color="#009900">เปิดใช้งาน</font>&nbsp;&nbsp;
					  <input type="radio" name="kpi_status" value="0"  class="minimal" <?php echo $kpi_status_0;?>> <i class='fa fa-ban'></i> <font color="#ff0000">ปิดใช้งาน</font>

					  <input type="hidden" name="kpi_user_update" value="<?php echo $ok_login_user;?>">
					  <input type="hidden" name="kpi_id" value="<?php echo $data2['kpi_id'];?>">
					  <input type="hidden" name="kpi_dpid" value="<?php echo $data2['kpi_dpid'];?>">
					  <input type="hidden" name="kpi_year" value="<?php echo $data2['kpi_year'];?>">
					  <input type="hidden" name="bsc_code" value="<?php echo $data2['bsc_code'];?>">
					  <input type="hidden" name="kpi_code" value="<?php echo $data2['kpi_code'];?>">
					  <input type="hidden" name="kpi_template_file" value="<?php echo $data2['kpi_template_file'];?>">
					  <input type="hidden" name="i_kpi_owner" value="<?php echo $kpi_owner;?>">

                </div>
				</div>

				<div class="col-lg-8 col-md-8 col-sm-12">
				<div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> การเผยแพร่</label><br>
					  <input type="radio" name="kpi_view" value="1" class="minimal" <?php echo $kpi_view_1;?>> <font color="#ff0000">เฉพาะระดับหัวหน้าขึ้นไป</font>&nbsp;&nbsp;
					  <input type="radio" name="kpi_view" value="2"  class="minimal" <?php echo $kpi_view_2;?>> <font color="#ffcc00">สำหรับสมาชิก MIS</font>&nbsp;&nbsp;
					  <input type="radio" name="kpi_view" value="3"  class="minimal" <?php echo $kpi_view_3;?>> <font color="#0000cc">เจ้าหน้าที่ รพ.</font>&nbsp;&nbsp;
					  <input type="radio" name="kpi_view" value="4"  class="minimal" <?php echo $kpi_view_4;?>> <font color="#009900">สาธารณะ</font>
                </div>
				</div>
			</div>
<hr>
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="form-group has-success">
					<label class="control-label"><i class="fa fa-check"></i> ประเภทตัวชี้วัด</label>
						<br><input type="radio" name="kpi_type" value="1" class="minimal" <?php echo $kpi_type_1;?>> AP แผนปฏิบัติ
						<br><input type="radio" name="kpi_type" value="2"  class="minimal" <?php echo $kpi_type_2;?>> QMP แผนพัฒนาคุณภาพ
						<br><p class="text-red"><input type="radio" name="kpi_type" value="3"  class="minimal" <?php echo $kpi_type_3;?>> QP แผนคุณภาพ
						<!-- <br><input type="radio" name="kpi_type" value="4"  class="minimal" <?php echo $kpi_type_4;?>> BSC องค์กร</p> -->
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="form-group">
					<label>หน่วยงาน</label>
						<input type="text" class="form-control" value="<?php echo $kpi_depart_name;?>" disabled>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12">
					<div class="form-group">
					<label>รหัสตัวชี้วัด</label>
						<input type="text" class="form-control" value="<?php echo $data2['kpi_type_name']."-".$data2['qp_code']."-".$data2['kpi_number'];?>" disabled>
					</div>
				</div>

			</div>

                <div class="form-group has-error">
                  <label class="control-label"><i class="fa fa-check"></i> ชื่อตัวชี้วัด (ภาษาไทย)</label>
                  <input type="text" name="kpi_name_t" class="form-control" id="kpi_name_t" value="<?php echo $data2['kpi_name_t'];?>">
                </div>
				<!-- <div class="form-group">
                  <label class="control-label"> ชื่อตัวชี้วัด (English)</label>
                  <input type="text" name="kpi_name_e" class="form-control" value="<?php echo $data2['kpi_name_e'];?>">
                </div> -->

                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> คำอธิบายความหมายของตัวชี้วัด</label>
                  <textarea class="form-control" name="kpi_meaning" rows="3"><?php echo $data2['kpi_meaning'];?></textarea>
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> วัตถุประสงค์</label>
                  <input type="text" name="kpi_object" class="form-control" value="<?php echo $data2['kpi_object'];?>">
                </div>
                <div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> สูตรคำนวณ</label>
					<div class="row">
					  <div class="col-lg-4 col-md-4 col-sm-12">A ตัวตั้ง (ผลงาน)
					  <textarea class="form-control" name="kpi_cal_a" rows="3"><?php echo $data2['kpi_cal_a'];?></textarea></div>
					  <div class="col-lg-4 col-md-4 col-sm-12">B ตัวหาร (เป้าหมาย)
					  <textarea class="form-control" name="kpi_cal_b" rows="3"><?php echo $data2['kpi_cal_b'];?></textarea></div>
					  <div class="col-lg-4 col-md-4 col-sm-12">C ตัวคูณ (อัตรา)
					  <input type="number" step="any" class="form-control"  name="kpi_cal_c" rows="3" value="<?php echo $data2['kpi_cal_c'];?>"></div>
					</div>
                </div>
				<div class="form-group">
                  <label class="control-label"> แหล่งที่มาของข้อมูล</label>
                  <input type="text" name="kpi_source" class="form-control" value="<?php echo $data2['kpi_source'];?>">
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> หน่วยวัด</label>
                  <input type="text" name="kpi_unit" class="form-control" value="<?php echo $data2['kpi_unit'];?>">
                </div>
				<div class="form-group">
                  <label class="control-label"><i class="fa fa-check"></i> การแปรผล</label>
                  <input type="text" name="kpi_translate" class="form-control" value="<?php echo $data2['kpi_translate'];?>">
                </div>
		<div class="row">
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> การได้มาของข้อมูล</label>
				  <br><input type="radio" name="kpi_input_type" value="1" class="minimal" <?php echo $kpi_input_type_1;?>> ประมวลผล
				  <br><input type="radio" name="kpi_input_type" value="2"  class="minimal" <?php echo $kpi_input_type_2;?>> Key In
				</div>
			</div>
			<div class="col-lg-4 col-md-6 col-sm-12">
				<div class="form-group has-success">
                  <label class="control-label"><i class="fa fa-check"></i> ความถี่ของการรายงาน</label>
				  <br><input type="radio" name="kpi_duration_type" value="1" class="minimal" <?php echo $kpi_duration_type_1;?>> รายปี
				  <br><input type="radio" name="kpi_duration_type" value="2"  class="minimal" <?php echo $kpi_duration_type_2;?>> รายงวด 6 เดือน
				  <br><input type="radio" name="kpi_duration_type" value="3"  class="minimal" <?php echo $kpi_duration_type_3;?>> รายงวด 3 เดือน
				  <br><input type="radio" name="kpi_duration_type" value="4"  class="minimal" <?php echo $kpi_duration_type_4;?>> รายเดือน
				</div>
			</div>
		</div>

                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> Baseline</label> (3 ปีย้อนหลัง)
					<div class="row">
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $data2['kpi_year']-3;?><input type="number" step="any" class="form-control" name="kpi_baseline1" value="<?php echo $data2['kpi_baseline1'];?>"></div>
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $data2['kpi_year']-2;?><input type="number" step="any" class="form-control" name="kpi_baseline2" value="<?php echo $data2['kpi_baseline2'];?>"></div>
					  <div class="col-lg-4 col-md-6 col-sm-12">ปี <?php echo $data2['kpi_year']-1;?><input type="number" step="any" class="form-control" name="kpi_baseline3" value="<?php echo $data2['kpi_baseline3'];?>"></div>
					</div>
                </div>

                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> เป้าหมาย</label> (ตามหน่วยวัด) ประเมินผลจากค่า 
					<input type="radio" name="kpi_target_type" value="1" class="minimal" <?php echo $kpi_target_type_1;?>> ต่ำดี 
					<input type="radio" name="kpi_target_type" value="2" class="minimal" <?php echo $kpi_target_type_2;?>> สูงดี

					<div class="row">
					  <div class="col-lg-2 col-md-6 col-sm-12">เป้าหมาย</span>
					  <input type="number" step="any" class="form-control" name="kpi_target" value="<?php echo $data2['kpi_target'];?>"></div>
					  <div class="col-lg-2 col-md-6 col-sm-12">ค่าต่ำ <span data-toggle="tooltip" title="(ต่ำดี &lt;= คือเขียว) (สูงดี &lt; คือแดง)"><i class="fa fa-commenting-o"></i>
					  <input type="number" step="any" class="form-control" name="kpi_targeta" value="<?php echo $data2['kpi_targeta'];?>"></div>
					  <div class="col-lg-2 col-md-6 col-sm-12">ค่าสูง <span data-toggle="tooltip" title="(ต่ำดี &gt; คือแดง) (สูงดี &gt;= คือเขียว)"><i class="fa fa-commenting-o"></i>
					  <input type="number" step="any" class="form-control" name="kpi_targetb" value="<?php echo $data2['kpi_targetb'];?>"></div>
					</div>
                </div>
                <div class="form-group has-warning">
                  <label class="control-label"><i class="fa fa-check"></i> น้ำหนัก</label> (ผลรวมทุกตัวชี้วัดต้องได้ 100 หรือถ้าหากกำหนดเป็นคะแนน ระบบจะคำนวนสัดส่วนออกมาให้ได้ผลรวม 100%)
					<div class="row">
					  <div class="col-lg-4 col-md-6 col-sm-12"><input type="number" step="any" class="form-control" name="kpi_weight" value="<?php echo $data2['kpi_weight'];?>"></div>
					</div>
                </div>
                  
				<div class="form-group">
					<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-12">
                  <label class="control-label"><i class="fa fa-check"></i>ผู้รับผิดชอบ : <?php echo $kpi_owner_name; ?></label>
					<div class="left">
						<img src="<?php echo $kpi_owner_pic; ?>" class="profile-user-img img-responsive img-circle" alt="">
					</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12">
                  <label class="control-label"><i class="fa fa-check"></i>เลือกเพื่อกำหนดผู้รับผิดชอบใหม่</label>
<?php

	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM mis_user $dpart_adm ";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='kpi_owner' name='kpi_owner'>";
		foreach($query as $data) {
			if ($data['m_login'] == "$kpi_owner") { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['m_login']."' ".$eselected.">".$data['m_namefull']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
					</div>
					</div>
                </div>

            <section>
            <div class="form-group">
				<label><i class="fa fa-file-pdf-o margin-r-5"></i> <?php echo " ".$k_template_f; ?></label>
				<div class="input-group">
					<div class="input-group-addon">
						<i class="fa fa-file-pdf-o"></i>
					</div>
					<input id="fileToUpload" type="file" name="fileToUpload" />
					<script>
						$('#fileToUpload').fileselect({
							allowedFileExtensions: ['pdf'], // default: false, all extensions allowed
							allowedFileSize: 5120000 // 5MB, default: false, no limitation
						});
					</script>
				</div>
            </div>
            </section>

            </div>
            <!-- /.box-body -->
              <div class="box-footer">
			  <?php if ($mis_user_level >= 4) { ?>
                <button type="submit" class="btn btn-danger" name="submit_data_kpi" value="delete" onClick="return confirm('คุณแน่ใจที่จะลบข้อมูล KPI นี้');"><i class='fa fa-close'></i> ลบตัวชี้วัด </button>
			  <?php } ?>
                <button type="submit" class="btn btn-success pull-right" name="submit_data_kpi" value="update"><i class='fa fa-check'></i> ปรับปรุงตัวชี้วัด </button>
              </div>
              <!-- /.box-footer -->
          </div>
              </form>
		</div>

<?php
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<?php } else {include 'error505.php';} ?>
