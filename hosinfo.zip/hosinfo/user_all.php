<?php
if ($mis_user_level >= 4) {
?>

		<div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">รายชื่อผู้ใช้งานระบบ MIS <?php echo $user_search_n;?></h3>

              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="mailbox-controls">
                <!-- Check all button -->

                <!-- /.pull-right -->
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                <thead>
                <tr>
                  <th></th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>หน่วยงาน</th>
                  <th>ระดับผู้ใช้</th>
                  <th>สถานะ</th>
                  <th>จัดการ</th>
                </tr>
                 </thead>
				  <tbody>

<?php

	try {
		include "_cfg_mis40db.php";
		// คำสั่ง SQL
		$sql = "SELECT u.*,d.* FROM mis_user u LEFT JOIN depart d ON d.id = u.dpid $user_search ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {

		if ($data['user_admin'] == "2") {
			$a_user_level_name = "SuperAdmin";
		} else if ($data['user_admin'] == "1") {
			$a_user_level_name = "ผู้ดูแลระบบ";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "111") {
			$a_user_level_name = "หัวหน้า";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "110") {
			$a_user_level_name = "หัวหน้า";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "101") {
			$a_user_level_name = "ผู้รับรองรายงาน";
		} else if ($data['user_status'].$data['user_head'].$data['user_approve'] == "100") {
			$a_user_level_name = "สมาชิก";
		} else {
			$a_user_level_name = "ผู้ใช้HOSxP";
		}

		if ($data['user_status'] == "1") {
			$a_user_status = "ปกติ";
		} else {
			$a_user_status = "<font color='#ff0000'>ปิดการใช้งาน</font>";
		}

		if ($data['user_head'] == "1") {
			$a_head_checked = "";
		} else {
			$a_head_checked = "-o";
		}

		if ($data['user_admin'] == "2") {
			$a_is_superadmin = "YES";
			$a_admin_checked = "checked";
			$a_admin_redcolor1 = "<font color='#ff0000'>";
			$a_admin_redcolor2 = "</font>";
		} else if ($data['user_admin'] == "1") {
			$a_is_superadmin = "";
      $a_admin_checked = "checked";
			$a_admin_redcolor1 = "<font color='#ff00ff'>";
			$a_admin_redcolor2 = "</font>";
		} else {
			$a_is_superadmin = "";
      $a_admin_checked = "";
			$a_admin_redcolor1 = "";
			$a_admin_redcolor2 = "";
		}

			echo "<tr>";
			echo "<td class='mailbox-star'><input type='checkbox' ".$a_admin_checked.">&nbsp;&nbsp;&nbsp;";
			//echo "<td class='mailbox-star'>";
			echo "<a href='#'><i class='fa fa-star".$a_head_checked." text-yellow'></i></a>&nbsp;&nbsp;<img src='images/users/".$data['user_picture']."' height='25' class='img-circle' alt=''></td>";
			echo "<td class='mailbox-name'><span data-toggle='tooltip' title='ใช้งานล่าสุดเมื่อ ".DateTimeThai($data['last_login'])."'><b>".$a_admin_redcolor1.$data['m_namefull'].$a_admin_redcolor2."</b></span></td>";
			echo "<td class='mailbox-subject'>".$a_admin_redcolor1.$data['dp_name'].$a_admin_redcolor2."</td>";
			echo "<td class='mailbox-subject'>".$a_admin_redcolor1.$a_user_level_name.$a_admin_redcolor2."</td>";
			echo "<td class='mailbox-subject'>".$a_admin_redcolor1.$a_user_status.$a_admin_redcolor2."</td>";
			echo "<td class='mailbox-date'><div class='dropdown'>
<button class='btn btn-default dropdown-toggle'
class='drop-edit' data-toggle='dropdown'>
<i class='fa fa-cog'></i>
<span class='caret'></span>
</button>";

if ($a_is_superadmin == "YES") {
} else {

?>

<ul class='dropdown-menu'>
<li><a class="edit-misuser"
data-login_secure="<?php echo $data['login_secure']; ?>"
data-user_status="<?php echo $data['user_status']; ?>"
data-user_head="<?php echo $data['user_head']; ?>"
data-user_approve="<?php echo $data['user_approve']; ?>"
data-m_namefull="<?php echo $data['m_namefull']; ?>"
data-m_email="<?php echo $data['m_email']; ?>"
data-m_phoneno="<?php echo $data['m_phoneno']; ?>"
data-dpid="<?php echo $data['dpid']; ?>">แก้ไข</a></li>
<li><a class="delete-misuser"
datad-login_secure="<?php echo $data['login_secure']; ?>"
datad-user_status="<?php echo $data['user_status']; ?>"
datad-user_head="<?php echo $data['user_head']; ?>"
datad-user_approve="<?php echo $data['user_approve']; ?>"
datad-m_namefull="<?php echo $data['m_namefull']; ?>"
datad-m_email="<?php echo $data['m_email']; ?>"
datad-m_phoneno="<?php echo $data['m_phoneno']; ?>"
datad-dpid="<?php echo $data['dpid']; ?>">ลบ</a></li>
</ul>

<?php
  
}
echo "</div></td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
<!-- 
				<tfoot>
                <tr>
                  <th><button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
                </tfoot>
 -->

                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>

          </div>
          <!-- /. box -->
        </div>

<!-- // Modal Edit User -->

        <div class="modal modal-success fade" id="Modal-edit-misuser">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">แก้ไขข้อมูลผู้ใช้</h4>
              </div>
              <div class="modal-body">

        <form action="?main=user&act=usersave" method="post">
			<div class="form-group">
                <label for="m_namefull"><i class="fa fa-user margin-r-5"></i>ชื่อ-สกุล:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" class="form-control" name="m_namefull" id="m_namefull">
                </div>
            </div>

			<div class="form-group">
                <label for="dpid"><i class="fa fa-home margin-r-5"></i>หน่วยงานที่ปฏิบัติงาน:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-home"></i>
                  </div>
<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='dpid' name='dpid'>";
		foreach($query as $data) {
			if ($data['id'] == "$dpid") { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['id']."' ".$eselected.">".$data['dp_name']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
                  <!-- <input type="text" class="form-control" name="dpid" id="dpid"> -->
                </div>
            </div>

                <div class="form-group">
                <label><i class="fa fa-crosshairs margin-r-5"></i>ตำแหน่ง/หน้าที่:</label>
                <br><label>
                  <input type="checkbox" name="1user_status" id="1user_status" class="minimal" value='1' checked> สถานะการใช้งาน</label>
                <br><label>
                  <input type="checkbox" name="1user_head" id="1user_head" class="minimal-red" value='1'> หัวหน้างาน</label>
                <br><label>
                  <input type="checkbox" name="1user_approve" id="1user_approve" class="flat-red" value='1'> ผู้รับรองรายงาน</label>
                </div>

				<div class="form-group">
                <label for="m_email"><i class="fa fa-envelope margin-r-5"></i>อีเมล์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>
                  <input type="email" class="form-control" name="m_email" id="m_email">
                </div>
              </div>

              <div class="form-group">
                <label for="m_phoneno"><i class="fa fa-mobile margin-r-5"></i>เบอร์โทรศัพท์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-phone"></i>
                  </div>
                  <input type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask name="m_phoneno" id="m_phoneno">
                </div>
              </div>

                <label for="login_secure"></label><input type="hidden" name="login_secure" id="login_secure">
                <label for="user_status"></label><input type="hidden" name="user_status" id="user_status">
                <label for="user_head"></label><input type="hidden" name="user_head" id="user_head">
                <label for="user_approve"></label><input type="hidden" name="user_approve" id="user_approve">
          </div>

			  </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal"> ปิด </button>
                <button name="submit_user_edit" id="submit_user_edit" value="modalsaveuser" type="submit" class="btn btn-primary"> บันทึก </button>
              </div>
            </div>
          </div>
        </div>
        </form>

<!-- Modal Edit User // -->

<!-- // Modal Delete User -->

        <div class="modal modal-warning fade" id="Modal-delete-misuser">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">ลบผู้ใช้งาน</h4>
              </div>
              <div class="modal-body">

        <form action="?main=user&act=usersave" method="post">
			<div class="form-group">
                <label for="dm_namefull"><i class="fa fa-user margin-r-5"></i>ชื่อ-สกุล:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" class="form-control" name="dm_namefull" id="dm_namefull">
                </div>
            </div>

			<div class="form-group">
                <label for="ddpid"><i class="fa fa-home margin-r-5"></i>หน่วยงานที่ปฏิบัติงาน:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-home"></i>
                  </div>
                  <input type="text" class="form-control" name="ddpid" id="ddpid">
                </div>
            </div>

                <div class="form-group">
                <label><i class="fa fa-crosshairs margin-r-5"></i>ตำแหน่ง/หน้าที่:</label>
                <br><label>
                  <input type="checkbox" name="user_status" class="minimal" checked> สถานะการใช้งาน
                </label>
                <br><label>
                  <input type="checkbox" name="user_head" class="minimal-red"> หัวหน้างาน
                </label>
                <br><label>
                  <input type="checkbox" name="user_approve" class="flat-red"> ผู้รับรองรายงาน
                </label>
                </div>

				<div class="form-group">
                <label for="dm_email"><i class="fa fa-envelope margin-r-5"></i>อีเมล์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>
                  <input type="email" class="form-control" name="dm_email" id="dm_email">
                </div>
              </div>

              <div class="form-group">
                <label for="dm_phoneno"><i class="fa fa-mobile margin-r-5"></i>เบอร์โทรศัพท์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-phone"></i>
                  </div>
                  <input type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask name="dm_phoneno" id="dm_phoneno">
                </div>
              </div>

                <label for="dlogin_secure"></label><input type="hidden" name="dlogin_secure" id="dlogin_secure">
                <label for="duser_status"></label><input type="hidden" name="duser_status" id="duser_status">
                <label for="duser_head"></label><input type="hidden" name="duser_head" id="duser_head">
                <label for="duser_approve"></label><input type="hidden" name="duser_approve" id="duser_approve">
          </div>

			  </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default pull-left" data-dismiss="modal"> ปิด </button>
                <button name="submit_user_delete" id="submit_user_delete" value="modaldeleteuser" type="submit" class="btn btn-danger" onClick="return confirm('คุณแน่ใจที่จะลบผู้ใช้คนนี้');"> ลบผู้ใช้ </button>
              </div>
            </div>
          </div>
        </div>
        </form>

<!-- Modal Delete User // -->

<?php } else {include 'error505.php';} ?>
