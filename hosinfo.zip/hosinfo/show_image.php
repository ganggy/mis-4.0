<?php
header("Content-type: image/jpeg");

	try {
		include '_cfg_hos.php';

		$sql = "SELECT image FROM patient_image WHERE hn = '".$_GET['hn']."'  ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			echo $row['image'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
