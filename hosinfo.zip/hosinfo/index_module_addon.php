	  <div class="row">

		<div class="col-md-6">
		<!-- // content col1 -->


		<!-- content col1 // -->
		</div>
		<div class="col-md-6">
		<!-- // content col2 -->


		<!-- content col2 // -->
		</div>

	  </div>
	  <!-- /.row -->
