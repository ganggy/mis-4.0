<?php
if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

<!-- // Upload file -->
<?php
$ddate = date("YmdHis");
$target_dir = "images/users/";
$target_file = $target_dir.$_POST['user_login_user']."-".$ddate."-".basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit_user_picture"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 1000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ".$_POST['user_login_user']."-".basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			  $firename_user_picture = $_POST['user_login_user']."-".$ddate."-".basename( $_FILES["fileToUpload"]["name"]);
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>
<!-- Upload file // -->

<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

<?php

if ($_POST['submit_user_regist'] == "regist") {

$reg_last_update = date("Y-m-d H:i:s");
if ($user_regis_mis <= 0) {
    $user_admin = 2;
    $user_head = 1;
    $user_approve = 1;
} else {
    $user_admin = 0;
    $user_head = 0;
    $user_approve = 0;
}

try {
	include "_cfg_mis40db.php";
	$sql = "INSERT INTO mis_user (m_login,dpid,m_namefull,m_realname,user_status,user_head,user_approve,user_admin,m_email,m_phoneno,login_secure,user_subject,user_descript,regist_date,user_picture) 
	VALUES ('".$_POST['user_login_user']."','".$_POST['user_department']."','".$_POST['user_fullname']."','".$_POST['user_realname']."','1','".$user_head."','".$user_approve."','".$user_admin."','".$_POST['user_email']."','".$_POST['user_phoneno']."','".$_POST['user_login_secure']."','".$_POST['user_subject']."','".$_POST['user_descript']."','".$reg_last_update."','".$firename_user_picture."')";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ลงทะเบียนเรียบร้อยแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! ลงทะเบียนไม่สำเร็จ');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>


<?php

if ($_POST['submit_user_update'] == "update") {

$up_user = $_POST['user_login_user'];
$up_fullname = $_POST['user_fullname'];
$up_realname = $_POST['user_realname'];
$up_email = $_POST['user_email'];
$up_phoneno = $_POST['user_phoneno'];
$up_subject = $_POST['user_subject'];
$up_descript = $_POST['user_descript'];
$up_department = $_POST['user_department'];
$up_last_update = date("Y-m-d H:i:s");
$chk_login_secure = $_POST['user_login_secure'];

if ($firename_user_picture == "") {
	$u_picture = $mis_u_user_picture;
} else {
	$u_picture = $firename_user_picture;
}

try {
	include "_cfg_mis40db.php";
	$sql = "UPDATE mis_user SET dpid='$up_department',m_namefull='$up_fullname',m_realname='$up_realname',m_email='$up_email',m_phoneno='$up_phoneno',user_subject='$up_subject',user_descript='$up_descript',last_update='$up_last_update',user_picture='$u_picture' WHERE login_secure='$chk_login_secure' ";

	if ($myPDO->query($sql)) {
		echo "<script type= 'text/javascript'>alert('ปรับปรุงข้อมูลของคุณแล้ว');</script>";
	} else {
		echo "<script type= 'text/javascript'>alert('ERROR!!! เกิดปัญหาบางอย่าง');</script>";
	}

//$myPDO = null;
}
catch(PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
}

//**************//
} else {}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv=refresh content=0;URL="<?php echo $wwwurl;?>/?main=profile">
</head>
<body>
</body>
</html>

    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } ?>


