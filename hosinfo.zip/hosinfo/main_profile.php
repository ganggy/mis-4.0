<?php
if ($_SESSION["login_encode"] == "") {include 'error505.php';} else {
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        ข้อมูลสมาชิก
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">ข้อมูลสมาชิก</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <div class="row">
        <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
			  <!-- <img src="main_profile_show_user_img.php" class="img-circle" alt=""> -->
<?php
if ($login_ok == 1) {
		if ($mis_u_user_picture == "") {
				if ($_sex == 1) {
					echo "<img src='dist/img/user-icon-image-man.jpg' class='profile-user-img img-responsive img-circle' alt=''>";
				} else {
					echo "<img src='dist/img/user-icon-image-women.jpg' class='profile-user-img img-responsive img-circle' alt=''>";
				}
		} else {
			echo "<img src='images/users/".$mis_u_user_picture."' class='profile-user-img img-responsive img-circle' alt=''>";
		}
} else {
	echo "<img src='dist/img/guestuser.png' class='img-circle' alt=''>";
}
?>

              <h3 class="profile-username text-center"><?php echo $ok_login_name;?></h3>
              <h3 class="profile-username text-center"><?php echo $ok_login_user;?></h3>
              <p class="text-muted text-center"><?php echo $_entryposition;?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b><?php echo $_cid;?></b> <a class="pull-right">เลขที่บัตรประชาชน</a>
                </li>
                <li class="list-group-item">
                  <b><?php echo LongDateThai($_birth_date);?></b> <a class="pull-right">วัน-เดือน-ปี เกิด</a>
                </li>
                <li class="list-group-item">
                  <b><?php echo $_pname."".$_fname."  ".$_lname;?></b> <a class="pull-right">ชื่อ-สกุล</a>
                </li>
                <li class="list-group-item">
                  <b><?php echo $_licenseno;?>&nbsp;</b> <a class="pull-right">เลขที่ใบประกอบโรคศิลป์</a>
                </li>
                <li class="list-group-item">
                  <b><?php echo $mis_user_level_name;?></b> <a class="pull-right">ระดับผู้ใช้งาน</a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-success">
            <div class="box-header with-border">
              <h3 class="box-title">ข้อมูลอื่นๆ</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

              <strong><i class="fa fa-map-marker margin-r-5"></i> ที่อยู่</strong>
              <p class="text-muted"><?php echo $mis_u_user_subject;?></p>

			  <hr>
              <strong><i class="fa fa-book margin-r-5"></i> คติประจำใจ ข้อคิดในการทำงาน</strong>
              <p class="text-muted"><?php echo $mis_u_user_descript;?></p>


			</div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
		          <!-- quick email widget -->
          <div class="box box-danger">
            <div class="box-header">
              <i class="fa fa-user"></i>

              <h3 class="box-title">ข้อมูล : <?php echo $mis_u_m_namefull;?> (<?php echo $mis_user_level_name;?>)</h3>
              <!-- tools box -->

              <div class="pull-right box-tools">
			  <!-- 
                  <button type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-bars"></i></button>
                  <ul class="dropdown-menu pull-right" role="menu">
                    <li><a href="#">Add new event</a></li>
                    <li><a href="#">Clear events</a></li>
                    <li class="divider"></li>
                    <li><a href="#">View calendar</a></li>
                  </ul>
				   -->
				<button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip" title=" ย่อ "><i class="fa fa-minus"></i></button>
                <!-- <button type="button" class="btn btn-info btn-sm" data-widget="remove" data-toggle="tooltip" title=" ปิด "><i class="fa fa-times"></i></button> -->
              </div>
              <!-- /. tools -->
            </div>
            <div class="box-body">

			<?php
			if($login_secure_ok == "") {
				$m_namefull_ok = $_pname.$_fname."  ".$_lname;
			} else {
				$m_namefull_ok = $mis_u_m_namefull;
			}
			?>

    <form action="?main=profileup" method="post" enctype="multipart/form-data">

			<div class="form-group">
                <label><i class="fa fa-user margin-r-5"></i>ชื่อ-สกุล:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-user"></i>
                  </div>
                  <input type="text" class="form-control" name="user_fullname" placeholder="ชื่อ-สกุล" value="<?php echo $m_namefull_ok;?>">
                  <input type="hidden" name="user_realname" value="<?php echo $_pname."".$_fname."  ".$_lname;?>">
                </div>
            </div>

            <section>
            <div class="form-group">
				<label><i class="fa fa-file-image-o margin-r-5"></i>เลือกภาพสมาชิก</label>
				<div class="input-group">
					<div class="input-group-addon">
						<i class="fa fa-file-image-o"></i>
					</div>
					<!-- <input id="fileToUpload" type="file" name="fileToUpload" multiple /> -->
					<input id="fileToUpload" type="file" name="fileToUpload" />
					<script>
						$('#fileToUpload').fileselect({
							//allowedNumberOfFiles: 3, // default: false, no limitation
							allowedFileExtensions: ['jpg','jpeg','png','gif'], // default: false, all extensions allowed
							allowedFileSize: 2048000 // 2MB, default: false, no limitation
						});
					</script>
				</div>
            </div>
            </section>

<!-- 
			<div class="form-group">
                <label><i class="fa fa-file margin-r-5"></i>รูปภาพสมาชิก</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-file"></i>
                  </div>
                  <input type="file" name="fileToUpload" id="fileToUpload" class="form-control"><span class="custom-file-control"></span>
                </div>
            </div>
 -->
            <div class="form-group">
                <label><i class="fa fa-home margin-r-5"></i>หน่วยงานที่ปฏิบัติงาน:</label>
                <div class="input-group">
				  <div class="input-group-addon">
                    <i class="fa fa-home"></i>
                  </div>

<?php
	try {
		include "_cfg_mis40db.php";
		$sql = "SELECT * FROM depart WHERE dp_status <> 0";
		$query = $myPDO->query($sql);
			echo "<select class='form-control select2' style='width: 100%;' id='user_department' name='user_department'>";

		foreach($query as $data) {
			if ($data['id'] == $mis_u_m_depart) { $eselected = "selected"; } else { $eselected = ""; }
			echo "<option value='".$data['id']."'".$eselected.">".$data['dp_name']."</option>";
		}
			echo "</select>";

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>
              </div>
            </div>
                <div class="form-group">
                <label><i class="fa fa-crosshairs margin-r-5"></i>ตำแหน่ง/หน้าที่: <font  color="#ff0000">(ส่วนนี้ผู้ดูแลระบบจะกำหนดให้)</font></label>
                <br><label>
                  <input type="checkbox" name="user_status" class="minimal" checked disabled> สมาชิก
                </label>
                <br><label>
                  <input type="checkbox" name="user_head" class="minimal-red"  disabled <?php if ($mis_u_user_head == 1) {echo "checked";};?>> หัวหน้างาน
                </label>
                <br><label>
                  <input type="checkbox" name="user_approve" class="flat-red"  disabled <?php if ($mis_u_user_approve == 1) {echo "checked";};?>> ผู้รับรองรายงาน
                </label>

                </div>

				<div class="form-group">
                <label><i class="fa fa-envelope margin-r-5"></i>อีเมล์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-envelope"></i>
                  </div>
                  <input type="email" class="form-control" name="user_email" placeholder="Email" value="<?php echo $mis_u_m_email;?>">
                </div>
              </div>

              <div class="form-group">
                <label><i class="fa fa-mobile margin-r-5"></i>เบอร์โทรศัพท์:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-phone"></i>
                  </div>
                  <input name="user_phoneno" type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask value="<?php echo $mis_u_m_phoneno;?>">
                </div>
              </div>

			  <div class="form-group">
                <label><i class="fa fa-commenting-o margin-r-5"></i>ที่อยู่:</label>
                <div class="input-group">
                  <div class="input-group-addon">
                    <i class="fa fa-commenting-o"></i>
                  </div>
                  <input type="text" class="form-control" name="user_subject" placeholder="บ้านเลขที่ หมู่ ตำบล อำเภอ จังหวัด" value="<?php echo $mis_u_user_subject;?>">
                </div>
              </div>

			        <div class="form-group">
                <label><i class="fa fa-comments-o margin-r-5"></i>คติประจำใจ ข้อคิดในการทำงาน:</label>
                  <textarea name="user_descript" class="textarea" placeholder="พิมพ์ข้อความข้อคิดในการทำงาน" 
				  style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo $mis_u_user_descript;?></textarea>
              </div>
 
			<input type="hidden" name="user_login_secure" value="<?php echo $ok_login_secure;?>">
			<input type="hidden" name="user_login_user" value="<?php echo $ok_login_user;?>">
			<input type="hidden" name="mis_u_user_picture" value="<?php echo $mis_u_user_picture;?>">
			<input type="hidden" name="submit_user_picture" value="submit_user_picture">

            <div class="box-footer clearfix">
			<?php
			if($login_secure_ok == "") {
				echo "<button type='submit' class='pull-right btn btn-danger' id='submit_user_regist' name='submit_user_regist' value='regist'> ลงทะเบียน <i class='fa fa-arrow-circle-right'></i></button>";
			} else {
				echo "<button type='submit' class='pull-right btn btn-info' id='submit_user_update' name='submit_user_update' value='update'> ปรับปรุงข้อมูล <i class='fa fa-arrow-circle-right'></i></button>";
			}
			?>
            </div>
          </div>
        </form>

		</div>
		<!-- /.col -->
      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } ?>