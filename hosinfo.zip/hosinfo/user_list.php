
		<div class="col-md-9">
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">รายชื่อเจ้าหน้าที่</h3>

              <!-- /.box-tools -->
            </div>
            <!-- /.box-header -->
            <div class="box-body no-padding">
              <div class="mailbox-controls">
                <!-- Check all button -->

                <!-- /.pull-right -->
              </div>
              <div class="table-responsive mailbox-messages">
                <table class="table table-hover table-striped">
                <thead>
                <tr>
                  <th></th>
                  <th>ชื่อ-นามสกุล</th>
                  <th>ตำแหน่ง-หน่วยงาน</th>
                  <th>ผู้รับรอง</th>
                  <th>Edit</th>
                </tr>
                 </thead>
				  <tbody>

<?php

	try {
		include "_cfg_mis40db.php";
		// คำสั่ง SQL
		$sql = "SELECT * FROM mis_user ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			echo "<tr>";
			echo "<td class='mailbox-star'><input type='checkbox'>&nbsp;&nbsp;&nbsp;";
			echo "<a href='#'><i class='fa fa-star-o text-yellow'></i></a></td>";
			echo "<td class='mailbox-name'><span data-toggle='tooltip' title='ใช้งานล่าสุดเมื่อ ...' class='badge bg-light-blue'><a href='#'>".$data['m_namefull']."</a> 3</span></td>";
			echo "<td class='mailbox-subject'><b>".$data['dpid']."</b> (".$data['user_head'].")</td>";
			echo "<td class='mailbox-attachment'>".$data['user_approve']."</td>";
			echo "<td class='mailbox-date'><div class='dropdown'>
<button class='btn btn-default dropdown-toggle'
class='drop-edit' data-toggle='dropdown'>
<i class='fa fa-cog'></i>
<span class='caret'></span>
</button>
<ul class='dropdown-menu'>
<li><a href='#'>แก้ไข</a></li>
<li><a href='#'>ลบ</a></li>
</ul>
</div></td>";
			echo "</tr>";
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

				<tfoot>
                <tr>
                  <th><button type="button" class="btn btn-default btn-sm checkbox-toggle"><i class="fa fa-square-o"></i></button>
<button type="button" class="btn btn-default btn-sm"><i class="fa fa-trash-o"></i></button></th>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                </tr>
                </tfoot>


                  </tbody>
                </table>
                <!-- /.table -->
              </div>
              <!-- /.mail-box-messages -->
            </div>

          </div>
          <!-- /. box -->
        </div>

