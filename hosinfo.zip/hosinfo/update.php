<?php

	try {
		include '_cfg_mis40db.php';
		$sql1 = "SELECT COUNT(*) AS cupdate FROM sys_update ";
		$query1 = $myPDO->query($sql1);

		foreach($query1 as $data1) {
			$cupdate = $data1['cupdate'];
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

              <!-- DIRECT CHAT -->
              <div class="box box-warning direct-chat direct-chat-warning">
                <div class="box-header with-border">
				<i class="fa fa-bullhorn"></i>
                  <h3 class="box-title">ประกาศ</h3>

                  <div class="box-tools pull-right">
                    <span data-toggle="tooltip" title="<?php echo $cupdate; ?> ข้อความ" class="badge bg-yellow"><?php echo $cupdate; ?></span>
                    <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                    </button>
                    <button type="button" class="btn btn-box-tool" data-toggle="tooltip" title="ติดต่อผู้พัฒนา"
                            data-widget="chat-pane-toggle">
                      <i class="fa fa-comments"></i></button>
                    <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i>
                    </button>
                  </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <!-- Conversations are loaded here -->
                  <div class="direct-chat-messages">

<?php

	try {
		include '_cfg_mis40db.php';
	    $sql = "SELECT c.*,u.* FROM sys_update c LEFT JOIN mis_user u ON u.m_login = c.sysuser ORDER BY id DESC ";
		$query = $myPDO->query($sql);

		foreach($query as $data) {
			if ($data['user_picture'] == "") {
				if ($data['sysuser'] == "ghost") {$userpicture = "images/ghost_50.jpg";} else {$userpicture = "dist/img/guestuser.png";}
			} else {
				$userpicture = "images/users/".$data['user_picture'];
			}

		if ($data['position'] == "r") {
?>
                    <!-- Message to the right -->
                    <div class="direct-chat-msg right">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-right"><?php echo $data['sysuser'];?></span>
                        <span class="direct-chat-timestamp pull-left"><i class="fa fa-clock-o"></i> <?php echo DateTimeThai($data['sysupdate']);?></span>
                      </div>
                      <img class="direct-chat-img" src="<?php echo $userpicture;?>" alt="">
                      <div class="direct-chat-text">
                        <?php echo $data['updatetext'];?>
                      </div>
                    </div>
<?php } else {?>
					<!-- Message. Default to the left -->
                    <div class="direct-chat-msg">
                      <div class="direct-chat-info clearfix">
                        <span class="direct-chat-name pull-left"><?php echo $data['sysuser'];?></span>
                        <span class="direct-chat-timestamp pull-right"><i class="fa fa-clock-o"></i> <?php echo DateTimeThai($data['sysupdate']);?></span>
                      </div>
                      <img class="direct-chat-img" src="<?php echo $userpicture;?>" alt="">
                      <div class="direct-chat-text">
                        <?php echo $data['updatetext'];?>
                      </div>
                    </div>
<?php
					}
		}
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

                  </div>
                  <!--/.direct-chat-messages-->

                  <!-- Contacts are loaded here -->
                  <div class="direct-chat-contacts">
                    <ul class="contacts-list">
                      <li>
                        <a href="#">
                          <img class="contacts-list-img" src="https://mis.tphcp.go.th/images/users/ghost-20180403134833-63601.jpg" alt="ghost">

                          <div class="contacts-list-info">
                                <span class="contacts-list-name">
                                  ณัฐพงศ์  เครือเทศ (ghost)
                                  <small class="contacts-list-date pull-right"><a href="https://mis.tphcp.go.th/?main=update">Last update</a></small>
                                </span>
                            <span class="contacts-list-msg">phichitonline@gmail.com<br>โทรศัพท์ 061-9921666</span>
                                <span class="contacts-list-name">
                                  Line ID : 0619921666 <br>
                                  <small class="contacts-list-date pull-right">QR Code</small>
                                </span>
                          <img src="https://mis.tphcp.go.th/images/0619921666.png" alt="">
                          </div>
                          <!-- /.contacts-list-info -->
                        </a>
                      </li>
                      <!-- End Contact Item -->
                    </ul>
                    <!-- /.contatcts-list -->
                  </div>
                  <!-- /.direct-chat-contacts -->
                </div>
                <!-- /.box-body -->
<?php
if ($mis_user_level >= 4) {
?>
                <div class="box-footer">
                  <form action="main_update_up.php" method="POST">
                    <div class="input-group">
                        <span class="input-group-addon">
                          <input type="checkbox" name="position" value="r">
                        </span>
                      <input type="text" name="updatetext" placeholder="<-- ติ๊ก กำหนดให้แสดงทางขวา" class="form-control">
                      <input type="hidden" name="login_user" value="<?php echo $ok_login_user; ?>">

                      <span class="input-group-btn">
                            <button type="submit" class="btn btn-info btn-flat">Send</button>
                          </span>
                    </div>
                  </form>
                </div>
<?php
	} else {}
?>
              </div>
              <!--/.direct-chat -->
