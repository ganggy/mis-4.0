  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->

    <!-- Main content -->
    <section class="content">

      <div class="error-page">
        <h2 class="headline text-red"><i class="fa fa-warning text-red"></i> Owner only!</h2>
      </div>

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
