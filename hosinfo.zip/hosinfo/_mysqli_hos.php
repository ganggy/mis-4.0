<?php
$host = "192.168.2.254";
$user = "opd";
$pwd = "opd";
$db = "hos";

$con = new mysqli($host, $user, $pwd, $db);
$con->set_charset("utf8");

?>