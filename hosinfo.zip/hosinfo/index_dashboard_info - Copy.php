<?php
// รหัสแผนกรับบริการกายภาพบำบัด
// รหัสแผนกรับบริการแพทย์แผนไทย
// ทันตกรรม นับเฉพาะผู้รับบริการที่ทำหัตถการ หรือตรวจทันตสุขภาพ (ข้อมูลจากตาราง dtmain)
// อุบัติเหตุ จะดูจากชนิดการมาห้องฉุกเฉิน (ดูจากตาราง er_pt_type ที่มีฟิลด์ accident_code = 'Y')
// จำนวนเตียงทั้งหมดเพื่อคำนวนอัตราการครองเตียง (SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')

  try {

		include '_cfg_hos.php';

		$sql1 = "SELECT COUNT(DISTINCT hn) AS ptm_opd_hn,COUNT(DISTINCT vn) AS ptm_opd_vn
    ,COUNT(DISTINCT IF(vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d'),vn,NULL)) AS pt_opd_today
    FROM ovst
    WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query1 = $myPDO->query($sql1);
		foreach($query1 as $data1) {
			$ptm_opd_hn = $data1['ptm_opd_hn'];
			$ptm_opd_vn = $data1['ptm_opd_vn'];
			$pt_opd_today = $data1['pt_opd_today'];
      }
      
		$sql2 = "SELECT COUNT(DISTINCT hn) AS ptm_phy_hn,COUNT(DISTINCT vn) AS ptm_phy_vn
    ,COUNT(DISTINCT IF(vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d'),vn,NULL)) AS pt_phy_today
    FROM physic_main
    WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $data2) {
			$ptm_phy_hn = $data2['ptm_phy_hn'];
			$ptm_phy_vn = $data2['ptm_phy_vn'];
			$pt_phy_today = $data2['pt_phy_today'];
    }
    
		$sql6 = "SELECT COUNT(DISTINCT hn) AS ptm_ipd_hn,COUNT(DISTINCT an) AS ptm_ipd_an
    ,COUNT(DISTINCT IF(regdate = DATE_FORMAT(NOW(),'%Y-%m-%d'),an,NULL)) AS pt_ipd_today
    FROM ipt
    WHERE regdate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')";
		$query6 = $myPDO->query($sql6);
		foreach($query6 as $data6) {
      $ptm_ipd_hn = $data6['ptm_ipd_hn'];
      $ptm_ipd_an = $data6['ptm_ipd_an'];
      $pt_ipd_today = $data6['pt_ipd_today'];
    }
    
		$sql7 = "SELECT COUNT(DISTINCT hn) AS ptm_dent_hn,COUNT(DISTINCT vn) AS ptm_dent_vn
    ,COUNT(DISTINCT IF(vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d'),vn,NULL)) AS pt_dent_today
    FROM dtmain
    WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query7 = $myPDO->query($sql7);
		foreach($query7 as $data7) {
      $ptm_dent_hn = $data7['ptm_dent_hn'];
      $ptm_dent_vn = $data7['ptm_dent_vn'];
      $pt_dent_today = $data7['pt_dent_today'];
      }

		$sql8 = "SELECT COUNT(DISTINCT hn) AS ptm_ttm_hn,COUNT(DISTINCT vn) AS ptm_ttm_vn
    ,COUNT(DISTINCT IF(service_date = DATE_FORMAT(NOW(),'%Y-%m-%d'),vn,NULL)) AS pt_ttm_today
    FROM health_med_service
    WHERE service_date BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')
    AND in_hospcode_service = 'Y' ";
		$query8 = $myPDO->query($sql8);
		foreach($query8 as $data8) {
      $ptm_ttm_hn = $data8['ptm_ttm_hn'];
      $ptm_ttm_vn = $data8['ptm_ttm_vn'];
      $pt_ttm_today = $data8['pt_ttm_today'];
      }
      
		$sql3 = "SELECT COUNT(DISTINCT o.hn) AS ptm_er_hn,COUNT(DISTINCT o.vn) AS ptm_er_vn
    ,COUNT(DISTINCT IF(er.vstdate = DATE_FORMAT(NOW(),'%Y-%m-%d'),o.vn,NULL)) AS pt_er_today
        FROM er_regist er 
        LEFT OUTER JOIN ovst o ON o.vn = er.vn
        LEFT OUTER JOIN er_pt_type et ON et.er_pt_type = er.er_pt_type 
        WHERE er.vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')
        AND er.er_pt_type IN (SELECT er_pt_type FROM er_pt_type WHERE accident_code = 'Y') ";
		$query3 = $myPDO->query($sql3);
		foreach($query3 as $data3) {
			$ptm_er_hn = $data3['ptm_er_hn'];
			$ptm_er_vn = $data3['ptm_er_vn'];
			$pt_er_today = $data3['pt_er_today'];
    }
    
		$sql4 = "SELECT COUNT(DISTINCT hn) AS ptm_or_hn
    ,COUNT(hn) AS ptm_or_vn
    ,COUNT(IF(patient_department = 'OPD',vn,NULL)) AS ptm_or_opd
    ,COUNT(IF(patient_department = 'IPD',an,NULL)) AS ptm_or_ipd
    ,COUNT(IF(operation_date = DATE_FORMAT(NOW(),'%Y-%m-%d'),hn,NULL)) AS pt_or_today
    FROM operation_list
    WHERE operation_date BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query4 = $myPDO->query($sql4);
		foreach($query4 as $data4) {
			$ptm_or_hn = $data4['ptm_or_hn'];
			$ptm_or_vn = $data4['ptm_or_vn'];
			$ptm_or_opd = $data4['ptm_or_opd'];
			$ptm_or_ipd = $data4['ptm_or_ipd'];
			$pt_or_today = $data4['pt_or_today'];
    }
    
		$sql5 = "SELECT COUNT(DISTINCT hn) AS ptm_xray_hn,COUNT(vn) AS ptm_xray_vn
    ,COUNT(IF(examined_date = DATE_FORMAT(NOW(),'%Y-%m-%d'),vn,NULL)) AS pt_xray_today
    FROM xray_report
    WHERE examined_date BETWEEN DATE_FORMAT(NOW(),'%Y-%m-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query5 = $myPDO->query($sql5);
		foreach($query5 as $data5) {
			$ptm_xray_hn = $data5['ptm_xray_hn'];
			$ptm_xray_vn = $data5['ptm_xray_vn'];
			$pt_xray_today = $data5['pt_xray_today'];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php echo number_format($pt_opd_today,0);?></h3>
              <p>ผู้รับบริการวันนี้ <br>(เดือนนี้ <?php echo number_format($ptm_opd_hn,0);?> คน / <?php echo number_format($ptm_opd_vn,0);?> ครั้ง)</p>
            </div>
            <div class="icon">
              <i class="fa fa-stethoscope"></i>
            </div>
            <a href="?kpi=501" class="small-box-footer">รายละเอียด <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo number_format($pt_ipd_today,0);?></h3>
              <p>Admit วันนี้ (เดือนนี้ <br>(เดือนนี้ <?php echo number_format($ptm_ipd_hn,0);?> คน / <?php echo number_format($ptm_ipd_an,0);?> ครั้ง)</p>
            </div>
            <div class="icon">
              <i class="fa fa-bed"></i>
            </div>
            <a href="?kpi=502" class="small-box-footer">รายละเอียด <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo number_format($pt_ttm_today,0);?></h3>
              <p>แพทย์แผนไทย วันนี้ <br>(เดือนนี้ <?php echo number_format($ptm_ttm_hn,0);?> คน / <?php echo number_format($ptm_ttm_vn,0);?> ครั้ง)</p>
            </div>
            <div class="icon">
              <i class="fa fa-quote-left"></i>
            </div>
            <a href="?kpi=503" class="small-box-footer">รายละเอียด  <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php echo number_format($pt_dent_today,0);?></h3>
              <p>ทันตกรรม วันนี้ <br>(เดือนนี้ <?php echo number_format($ptm_dent_hn,0);?> คน / <?php echo number_format($ptm_dent_vn,0);?> ครั้ง)</p>
            </div>
            <div class="icon">
              <i class="fa fa-hand-paper-o"></i>
            </div>
            <a href="?kpi=504" class="small-box-footer">รายละเอียด  <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
        <!-- ./col -->
      </div>
      <!-- /.row -->

      <!-- Info boxes -->
      <div class="row">
        <div class="col-md-3 col-sm-6 col-xs-12">
		<a data-toggle="tooltip" title="คลิกดูรายละเอียด --> X-RAY" style="color:black;" href="?kpi=511">
          <div class="info-box">
            <span class="info-box-icon bg-aqua"><i class="fa fa-times"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">วันนี้ <?php echo number_format($pt_xray_today,0);?></span>
              <span class="info-box-text">X-RAY <br>เดือนนี้ <?php echo number_format($ptm_xray_hn,0);?> คน / <?php echo number_format($ptm_xray_vn,0);?> ครั้ง</span></a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->
        <div class="col-md-3 col-sm-6 col-xs-12">
		<a data-toggle="tooltip" title="คลิกดูรายละเอียด --> อุบัติเหตุ" style="color:black;" href="?kpi=505">
          <div class="info-box">
            <span class="info-box-icon bg-red"><i class="fa fa-ambulance"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">วันนี้ <?php echo number_format($pt_er_today,0);?></span>
              <span class="info-box-text">อุบัติเหตุ <br>เดือนนี้ <?php echo number_format($ptm_er_hn,0);?> คน / <?php echo number_format($ptm_er_hn,0);?> ครั้ง</span></a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <!-- fix for small devices only -->
        <!-- <div class="clearfix visible-sm-block"></div> -->

        <div class="col-md-3 col-sm-6 col-xs-12">
		<a data-toggle="tooltip" title="คลิกดูรายละเอียด --> กายภาพบำบัด" style="color:black;" href="?kpi=510">
          <div class="info-box">
            <span class="info-box-icon bg-green"><i class="fa fa-wheelchair"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">วันนี้ <?php echo number_format($pt_phy_today,0);?></span>
              <span class="info-box-text">กายภาพบำบัด <br>เดือนนี้ <?php echo number_format($ptm_phy_hn,0);?> คน / <?php echo number_format($ptm_phy_vn,0);?> ครั้ง</span></a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

        <div class="col-md-3 col-sm-6 col-xs-12">
		<a data-toggle="tooltip" title="คลิกดูรายละเอียด --> ผู้ป่วยผ่าตัด" style="color:black;" href="?kpi=506">
          <div class="info-box">
            <span class="info-box-icon bg-yellow"><i class="fa fa-heartbeat"></i></span>

            <div class="info-box-content">
              <span class="info-box-number">วันนี้ <?php echo number_format($pt_or_today,0);?></span>
              <span class="info-box-text">ผู้ป่วยผ่าตัด <br>เดือนนี้ <?php echo number_format($ptm_or_hn,0);?> คน / <?php echo number_format($ptm_or_vn,0);?> ครั้ง (OPD <?php echo number_format($ptm_or_opd,0);?> / IPD <?php echo number_format($ptm_or_ipd,0);?>))</span></a>
            </div>
            <!-- /.info-box-content -->
          </div>
          <!-- /.info-box -->
        </div>
        <!-- /.col -->

      </div>
      <!-- /.row -->

<?php
	if ($login_ok == 1) {
		include 'index_financial.php';
	}
?>

      <div class="row">
        <div class="col-md-12">
          <div class="box box-danger">
            <div class="box-header with-border">
            <i class="fa fa-yelp"></i><h3 class="box-title">โรคติดต่อที่สำคัญ</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				        <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="?kpi=508">ข้อมูลโรคติดต่อ</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">

                  <div class="chart">
                    <!-- Chart DHF -->

<?php
 $monthx = array(); // ตัวแปรแกน x
 $median = array(); //ตัวแปรแกน y
 $y2557 = array(); //ตัวแปรแกน y
 $y2558 = array(); //ตัวแปรแกน y
 $y2559 = array(); //ตัวแปรแกน y
 $y2560 = array(); //ตัวแปรแกน y
 $y2561 = array(); //ตัวแปรแกน y
 $y2562 = array(); //ตัวแปรแกน y
	try {
		include '_cfg_mis40db.php';

		$sql = "SELECT '01 มกราคม' AS monthname
,SUM(IF(year = 'median',m01,0)) AS median
,SUM(IF(year = '2556',m01,0)) AS y2556
,SUM(IF(year = '2557',m01,0)) AS y2557
,SUM(IF(year = '2558',m01,0)) AS y2558
,SUM(IF(year = '2559',m01,0)) AS y2559
,SUM(IF(year = '2560',m01,0)) AS y2560
,SUM(IF(year = '2561',m01,0)) AS y2561
,SUM(IF(year = '2562',m01,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '02 กุมภาพันธ์' AS monthname
,SUM(IF(year = 'median',m02,0)) AS median
,SUM(IF(year = '2556',m02,0)) AS y2556
,SUM(IF(year = '2557',m02,0)) AS y2557
,SUM(IF(year = '2558',m02,0)) AS y2558
,SUM(IF(year = '2559',m02,0)) AS y2559
,SUM(IF(year = '2560',m02,0)) AS y2560
,SUM(IF(year = '2561',m02,0)) AS y2561
,SUM(IF(year = '2562',m02,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '03 มีนาคม' AS monthname
,SUM(IF(year = 'median',m03,0)) AS median
,SUM(IF(year = '2556',m03,0)) AS y2556
,SUM(IF(year = '2557',m03,0)) AS y2557
,SUM(IF(year = '2558',m03,0)) AS y2558
,SUM(IF(year = '2559',m03,0)) AS y2559
,SUM(IF(year = '2560',m03,0)) AS y2560
,SUM(IF(year = '2561',m03,0)) AS y2561
,SUM(IF(year = '2562',m03,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '04 เมษายน' AS monthname
,SUM(IF(year = 'median',m04,0)) AS median
,SUM(IF(year = '2556',m04,0)) AS y2556
,SUM(IF(year = '2557',m04,0)) AS y2557
,SUM(IF(year = '2558',m04,0)) AS y2558
,SUM(IF(year = '2559',m04,0)) AS y2559
,SUM(IF(year = '2560',m04,0)) AS y2560
,SUM(IF(year = '2561',m04,0)) AS y2561
,SUM(IF(year = '2562',m04,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '05 พฤษภาคม' AS monthname
,SUM(IF(year = 'median',m05,0)) AS median
,SUM(IF(year = '2556',m05,0)) AS y2556
,SUM(IF(year = '2557',m05,0)) AS y2557
,SUM(IF(year = '2558',m05,0)) AS y2558
,SUM(IF(year = '2559',m05,0)) AS y2559
,SUM(IF(year = '2560',m05,0)) AS y2560
,SUM(IF(year = '2561',m05,0)) AS y2561
,SUM(IF(year = '2562',m05,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '06 มิถุนายน' AS monthname
,SUM(IF(year = 'median',m06,0)) AS median
,SUM(IF(year = '2556',m06,0)) AS y2556
,SUM(IF(year = '2557',m06,0)) AS y2557
,SUM(IF(year = '2558',m06,0)) AS y2558
,SUM(IF(year = '2559',m06,0)) AS y2559
,SUM(IF(year = '2560',m06,0)) AS y2560
,SUM(IF(year = '2561',m06,0)) AS y2561
,SUM(IF(year = '2562',m06,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '07 กรกฎาคม' AS monthname
,SUM(IF(year = 'median',m07,0)) AS median
,SUM(IF(year = '2556',m07,0)) AS y2556
,SUM(IF(year = '2557',m07,0)) AS y2557
,SUM(IF(year = '2558',m07,0)) AS y2558
,SUM(IF(year = '2559',m07,0)) AS y2559
,SUM(IF(year = '2560',m07,0)) AS y2560
,SUM(IF(year = '2561',m07,0)) AS y2561
,SUM(IF(year = '2562',m07,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '08 สิงหาคม' AS monthname
,SUM(IF(year = 'median',m08,0)) AS median
,SUM(IF(year = '2556',m08,0)) AS y2556
,SUM(IF(year = '2557',m08,0)) AS y2557
,SUM(IF(year = '2558',m08,0)) AS y2558
,SUM(IF(year = '2559',m08,0)) AS y2559
,SUM(IF(year = '2560',m08,0)) AS y2560
,SUM(IF(year = '2561',m08,0)) AS y2561
,SUM(IF(year = '2562',m08,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '09 กันยายน' AS monthname
,SUM(IF(year = 'median',m09,0)) AS median
,SUM(IF(year = '2556',m09,0)) AS y2556
,SUM(IF(year = '2557',m09,0)) AS y2557
,SUM(IF(year = '2558',m09,0)) AS y2558
,SUM(IF(year = '2559',m09,0)) AS y2559
,SUM(IF(year = '2560',m09,0)) AS y2560
,SUM(IF(year = '2561',m09,0)) AS y2561
,SUM(IF(year = '2562',m09,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '10 ตุลาคม' AS monthname
,SUM(IF(year = 'median',m10,0)) AS median
,SUM(IF(year = '2556',m10,0)) AS y2556
,SUM(IF(year = '2557',m10,0)) AS y2557
,SUM(IF(year = '2558',m10,0)) AS y2558
,SUM(IF(year = '2559',m10,0)) AS y2559
,SUM(IF(year = '2560',m10,0)) AS y2560
,SUM(IF(year = '2561',m10,0)) AS y2561
,SUM(IF(year = '2562',m10,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '11 พฤศจิกายน' AS monthname
,SUM(IF(year = 'median',m11,0)) AS median
,SUM(IF(year = '2556',m11,0)) AS y2556
,SUM(IF(year = '2557',m11,0)) AS y2557
,SUM(IF(year = '2558',m11,0)) AS y2558
,SUM(IF(year = '2559',m11,0)) AS y2559
,SUM(IF(year = '2560',m11,0)) AS y2560
,SUM(IF(year = '2561',m11,0)) AS y2561
,SUM(IF(year = '2562',m11,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '12 ธันวาคม' AS monthname
,SUM(IF(year = 'median',m12,0)) AS median
,SUM(IF(year = '2556',m12,0)) AS y2556
,SUM(IF(year = '2557',m12,0)) AS y2557
,SUM(IF(year = '2558',m12,0)) AS y2558
,SUM(IF(year = '2559',m12,0)) AS y2559
,SUM(IF(year = '2560',m12,0)) AS y2560
,SUM(IF(year = '2561',m12,0)) AS y2561
,SUM(IF(year = '2562',m12,0)) AS y2562
FROM rep_506_dhf ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
			 array_push($median,$row[median]);
			 array_push($y2557,$row[y2557]);
			 array_push($y2558,$row[y2558]);
			 array_push($y2559,$row[y2559]);
			 array_push($y2560,$row[y2560]);
			 array_push($y2561,$row[y2561]);
			 array_push($y2562,$row[y2562]);
			 array_push($monthx,$row[month]);
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<div id="container" style="min-width: 310px; height: 400px; margin: 0 auto"></div>

<script type="text/javascript">
Highcharts.chart('container', {
    chart: {
        type: 'spline'
    },
    title: {
        text: 'สถานการณ์โรคไข้เลือดออก'
    },
    subtitle: {
        text: 'อำเภอตะพานหิน จังหวัดพิจิตร'
    },
    xAxis: {
        categories: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน','กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
    },
    yAxis: {
        title: {
            text: 'จำนวนผู้ป่วย (ราย)'
        }
    },
	tooltip: {
		crosshairs: true,
		shared: true
	},
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            marker: {
				radius: 4,
				lineColor: '#666666',
				lineWidth: 1
			},
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Medien',
        color: '#ff9900',
        type: 'areaspline',
        marker: {
			symbol: 'square'
        },
        data: [<?= implode(',', $median) ?>]
    }, {
        name: 'ปี 2557',
        data: [<?= implode(',', $y2557) ?>]
    }, {
        name: 'ปี 2558',
        data: [<?= implode(',', $y2558) ?>]
    }, {
        name: 'ปี 2559',
        data: [<?= implode(',', $y2559) ?>]
    }, {
        name: 'ปี 2560',
        data: [<?= implode(',', $y2560) ?>]
    }, {
        name: 'ปี 2561',
        data: [<?= implode(',', $y2561) ?>]
    }, {
        name: 'ปี 2562',
        data: [<?= implode(',', $y2562) ?>]
    }]
});
</script>

                  </div>
                  <!-- /.chart-DHF -->


                </div>
                <!-- /.col -->
                <div class="col-md-4">
                  <p class="text-center">
                    <strong>อันดับโรคติดต่อที่ต้องรายงานเดือนนี้</strong>
                  </p>

                <table class="table table-hover table no-margin">
                  <thead>
                  <tr>
                    <th>รหัส506</th>
                    <th>ชื่อโรค</th>
                    <th>จำนวน(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT n.code506,p.name AS namee,n.name AS namet,COUNT(*) AS count506
		FROM surveil_member s 
		LEFT OUTER JOIN provis_code506 p ON p.code = s.code506
		LEFT OUTER JOIN name506 n ON n.code = s.code506
		WHERE DATE_FORMAT(s.vstdate,'%Y-%m') = DATE_FORMAT(NOW(),'%Y-%m') 
		GROUP BY s.code506 
		ORDER BY COUNT(*) DESC
		LIMIT 10";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

            echo "      <tr>";
            echo "        <td class='text-center'>".$row[code506]."</td>";
            echo "        <td>".$row[namet]." ".$row[namee]."</td>";
            echo "        <td class='text-right'><span class='label label-danger'> ".$row[count506]." </span></td>";
            echo "      </tr>";

		}
		$sql2 = "SELECT t.vstyear,SUM(t.count506) AS count506,SUM(t.dhf) AS dhf,SUM(t.fu) AS fu,SUM(t.food) AS food,SUM(t.diarrhea) AS diarrhea
    ,SUM(t.count5062) AS count5062,SUM(t.dhf2) AS dhf2,SUM(t.fu2) AS fu2,SUM(t.food2) AS food2,SUM(t.diarrhea2) AS diarrhea2 FROM (
    SELECT DATE_FORMAT(vstdate,'%Y') AS vstyear
        ,COUNT(*) AS count506
        ,SUM(IF(code506 = '66',1,0)) AS dhf
        ,SUM(IF(code506 = '15',1,0)) AS fu
        ,SUM(IF(code506 = '3',1,0)) AS food
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea
        ,'' AS count5062,'' AS dhf2,'' AS fu2,'' AS food2,'' AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')
    UNION
    SELECT DATE_FORMAT(vstdate,'%Y')+1 AS vstyear
        ,'' AS count506,'' AS dhf,'' AS fu,'' AS food,'' AS diarrhea
        ,COUNT(*) AS count5062
        ,SUM(IF(code506 = '66',1,0)) AS dhf2
        ,SUM(IF(code506 = '15',1,0)) AS fu2
        ,SUM(IF(code506 = '3',1,0)) AS food2
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-01-01')) AND CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-%m-%d'))
    ) AS t
    GROUP BY vstyear ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $row2) {
			$cd_year = $row2[vstyear];
			$cd_count506 = $row2[count506];
			$cd_dhf = $row2[dhf];
			$cd_fu = $row2[fu];
			$cd_food = $row2[food];
      $cd_diarrhea = $row2[diarrhea];
      $cd_count5062 = $row2[count5062];
			$cd_dhf2 = $row2[dhf2];
			$cd_fu2 = $row2[fu2];
			$cd_food2 = $row2[food2];
			$cd_diarrhea2 = $row2[diarrhea2];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_dhf >= $cd_dhf2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_dhf >= $cd_dhf2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_dhf >= $cd_dhf2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_dhf*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_dhf;?></h5>
                    <span class="description-text">Dengue Fever</span> (<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_fu >= $cd_fu2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_fu >= $cd_fu2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_fu >= $cd_fu2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_fu*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_fu;?></h5>
                    <span class="description-text">Influenza,(FU)</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_food >= $cd_food2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_food >= $cd_food2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_food >= $cd_food2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_food*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_food;?></h5>
                    <span class="description-text">Food Poisoning</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                  <a data-toggle="tooltip" title="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_diarrhea*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_diarrhea;?></h5>
                    <span class="description-text">Diarrhea</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->



<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT COUNT(*) AS wtotal
    ,(SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')-COUNT(*) AS wblank
    FROM ipt WHERE dchdate IS NULL ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_wtotal = $data['wtotal'];
			$ipt_wblank = $data['wblank'];
			}

		$sql = "SELECT COUNT(*) AS admittoday FROM ipt WHERE regdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admittoday = $data['admittoday'];
			}

		$sql = "SELECT COUNT(*) AS dchtoday FROM ipt WHERE dchdate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_dchtoday = $data['dchtoday'];
			}

		$sql = "SELECT COUNT(*) AS movetoday FROM iptbedmove WHERE movedate = DATE_FORMAT(NOW(),'%Y-%m-%d') ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_movetoday = $data['movetoday'];
			}

 		$sql = "SELECT SUM(bedcount) AS bedcount FROM ward WHERE ward_active = 'Y' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_bedcount = $data['bedcount'];
			}

if ($_POST['submitsend'] == null) {
	$myearb = date("Y")-1;
	$myeare = date("Y");
} else {
	$myearb = $_POST['year']-544;
	$myeare = $_POST['year']-543;
}

$nowdate = date("Y-m-d");
if ($nowdate > $myeare."-09-30") {
    $enddate = $myeare."-09-30";
} else {
    $enddate = date("Y-m-d");
}

		$sql = "SELECT (SUM(i.admdate)*100)/((SELECT SUM(bedcount) FROM ward WHERE ward_active = 'Y')*DATEDIFF('$enddate','$myearb-10-01')+1) AS admsum
			FROM an_stat i
			WHERE i.dchdate BETWEEN '$myearb-10-01' AND '$myeare-09-30' ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$ipt_admsum = $data['admsum'];
			}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

      <div class="row">

		<div class="col-md-4">
          <!-- Widget: user widget style 1 -->
          <div class="box box-widget widget-user-2">
            <!-- Add the bg color to the header using any of the bg-* classes -->
            <div class="widget-user-header bg-red">
              <div class="widget-user-image">
                <img class="img-circle" src="dist/img/ipd_icon.png" alt="">
              </div>
              <!-- /.widget-user-image -->
              <h3 class="widget-user-username">สถิติผู้ป่วยในวันนี้</h3>
              <h5 class="widget-user-desc">จำนวนเตียงทั้งหมด <?php echo number_format($ipt_bedcount,0);?> เตียง</h5>
            </div>
            <div class="box-footer no-padding">
				<div class="row">
					<div class="col-sm-6">
              <ul class="nav nav-stacked">
                <li><a href="?kpi=502">รับใหม่วันนี้ <span class="pull-right badge bg-red"><?php echo number_format($ipt_admittoday,0);?> เตียง</span></a></li>
                <li><a href="?kpi=502">จำหน่ายวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_dchtoday,0);?> เตียง</span></a></li>
                <li><a href="?kpi=502">Admit อยู่ <span class="pull-right badge bg-blue"><?php echo number_format($ipt_wtotal,0);?> เตียง</span></a></li>
                <li><a href="?kpi=502">เตียงว่าง <span class="pull-right badge bg-green"><?php echo number_format($ipt_wblank,0);?> เตียง</span></a></li>
              </ul>
					</div>
					<div class="col-sm-6">
              <ul class="nav nav-stacked">
                <li><a href="?kpi=502">ย้ายเตียงวันนี้ <span class="pull-right badge bg-yellow"><?php echo number_format($ipt_movetoday,0);?> ราย</span></a></li>
                <li><a href="?kpi=502">? <span class="pull-right badge bg-green"> 0 </span></a></li>
                <li><a href="?kpi=502">? <span class="pull-right badge bg-green"> 0 </span></a></li>
                <li><a href="?kpi=502">อัตราการครองเตียง <span class="pull-right badge bg-red"><?php echo number_format($ipt_admsum,2);?> %</span></a></li>
              </ul>
					</div>
				</div>


            </div>
          </div>
        </div>
        <!-- /.col -->

        <!-- col -->
        <div class="col-md-8">
				  <div class="row">

<?php
	try {
		include '_cfg_hos.php';
		$sql = "SELECT w.ward,w.name,w.bedcount,COUNT(*) AS admitnow
    FROM ipt i
    LEFT OUTER JOIN ward w ON w.ward = i.ward
    WHERE dchdate IS NULL
    GROUP BY w.ward
    ORDER BY w.ward ASC ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
      if ($data['admitnow']*100/$data['bedcount'] >= 90) {
        $bg_info_color = "bg-red";
      } else if ($data['admitnow']*100/$data['bedcount'] >= 75) {
        $bg_info_color = "bg-yellow";
      } else if ($data['admitnow']*100/$data['bedcount'] >= 50) {
        $bg_info_color = "bg-aqua";
      } else {
        $bg_info_color = "bg-green";
      }
?>

            <!-- /.ward-box -->
            <div class="col-sm-6">
              <div class="info-box <?php echo $bg_info_color;?>">
                <a data-toggle="tooltip" title="คลิกดูรายละเอียด --> <?php echo $data['name'];?>" style="color:white;" href="?ward=<?php echo $data['ward'];?>">
                <span class="info-box-icon"><i class="fa fa-bed"></i></span>
                <div class="info-box-content">
                  <span class="info-box-text"><?php echo $data['name'];?></span>
                  <span class="info-box-number">Admit <?php echo $data['admitnow'];?> / <?php echo $data['bedcount'];?> เตียง (ว่าง <?php echo $data['bedcount']-$data['admitnow'];?>)</span>
                  <div class="progress">
                    <div class="progress-bar" style="width: <?php echo $data['admitnow']*100/$data['bedcount'] ;?>%"></div>
                  </div>
                  <span class="progress-description">ครองเตียง <?php echo number_format($data['admitnow']*100/$data['bedcount'],2) ;?>% </span></a>
                </div>
              </div>
            </div>
            <!-- ward-box./ -->

<?php
    }
	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>



          </div>

      </div></div>
      <!-- /.row -->