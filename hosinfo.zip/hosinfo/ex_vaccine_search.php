<?php
if ($login_ok == 1) {

if ($_POST['submitsearch'] == "submitcid") {
	$ptcid = " p.cid = '".str_replace("-","",$_POST['cid'])."'";
} else {
	$ptcid = " p.cid = '***' ";
}

?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        SEARCH :
        <small><?php echo $export_name;?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo $wwwurl;?>/"><i class="fa fa-home"></i> Home</a></li>
        <li class="active">Search Vaccine</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">ค้นหาข้อมูลการได้รับวัคซีน </h3><!-- LOSARTAN (icode 1520549) -->
            </div>
            <!-- /.box-header -->
            <div class="box-body">

			<div class="row">
				<div class="col-sm-3">
					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #FF6600;">
							<i class="fa fa-search"></i><h3 class="box-title">ค้นหา</h3>
						</div>
						<div class="box-footer text-black">
						<div>ค้นหาด้วยเลขประจำตัวประชาชน
						</div>
<form method="post" name="search_form" action="<?php echo $PHP_SELF ?>">

						  <div class="form-group">
							  <div class="input-group">
								<div class="input-group-addon">
										<i class="fa fa-credit-card"></i>
								</div>
								<input type="text" name="cid" class="form-control" data-inputmask='"mask": "9-9999-99999-99-9"' data-mask>
									<span class="input-group-btn">
									  <button type="submit" name="submitsearch" value="submitcid" class="btn btn-info btn-flat"> ค้นหาด้วย CID </button>
									</span>
							  </div>
						  </div>

</form>
						</div>
					</div>
	
	<?php

	try {
		include '_cfg_hos.php';
		$sql = "SELECT p.hn,p.pname,p.fname,p.lname,p.birthday,p.fathername,p.mathername,p.addrpart,p.road,p.moopart,t.full_name,p.last_visit
			FROM patient p LEFT OUTER JOIN thaiaddress t ON t.addressid = CONCAT(p.chwpart,p.amppart,p.tmbpart) WHERE $ptcid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
			$info_hn = $data[hn];
			$info_last_visit = $data[last_visit];
			$info_name = $data[pname]."".$data[fname]."  ".$data[lname];
			$info_birthday = $data[birthday];
			$info_fathername = $data[fathername];
			$info_mathername = $data[mathername];
			$info_address = $data[addrpart]." ".$data[road]." ม.".$data[moopart]." ".$data[full_name];
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

					<div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #0080c0;">
							<i class="fa fa-user"></i><h3 class="box-title">ข้อมูลคนไข้</h3>
						</div>
						<div class="box-footer text-black">

              <table class="table table-hover">
                <tr>
                  <th class='text-right'>ชื่อ - สกุล :</th>
                  <th><?php echo $info_name; ?></th>
                </tr>
                <tr>
                  <td class='text-right'>HN :</td>
                  <td><?php echo $info_hn; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>วันเกิด :</td>
                  <td><?php echo DateThaiFull($info_birthday); ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ชื่อบิดา :</td>
                  <td><?php echo $info_fathername; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ชื่อมารดา :</td>
                  <td><?php echo $info_mathername; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>ที่อยู่ :</td>
                  <td><?php echo $info_address; ?></td>
                </tr>
                <tr>
                  <td class='text-right'>รับบริการครั้งล่าสุด :</td>
                  <td><?php echo DateThaiFull($info_last_visit); ?></td>
                </tr>
              </table>
						
						</div>
					</div>
				</div>

				<div class="col-sm-9">
				    <div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-eyedropper"></i><h3 class="box-title">ข้อมูลวัคซีนอายุ 0-1 ปี</h3>
						</div>
						<div class="box-footer text-black">
                        <table class="table table-bordered table-striped">
                <thead>
                <tr>
                <th class='text-center'>วันที่รับบริการ</th>
                  <th class='text-center'>สถานที่รับบริการ</th>
                  <th class='text-center'>รายการวัคซีน</th>
                  <th class='text-center'>Note</th>
                  <th class='text-center'>ผู้ให้บริการ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
		include "_cfg_hosmain.php";
		$sql = "SELECT p.pname,p.fname,p.lname,GROUP_CONCAT(DISTINCT pw.vaccine_bcg_date) AS vaccine_bcg_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtp1_date) AS vaccine_dtp1_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtp2_date) AS vaccine_dtp2_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtp3_date) AS vaccine_dtp3_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_opv1_date) AS vaccine_opv1_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_opv2_date) AS vaccine_opv2_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_opv3_date) AS vaccine_opv3_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_hbv1_date) AS vaccine_hbv1_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_hbv2_date) AS vaccine_hbv2_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_hbv3_date) AS vaccine_hbv3_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_ipv_date) AS vaccine_ipv_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_measles_date) AS vaccine_measles_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_mmr_date) AS vaccine_mmr_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtphb1_date) AS vaccine_dtphb1_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtphb2_date) AS vaccine_dtphb2_date
        ,GROUP_CONCAT(DISTINCT pw.vaccine_dtphb3_date) AS vaccine_dtphb3_date
        FROM person p
        LEFT OUTER JOIN person_wbc pw ON pw.person_id = p.person_id
        WHERE $ptcid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {
            $vaccine_bcg_date = $data['vaccine_bcg_date'];
            $vaccine_dtp1_date = $data['vaccine_dtp1_date'];
            $vaccine_dtp2_date = $data['vaccine_dtp2_date'];
            $vaccine_dtp3_date = $data['vaccine_dtp3_date'];
            $vaccine_opv1_date = $data['vaccine_opv1_date'];
            $vaccine_opv2_date = $data['vaccine_opv2_date'];
            $vaccine_opv3_date = $data['vaccine_opv3_date'];
            $vaccine_hbv1_date = $data['vaccine_hbv1_date'];
            $vaccine_hbv2_date = $data['vaccine_hbv2_date'];
            $vaccine_hbv3_date = $data['vaccine_hbv3_date'];
            $vaccine_ipv_date = $data['vaccine_ipv_date'];
            $vaccine_measles_date = $data['vaccine_measles_date'];
            $vaccine_mmr_date = $data['vaccine_mmr_date'];
            $vaccine_dtphb1_date = $data['vaccine_dtphb1_date'];
            $vaccine_dtphb2_date = $data['vaccine_dtphb2_date'];
            $vaccine_dtphb3_date = $data['vaccine_dtphb3_date'];
            
        }
        if ($vaccine_bcg_date || "") {
            echo "<tr>";
            echo "<td>".$vaccine_bcg_date."</td>";
            echo "<td>รับบริการที่นี่</span></td>";
            echo "<td>วัคซีน BCG</td>";
            echo "<td></td>";
            echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtp1_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtp1_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>DTP เข็มที่ 1</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtp2_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtp2_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>DTP เข็มที่ 2</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtp3_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtp3_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>DTP เข็มที่ 3</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_opv1_date || "") {
            echo "<tr>";
			echo "<td>".$vaccine_opv1_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีน OPV ครั้งที่ 1</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_opv2_date || "") {
            echo "<tr>";
			echo "<td>".$vaccine_opv2_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีน OPV ครั้งที่ 2</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_opv3_date || "") {
            echo "<tr>";
			echo "<td>".$vaccine_opv3_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีน OPV ครั้งที่ 3</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_hbv1_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_hbv1_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>ไวรัสตับอักเสบ บี เข็มที่ 1</td>";
			echo "<td></td>";
			echo "<td></td>";
			echo "</tr>";
        }
        if ($vaccine_hbv2_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_hbv2_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>ไวรัสตับอักเสบ บี เข็มที่ 2</td>";
			echo "<td></td>";
			echo "<td></td>";
			echo "</tr>";
        }
        if ($vaccine_hbv3_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_hbv3_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>ไวรัสตับอักเสบ บี เข็มที่ 3</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_ipv_date || "") {
			echo "<tr>";
			echo "<td>".$vaccineipv_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีน IPV</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_measles_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_measles_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีนหัด Measle</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_mmr_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_mmr_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีนหัด MMR</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtphb1_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtphb1_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีนรวม DTPHB1</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtphb2_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtphb2_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีนรวม DTPHB2</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }
        if ($vaccine_dtphb3_date || "") {
			echo "<tr>";
			echo "<td>".$vaccine_dtphb3_date."</td>";
			echo "<td>รับบริการที่นี่</span></td>";
			echo "<td>วัคซีนรวม DTPHB3</td>";
			echo "<td></td>";
			echo "<td></td>";
            echo "</tr>";
        }

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
              </table>
						</div>
					</div>


                    <div class="box box-solid bg-blue-gradient" >
						<div class="box-header ui-sortable-handle" style="background-color: #c0c0c0;">
							<i class="fa fa-eyedropper"></i><h3 class="box-title">ข้อมูลวัคซีนอื่นๆ</h3>
						</div>
						<div class="box-footer text-black">
              <table id="DataTable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th class='text-center'>วันที่รับบริการ</th>
                  <th class='text-center'>สถานที่รับบริการ</th>
                  <th class='text-center'>รายการวัคซีน</th>
                  <th class='text-center'>Note</th>
                  <th class='text-center'>ผู้ให้บริการ</th>
                </tr>
                </thead>
                <tbody>

<?php

	try {
        include "_cfg_hosmain.php";
        // วัคซีน
		$sql = "SELECT pl.vaccine_date,pv.vaccine_name,pv.vaccine_code,pl.vaccine_note,'รับบริการที่นี่' AS hospcode,'' AS staff
        FROM person p
        LEFT OUTER JOIN person_vaccine_list pl ON pl.person_id = p.person_id
        LEFT OUTER JOIN person_vaccine pv ON pv.person_vaccine_id = pl.person_vaccine_id
        WHERE $ptcid 
        UNION ALL
        SELECT pe.vaccine_date,pv.vaccine_name,pv.vaccine_code,CONCAT(pe.vaccine_note,' ',pe.vaccine_lotno,' ',pe.vaccine_expire_date) AS vaccine_note,h.name AS hospcode,'' AS staff
        FROM person p
        LEFT OUTER JOIN person_vaccine_elsewhere pe ON pe.person_id = p.person_id
        LEFT OUTER JOIN person_vaccine pv ON pv.person_vaccine_id = pe.person_vaccine_id
        LEFT OUTER JOIN hospcode h ON h.hospcode = pe.hospcode
        WHERE $ptcid 
        UNION ALL
        SELECT o.vstdate AS vaccine_date,pv.vaccine_name,pv.vaccine_code,CONCAT(ov.vaccine_note,' ',ov.vaccine_lot_no,' ',ov.expire_date) AS vaccine_note,'รับบริการที่นี่' AS hospcode,d.name AS staff
        FROM ovst_vaccine ov
        LEFT OUTER JOIN ovst o ON o.vn = ov.vn
        LEFT OUTER JOIN person_vaccine pv ON pv.person_vaccine_id = ov.person_vaccine_id
        LEFT OUTER JOIN patient p ON p.hn = o.hn
        LEFT OUTER JOIN doctor d ON d.code = ov.staff
        WHERE $ptcid ";
		$query = $myPDO->query($sql);
		foreach($query as $data) {

			echo "<tr>";
			echo "<td>".$data['vaccine_date']."</td>";
			echo "<td>".$data['hospcode']."</td>";
			echo "<td>".$data['vaccine_name']." (".$data['vaccine_code'].")</td>";
			echo "<td>".$data['vaccine_note']."</td>";
			echo "<td></td>";
			echo "</tr>";
		}

	}
	catch (PDOException $e) {echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
				</tbody>
              </table>
						</div>
					</div>
				</div>
			</div>


            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

<?php } else {include 'error505.php';} ?>
