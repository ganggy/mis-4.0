$(document).ready(function() {

	$('.edit-misuser').click(function() {
		// get data from edit
		var login_secure = $(this).attr('data-login_secure');
		var user_status = $(this).attr('data-user_status');
		var user_head = $(this).attr('data-user_head');
		var user_approve = $(this).attr('data-user_approve');
		var m_namefull = $(this).attr('data-m_namefull');
		var m_email = $(this).attr('data-m_email');
		var m_phoneno = $(this).attr('data-m_phoneno');
		var dpid = $(this).attr('data-dpid');
		console.log(dpid);

		// set value to modal
		$('#login_secure').val(login_secure);
		$('#user_status').val(user_status);
		$('#user_head').val(user_head);
		$('#user_approve').val(user_approve);
		$('#m_namefull').val(m_namefull);
		$('#m_email').val(m_email);
		$('#m_phoneno').val(m_phoneno);
		$('#dpid').val(dpid);

		// open modal
		$('#Modal-edit-misuser').modal('show');
	});

	$('.delete-misuser').click(function() {
		// get data from edit
		var dlogin_secure = $(this).attr('datad-login_secure');
		var duser_status = $(this).attr('datad-user_status');
		var duser_head = $(this).attr('datad-user_head');
		var duser_approve = $(this).attr('datad-user_approve');
		var dm_namefull = $(this).attr('datad-m_namefull');
		var dm_email = $(this).attr('datad-m_email');
		var dm_phoneno = $(this).attr('datad-m_phoneno');
		var ddpid = $(this).attr('datad-dpid');

		// set value to modal
		$('#dlogin_secure').val(dlogin_secure);
		$('#duser_status').val(duser_status);
		$('#duser_head').val(duser_head);
		$('#duser_approve').val(duser_approve);
		$('#dm_namefull').val(dm_namefull);
		$('#dm_email').val(dm_email);
		$('#dm_phoneno').val(dm_phoneno);
		$('#ddpid').val(ddpid);

		// open modal
		$('#Modal-delete-misuser').modal('show');
	});

});