<?php
	try {
		include '_cfg_hos.php';

          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab1' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab1_name = $row['sys_show_name'];
            $tab1_value = $row['sys_value'];
            $tab1_status = $row['sys_status'];
            $tab1_include = $row['sys_include'];
          }
          
          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab2' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab2_name = $row['sys_show_name'];
            $tab2_value = $row['sys_value'];
            $tab2_status = $row['sys_status'];
            $tab2_include = $row['sys_include'];
          }
          
          $sql = "SELECT * FROM sys_setting WHERE sys_name = 'cd_disease_tab3' ";
          $query = $myPDO->query($sql);
          foreach($query as $row) {
            $tab3_name = $row['sys_show_name'];
            $tab3_value = $row['sys_value'];
            $tab3_status = $row['sys_status'];
            $tab3_include = $row['sys_include'];
          }

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
?>

<div class="row">
        <div class="col-md-12">
          <div class="box box-danger">
            <div class="box-header with-border">
            <i class="fa fa-yelp"></i><h3 class="box-title">โรคติดต่อที่สำคัญ</h3>

              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
				        <div class="btn-group">
                  <button type="button" class="btn btn-box-tool dropdown-toggle" data-toggle="dropdown">
                    <i class="fa fa-wrench"></i></button>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="?kpi=508">ข้อมูลโรคติดต่อ</a></li>
                  </ul>
                </div>
                <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <div class="row">
                <div class="col-md-8">

<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

          <!-- Custom tabs (Charts with tabs)-->
          <div class="nav-tabs-custom">
            <!-- Tabs within a box -->
            <ul class="nav nav-tabs pull-right">
              <li class="active"><a href="#container-tab1" data-toggle="tab"><?php echo $tab1_name ;?></a></li>
              <?php if($tab2_status == 'Y'){;?><li><a href="#container-tab2" data-toggle="tab"><?php echo $tab2_name ;?></a></li><?php } ?>
              <?php if($tab3_status == 'Y'){;?><li><a href="#container-tab3" data-toggle="tab"><?php echo $tab3_name ;?></a></li><?php } ?>
              <li class="pull-left header"><i class="fa fa-line-chart"></i> สถานการณ์โรคที่ต้องเฝ้าระวัง</li>
            </ul>
            <div class="tab-content no-padding">
              <!-- Morris chart - Sales -->
              <div class="chart tab-pane active" id="container-tab1" style="position: relative; height: 400px;"></div>
              <?php if($tab2_status == 'Y'){;?><div class="chart tab-pane" id="container-tab2" style="position: relative; height: 400px;"></div><?php } ?>
              <?php if($tab3_status == 'Y'){;?><div class="chart tab-pane" id="container-tab3" style="position: relative; height: 400px;"></div><?php } ?>
            </div>
          </div>
          <!-- /.nav-tabs-custom -->


                </div>
                <!-- /.col -->
                <div class="col-md-4">
                  <p class="text-center">
                    <strong>อันดับโรคติดต่อที่ต้องรายงานเดือนนี้</strong>
                  </p>

                <table class="table table-hover table no-margin">
                  <thead>
                  <tr>
                    <th>รหัส506</th>
                    <th>ชื่อโรค</th>
                    <th>จำนวน(ราย)</th>
                  </tr>
                  </thead>
                  <tbody>

<?php
	try {
		include '_cfg_hos.php';

		$sql = "SELECT n.code506,p.name AS namee,n.name AS namet,COUNT(*) AS count506
		FROM surveil_member s 
		LEFT OUTER JOIN provis_code506 p ON p.code = s.code506
		LEFT OUTER JOIN name506 n ON n.code = s.code506
		WHERE DATE_FORMAT(s.vstdate,'%Y-%m') = DATE_FORMAT(NOW(),'%Y-%m') 
		GROUP BY s.code506 
		ORDER BY COUNT(*) DESC
		LIMIT 10";
		$query = $myPDO->query($sql);
		foreach($query as $row) {

            echo "      <tr>";
            echo "        <td class='text-center'>".$row[code506]."</td>";
            echo "        <td>".$row[namet]." ".$row[namee]."</td>";
            echo "        <td class='text-right'><span class='label label-danger'> ".$row[count506]." </span></td>";
            echo "      </tr>";

		}
		$sql2 = "SELECT t.vstyear,SUM(t.count506) AS count506,SUM(t.dhf) AS dhf,SUM(t.fu) AS fu,SUM(t.food) AS food,SUM(t.diarrhea) AS diarrhea
    ,SUM(t.count5062) AS count5062,SUM(t.dhf2) AS dhf2,SUM(t.fu2) AS fu2,SUM(t.food2) AS food2,SUM(t.diarrhea2) AS diarrhea2 FROM (
    SELECT DATE_FORMAT(vstdate,'%Y') AS vstyear
        ,COUNT(*) AS count506
        ,SUM(IF(code506 = '66',1,0)) AS dhf
        ,SUM(IF(code506 = '15',1,0)) AS fu
        ,SUM(IF(code506 = '3',1,0)) AS food
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea
        ,'' AS count5062,'' AS dhf2,'' AS fu2,'' AS food2,'' AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN DATE_FORMAT(NOW(),'%Y-01-01') AND DATE_FORMAT(NOW(),'%Y-%m-%d')
    UNION
    SELECT DATE_FORMAT(vstdate,'%Y')+1 AS vstyear
        ,'' AS count506,'' AS dhf,'' AS fu,'' AS food,'' AS diarrhea
        ,COUNT(*) AS count5062
        ,SUM(IF(code506 = '66',1,0)) AS dhf2
        ,SUM(IF(code506 = '15',1,0)) AS fu2
        ,SUM(IF(code506 = '3',1,0)) AS food2
        ,SUM(IF(code506 = '2',1,0)) AS diarrhea2
        FROM surveil_member
        WHERE vstdate BETWEEN CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-01-01')) AND CONCAT(DATE_FORMAT(NOW(),'%Y')-1,DATE_FORMAT(NOW(),'-%m-%d'))
    ) AS t
    GROUP BY vstyear ";
		$query2 = $myPDO->query($sql2);
		foreach($query2 as $row2) {
			$cd_year = $row2[vstyear];
			$cd_count506 = $row2[count506];
			$cd_dhf = $row2[dhf];
			$cd_fu = $row2[fu];
			$cd_food = $row2[food];
            $cd_diarrhea = $row2[diarrhea];
            $cd_count5062 = $row2[count5062];
			$cd_dhf2 = $row2[dhf2];
			$cd_fu2 = $row2[fu2];
			$cd_food2 = $row2[food2];
			$cd_diarrhea2 = $row2[diarrhea2];
		}

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>
                  </tbody>
                </table>

                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
            </div>
            <!-- ./box-body -->
            <div class="box-footer">
              <div class="row">
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_dhf >= $cd_dhf2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_dhf >= $cd_dhf2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_dhf >= $cd_dhf2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_dhf*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_dhf;?></h5>
                    <span class="description-text">Dengue Fever</span> (<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_fu >= $cd_fu2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_fu >= $cd_fu2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_fu >= $cd_fu2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_fu*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_fu;?></h5>
                    <span class="description-text">Influenza,(FU)</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block border-right">
                  <a data-toggle="tooltip" title="<?php if($cd_food >= $cd_food2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_food >= $cd_food2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_food >= $cd_food2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_food*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_food;?></h5>
                    <span class="description-text">Food Poisoning</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
                <!-- /.col -->
                <div class="col-sm-3 col-xs-6">
                  <div class="description-block">
                  <a data-toggle="tooltip" title="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "มากกว่าปีที่แล้ว";}else{echo "น้อยกว่าปีที่แล้ว";}?>" style="color:white;">
                    <span class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "description-percentage text-red";}else{echo "description-percentage text-green";}?>"><i class="<?php if($cd_diarrhea >= $cd_diarrhea2){echo "fa fa-caret-up";}else{echo "fa fa-caret-down";}?>"></i> <?php echo number_format($cd_diarrhea*100/$cd_count506,2);?>%</span>
                  </a>
                    <h5 class="description-header"><?php echo $cd_diarrhea;?></h5>
                    <span class="description-text">Diarrhea</span>(<?php echo $cd_year;?>)
                  </div>
                  <!-- /.description-block -->
                </div>
              </div>
              <!-- /.row -->
            </div>
            <!-- /.box-footer -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->


<?php

 $monthx = array(); // ตัวแปรแกน x
 $median = array(); //ตัวแปรแกน y
 $y2557 = array(); //ตัวแปรแกน y
 $y2558 = array(); //ตัวแปรแกน y
 $y2559 = array(); //ตัวแปรแกน y
 $y2560 = array(); //ตัวแปรแกน y
 $y2561 = array(); //ตัวแปรแกน y
 $y2562 = array(); //ตัวแปรแกน y
 try {
     include '_cfg_mis40db.php';
     
     $sql = "SELECT '01 มกราคม' AS monthname
,SUM(IF(year = 'median',m01,0)) AS median
,SUM(IF(year = '2556',m01,0)) AS y2556
,SUM(IF(year = '2557',m01,0)) AS y2557
,SUM(IF(year = '2558',m01,0)) AS y2558
,SUM(IF(year = '2559',m01,0)) AS y2559
,SUM(IF(year = '2560',m01,0)) AS y2560
,SUM(IF(year = '2561',m01,0)) AS y2561
,SUM(IF(year = '2562',m01,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '02 กุมภาพันธ์' AS monthname
,SUM(IF(year = 'median',m02,0)) AS median
,SUM(IF(year = '2556',m02,0)) AS y2556
,SUM(IF(year = '2557',m02,0)) AS y2557
,SUM(IF(year = '2558',m02,0)) AS y2558
,SUM(IF(year = '2559',m02,0)) AS y2559
,SUM(IF(year = '2560',m02,0)) AS y2560
,SUM(IF(year = '2561',m02,0)) AS y2561
,SUM(IF(year = '2562',m02,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '03 มีนาคม' AS monthname
,SUM(IF(year = 'median',m03,0)) AS median
,SUM(IF(year = '2556',m03,0)) AS y2556
,SUM(IF(year = '2557',m03,0)) AS y2557
,SUM(IF(year = '2558',m03,0)) AS y2558
,SUM(IF(year = '2559',m03,0)) AS y2559
,SUM(IF(year = '2560',m03,0)) AS y2560
,SUM(IF(year = '2561',m03,0)) AS y2561
,SUM(IF(year = '2562',m03,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '04 เมษายน' AS monthname
,SUM(IF(year = 'median',m04,0)) AS median
,SUM(IF(year = '2556',m04,0)) AS y2556
,SUM(IF(year = '2557',m04,0)) AS y2557
,SUM(IF(year = '2558',m04,0)) AS y2558
,SUM(IF(year = '2559',m04,0)) AS y2559
,SUM(IF(year = '2560',m04,0)) AS y2560
,SUM(IF(year = '2561',m04,0)) AS y2561
,SUM(IF(year = '2562',m04,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '05 พฤษภาคม' AS monthname
,SUM(IF(year = 'median',m05,0)) AS median
,SUM(IF(year = '2556',m05,0)) AS y2556
,SUM(IF(year = '2557',m05,0)) AS y2557
,SUM(IF(year = '2558',m05,0)) AS y2558
,SUM(IF(year = '2559',m05,0)) AS y2559
,SUM(IF(year = '2560',m05,0)) AS y2560
,SUM(IF(year = '2561',m05,0)) AS y2561
,SUM(IF(year = '2562',m05,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '06 มิถุนายน' AS monthname
,SUM(IF(year = 'median',m06,0)) AS median
,SUM(IF(year = '2556',m06,0)) AS y2556
,SUM(IF(year = '2557',m06,0)) AS y2557
,SUM(IF(year = '2558',m06,0)) AS y2558
,SUM(IF(year = '2559',m06,0)) AS y2559
,SUM(IF(year = '2560',m06,0)) AS y2560
,SUM(IF(year = '2561',m06,0)) AS y2561
,SUM(IF(year = '2562',m06,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '07 กรกฎาคม' AS monthname
,SUM(IF(year = 'median',m07,0)) AS median
,SUM(IF(year = '2556',m07,0)) AS y2556
,SUM(IF(year = '2557',m07,0)) AS y2557
,SUM(IF(year = '2558',m07,0)) AS y2558
,SUM(IF(year = '2559',m07,0)) AS y2559
,SUM(IF(year = '2560',m07,0)) AS y2560
,SUM(IF(year = '2561',m07,0)) AS y2561
,SUM(IF(year = '2562',m07,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '08 สิงหาคม' AS monthname
,SUM(IF(year = 'median',m08,0)) AS median
,SUM(IF(year = '2556',m08,0)) AS y2556
,SUM(IF(year = '2557',m08,0)) AS y2557
,SUM(IF(year = '2558',m08,0)) AS y2558
,SUM(IF(year = '2559',m08,0)) AS y2559
,SUM(IF(year = '2560',m08,0)) AS y2560
,SUM(IF(year = '2561',m08,0)) AS y2561
,SUM(IF(year = '2562',m08,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '09 กันยายน' AS monthname
,SUM(IF(year = 'median',m09,0)) AS median
,SUM(IF(year = '2556',m09,0)) AS y2556
,SUM(IF(year = '2557',m09,0)) AS y2557
,SUM(IF(year = '2558',m09,0)) AS y2558
,SUM(IF(year = '2559',m09,0)) AS y2559
,SUM(IF(year = '2560',m09,0)) AS y2560
,SUM(IF(year = '2561',m09,0)) AS y2561
,SUM(IF(year = '2562',m09,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '10 ตุลาคม' AS monthname
,SUM(IF(year = 'median',m10,0)) AS median
,SUM(IF(year = '2556',m10,0)) AS y2556
,SUM(IF(year = '2557',m10,0)) AS y2557
,SUM(IF(year = '2558',m10,0)) AS y2558
,SUM(IF(year = '2559',m10,0)) AS y2559
,SUM(IF(year = '2560',m10,0)) AS y2560
,SUM(IF(year = '2561',m10,0)) AS y2561
,SUM(IF(year = '2562',m10,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '11 พฤศจิกายน' AS monthname
,SUM(IF(year = 'median',m11,0)) AS median
,SUM(IF(year = '2556',m11,0)) AS y2556
,SUM(IF(year = '2557',m11,0)) AS y2557
,SUM(IF(year = '2558',m11,0)) AS y2558
,SUM(IF(year = '2559',m11,0)) AS y2559
,SUM(IF(year = '2560',m11,0)) AS y2560
,SUM(IF(year = '2561',m11,0)) AS y2561
,SUM(IF(year = '2562',m11,0)) AS y2562
FROM rep_506_dhf
UNION
SELECT '12 ธันวาคม' AS monthname
,SUM(IF(year = 'median',m12,0)) AS median
,SUM(IF(year = '2556',m12,0)) AS y2556
,SUM(IF(year = '2557',m12,0)) AS y2557
,SUM(IF(year = '2558',m12,0)) AS y2558
,SUM(IF(year = '2559',m12,0)) AS y2559
,SUM(IF(year = '2560',m12,0)) AS y2560
,SUM(IF(year = '2561',m12,0)) AS y2561
,SUM(IF(year = '2562',m12,0)) AS y2562
FROM rep_506_dhf ";
		$query = $myPDO->query($sql);
		foreach($query as $row) {
            array_push($median,$row[median]);
            array_push($y2557,$row[y2557]);
            array_push($y2558,$row[y2558]);
            array_push($y2559,$row[y2559]);
            array_push($y2560,$row[y2560]);
            array_push($y2561,$row[y2561]);
            array_push($y2562,$row[y2562]);
            array_push($monthx,$row[month]);
		}
        
	} catch (PDOException $e) {
        echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}
    
?>

<script type="text/javascript">
Highcharts.chart('container-tab1', {
    chart: {
        type: 'spline'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: 'โรคไข้เลือดออก อำเภอตะพานหิน จังหวัดพิจิตร'
    },
    xAxis: {
        categories: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน','กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
    },
    yAxis: {
        title: {
            text: 'จำนวนผู้ป่วย (ราย)'
        }
    },
	tooltip: {
		crosshairs: true,
		shared: true
	},
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            marker: {
				radius: 4,
				lineColor: '#666666',
				lineWidth: 1
			},
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Medien',
        color: '#ff9900',
        type: 'areaspline',
        marker: {
			symbol: 'square'
        },
        data: [<?= implode(',', $median) ?>]
    }, {
        name: 'ปี 2557',
        data: [<?= implode(',', $y2557) ?>]
    }, {
        name: 'ปี 2558',
        data: [<?= implode(',', $y2558) ?>]
    }, {
        name: 'ปี 2559',
        data: [<?= implode(',', $y2559) ?>]
    }, {
        name: 'ปี 2560',
        data: [<?= implode(',', $y2560) ?>]
    }, {
        name: 'ปี 2561',
        data: [<?= implode(',', $y2561) ?>]
    }, {
        name: 'ปี 2562',
        data: [<?= implode(',', $y2562) ?>]
    }]
});
</script>

<?php
    $tab3a00 = array();
    $tab3j00 = array();
	try {
		include '_cfg_hos.php';

		$sql = "SELECT CONCAT('[`',vstdate,'`,',COUNT(*),']') AS disease_arr
        FROM ovstdiag 
        WHERE vstdate BETWEEN SUBDATE(CURDATE(),INTERVAL 365 DAY) AND DATE_FORMAT(NOW(),'%Y-%m-%d') 
        AND (icd10 BETWEEN 'A040' AND 'A049' OR icd10 BETWEEN 'A090' AND 'A090' OR icd10 BETWEEN 'A099' AND 'A099' OR icd10 BETWEEN 'A080' 
        AND 'A085' OR icd10 BETWEEN 'A020' AND 'A020')
        GROUP BY vstdate ORDER BY vstdate ASC ";
        $query = $myPDO->query($sql);
        foreach($query as $row) {
            array_push($tab3a00,$row['disease_arr']);
        }

		$sql = "SELECT COUNT(*) AS disease_arr
        FROM ovstdiag 
        WHERE vstdate BETWEEN '2019-01-01' AND '2019-12-31'
        AND (icd10 BETWEEN 'J100' AND 'J101' OR icd10 BETWEEN 'J108' AND 'J108' OR icd10 BETWEEN 'J110' AND 'J111' OR icd10 BETWEEN 'J118' AND 'J118')
        GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY vstdate ASC ";
        $query = $myPDO->query($sql);
        foreach($query as $row) {
            array_push($tab3j00,$row['disease_arr']);
        }

      $sql = "SELECT COUNT(*) AS disease_arr
        FROM ovstdiag 
        WHERE vstdate BETWEEN '2019-01-01' AND '2019-12-31'
        AND (icd10 BETWEEN 'J100' AND 'J101' OR icd10 BETWEEN 'J108' AND 'J108' OR icd10 BETWEEN 'J110' AND 'J111' OR icd10 BETWEEN 'J118' AND 'J118')
        GROUP BY DATE_FORMAT(vstdate,'%Y-%m') ORDER BY vstdate ASC ";
        $query = $myPDO->query($sql);
        foreach($query as $row) {
            array_push($tab3j00,$row['disease_arr']);
        }

	} catch (PDOException $e) {
		echo "ไม่สามารถเชื่อมต่อฐานข้อมูลได้ : ".$e->getMessage();
	}

?>

<script type="text/javascript">

        Highcharts.chart('container-tab2', {
            chart: {
                zoomType: 'x'
            },
            title: {
                text: ''
            },
            subtitle: {
                text: document.ontouchstart === undefined ?
                        'คลิกเลือกเพื่อขยาย' : 'Pinch the chart to zoom in'
            },
            xAxis: {
                type: 'date'
            },
            yAxis: {
                title: {
                    text: 'จำนวนผู้ป่วย(คน)'
                }
            },
            legend: {
                enabled: false
            },
            plotOptions: {
                area: {
                    fillColor: {
                        linearGradient: {
                            x1: 0,
                            y1: 0,
                            x2: 0,
                            y2: 1
                        },
                        stops: [
                            [0, Highcharts.getOptions().colors[0]],
                            [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
                        ]
                    },
                    marker: {
                        radius: 2
                    },
                    lineWidth: 1,
                    states: {
                        hover: {
                            lineWidth: 1
                        }
                    },
                    threshold: null
                }
            },

            series: [{
                type: 'area',
                name: 'จำนวนผู้ป่วย(คน)',
                data: [<?= implode(',', $tab3a00)?>]
            }]
        });

</script>

<script type="text/javascript">
Highcharts.chart('container-tab3', {
    chart: {
        type: 'spline'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: '(ผลวินิจฉัยจาก รพร.ตะพานหิน)'
    },
    xAxis: {
        categories: ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน','กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม']
    },
    yAxis: {
        title: {
            text: 'จำนวนผู้ป่วย(ราย)'
        }
    },
	tooltip: {
		crosshairs: true,
		shared: true
	},
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            marker: {
				radius: 4,
				lineColor: '#666666',
				lineWidth: 1
			},
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'ไข้ไวัดนก',
        data: [<?= implode(',', $y2559) ?>]
    }, {
        name: 'ไข้หวัดใหญ่',
        data: [<?= implode(',', $tab3j00) ?>]
    }, {
        name: 'ไข้ปวดข้อยุงลาย',
        data: [<?= implode(',', $y2561) ?>]
    }, {
        name: 'ไข้มาลาเรีย',
        data: [<?= implode(',', $y2562) ?>]
    }]
});
</script>
